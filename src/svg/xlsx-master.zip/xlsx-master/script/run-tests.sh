#!/bin/bash
cd ../build/Clang-Debug-x64/test/
FILES=*

for f in $FILES
do
./$f
done

cd ../../../script/