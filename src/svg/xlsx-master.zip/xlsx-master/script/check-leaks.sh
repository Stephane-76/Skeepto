#!/bin/bash
FILES=../build/Clang-Debug-x64/test/*

for f in $FILES
do
valgrind --leak-check=full --track-origins=yes ./$f
done
