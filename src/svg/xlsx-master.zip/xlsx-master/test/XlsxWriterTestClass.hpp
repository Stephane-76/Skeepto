/*!
 * \file        XlsxWriterTestClass.hpp
 * \author      Invoke - Jean-Christophe PHILIPPE (jcphilippe\@invoke.fr)
 * \date        Octobre 2014
 * \copyright   SA Invoke
 */

#ifndef XlsxWriterTestClass_hpp
#define XlsxWriterTestClass_hpp

#include <cppunit/extensions/HelperMacros.h>

#include "xlsx/WorkbookReadInterface.hpp"
#include "zip/zip.hpp"

#include <iostream>

class XlsxWriterTestClass : public CPPUNIT_NS::TestFixture {
    CPPUNIT_TEST_SUITE(XlsxWriterTestClass);

    CPPUNIT_TEST(testTest);
    CPPUNIT_TEST(testNull);
    CPPUNIT_TEST(testEmpty);
    CPPUNIT_TEST(testSheets);
    CPPUNIT_TEST(testValues);
    CPPUNIT_TEST(testFormats);
    CPPUNIT_TEST(testColumnsAndRows);
    CPPUNIT_TEST(testOutlines);
    CPPUNIT_TEST(testPageSetting);
    CPPUNIT_TEST(testDefinedNames);
    CPPUNIT_TEST(testCharacters);
    CPPUNIT_TEST(testConditionalFormatting);
    CPPUNIT_TEST(testValidations);
    CPPUNIT_TEST(testImages);
    CPPUNIT_TEST(testHyperlinks);
    CPPUNIT_TEST(testSelections);
    CPPUNIT_TEST(testComments);
    CPPUNIT_TEST(testRedmine70163);
    CPPUNIT_TEST(testFilters);
	CPPUNIT_TEST(testRichText);

    CPPUNIT_TEST_SUITE_END();

private:
    bool areStreamEqual(std::istream&, std::istream&) const;
    bool areZipEqual(std::istream&, std::istream&) const;
    bool isWorkbookValid(const Invoke::XLSX::Interface::Read::Workbook*, const std::string&) const;
    void saveWorkbook(const Invoke::XLSX::Interface::Read::Workbook*, const std::string&, bool =false) const;
    void saveWorkbook(const Invoke::XLSX::Interface::Read::Workbook*, std::ostream&, bool =false) const;
    void saveWorkbook(const Invoke::XLSX::Interface::Read::Workbook*, Invoke::Zip::byte_t*&, unsigned int&, bool =false) const;

private:
    void testNull();
    void testTest();
    void testEmpty();
    void testSheets();
    void testValues();
    void testFormats();
    void testColumnsAndRows();
    void testOutlines();
    void testPageSetting();
    void testDefinedNames();
    void testCharacters();
    void testConditionalFormatting();
    void testValidations();
    void testImages();
    void testHyperlinks();
    void testSelections();
    void testComments();
    void testRedmine70163();
    void testFilters();
	void testRichText();
};

#endif  /* XlsxWriterTestClass_hpp */

