/*!
 * \file        XlsxReaderTestClass.cpp
 * \author      Invoke - Jean-Christophe PHILIPPE (jcphilippe\@invoke.fr)
 * \date        Juillet 2015
 * \copyright   SA Invoke
 */

#include "XlsxReaderTestClass.hpp"

#include "xlsx/XlsxReader.hpp"
#include "xlsx/SimpleWorkbook.hpp"

#include <chrono>

#define XLSX_PATH "../../../test/resource/"

CPPUNIT_TEST_SUITE_REGISTRATION(XlsxReaderTestClass);

void XlsxReaderTestClass::loadXlsxFile(const std::string& p_filename, Invoke::XLSX::Interface::Write::Workbook* o_workbook) const
{
    using namespace std::chrono;
    using namespace Invoke::XLSX;

    std::ifstream w_file(p_filename, std::fstream::binary | std::fstream::in);

    const high_resolution_clock::time_point k_start = high_resolution_clock::now();
    Reader::load(w_file, o_workbook);
    const high_resolution_clock::time_point k_stop = high_resolution_clock::now();

    const duration<double> k_timeSpan = duration_cast<duration<double>>(k_stop - k_start);

    std::cout << " (" << k_timeSpan.count() << "s)";
}

void XlsxReaderTestClass::testNull()
{
    try {

        using namespace Invoke::XLSX;

        SimpleWorkbook::SimpleWorkbook w_workbook;
        loadXlsxFile(XLSX_PATH "A.excel_empty.xlsx", &w_workbook);

        CPPUNIT_ASSERT_MESSAGE("#01", w_workbook.worksheetCount() == 1);
        CPPUNIT_ASSERT_MESSAGE("#02", w_workbook.worksheet(0)->name() == "Feuil1");

    } catch (CppUnit::Exception) {
        throw;
    } catch (std::exception& w_exception) {
        CPPUNIT_ASSERT_MESSAGE(std::string(std::string("standard exception ! <") + w_exception.what() + std::string(">")).c_str(), false);
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxReaderTestClass::testValues()
{
    try {

        using namespace Invoke::XLSX;

        SimpleWorkbook::SimpleWorkbook w_workbook;
        loadXlsxFile(XLSX_PATH "B.excel_values.xlsx", &w_workbook);

        CPPUNIT_ASSERT_MESSAGE("#01", w_workbook.worksheetCount() == 3);
        CPPUNIT_ASSERT_MESSAGE("#02", w_workbook.worksheet(0)->name() == "values");
        CPPUNIT_ASSERT_MESSAGE("#03", w_workbook.worksheet(1)->name() == "< \" > &");
        CPPUNIT_ASSERT_MESSAGE("#04", w_workbook.worksheet(2)->name() == "mergeCells");

        const Interface::Read::CellValue* w_value = nullptr;

        // feuille 1
        const Interface::Read::Worksheet* w_worksheet = w_workbook.worksheet(0);

        // ... null
        w_value = w_worksheet->cellValue(0, 2);
        CPPUNIT_ASSERT_MESSAGE("#NUL.01", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#NUL.02", w_value->type() == Interface::ctNull);

        w_value = w_worksheet->cellValue(0, 4);
        CPPUNIT_ASSERT_MESSAGE("#NUL.03", w_value == nullptr);

        // ... string
        w_value = w_worksheet->cellValue(2, 2);
        CPPUNIT_ASSERT_MESSAGE("#STR.01", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#STR.02", w_value->type() == Interface::ctString);
        CPPUNIT_ASSERT_MESSAGE("#STR.03 <"+ w_value->string() +">", w_value->string() == "Mercure");

        w_value = w_worksheet->cellValue(2, 4);
        CPPUNIT_ASSERT_MESSAGE("#STR.04", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#STR.05", w_value->type() == Interface::ctRichText);
        CPPUNIT_ASSERT_MESSAGE("#STR.06 <"+ w_value->string() +">", w_value->string() == "Terre + lune");

        w_value = w_worksheet->cellValue(2, 5);
        CPPUNIT_ASSERT_MESSAGE("#STR.07", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#STR.08", w_value->type() == Interface::ctString);
        CPPUNIT_ASSERT_MESSAGE("#STR.09 <"+ w_value->string() +">", w_value->string() == "MARS");

        w_value = w_worksheet->cellValue(2, 7);
        CPPUNIT_ASSERT_MESSAGE("#STR.10", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#STR.11", w_value->type() == Interface::ctString);
        CPPUNIT_ASSERT_MESSAGE("#STR.12 <"+ w_value->string() +">", w_value->string() == "Saturne");

        w_value = w_worksheet->cellValue(2, 9);
        CPPUNIT_ASSERT_MESSAGE("#STR.13", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#STR.14", w_value->type() == Interface::ctString);
        CPPUNIT_ASSERT_MESSAGE("#STR.15 <"+ w_value->string() +">", w_value->string() == "Pluton et\r\nCharon");

        w_value = w_worksheet->cellValue(2, 10);
        CPPUNIT_ASSERT_MESSAGE("#STR.16", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#STR.17", w_value->type() == Interface::ctString);
        CPPUNIT_ASSERT_MESSAGE("#STR.18 <"+ w_value->string() +">", w_value->string() == " ");

        // ... double
        w_value = w_worksheet->cellValue(4, 2);
        CPPUNIT_ASSERT_MESSAGE("#DBL.01", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#DBL.02", w_value->type() == Interface::ctNumber);
        CPPUNIT_ASSERT_MESSAGE("#DBL.03 <"+ std::to_string(w_value->number()) +">", w_value->number() == 3.14);

        w_value = w_worksheet->cellValue(4, 3);
        CPPUNIT_ASSERT_MESSAGE("#DBL.04", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#DBL.05", w_value->type() == Interface::ctNumber);
        CPPUNIT_ASSERT_MESSAGE("#DBL.06 <"+ std::to_string(w_value->number()) +">", w_value->number() == 3.1415926535897931);

        w_value = w_worksheet->cellValue(4, 4);
        CPPUNIT_ASSERT_MESSAGE("#DBL.07", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#DBL.08", w_value->type() == Interface::ctNumber);
        CPPUNIT_ASSERT_MESSAGE("#DBL.09 <"+ std::to_string(w_value->number()) +">", w_value->number() == -54.321);

        // ... integer
        w_value = w_worksheet->cellValue(6, 2);
        CPPUNIT_ASSERT_MESSAGE("#INT.01", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#INT.02", w_value->type() == Interface::ctNumber);
        CPPUNIT_ASSERT_MESSAGE("#INT.03 <"+ std::to_string(w_value->number()) +">", w_value->number() == 3);

        w_value = w_worksheet->cellValue(6, 3);
        CPPUNIT_ASSERT_MESSAGE("#INT.04", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#INT.05", w_value->type() == Interface::ctNumber);
        CPPUNIT_ASSERT_MESSAGE("#INT.06 <"+ std::to_string(w_value->number()) +">", w_value->number() == -12);

        w_value = w_worksheet->cellValue(6, 4);
        CPPUNIT_ASSERT_MESSAGE("#INT.07", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#INT.08", w_value->type() == Interface::ctNumber);
        CPPUNIT_ASSERT_MESSAGE("#INT.09 <"+ std::to_string(w_value->number()) +">", w_value->number() == 0);

        // ... error
        w_value = w_worksheet->cellValue(8, 2);
        CPPUNIT_ASSERT_MESSAGE("#ERR.01", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#ERR.02", w_value->type() == Interface::ctError);
        CPPUNIT_ASSERT_MESSAGE("#ERR.03", w_value->error() == Interface::ceDIV0);

        w_value = w_worksheet->cellValue(8, 3);
        CPPUNIT_ASSERT_MESSAGE("#ERR.04", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#ERR.05", w_value->type() == Interface::ctError);
        CPPUNIT_ASSERT_MESSAGE("#ERR.06", w_value->error() == Interface::ceNULL);

        w_value = w_worksheet->cellValue(8, 4);
        CPPUNIT_ASSERT_MESSAGE("#ERR.07", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#ERR.08", w_value->type() == Interface::ctError);
        CPPUNIT_ASSERT_MESSAGE("#ERR.09", w_value->error() == Interface::ceVALUE);

        w_value = w_worksheet->cellValue(8, 5);
        CPPUNIT_ASSERT_MESSAGE("#ERR.10", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#ERR.11", w_value->type() == Interface::ctError);
        CPPUNIT_ASSERT_MESSAGE("#ERR.12", w_value->error() == Interface::ceREF);

        w_value = w_worksheet->cellValue(8, 6);
        CPPUNIT_ASSERT_MESSAGE("#ERR.13", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#ERR.14", w_value->type() == Interface::ctError);
        CPPUNIT_ASSERT_MESSAGE("#ERR.15", w_value->error() == Interface::ceNAME);

        w_value = w_worksheet->cellValue(8, 7);
        CPPUNIT_ASSERT_MESSAGE("#ERR.16", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#ERR.17", w_value->type() == Interface::ctError);
        CPPUNIT_ASSERT_MESSAGE("#ERR.18", w_value->error() == Interface::ceNUM);

        w_value = w_worksheet->cellValue(8, 8);
        CPPUNIT_ASSERT_MESSAGE("#ERR.19", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#ERR.20", w_value->type() == Interface::ctError);
        CPPUNIT_ASSERT_MESSAGE("#ERR.21", w_value->error() == Interface::ceNA);

        // ... date
        w_value = w_worksheet->cellValue(10, 2);
        CPPUNIT_ASSERT_MESSAGE("#DTE.01", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#DTE.02", w_value->type() == Interface::ctNumber);
        CPPUNIT_ASSERT_MESSAGE("#DTE.03 <"+ std::to_string(w_value->number()) +">", w_value->number() == 37845);

        // boolean
        w_value = w_worksheet->cellValue(12, 2);
        CPPUNIT_ASSERT_MESSAGE("#BOO.01", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#BOO.02", w_value->type() == Interface::ctBoolean);
        CPPUNIT_ASSERT_MESSAGE("#BOO.03 <"+ std::to_string(w_value->boolean()) +">", w_value->boolean() == true);

        w_value = w_worksheet->cellValue(12, 3);
        CPPUNIT_ASSERT_MESSAGE("#BOO.04", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#BOO.05", w_value->type() == Interface::ctBoolean);
        CPPUNIT_ASSERT_MESSAGE("#BOO.06 <"+ std::to_string(w_value->boolean()) +">", w_value->boolean() == false);

        w_value = w_worksheet->cellValue(12, 4);
        CPPUNIT_ASSERT_MESSAGE("#BOO.07", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#BOO.08", w_value->type() == Interface::ctBoolean);
        CPPUNIT_ASSERT_MESSAGE("#BOO.09 <"+ std::to_string(w_value->boolean()) +">", w_value->boolean() == true);

        w_value = w_worksheet->cellValue(12, 5);
        CPPUNIT_ASSERT_MESSAGE("#BOO.10", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#BOO.11", w_value->type() == Interface::ctBoolean);
        CPPUNIT_ASSERT_MESSAGE("#BOO.12 <"+ std::to_string(w_value->boolean()) +">", w_value->boolean() == false);

        // feuille 2
        w_worksheet = w_workbook.worksheet(1);

        w_value = w_worksheet->cellValue(1, 1);
        CPPUNIT_ASSERT_MESSAGE("#SPC.01", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#SPC.02", w_value->type() == Interface::ctString);
        CPPUNIT_ASSERT_MESSAGE("#SPC.03 <"+ w_value->string() +">", w_value->string() == "< \" > &");

        w_value = w_worksheet->cellValue(1, 2);
        CPPUNIT_ASSERT_MESSAGE("#SPC.04", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#SPC.05", w_value->type() == Interface::ctString);
        CPPUNIT_ASSERT_MESSAGE("#SPC.06 <"+ w_value->string() +">", w_value->string() == "NOT OK");
        CPPUNIT_ASSERT_MESSAGE("#SPC.07 <"+ w_value->formula() +">", w_value->formula() == "IF(AND('< \" > &'!A1 < 0, '< \" > &'!A2 > 0), \"OK\", \"NOT \" & \"OK\")");

        // feuille 3
        w_worksheet = w_workbook.worksheet(2);

        CPPUNIT_ASSERT_MESSAGE("#MRG.01", w_worksheet->mergeCount() == 6);

        Coordinates::MultiCellRange w_merges;
        for (unsigned int w_iMerge = 0; w_iMerge < w_worksheet->mergeCount(); ++w_iMerge)
            w_merges.addRange(*w_worksheet->merge(w_iMerge));

        Coordinates::MultiCellRange w_ref;
        w_ref.addRange( Coordinates::CellRange(w_worksheet, 3,  4, 5,  6) );
        w_ref.addRange( Coordinates::CellRange(w_worksheet, 4,  7, 4, 13) );
        w_ref.addRange( Coordinates::CellRange(w_worksheet, 2,  9, 3,  9) );
        w_ref.addRange( Coordinates::CellRange(w_worksheet, 5,  9, 6,  9) );
        w_ref.addRange( Coordinates::CellRange(w_worksheet, 3, 14, 3, 17) );
        w_ref.addRange( Coordinates::CellRange(w_worksheet, 5, 14, 5, 17) );

        CPPUNIT_ASSERT_MESSAGE("#MRG.02", w_ref.isEqual(w_merges));

    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxReaderTestClass::testFormats()
{
    try {

        using namespace Invoke::XLSX;

        SimpleWorkbook::SimpleWorkbook w_workbook;
        loadXlsxFile(XLSX_PATH "C.excel_formats.xlsx", &w_workbook);

        const Interface::Read::Worksheet* w_worksheet = nullptr;
        const Interface::Read::CellFormat* w_format = nullptr;

        // numFmt
        w_worksheet = w_workbook.worksheet(0);

        w_format = w_worksheet->cellFormat(2, 1);
        CPPUNIT_ASSERT_MESSAGE("#A.01", w_format == nullptr);

        w_format = w_worksheet->cellFormat(2, 2);
        CPPUNIT_ASSERT_MESSAGE("#A.02 <"+ w_format->numberFormat() +">", w_format->numberFormat() == "");

        w_format = w_worksheet->cellFormat(2, 3);
        CPPUNIT_ASSERT_MESSAGE("#A.03 <"+ w_format->numberFormat() +">", w_format->numberFormat() == "0.00");

        w_format = w_worksheet->cellFormat(2, 4);
        CPPUNIT_ASSERT_MESSAGE("#A.04 <"+ w_format->numberFormat() +">", w_format->numberFormat() == "#,##0.00\\ \"€\"");

        w_format = w_worksheet->cellFormat(2, 5);
        CPPUNIT_ASSERT_MESSAGE("#A.05 <"+ w_format->numberFormat() +">", w_format->numberFormat() == "_-* #,##0.00\\ \"€\"_-;\\-* #,##0.00\\ \"€\"_-;_-* \"-\"??\\ \"€\"_-;_-@_-");

        w_format = w_worksheet->cellFormat(2, 6);
        CPPUNIT_ASSERT_MESSAGE("#A.06 <"+ w_format->numberFormat() +">", w_format->numberFormat() == "dd/mm/yyyy");

        w_format = w_worksheet->cellFormat(2, 7);
        CPPUNIT_ASSERT_MESSAGE("#A.07 <"+ w_format->numberFormat() +">", w_format->numberFormat() == "[$-F400]h:mm:ss\\ AM/PM");

        w_format = w_worksheet->cellFormat(2, 8);
        CPPUNIT_ASSERT_MESSAGE("#A.08 <"+ w_format->numberFormat() +">", w_format->numberFormat() == "0.00%");

        w_format = w_worksheet->cellFormat(2, 9);
        CPPUNIT_ASSERT_MESSAGE("#A.09 <"+ w_format->numberFormat() +">", w_format->numberFormat() == "# ?/?");

        w_format = w_worksheet->cellFormat(2, 10);
        CPPUNIT_ASSERT_MESSAGE("#A.10 <"+ w_format->numberFormat() +">", w_format->numberFormat() == "0.00E+00");

        w_format = w_worksheet->cellFormat(2, 11);
        CPPUNIT_ASSERT_MESSAGE("#A.11 <"+ w_format->numberFormat() +">", w_format->numberFormat() == "@");

        w_format = w_worksheet->cellFormat(2, 12);
        CPPUNIT_ASSERT_MESSAGE("#A.12 <"+ w_format->numberFormat() +">", w_format->numberFormat() == "_(*.#,##0.00_);\\(*.#,##0.00\\);_(*.0.00_)");

        // font
        w_worksheet = w_workbook.worksheet(1);

        w_format = w_worksheet->cellFormat(1, 1);
        CPPUNIT_ASSERT_MESSAGE("#B.01", w_format == nullptr);

        w_format = w_worksheet->cellFormat(1, 2);
        CPPUNIT_ASSERT_MESSAGE("#B.02.1", w_format->fontName() == "Arial Black");
        CPPUNIT_ASSERT_MESSAGE("#B.02.2", w_format->fontSize() == 11);
        CPPUNIT_ASSERT_MESSAGE("#B.02.3", w_format->fontColor() == 0xFF000000);
        CPPUNIT_ASSERT_MESSAGE("#B.02.4", w_format->isFontBolded() == false);
        CPPUNIT_ASSERT_MESSAGE("#B.02.5", w_format->isFontItalicized() == false);
        CPPUNIT_ASSERT_MESSAGE("#B.02.6", w_format->isFontUnderlined() == false);

        w_format = w_worksheet->cellFormat(1, 3);
        CPPUNIT_ASSERT_MESSAGE("#B.03.1", w_format->fontName() == "Calibri");
        CPPUNIT_ASSERT_MESSAGE("#B.03.2", w_format->fontSize() == 11);
        CPPUNIT_ASSERT_MESSAGE("#B.03.3", w_format->fontColor() == 0xFF000000);
        CPPUNIT_ASSERT_MESSAGE("#B.03.4", w_format->isFontBolded() == true);
        CPPUNIT_ASSERT_MESSAGE("#B.03.5", w_format->isFontItalicized() == true);
        CPPUNIT_ASSERT_MESSAGE("#B.03.6", w_format->isFontUnderlined() == true);

        w_format = w_worksheet->cellFormat(1, 4);
        CPPUNIT_ASSERT_MESSAGE("#B.04.1", w_format->fontName() == "Calibri");
        CPPUNIT_ASSERT_MESSAGE("#B.04.2", w_format->fontSize() == 11);
        CPPUNIT_ASSERT_MESSAGE("#B.04.3", w_format->fontColor() == 0xFFFF0000);
        CPPUNIT_ASSERT_MESSAGE("#B.04.4", w_format->isFontBolded() == false);
        CPPUNIT_ASSERT_MESSAGE("#B.04.5", w_format->isFontItalicized() == false);
        CPPUNIT_ASSERT_MESSAGE("#B.04.6", w_format->isFontUnderlined() == false);

        w_format = w_worksheet->cellFormat(1, 5);
        CPPUNIT_ASSERT_MESSAGE("#B.05.1", w_format->fontName() == "Calibri");
        CPPUNIT_ASSERT_MESSAGE("#B.05.2", w_format->fontSize() == 22);
        CPPUNIT_ASSERT_MESSAGE("#B.05.3", w_format->fontColor() == 0xFF000000);
        CPPUNIT_ASSERT_MESSAGE("#B.05.4", w_format->isFontBolded() == false);
        CPPUNIT_ASSERT_MESSAGE("#B.05.5", w_format->isFontItalicized() == false);
        CPPUNIT_ASSERT_MESSAGE("#B.05.6", w_format->isFontUnderlined() == false);

        // fill
        w_worksheet = w_workbook.worksheet(2);

        const std::vector<Interface::color_t> k_stdColors {
            0xFFC00000,
            0xFFFF0000,
            0xFFFFC000,
            0xFFFFFF00,
            0xFF92D050,
            0xFF00B050,
            0xFF00B0F0,
            0xFF0070C0,
            0xFF002060,
            0xFF7030A0
        };

        w_format = w_worksheet->cellFormat(1, 1);
        CPPUNIT_ASSERT_MESSAGE("#C.1.A", w_format->patternStyle() == Interface::psSolid);
        CPPUNIT_ASSERT_MESSAGE("#C.1.B", w_format->foregroundColor() == 0xFFFFFFFF);

        w_format = w_worksheet->cellFormat(2, 1);
        CPPUNIT_ASSERT_MESSAGE("#C.2.A", w_format->patternStyle() == Interface::psSolid);
        CPPUNIT_ASSERT_MESSAGE("#C.2.B", w_format->foregroundColor() == 0xFF000000);

        for (unsigned int i = 0; i < 10; ++i) {
            w_format = w_worksheet->cellFormat(i+1, 8);
            CPPUNIT_ASSERT_MESSAGE("#C."+ std::to_string(i+3) +".A", w_format->patternStyle() == Interface::psSolid);
            CPPUNIT_ASSERT_MESSAGE("#C."+ std::to_string(i+3) +".B", w_format->foregroundColor() == k_stdColors[i]);
        }

        // border
        w_worksheet = w_workbook.worksheet(3);

        const std::vector<Interface::borderStyle_t> k_borderStyles {
            Interface::bsThin,
            Interface::bsHair,
            Interface::bsDotted,
            Interface::bsDashDotDot,
            Interface::bsDashDot,
            Interface::bsDashed,
            Interface::bsMediumDashDotDot,
            Interface::bsSlantDashDot,
            Interface::bsMediumDashDot,
            Interface::bsMediumDashed,
            Interface::bsMedium,
            Interface::bsThick,
            Interface::bsDouble
            };

        for (unsigned int i = 0; i < 13; ++i) {
            w_format = w_worksheet->cellFormat(1, (i*2)+1);
            CPPUNIT_ASSERT_MESSAGE("#D."+ std::to_string(i) +".Bottom", w_format->borderStyle(Interface::bBottom) == k_borderStyles[i]);
            w_format = w_worksheet->cellFormat(3, (i*2)+1);
            CPPUNIT_ASSERT_MESSAGE("#D."+ std::to_string(i) +".Top", w_format->borderStyle(Interface::bTop) == k_borderStyles[i]);
            w_format = w_worksheet->cellFormat(5, (i*2)+1);
            CPPUNIT_ASSERT_MESSAGE("#D."+ std::to_string(i) +".Left", w_format->borderStyle(Interface::bLeft) == k_borderStyles[i]);
            w_format = w_worksheet->cellFormat(7, (i*2)+1);
            CPPUNIT_ASSERT_MESSAGE("#D."+ std::to_string(i) +".Right", w_format->borderStyle(Interface::bRight) == k_borderStyles[i]);
            w_format = w_worksheet->cellFormat(9, (i*2)+1);
            CPPUNIT_ASSERT_MESSAGE("#D."+ std::to_string(i) +".DiagonalUp", w_format->borderStyle(Interface::bDiagonalUp) == k_borderStyles[i]);
            w_format = w_worksheet->cellFormat(11, (i*2)+1);
            CPPUNIT_ASSERT_MESSAGE("#D."+ std::to_string(i) +".DiagonalDown", w_format->borderStyle(Interface::bDiagonalDown) == k_borderStyles[i]);
        }

        for (unsigned int i = 0; i < 10; ++i) {
            w_format = w_worksheet->cellFormat(13, (i*2)+1);
            CPPUNIT_ASSERT_MESSAGE("#D."+ std::to_string(i) +".Color", w_format->borderColor(Interface::bLeft) == k_stdColors[i]);
        }

        // align
        w_worksheet = w_workbook.worksheet(4);

        w_format = w_worksheet->cellFormat(1, 1);
        CPPUNIT_ASSERT_MESSAGE("#E.01.A", w_format->horizontalAlignment() == Interface::haLeft);
        CPPUNIT_ASSERT_MESSAGE("#E.01.B", w_format->verticalAlignment() == Interface::vaTop);

        w_format = w_worksheet->cellFormat(3, 1);
        CPPUNIT_ASSERT_MESSAGE("#E.02.A", w_format->horizontalAlignment() == Interface::haCenter);
        CPPUNIT_ASSERT_MESSAGE("#E.02.B", w_format->verticalAlignment() == Interface::vaTop);

        w_format = w_worksheet->cellFormat(5, 1);
        CPPUNIT_ASSERT_MESSAGE("#E.03.A", w_format->horizontalAlignment() == Interface::haRight);
        CPPUNIT_ASSERT_MESSAGE("#E.03.B", w_format->verticalAlignment() == Interface::vaTop);

        w_format = w_worksheet->cellFormat(1, 3);
        CPPUNIT_ASSERT_MESSAGE("#E.04.A", w_format->horizontalAlignment() == Interface::haLeft);
        CPPUNIT_ASSERT_MESSAGE("#E.04.B", w_format->verticalAlignment() == Interface::vaCenter);

        w_format = w_worksheet->cellFormat(3, 3);
        CPPUNIT_ASSERT_MESSAGE("#E.05.A", w_format->horizontalAlignment() == Interface::haCenter);
        CPPUNIT_ASSERT_MESSAGE("#E.05.B", w_format->verticalAlignment() == Interface::vaCenter);

        w_format = w_worksheet->cellFormat(5, 3);
        CPPUNIT_ASSERT_MESSAGE("#E.06.A", w_format->horizontalAlignment() == Interface::haRight);
        CPPUNIT_ASSERT_MESSAGE("#E.06.B", w_format->verticalAlignment() == Interface::vaCenter);

        w_format = w_worksheet->cellFormat(1, 5);
        CPPUNIT_ASSERT_MESSAGE("#E.07.A", w_format->horizontalAlignment() == Interface::haLeft);
        CPPUNIT_ASSERT_MESSAGE("#E.07.B", w_format->verticalAlignment() == Interface::vaBottom);

        w_format = w_worksheet->cellFormat(3, 5);
        CPPUNIT_ASSERT_MESSAGE("#E.08.A", w_format->horizontalAlignment() == Interface::haCenter);
        CPPUNIT_ASSERT_MESSAGE("#E.08.B", w_format->verticalAlignment() == Interface::vaBottom);

        w_format = w_worksheet->cellFormat(5, 5);
        CPPUNIT_ASSERT_MESSAGE("#E.09.A", w_format->horizontalAlignment() == Interface::haRight);
        CPPUNIT_ASSERT_MESSAGE("#E.09.B", w_format->verticalAlignment() == Interface::vaBottom);

        w_format = w_worksheet->cellFormat(3, 9);
        CPPUNIT_ASSERT_MESSAGE("#E.10.A", w_format->horizontalAlignment() == Interface::haLeft);
        CPPUNIT_ASSERT_MESSAGE("#E.10.B", w_format->textIndent() == 3);

        w_format = w_worksheet->cellFormat(3, 11);
        CPPUNIT_ASSERT_MESSAGE("#E.11.A", w_format->horizontalAlignment() == Interface::haRight);
        CPPUNIT_ASSERT_MESSAGE("#E.11.B", w_format->textIndent() == 3);

        // rotation
        w_worksheet = w_workbook.worksheet(5);

        w_format = w_worksheet->cellFormat(1, 1);
        CPPUNIT_ASSERT_MESSAGE("#F.01", w_format->textRotation() == 90);

        w_format = w_worksheet->cellFormat(3, 1);
        CPPUNIT_ASSERT_MESSAGE("#F.02", w_format->textRotation() == -90);

        w_format = w_worksheet->cellFormat(5, 1);
        CPPUNIT_ASSERT_MESSAGE("#F.03", w_format->textRotation() == 0);

        w_format = w_worksheet->cellFormat(1, 3);
        CPPUNIT_ASSERT_MESSAGE("#F.04", w_format->textRotation() == 45);

        w_format = w_worksheet->cellFormat(3, 3);
        CPPUNIT_ASSERT_MESSAGE("#F.05", w_format->textRotation() == -45);

        // wrap
        w_worksheet = w_workbook.worksheet(6);

        w_format = w_worksheet->cellFormat(1, 1);
        CPPUNIT_ASSERT_MESSAGE("#G.1", w_format->wrapText());

        w_format = w_worksheet->cellFormat(1, 3);
        CPPUNIT_ASSERT_MESSAGE("#G.2", !w_format->wrapText());

    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxReaderTestClass::testColumnsAndRows()
{
    try {

        using namespace Invoke::XLSX;

        SimpleWorkbook::SimpleWorkbook w_workbook;
        loadXlsxFile(XLSX_PATH "D.excel_columnsAndRows.xlsx", &w_workbook);

        const Interface::Read::Worksheet* w_worksheet = nullptr;
        unsigned int w_parentIndex = 0;

        // width
        w_worksheet = w_workbook.worksheet(0);

        CPPUNIT_ASSERT_MESSAGE("#A.1", w_worksheet->defaultColumnWidth() == 9.140625);
        CPPUNIT_ASSERT_MESSAGE("#A.2", w_worksheet->defaultRowHeight() == 15);

        CPPUNIT_ASSERT_MESSAGE("#A.3", w_worksheet->columnWidth(1) == 18.28515625);
        CPPUNIT_ASSERT_MESSAGE("#A.4", w_worksheet->columnWidth(2) == 27.42578125);
        CPPUNIT_ASSERT_MESSAGE("#A.5", w_worksheet->columnWidth(3) == 36.5703125);

        CPPUNIT_ASSERT_MESSAGE("#A.6", w_worksheet->rowHeight(5) == 30);
        CPPUNIT_ASSERT_MESSAGE("#A.7", w_worksheet->rowHeight(6) == 45);
        CPPUNIT_ASSERT_MESSAGE("#A.8", w_worksheet->rowHeight(7) == 60);

        // hidden
        w_worksheet = w_workbook.worksheet(1);

        CPPUNIT_ASSERT_MESSAGE("#B.1", w_worksheet->isColumnVisible(1));
        CPPUNIT_ASSERT_MESSAGE("#B.2", !w_worksheet->isColumnVisible(2));
        CPPUNIT_ASSERT_MESSAGE("#B.3", w_worksheet->isColumnVisible(3));

        CPPUNIT_ASSERT_MESSAGE("#B.4", w_worksheet->isRowVisible(7));
        CPPUNIT_ASSERT_MESSAGE("#B.5", !w_worksheet->isRowVisible(8));
        CPPUNIT_ASSERT_MESSAGE("#B.6", w_worksheet->isRowVisible(9));

        // xSplit & ySplit
        w_worksheet = w_workbook.worksheet(2);

        unsigned int w_xSplit = 0;
        CPPUNIT_ASSERT_MESSAGE("#C.1", w_worksheet->getXSplit(w_xSplit));
        CPPUNIT_ASSERT_MESSAGE("#C.2", w_xSplit == 1);

        unsigned int w_ySplit = 0;
        CPPUNIT_ASSERT_MESSAGE("#C.3", w_worksheet->getYSplit(w_ySplit));
        CPPUNIT_ASSERT_MESSAGE("#C.4", w_ySplit == 2);

        w_worksheet = w_workbook.worksheet(0);
        CPPUNIT_ASSERT_MESSAGE("#C.5", !w_worksheet->getXSplit(w_xSplit));
        CPPUNIT_ASSERT_MESSAGE("#C.6", !w_worksheet->getYSplit(w_ySplit));

        // outlines columns 1
        w_worksheet = w_workbook.worksheet(3);

        CPPUNIT_ASSERT_MESSAGE("#D.01.1", w_worksheet->columnOutlineLevel(1) == 1);
        CPPUNIT_ASSERT_MESSAGE("#D.01.2", !w_worksheet->isColumnCollapsed(1));
        CPPUNIT_ASSERT_MESSAGE("#D.01.3", w_worksheet->isColumnVisible(1));

        CPPUNIT_ASSERT_MESSAGE("#D.02.1", w_worksheet->columnOutlineLevel(2) == 2);
        CPPUNIT_ASSERT_MESSAGE("#D.02.2", !w_worksheet->isColumnCollapsed(2));
        CPPUNIT_ASSERT_MESSAGE("#D.02.3", w_worksheet->isColumnVisible(2));

        CPPUNIT_ASSERT_MESSAGE("#D.03.1", w_worksheet->columnOutlineLevel(3) == 3);
        CPPUNIT_ASSERT_MESSAGE("#D.03.2", !w_worksheet->isColumnCollapsed(3));
        CPPUNIT_ASSERT_MESSAGE("#D.03.3", w_worksheet->isColumnVisible(3));

        CPPUNIT_ASSERT_MESSAGE("#D.04.1", w_worksheet->columnOutlineLevel(4) == 4);
        CPPUNIT_ASSERT_MESSAGE("#D.04.2", !w_worksheet->isColumnCollapsed(4));
        CPPUNIT_ASSERT_MESSAGE("#D.04.3", w_worksheet->isColumnVisible(4));

        CPPUNIT_ASSERT_MESSAGE("#D.05.1", w_worksheet->columnOutlineLevel(5) == 5);
        CPPUNIT_ASSERT_MESSAGE("#D.05.2", !w_worksheet->isColumnCollapsed(5));
        CPPUNIT_ASSERT_MESSAGE("#D.05.3", w_worksheet->isColumnVisible(5));

        CPPUNIT_ASSERT_MESSAGE("#D.06.1", w_worksheet->columnOutlineLevel(6) == 6);
        CPPUNIT_ASSERT_MESSAGE("#D.06.2", w_worksheet->isColumnCollapsed(6));
        CPPUNIT_ASSERT_MESSAGE("#D.06.3", !w_worksheet->isColumnVisible(6));

        CPPUNIT_ASSERT_MESSAGE("#D.07.1", w_worksheet->columnOutlineLevel(7) == 7);
        CPPUNIT_ASSERT_MESSAGE("#D.07.2", !w_worksheet->isColumnCollapsed(7));
        CPPUNIT_ASSERT_MESSAGE("#D.07.3", !w_worksheet->isColumnVisible(7));

        CPPUNIT_ASSERT_MESSAGE("#D.08.1", w_worksheet->columnOutlineLevel(8) == 6);
        CPPUNIT_ASSERT_MESSAGE("#D.08.2", w_worksheet->isColumnCollapsed(8));
        CPPUNIT_ASSERT_MESSAGE("#D.08.3", !w_worksheet->isColumnVisible(8));

        CPPUNIT_ASSERT_MESSAGE("#D.09.1", w_worksheet->columnOutlineLevel(9) == 5);
        CPPUNIT_ASSERT_MESSAGE("#D.09.2", !w_worksheet->isColumnCollapsed(9));
        CPPUNIT_ASSERT_MESSAGE("#D.09.3", w_worksheet->isColumnVisible(9));

        CPPUNIT_ASSERT_MESSAGE("#D.10.1", w_worksheet->columnOutlineLevel(10) == 4);
        CPPUNIT_ASSERT_MESSAGE("#D.10.2", !w_worksheet->isColumnCollapsed(10));
        CPPUNIT_ASSERT_MESSAGE("#D.10.3", w_worksheet->isColumnVisible(10));

        CPPUNIT_ASSERT_MESSAGE("#D.11.1", w_worksheet->columnOutlineLevel(11) == 3);
        CPPUNIT_ASSERT_MESSAGE("#D.11.2", !w_worksheet->isColumnCollapsed(11));
        CPPUNIT_ASSERT_MESSAGE("#D.11.3", w_worksheet->isColumnVisible(11));

        CPPUNIT_ASSERT_MESSAGE("#D.12.1", w_worksheet->columnOutlineLevel(12) == 2);
        CPPUNIT_ASSERT_MESSAGE("#D.12.2", !w_worksheet->isColumnCollapsed(12));
        CPPUNIT_ASSERT_MESSAGE("#D.12.3", w_worksheet->isColumnVisible(12));

        CPPUNIT_ASSERT_MESSAGE("#D.13.1", w_worksheet->columnOutlineLevel(13) == 1);
        CPPUNIT_ASSERT_MESSAGE("#D.13.2", !w_worksheet->isColumnCollapsed(13));
        CPPUNIT_ASSERT_MESSAGE("#D.13.3", w_worksheet->isColumnVisible(13));

        w_parentIndex = 0;
        CPPUNIT_ASSERT_MESSAGE("#D.14.1.0", !w_worksheet->getColumnParentIndex(15, w_parentIndex));
        CPPUNIT_ASSERT_MESSAGE("#D.14.1.1", w_worksheet->getColumnParentIndex(2, w_parentIndex));
        CPPUNIT_ASSERT_MESSAGE("#D.14.1.2", w_parentIndex == 13);
        CPPUNIT_ASSERT_MESSAGE("#D.14.2.1", w_worksheet->getColumnParentIndex(12, w_parentIndex));
        CPPUNIT_ASSERT_MESSAGE("#D.14.2.2", w_parentIndex == 13);

        CPPUNIT_ASSERT_MESSAGE("#D.15.1", !w_worksheet->hasColumnChildren(1));
        CPPUNIT_ASSERT_MESSAGE("#D.15.2", w_worksheet->hasColumnChildren(13));

        CPPUNIT_ASSERT_MESSAGE("#D.16.1", !w_worksheet->areColumnChildrenCollapsed(1));
        CPPUNIT_ASSERT_MESSAGE("#D.16.2", !w_worksheet->areColumnChildrenCollapsed(2));
        CPPUNIT_ASSERT_MESSAGE("#D.16.3", w_worksheet->areColumnChildrenCollapsed(9));
        CPPUNIT_ASSERT_MESSAGE("#D.16.4", !w_worksheet->areColumnChildrenCollapsed(10));

        // outlines columns 2
        w_worksheet = w_workbook.worksheet(4);

        CPPUNIT_ASSERT_MESSAGE("#E.01.1", w_worksheet->columnOutlineLevel(1) == 1);
        CPPUNIT_ASSERT_MESSAGE("#E.01.2", !w_worksheet->isColumnCollapsed(1));
        CPPUNIT_ASSERT_MESSAGE("#E.01.3", w_worksheet->isColumnVisible(1));

        CPPUNIT_ASSERT_MESSAGE("#E.02.1", w_worksheet->columnOutlineLevel(2) == 2);
        CPPUNIT_ASSERT_MESSAGE("#E.02.2", !w_worksheet->isColumnCollapsed(2));
        CPPUNIT_ASSERT_MESSAGE("#E.02.3", w_worksheet->isColumnVisible(2));

        CPPUNIT_ASSERT_MESSAGE("#E.03.1", w_worksheet->columnOutlineLevel(3) == 3);
        CPPUNIT_ASSERT_MESSAGE("#E.03.2", w_worksheet->isColumnCollapsed(3));
        CPPUNIT_ASSERT_MESSAGE("#E.03.3", !w_worksheet->isColumnVisible(3));

        CPPUNIT_ASSERT_MESSAGE("#E.04.1", w_worksheet->columnOutlineLevel(4) == 4);
        CPPUNIT_ASSERT_MESSAGE("#E.04.2", !w_worksheet->isColumnCollapsed(4));
        CPPUNIT_ASSERT_MESSAGE("#E.04.3", !w_worksheet->isColumnVisible(4));

        CPPUNIT_ASSERT_MESSAGE("#E.05.1", w_worksheet->columnOutlineLevel(5) == 5);
        CPPUNIT_ASSERT_MESSAGE("#E.05.2", !w_worksheet->isColumnCollapsed(5));
        CPPUNIT_ASSERT_MESSAGE("#E.05.3", !w_worksheet->isColumnVisible(5));

        CPPUNIT_ASSERT_MESSAGE("#E.06.1", w_worksheet->columnOutlineLevel(6) == 6);
        CPPUNIT_ASSERT_MESSAGE("#E.06.2", w_worksheet->isColumnCollapsed(6));
        CPPUNIT_ASSERT_MESSAGE("#E.06.3", !w_worksheet->isColumnVisible(6));

        CPPUNIT_ASSERT_MESSAGE("#E.07.1", w_worksheet->columnOutlineLevel(7) == 7);
        CPPUNIT_ASSERT_MESSAGE("#E.07.2", !w_worksheet->isColumnCollapsed(7));
        CPPUNIT_ASSERT_MESSAGE("#E.07.3", !w_worksheet->isColumnVisible(7));

        CPPUNIT_ASSERT_MESSAGE("#E.08.1", w_worksheet->columnOutlineLevel(8) == 6);
        CPPUNIT_ASSERT_MESSAGE("#E.08.2", w_worksheet->isColumnCollapsed(8));
        CPPUNIT_ASSERT_MESSAGE("#E.08.3", !w_worksheet->isColumnVisible(8));

        CPPUNIT_ASSERT_MESSAGE("#E.09.1", w_worksheet->columnOutlineLevel(9) == 5);
        CPPUNIT_ASSERT_MESSAGE("#E.09.2", !w_worksheet->isColumnCollapsed(9));
        CPPUNIT_ASSERT_MESSAGE("#E.09.3", !w_worksheet->isColumnVisible(9));

        CPPUNIT_ASSERT_MESSAGE("#E.10.1", w_worksheet->columnOutlineLevel(10) == 4);
        CPPUNIT_ASSERT_MESSAGE("#E.10.2", !w_worksheet->isColumnCollapsed(10));
        CPPUNIT_ASSERT_MESSAGE("#E.10.3", !w_worksheet->isColumnVisible(10));

        CPPUNIT_ASSERT_MESSAGE("#E.11.1", w_worksheet->columnOutlineLevel(11) == 3);
        CPPUNIT_ASSERT_MESSAGE("#E.11.2", w_worksheet->isColumnCollapsed(11));
        CPPUNIT_ASSERT_MESSAGE("#E.11.3", !w_worksheet->isColumnVisible(11));

        CPPUNIT_ASSERT_MESSAGE("#E.12.1", w_worksheet->columnOutlineLevel(12) == 2);
        CPPUNIT_ASSERT_MESSAGE("#E.12.2", !w_worksheet->isColumnCollapsed(12));
        CPPUNIT_ASSERT_MESSAGE("#E.12.3", w_worksheet->isColumnVisible(12));

        CPPUNIT_ASSERT_MESSAGE("#E.13.1", w_worksheet->columnOutlineLevel(13) == 1);
        CPPUNIT_ASSERT_MESSAGE("#E.13.2", !w_worksheet->isColumnCollapsed(13));
        CPPUNIT_ASSERT_MESSAGE("#E.13.3", w_worksheet->isColumnVisible(13));

        w_parentIndex = 0;
        CPPUNIT_ASSERT_MESSAGE("#E.14.1.0", !w_worksheet->getColumnParentIndex(15, w_parentIndex));
        CPPUNIT_ASSERT_MESSAGE("#E.14.1.1", w_worksheet->getColumnParentIndex(2, w_parentIndex));
        CPPUNIT_ASSERT_MESSAGE("#E.14.1.2", w_parentIndex == 1);
        CPPUNIT_ASSERT_MESSAGE("#E.14.2.1", w_worksheet->getColumnParentIndex(12, w_parentIndex));
        CPPUNIT_ASSERT_MESSAGE("#E.14.2.2", w_parentIndex == 1);

        CPPUNIT_ASSERT_MESSAGE("#E.15.1", w_worksheet->hasColumnChildren(1));
        CPPUNIT_ASSERT_MESSAGE("#E.15.2", !w_worksheet->hasColumnChildren(13));

        CPPUNIT_ASSERT_MESSAGE("#E.16.1", !w_worksheet->areColumnChildrenCollapsed(1));
        CPPUNIT_ASSERT_MESSAGE("#E.16.2", w_worksheet->areColumnChildrenCollapsed(2));
        CPPUNIT_ASSERT_MESSAGE("#E.16.3", !w_worksheet->areColumnChildrenCollapsed(9));
        CPPUNIT_ASSERT_MESSAGE("#E.16.4", !w_worksheet->areColumnChildrenCollapsed(10));

        // outlines rows 1
        w_worksheet = w_workbook.worksheet(5);

        CPPUNIT_ASSERT_MESSAGE("#F.01.1", w_worksheet->rowOutlineLevel(5) == 1);
        CPPUNIT_ASSERT_MESSAGE("#F.01.2", !w_worksheet->isRowCollapsed(5));
        CPPUNIT_ASSERT_MESSAGE("#F.01.3", w_worksheet->isRowVisible(5));

        CPPUNIT_ASSERT_MESSAGE("#F.02.1", w_worksheet->rowOutlineLevel(6) == 2);
        CPPUNIT_ASSERT_MESSAGE("#F.02.2", !w_worksheet->isRowCollapsed(6));
        CPPUNIT_ASSERT_MESSAGE("#F.02.3", w_worksheet->isRowVisible(6));

        CPPUNIT_ASSERT_MESSAGE("#F.03.1", w_worksheet->rowOutlineLevel(7) == 3);
        CPPUNIT_ASSERT_MESSAGE("#F.03.2", !w_worksheet->isRowCollapsed(7));
        CPPUNIT_ASSERT_MESSAGE("#F.03.3", w_worksheet->isRowVisible(7));

        CPPUNIT_ASSERT_MESSAGE("#F.04.1", w_worksheet->rowOutlineLevel(8) == 4);
        CPPUNIT_ASSERT_MESSAGE("#F.04.2", !w_worksheet->isRowCollapsed(8));
        CPPUNIT_ASSERT_MESSAGE("#F.04.3", w_worksheet->isRowVisible(8));

        CPPUNIT_ASSERT_MESSAGE("#F.05.1", w_worksheet->rowOutlineLevel(9) == 5);
        CPPUNIT_ASSERT_MESSAGE("#F.05.2", !w_worksheet->isRowCollapsed(9));
        CPPUNIT_ASSERT_MESSAGE("#F.05.3", w_worksheet->isRowVisible(9));

        CPPUNIT_ASSERT_MESSAGE("#F.06.1", w_worksheet->rowOutlineLevel(10) == 6);
        CPPUNIT_ASSERT_MESSAGE("#F.06.2", w_worksheet->isRowCollapsed(10));
        CPPUNIT_ASSERT_MESSAGE("#F.06.3", !w_worksheet->isRowVisible(10));

        CPPUNIT_ASSERT_MESSAGE("#F.07.1", w_worksheet->rowOutlineLevel(11) == 7);
        CPPUNIT_ASSERT_MESSAGE("#F.07.2", !w_worksheet->isRowCollapsed(11));
        CPPUNIT_ASSERT_MESSAGE("#F.07.3", !w_worksheet->isRowVisible(11));

        CPPUNIT_ASSERT_MESSAGE("#F.08.1", w_worksheet->rowOutlineLevel(12) == 6);
        CPPUNIT_ASSERT_MESSAGE("#F.08.2", w_worksheet->isRowCollapsed(12));
        CPPUNIT_ASSERT_MESSAGE("#F.08.3", !w_worksheet->isRowVisible(12));

        CPPUNIT_ASSERT_MESSAGE("#F.09.1", w_worksheet->rowOutlineLevel(13) == 5);
        CPPUNIT_ASSERT_MESSAGE("#F.09.2", !w_worksheet->isRowCollapsed(13));
        CPPUNIT_ASSERT_MESSAGE("#F.09.3", w_worksheet->isRowVisible(13));

        CPPUNIT_ASSERT_MESSAGE("#F.10.1", w_worksheet->rowOutlineLevel(14) == 4);
        CPPUNIT_ASSERT_MESSAGE("#F.10.2", !w_worksheet->isRowCollapsed(14));
        CPPUNIT_ASSERT_MESSAGE("#F.10.3", w_worksheet->isRowVisible(14));

        CPPUNIT_ASSERT_MESSAGE("#F.11.1", w_worksheet->rowOutlineLevel(15) == 3);
        CPPUNIT_ASSERT_MESSAGE("#F.11.2", !w_worksheet->isRowCollapsed(15));
        CPPUNIT_ASSERT_MESSAGE("#F.11.3", w_worksheet->isRowVisible(15));

        CPPUNIT_ASSERT_MESSAGE("#F.12.1", w_worksheet->rowOutlineLevel(16) == 2);
        CPPUNIT_ASSERT_MESSAGE("#F.12.2", !w_worksheet->isRowCollapsed(16));
        CPPUNIT_ASSERT_MESSAGE("#F.12.3", w_worksheet->isRowVisible(16));

        CPPUNIT_ASSERT_MESSAGE("#F.13.1", w_worksheet->rowOutlineLevel(17) == 1);
        CPPUNIT_ASSERT_MESSAGE("#F.13.2", !w_worksheet->isRowCollapsed(17));
        CPPUNIT_ASSERT_MESSAGE("#F.13.3", w_worksheet->isRowVisible(17));

        w_parentIndex = 0;
        CPPUNIT_ASSERT_MESSAGE("#F.14.1.0", !w_worksheet->getRowParentIndex(3, w_parentIndex));
        CPPUNIT_ASSERT_MESSAGE("#F.14.1.1", w_worksheet->getRowParentIndex(6, w_parentIndex));
        CPPUNIT_ASSERT_MESSAGE("#F.14.1.2", w_parentIndex == 17);
        CPPUNIT_ASSERT_MESSAGE("#F.14.2.1", w_worksheet->getRowParentIndex(16, w_parentIndex));
        CPPUNIT_ASSERT_MESSAGE("#F.14.2.2", w_parentIndex == 17);

        CPPUNIT_ASSERT_MESSAGE("#F.15.1", !w_worksheet->hasRowChildren(6));
        CPPUNIT_ASSERT_MESSAGE("#F.15.2", w_worksheet->hasRowChildren(16));

        CPPUNIT_ASSERT_MESSAGE("#F.16.1", !w_worksheet->areRowChildrenCollapsed(6));
        CPPUNIT_ASSERT_MESSAGE("#F.16.2", !w_worksheet->areRowChildrenCollapsed(7));
        CPPUNIT_ASSERT_MESSAGE("#F.16.3", !w_worksheet->areRowChildrenCollapsed(12));
        CPPUNIT_ASSERT_MESSAGE("#F.16.4", w_worksheet->areRowChildrenCollapsed(13));

        // outlines rows 2
        w_worksheet = w_workbook.worksheet(6);

        CPPUNIT_ASSERT_MESSAGE("#G.01.1", w_worksheet->rowOutlineLevel(5) == 1);
        CPPUNIT_ASSERT_MESSAGE("#G.01.2", !w_worksheet->isRowCollapsed(5));
        CPPUNIT_ASSERT_MESSAGE("#G.01.3", w_worksheet->isRowVisible(5));

        CPPUNIT_ASSERT_MESSAGE("#G.02.1", w_worksheet->rowOutlineLevel(6) == 2);
        CPPUNIT_ASSERT_MESSAGE("#G.02.2", !w_worksheet->isRowCollapsed(6));
        CPPUNIT_ASSERT_MESSAGE("#G.02.3", w_worksheet->isRowVisible(6));

        CPPUNIT_ASSERT_MESSAGE("#G.03.1", w_worksheet->rowOutlineLevel(7) == 3);
        CPPUNIT_ASSERT_MESSAGE("#G.03.2", w_worksheet->isRowCollapsed(7));
        CPPUNIT_ASSERT_MESSAGE("#G.03.3", !w_worksheet->isRowVisible(7));

        CPPUNIT_ASSERT_MESSAGE("#G.04.1", w_worksheet->rowOutlineLevel(8) == 4);
        CPPUNIT_ASSERT_MESSAGE("#G.04.2", !w_worksheet->isRowCollapsed(8));
        CPPUNIT_ASSERT_MESSAGE("#G.04.3", !w_worksheet->isRowVisible(8));

        CPPUNIT_ASSERT_MESSAGE("#G.05.1", w_worksheet->rowOutlineLevel(9) == 5);
        CPPUNIT_ASSERT_MESSAGE("#G.05.2", !w_worksheet->isRowCollapsed(9));
        CPPUNIT_ASSERT_MESSAGE("#G.05.3", !w_worksheet->isRowVisible(9));

        CPPUNIT_ASSERT_MESSAGE("#G.06.1", w_worksheet->rowOutlineLevel(10) == 6);
        CPPUNIT_ASSERT_MESSAGE("#G.06.2", w_worksheet->isRowCollapsed(10));
        CPPUNIT_ASSERT_MESSAGE("#G.06.3", !w_worksheet->isRowVisible(10));

        CPPUNIT_ASSERT_MESSAGE("#G.07.1", w_worksheet->rowOutlineLevel(11) == 7);
        CPPUNIT_ASSERT_MESSAGE("#G.07.2", !w_worksheet->isRowCollapsed(11));
        CPPUNIT_ASSERT_MESSAGE("#G.07.3", !w_worksheet->isRowVisible(11));

        CPPUNIT_ASSERT_MESSAGE("#G.08.1", w_worksheet->rowOutlineLevel(12) == 6);
        CPPUNIT_ASSERT_MESSAGE("#G.08.2", w_worksheet->isRowCollapsed(12));
        CPPUNIT_ASSERT_MESSAGE("#G.08.3", !w_worksheet->isRowVisible(12));

        CPPUNIT_ASSERT_MESSAGE("#G.09.1", w_worksheet->rowOutlineLevel(13) == 5);
        CPPUNIT_ASSERT_MESSAGE("#G.09.2", !w_worksheet->isRowCollapsed(13));
        CPPUNIT_ASSERT_MESSAGE("#G.09.3", !w_worksheet->isRowVisible(13));

        CPPUNIT_ASSERT_MESSAGE("#G.10.1", w_worksheet->rowOutlineLevel(14) == 4);
        CPPUNIT_ASSERT_MESSAGE("#G.10.2", !w_worksheet->isRowCollapsed(14));
        CPPUNIT_ASSERT_MESSAGE("#G.10.3", !w_worksheet->isRowVisible(14));

        CPPUNIT_ASSERT_MESSAGE("#G.11.1", w_worksheet->rowOutlineLevel(15) == 3);
        CPPUNIT_ASSERT_MESSAGE("#G.11.2", w_worksheet->isRowCollapsed(15));
        CPPUNIT_ASSERT_MESSAGE("#G.11.3", !w_worksheet->isRowVisible(15));

        CPPUNIT_ASSERT_MESSAGE("#G.12.1", w_worksheet->rowOutlineLevel(16) == 2);
        CPPUNIT_ASSERT_MESSAGE("#G.12.2", !w_worksheet->isRowCollapsed(16));
        CPPUNIT_ASSERT_MESSAGE("#G.12.3", w_worksheet->isRowVisible(16));

        CPPUNIT_ASSERT_MESSAGE("#G.13.1", w_worksheet->rowOutlineLevel(17) == 1);
        CPPUNIT_ASSERT_MESSAGE("#G.13.2", !w_worksheet->isRowCollapsed(17));
        CPPUNIT_ASSERT_MESSAGE("#G.13.3", w_worksheet->isRowVisible(17));

        w_parentIndex = 0;
        CPPUNIT_ASSERT_MESSAGE("#G.14.1.0", !w_worksheet->getRowParentIndex(3, w_parentIndex));
        CPPUNIT_ASSERT_MESSAGE("#G.14.1.1", w_worksheet->getRowParentIndex(6, w_parentIndex));
        CPPUNIT_ASSERT_MESSAGE("#G.14.1.2", w_parentIndex == 5);
        CPPUNIT_ASSERT_MESSAGE("#G.14.2.1", w_worksheet->getRowParentIndex(16, w_parentIndex));
        CPPUNIT_ASSERT_MESSAGE("#G.14.2.2", w_parentIndex == 5);

        CPPUNIT_ASSERT_MESSAGE("#G.15.1", w_worksheet->hasRowChildren(6));
        CPPUNIT_ASSERT_MESSAGE("#G.15.2", !w_worksheet->hasRowChildren(16));

        CPPUNIT_ASSERT_MESSAGE("#G.16.1", w_worksheet->areRowChildrenCollapsed(6));
        CPPUNIT_ASSERT_MESSAGE("#G.16.2", !w_worksheet->areRowChildrenCollapsed(7));
        CPPUNIT_ASSERT_MESSAGE("#G.16.3", !w_worksheet->areRowChildrenCollapsed(12));
        CPPUNIT_ASSERT_MESSAGE("#G.16.4", !w_worksheet->areRowChildrenCollapsed(13));

        // format
        w_worksheet = w_workbook.worksheet(7);

        CPPUNIT_ASSERT_MESSAGE("#H.01", w_worksheet->columnCellFormat(2) == nullptr);
        CPPUNIT_ASSERT_MESSAGE("#H.02", w_worksheet->columnCellFormat(3) != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#H.03", w_worksheet->columnCellFormat(4) == nullptr);

        CPPUNIT_ASSERT_MESSAGE("#H.04", w_worksheet->columnCellFormat(11) == nullptr);
        CPPUNIT_ASSERT_MESSAGE("#H.05", w_worksheet->columnCellFormat(12) != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#H.06", w_worksheet->columnCellFormat(13) != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#H.07", w_worksheet->columnCellFormat(14) == nullptr);

        Interface::Read::CellFormat const * const k_column03Format = w_worksheet->columnCellFormat(3);
        CPPUNIT_ASSERT_MESSAGE("#H.08", k_column03Format->patternStyle() == Interface::psLightDown);
        CPPUNIT_ASSERT_MESSAGE("#H.09", k_column03Format->foregroundColor() == 0xFF0070C0);
        CPPUNIT_ASSERT_MESSAGE("#H.10", k_column03Format->backgroundColor() == 0xFF92D050);
        CPPUNIT_ASSERT_MESSAGE("#H.11", k_column03Format->borderStyle(Interface::bLeft) == Interface::bsDouble);
        CPPUNIT_ASSERT_MESSAGE("#H.12", k_column03Format->borderStyle(Interface::bRight) == Interface::bsDouble);

        Interface::Read::CellFormat const * const k_column12Format = w_worksheet->columnCellFormat(12);
        CPPUNIT_ASSERT_MESSAGE("#H.13", k_column12Format->patternStyle() == Interface::psLightVertical);
        CPPUNIT_ASSERT_MESSAGE("#H.14", k_column12Format->foregroundColor() == 0xFF7030A0);
        CPPUNIT_ASSERT_MESSAGE("#H.15", k_column12Format->backgroundColor() == 0xFFFFFF00);
        CPPUNIT_ASSERT_MESSAGE("#H.16", k_column12Format->borderStyle(Interface::bLeft) == Interface::bsDashed);
        CPPUNIT_ASSERT_MESSAGE("#H.17", !k_column12Format->isBorderVisible(Interface::bRight));

        Interface::Read::CellFormat const * const k_row05Format = w_worksheet->rowCellFormat(5);
        CPPUNIT_ASSERT_MESSAGE("#H.18", k_row05Format->patternStyle() == Interface::psLightUp);
        CPPUNIT_ASSERT_MESSAGE("#H.19", k_row05Format->foregroundColor() == 0xFF0070C0);
        CPPUNIT_ASSERT_MESSAGE("#H.20", k_row05Format->backgroundColor() == 0xFF92D050);
        CPPUNIT_ASSERT_MESSAGE("#H.21", k_row05Format->borderStyle(Interface::bTop) == Interface::bsDouble);
        CPPUNIT_ASSERT_MESSAGE("#H.22", k_row05Format->borderStyle(Interface::bBottom) == Interface::bsDouble);

        Interface::Read::CellFormat const * const k_row18Format = w_worksheet->rowCellFormat(18);
        CPPUNIT_ASSERT_MESSAGE("#H.23", k_row18Format->patternStyle() == Interface::psLightHorizontal);
        CPPUNIT_ASSERT_MESSAGE("#H.24", k_row18Format->foregroundColor() == 0xFF7030A0);
        CPPUNIT_ASSERT_MESSAGE("#H.25", k_row18Format->backgroundColor() == 0xFFFFFF00);
        CPPUNIT_ASSERT_MESSAGE("#H.26", !k_row18Format->isBorderVisible(Interface::bTop));
        CPPUNIT_ASSERT_MESSAGE("#H.27", k_row18Format->borderStyle(Interface::bBottom) == Interface::bsDashed);

    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxReaderTestClass::testDefinedNames()
{
    try {

        using namespace Invoke::XLSX;

        SimpleWorkbook::SimpleWorkbook w_workbook;
        loadXlsxFile(XLSX_PATH "E.excel_definedNames.xlsx", &w_workbook);

        // point
        const Interface::Read::DefinedName* k_point = w_workbook.definedName("point");
        CPPUNIT_ASSERT_MESSAGE("#01", k_point->zone().name(nullptr) == "simple!$D$11");

        // line
        const Interface::Read::DefinedName* k_line = w_workbook.definedName("line");
        CPPUNIT_ASSERT_MESSAGE("#02", k_line->zone().name(nullptr) == "simple!$D$2:$D$9");

        // blue alien
        Coordinates::MultiCellRange w_blueAlienZone;
        w_blueAlienZone.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  6, 11,  9, 11, true) );
        w_blueAlienZone.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  3, 12, 12, 12, true) );
        w_blueAlienZone.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  2, 13, 13, 13, true) );
        w_blueAlienZone.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  2, 14,  4, 14, true) );
        w_blueAlienZone.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  7, 14,  8, 14, true) );
        w_blueAlienZone.addRange( Coordinates::CellRange(w_workbook.worksheet(0), 11, 14, 13, 14, true) );
        w_blueAlienZone.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  2, 15, 13, 15, true) );
        w_blueAlienZone.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  5, 16,  6, 16, true) );
        w_blueAlienZone.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  9, 16, 10, 16, true) );
        w_blueAlienZone.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  4, 17,  5, 17, true) );
        w_blueAlienZone.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  7, 17,  8, 17, true) );
        w_blueAlienZone.addRange( Coordinates::CellRange(w_workbook.worksheet(0), 10, 17, 11, 17, true) );
        w_blueAlienZone.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  2, 18,  3, 18, true) );
        w_blueAlienZone.addRange( Coordinates::CellRange(w_workbook.worksheet(0), 12, 18, 13, 18, true) );

        const Interface::Read::DefinedName* k_blueAlien = w_workbook.definedName("blue_alien");
        CPPUNIT_ASSERT_MESSAGE("#03", k_blueAlien->zone() == w_blueAlienZone);

        // red alien
        Coordinates::MultiCellRange w_redAlienZone_h;
        w_redAlienZone_h.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  8,  8,  9,  8, true) );
        w_redAlienZone_h.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  5,  8,  6,  8, true) );
        w_redAlienZone_h.addRange( Coordinates::CellRange(w_workbook.worksheet(0), 12,  7, 12,  7, true) );
        w_redAlienZone_h.addRange( Coordinates::CellRange(w_workbook.worksheet(0), 10,  7, 10,  7, true) );
        w_redAlienZone_h.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  4,  7,  4,  7, true) );
        w_redAlienZone_h.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  2,  7,  2,  7, true) );
        w_redAlienZone_h.addRange( Coordinates::CellRange(w_workbook.worksheet(0), 12,  6, 12,  6, true) );
        w_redAlienZone_h.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  4,  6, 10,  6, true) );
        w_redAlienZone_h.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  2,  6,  2,  6, true) );
        w_redAlienZone_h.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  2,  5, 12,  5, true) );
        w_redAlienZone_h.addRange( Coordinates::CellRange(w_workbook.worksheet(0), 10,  4, 11,  4, true) );
        w_redAlienZone_h.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  6,  4,  8,  4, true) );
        w_redAlienZone_h.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  3,  4,  4,  4, true) );
        w_redAlienZone_h.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  4,  3, 10,  3, true) );
        w_redAlienZone_h.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  9,  2,  9,  2, true) );
        w_redAlienZone_h.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  5,  2,  5,  2, true) );
        w_redAlienZone_h.addRange( Coordinates::CellRange(w_workbook.worksheet(0), 10,  1, 10,  1, true) );
        w_redAlienZone_h.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  4,  1,  4,  1, true) );

        Coordinates::MultiCellRange w_redAlienZone_v;
        w_redAlienZone_v.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  2,  5,  2,  7, true) );
        w_redAlienZone_v.addRange( Coordinates::CellRange(w_workbook.worksheet(0), 12,  5, 12,  7, true) );
        w_redAlienZone_v.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  3,  4,  3,  5, true) );
        w_redAlienZone_v.addRange( Coordinates::CellRange(w_workbook.worksheet(0), 11,  4, 11,  5, true) );
        w_redAlienZone_v.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  4,  1,  4,  1, true) );
        w_redAlienZone_v.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  4,  3,  4,  7, true) );
        w_redAlienZone_v.addRange( Coordinates::CellRange(w_workbook.worksheet(0), 10,  1, 10,  1, true) );
        w_redAlienZone_v.addRange( Coordinates::CellRange(w_workbook.worksheet(0), 10,  3, 10,  7, true) );
        w_redAlienZone_v.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  5,  2,  5,  3, true) );
        w_redAlienZone_v.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  5,  5,  5,  6, true) );
        w_redAlienZone_v.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  5,  8,  5,  8, true) );
        w_redAlienZone_v.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  9,  2,  9,  3, true) );
        w_redAlienZone_v.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  9,  5,  9,  6, true) );
        w_redAlienZone_v.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  9,  8,  9,  8, true) );
        w_redAlienZone_v.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  6,  3,  6,  6, true) );
        w_redAlienZone_v.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  6,  8,  6,  8, true) );
        w_redAlienZone_v.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  8,  3,  8,  6, true) );
        w_redAlienZone_v.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  8,  8,  8,  8, true) );
        w_redAlienZone_v.addRange( Coordinates::CellRange(w_workbook.worksheet(0),  7,  3,  7,  6, true) );


        const Interface::Read::DefinedName* k_redAlien_h = w_workbook.definedName("red_alien_h");
        CPPUNIT_ASSERT_MESSAGE("#04.1", k_redAlien_h->zone() == w_redAlienZone_h);
        CPPUNIT_ASSERT_MESSAGE("#04.2", k_redAlien_h->zone() != w_redAlienZone_v);

        const Interface::Read::DefinedName* k_redAlien_v = w_workbook.definedName("red_alien_v");
        CPPUNIT_ASSERT_MESSAGE("#05.1", k_redAlien_v->zone() != w_redAlienZone_h);
        CPPUNIT_ASSERT_MESSAGE("#05.2", k_redAlien_v->zone() == w_redAlienZone_v);

        CPPUNIT_ASSERT_MESSAGE("#06.1", k_redAlien_h->zone().isEqual(w_redAlienZone_h));
        CPPUNIT_ASSERT_MESSAGE("#06.2", k_redAlien_h->zone().isEqual(w_redAlienZone_v));
        CPPUNIT_ASSERT_MESSAGE("#06.3", k_redAlien_v->zone().isEqual(w_redAlienZone_h));
        CPPUNIT_ASSERT_MESSAGE("#06.4", k_redAlien_v->zone().isEqual(w_redAlienZone_v));

    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxReaderTestClass::testSelections()
{
    try {

        using namespace Invoke::XLSX;

        SimpleWorkbook::SimpleWorkbook w_workbook;
        loadXlsxFile(XLSX_PATH "F.excel_selections.xlsx", &w_workbook);

        // cell
        const Interface::Read::Worksheet* w_sheet = w_workbook.worksheet(0);

        Coordinates::Cell w_activeCell = Coordinates::Cell(w_sheet, 2, 3);
        Coordinates::MultiCellRange w_selection = Coordinates::MultiCellRange();
        w_selection.addRange(Coordinates::Cell(w_sheet, 2, 3));

        CPPUNIT_ASSERT_MESSAGE("#01.1", *w_sheet->activeCell() == w_activeCell);
        CPPUNIT_ASSERT_MESSAGE("#01.2", *w_sheet->selection() == w_selection);

        // simple range
        w_sheet = w_workbook.worksheet(1);

        w_activeCell = Coordinates::Cell(w_sheet, 2, 3);
        w_selection = Coordinates::MultiCellRange();
        w_selection.addRange(Coordinates::CellRange(w_sheet, 2, 3, 4, 6));

        CPPUNIT_ASSERT_MESSAGE("#02.1", *w_sheet->activeCell() == w_activeCell);
        CPPUNIT_ASSERT_MESSAGE("#02.2", *w_sheet->selection() == w_selection);

        // range
        w_sheet = w_workbook.worksheet(2);

        w_activeCell = Coordinates::Cell(w_sheet, 3, 4);
        w_selection = Coordinates::MultiCellRange();
        w_selection.addRange(Coordinates::CellRange(w_sheet, 2, 3, 4, 6));

        CPPUNIT_ASSERT_MESSAGE("#03.1", *w_sheet->activeCell() == w_activeCell);
        CPPUNIT_ASSERT_MESSAGE("#03.2", *w_sheet->selection() == w_selection);

        // multi selection
        w_sheet = w_workbook.worksheet(3);

        w_activeCell = Coordinates::Cell(w_sheet, 4, 8);
        w_selection = Coordinates::MultiCellRange();
        w_selection.addRange(Coordinates::CellRange(w_sheet, 2, 3, 3, 4));
        w_selection.addRange(Coordinates::CellRange(w_sheet, 2, 8, 6, 8));
        w_selection.addRange(Coordinates::CellRange(w_sheet, 5, 3, 6, 4));

        CPPUNIT_ASSERT_MESSAGE("#04.1", *w_sheet->activeCell() == w_activeCell);
        CPPUNIT_ASSERT_MESSAGE("#04.2", w_sheet->selection()->isEqual(w_selection));

        // split
        w_sheet = w_workbook.worksheet(4);

        w_activeCell = Coordinates::Cell(w_sheet, 2, 3);
        w_selection = Coordinates::MultiCellRange();
        w_selection.addRange(Coordinates::CellRange(w_sheet, 2, 3, 4, 6));

        CPPUNIT_ASSERT_MESSAGE("#05.1", *w_sheet->activeCell() == w_activeCell);
        CPPUNIT_ASSERT_MESSAGE("#05.2", *w_sheet->selection() == w_selection);


    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxReaderTestClass::testPageSetting()
{
    try {

        using namespace Invoke::XLSX;

        SimpleWorkbook::SimpleWorkbook w_workbook;
        loadXlsxFile(XLSX_PATH "G.excel_pageSetting.xlsx", &w_workbook);

        // Feuil1
        const Interface::Read::Worksheet* w_sheet = w_workbook.worksheet(0);

        CPPUNIT_ASSERT_MESSAGE("#01.01", w_sheet->pageSetting()->pageOrientation() == Interface::poPortrait);
        CPPUNIT_ASSERT_MESSAGE("#01.02", !w_sheet->pageSetting()->fitToHeight());
        CPPUNIT_ASSERT_MESSAGE("#01.03", !w_sheet->pageSetting()->fitToWidth());
        CPPUNIT_ASSERT_MESSAGE("#01.04", (w_sheet->pageSetting()->scale() == nullptr));
        CPPUNIT_ASSERT_MESSAGE("#01.05", w_sheet->pageSetting()->printArea() == nullptr);
        CPPUNIT_ASSERT_MESSAGE("#01.06", w_sheet->pageSetting()->headerColumns() == nullptr);
        CPPUNIT_ASSERT_MESSAGE("#01.07", w_sheet->pageSetting()->headerRows() == nullptr);

        // Feuil2
        w_sheet = w_workbook.worksheet(1);

        Coordinates::MultiCellRange w_printArea;
        w_printArea.addRange(Coordinates::CellRange(w_sheet, 3, 3, 11, 54));

        CPPUNIT_ASSERT_MESSAGE("#02.01", w_sheet->pageSetting()->pageOrientation() == Interface::poPortrait);
        CPPUNIT_ASSERT_MESSAGE("#02.02", !w_sheet->pageSetting()->fitToHeight());
        CPPUNIT_ASSERT_MESSAGE("#02.03", !w_sheet->pageSetting()->fitToWidth());
        CPPUNIT_ASSERT_MESSAGE("#02.04", (w_sheet->pageSetting()->scale() == nullptr));
        CPPUNIT_ASSERT_MESSAGE("#02.05", ((w_sheet->pageSetting()->printArea() != nullptr) && (w_sheet->pageSetting()->printArea()->isEqual(w_printArea))));
        CPPUNIT_ASSERT_MESSAGE("#02.06", w_sheet->pageSetting()->headerColumns() == nullptr);
        CPPUNIT_ASSERT_MESSAGE("#02.07", w_sheet->pageSetting()->headerRows() == nullptr);

        // Feuil3
        w_sheet = w_workbook.worksheet(2);

        w_printArea = Coordinates::MultiCellRange();
        w_printArea.addRange(Coordinates::CellRange(w_sheet, 3, 3, 11, 54));

        Coordinates::ColumnRowRange w_headerRows(Coordinates::Index::itRow, w_sheet, 0, 1);

        CPPUNIT_ASSERT_MESSAGE("#03.01", w_sheet->pageSetting()->pageOrientation() == Interface::poPortrait);
        CPPUNIT_ASSERT_MESSAGE("#03.02", !w_sheet->pageSetting()->fitToHeight());
        CPPUNIT_ASSERT_MESSAGE("#03.03", !w_sheet->pageSetting()->fitToWidth());
        CPPUNIT_ASSERT_MESSAGE("#03.04", (w_sheet->pageSetting()->scale() == nullptr));
        CPPUNIT_ASSERT_MESSAGE("#03.05", ((w_sheet->pageSetting()->printArea() != nullptr) && (w_sheet->pageSetting()->printArea()->isEqual(w_printArea))));
        CPPUNIT_ASSERT_MESSAGE("#03.06", w_sheet->pageSetting()->headerColumns() == nullptr);
        CPPUNIT_ASSERT_MESSAGE("#03.07", ((w_sheet->pageSetting()->headerRows() != nullptr) && (*w_sheet->pageSetting()->headerRows() == w_headerRows)));

        // Feuil4
        w_sheet = w_workbook.worksheet(3);

        w_printArea = Coordinates::MultiCellRange();
        w_printArea.addRange(Coordinates::CellRange(w_sheet, 3, 3, 11, 54));

        Coordinates::ColumnRowRange w_headerColumns(Coordinates::Index::itColumn, w_sheet, 0, 1);

        CPPUNIT_ASSERT_MESSAGE("#04.01", w_sheet->pageSetting()->pageOrientation() == Interface::poPortrait);
        CPPUNIT_ASSERT_MESSAGE("#04.02", !w_sheet->pageSetting()->fitToHeight());
        CPPUNIT_ASSERT_MESSAGE("#04.03", !w_sheet->pageSetting()->fitToWidth());
        CPPUNIT_ASSERT_MESSAGE("#04.04", (w_sheet->pageSetting()->scale() == nullptr));
        CPPUNIT_ASSERT_MESSAGE("#04.05", ((w_sheet->pageSetting()->printArea() != nullptr) && (w_sheet->pageSetting()->printArea()->isEqual(w_printArea))));
        CPPUNIT_ASSERT_MESSAGE("#04.06", ((w_sheet->pageSetting()->headerColumns() != nullptr) && (*w_sheet->pageSetting()->headerColumns() == w_headerColumns)));
        CPPUNIT_ASSERT_MESSAGE("#04.07", w_sheet->pageSetting()->headerRows() == nullptr);

        // Feuil5
        w_sheet = w_workbook.worksheet(4);

        w_printArea = Coordinates::MultiCellRange();
        w_printArea.addRange(Coordinates::CellRange(w_sheet, 3, 3, 11, 54));

        w_headerColumns = Coordinates::ColumnRowRange(Coordinates::Index::itColumn, w_sheet, 0, 1);
        w_headerRows = Coordinates::ColumnRowRange(Coordinates::Index::itRow, w_sheet, 0, 1);

        CPPUNIT_ASSERT_MESSAGE("#05.01", w_sheet->pageSetting()->pageOrientation() == Interface::poPortrait);
        CPPUNIT_ASSERT_MESSAGE("#05.02", !w_sheet->pageSetting()->fitToHeight());
        CPPUNIT_ASSERT_MESSAGE("#05.03", !w_sheet->pageSetting()->fitToWidth());
        CPPUNIT_ASSERT_MESSAGE("#05.04", (w_sheet->pageSetting()->scale() == nullptr));
        CPPUNIT_ASSERT_MESSAGE("#05.05", ((w_sheet->pageSetting()->printArea() != nullptr) && (w_sheet->pageSetting()->printArea()->isEqual(w_printArea))));
        CPPUNIT_ASSERT_MESSAGE("#05.06", ((w_sheet->pageSetting()->headerColumns() != nullptr) && (*w_sheet->pageSetting()->headerColumns() == w_headerColumns)));
        CPPUNIT_ASSERT_MESSAGE("#05.07", ((w_sheet->pageSetting()->headerRows() != nullptr) && (*w_sheet->pageSetting()->headerRows() == w_headerRows)));

        // Feuil6
        w_sheet = w_workbook.worksheet(5);

        w_headerColumns = Coordinates::ColumnRowRange(Coordinates::Index::itColumn, w_sheet, 0, 1);
        w_headerRows = Coordinates::ColumnRowRange(Coordinates::Index::itRow, w_sheet, 0, 1);

        CPPUNIT_ASSERT_MESSAGE("#06.01", w_sheet->pageSetting()->pageOrientation() == Interface::poPortrait);
        CPPUNIT_ASSERT_MESSAGE("#06.02", !w_sheet->pageSetting()->fitToHeight());
        CPPUNIT_ASSERT_MESSAGE("#06.03", !w_sheet->pageSetting()->fitToWidth());
        CPPUNIT_ASSERT_MESSAGE("#06.04", (w_sheet->pageSetting()->scale() == nullptr));
        CPPUNIT_ASSERT_MESSAGE("#06.05", w_sheet->pageSetting()->printArea() == nullptr);
        CPPUNIT_ASSERT_MESSAGE("#06.06", ((w_sheet->pageSetting()->headerColumns() != nullptr) && (*w_sheet->pageSetting()->headerColumns() == w_headerColumns)));
        CPPUNIT_ASSERT_MESSAGE("#06.07", ((w_sheet->pageSetting()->headerRows() != nullptr) && (*w_sheet->pageSetting()->headerRows() == w_headerRows)));

        // Feuil7
        w_sheet = w_workbook.worksheet(6);

        w_printArea = Coordinates::MultiCellRange();
        w_printArea.addRange(Coordinates::CellRange(w_sheet, 1, 1, 11, 54));

        CPPUNIT_ASSERT_MESSAGE("#07.01", w_sheet->pageSetting()->pageOrientation() == Interface::poPortrait);
        CPPUNIT_ASSERT_MESSAGE("#07.02", !w_sheet->pageSetting()->fitToHeight());
        CPPUNIT_ASSERT_MESSAGE("#07.03", !w_sheet->pageSetting()->fitToWidth());
        CPPUNIT_ASSERT_MESSAGE("#07.04", ((w_sheet->pageSetting()->scale() != nullptr) && (*w_sheet->pageSetting()->scale() == 69)));
        CPPUNIT_ASSERT_MESSAGE("#07.05", ((w_sheet->pageSetting()->printArea() != nullptr) && (w_sheet->pageSetting()->printArea()->isEqual(w_printArea))));
        CPPUNIT_ASSERT_MESSAGE("#07.06", w_sheet->pageSetting()->headerColumns() == nullptr);
        CPPUNIT_ASSERT_MESSAGE("#07.07", w_sheet->pageSetting()->headerRows() == nullptr);

        // Feuil8
        w_sheet = w_workbook.worksheet(7);

        w_printArea = Coordinates::MultiCellRange();
        w_printArea.addRange(Coordinates::CellRange(w_sheet, 1, 1, 11, 54));

        CPPUNIT_ASSERT_MESSAGE("#08.01", w_sheet->pageSetting()->pageOrientation() == Interface::poLandscape);
        CPPUNIT_ASSERT_MESSAGE("#08.02", w_sheet->pageSetting()->fitToHeight() == 2);
        CPPUNIT_ASSERT_MESSAGE("#08.03", w_sheet->pageSetting()->fitToWidth() == 3);
        CPPUNIT_ASSERT_MESSAGE("#08.04", (w_sheet->pageSetting()->scale() == nullptr));
        CPPUNIT_ASSERT_MESSAGE("#08.05", ((w_sheet->pageSetting()->printArea() != nullptr) && (w_sheet->pageSetting()->printArea()->isEqual(w_printArea))));
        CPPUNIT_ASSERT_MESSAGE("#08.06", w_sheet->pageSetting()->headerColumns() == nullptr);
        CPPUNIT_ASSERT_MESSAGE("#08.07", w_sheet->pageSetting()->headerRows() == nullptr);

        // Feuil9
        w_sheet = w_workbook.worksheet(8);

        CPPUNIT_ASSERT_MESSAGE("#09.01", w_sheet->pageSetting()->pageHeaderFooter()->isDifferentFirst() == false);
        CPPUNIT_ASSERT_MESSAGE("#09.02", w_sheet->pageSetting()->pageHeaderFooter()->isDifferentOddEven() == true);
        CPPUNIT_ASSERT_MESSAGE("#09.03", w_sheet->pageSetting()->pageHeaderFooter()->leftHeader() == "HAUT GAUCHE");
        CPPUNIT_ASSERT_MESSAGE("#09.04", w_sheet->pageSetting()->pageHeaderFooter()->centerHeader() == Interface::code(Interface::hfcDate) +" - "+ Interface::code(Interface::hfcTime));
        CPPUNIT_ASSERT_MESSAGE("#09.05", w_sheet->pageSetting()->pageHeaderFooter()->rightHeader() == Interface::headerFooterFontCode("", 0, 0xFFFF0000) +"HAUT DROITE");
        CPPUNIT_ASSERT_MESSAGE("#09.06", w_sheet->pageSetting()->pageHeaderFooter()->leftFooter() == "");
        CPPUNIT_ASSERT_MESSAGE("#09.07", w_sheet->pageSetting()->pageHeaderFooter()->centerFooter() == "");
        CPPUNIT_ASSERT_MESSAGE("#09.08", w_sheet->pageSetting()->pageHeaderFooter()->rightFooter() == Interface::code(Interface::hfcPage) +" / "+ Interface::code(Interface::hfcPages));
        CPPUNIT_ASSERT_MESSAGE("#09.09", *w_sheet->pageSetting()->pageHeaderFooter()->leftEvenHeader() == "PAGE PAIRE");
        CPPUNIT_ASSERT_MESSAGE("#09.10", *w_sheet->pageSetting()->pageHeaderFooter()->centerEvenHeader() == "");
        CPPUNIT_ASSERT_MESSAGE("#09.11", *w_sheet->pageSetting()->pageHeaderFooter()->rightEvenHeader() == "");
        CPPUNIT_ASSERT_MESSAGE("#09.09", *w_sheet->pageSetting()->pageHeaderFooter()->leftEvenFooter() == "");
        CPPUNIT_ASSERT_MESSAGE("#09.10", *w_sheet->pageSetting()->pageHeaderFooter()->centerEvenFooter() == Interface::code(Interface::hfcSheet));
        CPPUNIT_ASSERT_MESSAGE("#09.11", *w_sheet->pageSetting()->pageHeaderFooter()->rightEvenFooter() == "");
        CPPUNIT_ASSERT_MESSAGE("#09.12", !w_sheet->pageSetting()->pageHeaderFooter()->leftFirstHeader());
        CPPUNIT_ASSERT_MESSAGE("#09.13", !w_sheet->pageSetting()->pageHeaderFooter()->centerFirstHeader());
        CPPUNIT_ASSERT_MESSAGE("#09.14", !w_sheet->pageSetting()->pageHeaderFooter()->rightFirstHeader());
        CPPUNIT_ASSERT_MESSAGE("#09.15", !w_sheet->pageSetting()->pageHeaderFooter()->leftFirstFooter());
        CPPUNIT_ASSERT_MESSAGE("#09.16", !w_sheet->pageSetting()->pageHeaderFooter()->centerFirstFooter());
        CPPUNIT_ASSERT_MESSAGE("#09.17", !w_sheet->pageSetting()->pageHeaderFooter()->rightFirstFooter());


    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxReaderTestClass::testConditionalFormatting()
{
    try {

        using namespace Invoke::XLSX;

        SimpleWorkbook::SimpleWorkbook w_workbook;
        loadXlsxFile(XLSX_PATH "H.excel_conditionalFormatting.xlsx", &w_workbook);

        const Interface::Read::Worksheet* w_sheet = w_workbook.worksheet(0);

        CPPUNIT_ASSERT_MESSAGE("#01: nombre de format conditionnel différent de 6!", w_sheet->conditionalFormattingCount() == 6);

        for (unsigned int i = 0; i < 6; ++i) {
            Interface::Read::ConditionalFormatting const * const k_conditionalFormatting = w_sheet->conditionalFormatting(i);

            if (k_conditionalFormatting->formula() == "B3>5") {
                Coordinates::MultiCellRange w_compare;
                w_compare.addRange(Coordinates::CellRange(nullptr, 1, 2, 1, 11));
                CPPUNIT_ASSERT_MESSAGE("#10: référence erronée!", k_conditionalFormatting->reference().isEqual(w_compare));

                CPPUNIT_ASSERT_MESSAGE("#11: format non assigné!", k_conditionalFormatting->format());
                CPPUNIT_ASSERT_MESSAGE("#12.1.1: format différentiel (font)!", k_conditionalFormatting->format()->isFontBolded() );
                CPPUNIT_ASSERT_MESSAGE("#12.1.2: format différentiel (font)!", *k_conditionalFormatting->format()->isFontBolded() );
                CPPUNIT_ASSERT_MESSAGE("#12.2.1: format différentiel (font)!", k_conditionalFormatting->format()->isFontItalicized() );
                CPPUNIT_ASSERT_MESSAGE("#12.2.2: format différentiel (font)!", *k_conditionalFormatting->format()->isFontItalicized() == false );
                CPPUNIT_ASSERT_MESSAGE("#12.3.1: format différentiel (font)!", k_conditionalFormatting->format()->isFontUnderlined() );
                CPPUNIT_ASSERT_MESSAGE("#12.3.2: format différentiel (font)!", *k_conditionalFormatting->format()->isFontUnderlined() );
                CPPUNIT_ASSERT_MESSAGE("#12.4.1: format différentiel (font)!", k_conditionalFormatting->format()->fontColor() );
                CPPUNIT_ASSERT_MESSAGE("#12.4.2: format différentiel (font)!", *k_conditionalFormatting->format()->fontColor() == 0xFFFFFFFF );
                CPPUNIT_ASSERT_MESSAGE("#13.1.1: format différentiel (pattern)!", k_conditionalFormatting->format()->patternStyle() );
                CPPUNIT_ASSERT_MESSAGE("#13.1.2: format différentiel (pattern)!", *k_conditionalFormatting->format()->patternStyle() == Interface::psSolid );
                CPPUNIT_ASSERT_MESSAGE("#13.2.1: format différentiel (pattern)!", k_conditionalFormatting->format()->foregroundColor() == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#13.3.1: format différentiel (pattern)!", k_conditionalFormatting->format()->backgroundColor() );
                CPPUNIT_ASSERT_MESSAGE("#13.3.2: format différentiel (pattern)!", *k_conditionalFormatting->format()->backgroundColor() == 0xFF000000 );
                CPPUNIT_ASSERT_MESSAGE("#14.1.1.1: format différentiel (left border)!", k_conditionalFormatting->format()->isBorderVisible(Interface::bLeft) );
                CPPUNIT_ASSERT_MESSAGE("#14.1.1.2: format différentiel (left border)!", *k_conditionalFormatting->format()->isBorderVisible(Interface::bLeft) );
                CPPUNIT_ASSERT_MESSAGE("#14.1.2.1: format différentiel (left border)!", k_conditionalFormatting->format()->borderStyle(Interface::bLeft) );
                CPPUNIT_ASSERT_MESSAGE("#14.1.2.2: format différentiel (left border)!", *k_conditionalFormatting->format()->borderStyle(Interface::bLeft) == Interface::bsThin );
                CPPUNIT_ASSERT_MESSAGE("#14.1.3.1: format différentiel (left border)!", k_conditionalFormatting->format()->borderColor(Interface::bLeft) );
                CPPUNIT_ASSERT_MESSAGE("#14.1.3.2: format différentiel (left border)!", *k_conditionalFormatting->format()->borderColor(Interface::bLeft) == 0xFFFF0000 );
                CPPUNIT_ASSERT_MESSAGE("#14.2.1.1: format différentiel (top border)!", k_conditionalFormatting->format()->isBorderVisible(Interface::bTop) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#14.2.2.1: format différentiel (top border)!", k_conditionalFormatting->format()->borderStyle(Interface::bTop) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#14.2.3.1: format différentiel (top border)!", k_conditionalFormatting->format()->borderColor(Interface::bTop) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#14.3.1.1: format différentiel (right border)!", k_conditionalFormatting->format()->isBorderVisible(Interface::bRight) );
                CPPUNIT_ASSERT_MESSAGE("#14.3.1.2: format différentiel (right border)!", *k_conditionalFormatting->format()->isBorderVisible(Interface::bRight) );
                CPPUNIT_ASSERT_MESSAGE("#14.3.2.1: format différentiel (right border)!", k_conditionalFormatting->format()->borderStyle(Interface::bRight) );
                CPPUNIT_ASSERT_MESSAGE("#14.3.2.2: format différentiel (right border)!", *k_conditionalFormatting->format()->borderStyle(Interface::bRight) == Interface::bsThin );
                CPPUNIT_ASSERT_MESSAGE("#14.3.3.1: format différentiel (right border)!", k_conditionalFormatting->format()->borderColor(Interface::bRight) );
                CPPUNIT_ASSERT_MESSAGE("#14.3.3.2: format différentiel (right border)!", *k_conditionalFormatting->format()->borderColor(Interface::bRight) == 0xFFFF0000 );
                CPPUNIT_ASSERT_MESSAGE("#14.4.1.1: format différentiel (bottom border)!", k_conditionalFormatting->format()->isBorderVisible(Interface::bBottom) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#14.4.2.1: format différentiel (bottom border)!", k_conditionalFormatting->format()->borderStyle(Interface::bBottom) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#14.4.3.1: format différentiel (bottom border)!", k_conditionalFormatting->format()->borderColor(Interface::bBottom) == nullptr );

            } else if (k_conditionalFormatting->formula() == "D3<16") {
                Coordinates::MultiCellRange w_compare;
                w_compare.addRange(Coordinates::CellRange(nullptr, 3, 2, 3, 11));
                CPPUNIT_ASSERT_MESSAGE("#20: référence erronée!", k_conditionalFormatting->reference().isEqual(w_compare));

                CPPUNIT_ASSERT_MESSAGE("#21: format non assigné!", k_conditionalFormatting->format());
                CPPUNIT_ASSERT_MESSAGE("#22.1.1: format différentiel (font)!", k_conditionalFormatting->format()->isFontBolded() == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#22.2.1: format différentiel (font)!", k_conditionalFormatting->format()->isFontItalicized() == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#22.3.1: format différentiel (font)!", k_conditionalFormatting->format()->isFontUnderlined() == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#22.4.1: format différentiel (font)!", k_conditionalFormatting->format()->fontColor() );
                CPPUNIT_ASSERT_MESSAGE("#22.4.2: format différentiel (font)!", *k_conditionalFormatting->format()->fontColor() == 0xFFFF0000 );
                CPPUNIT_ASSERT_MESSAGE("#23.1.1: format différentiel (pattern)!", k_conditionalFormatting->format()->patternStyle() );
                CPPUNIT_ASSERT_MESSAGE("#23.1.2: format différentiel (pattern)!", *k_conditionalFormatting->format()->patternStyle() == Interface::psLightHorizontal );
                CPPUNIT_ASSERT_MESSAGE("#23.2.1: format différentiel (pattern)!", k_conditionalFormatting->format()->foregroundColor() );
                CPPUNIT_ASSERT_MESSAGE("#23.3.1: format différentiel (pattern)!", k_conditionalFormatting->format()->backgroundColor() );
                CPPUNIT_ASSERT_MESSAGE("#24.1.1.1: format différentiel (left border)!", k_conditionalFormatting->format()->isBorderVisible(Interface::bLeft) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#24.1.2.1: format différentiel (left border)!", k_conditionalFormatting->format()->borderStyle(Interface::bLeft) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#24.1.3.1: format différentiel (left border)!", k_conditionalFormatting->format()->borderColor(Interface::bLeft) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#24.2.1.1: format différentiel (top border)!", k_conditionalFormatting->format()->isBorderVisible(Interface::bTop) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#24.2.2.1: format différentiel (top border)!", k_conditionalFormatting->format()->borderStyle(Interface::bTop) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#24.2.3.1: format différentiel (top border)!", k_conditionalFormatting->format()->borderColor(Interface::bTop) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#24.3.1.1: format différentiel (right border)!", k_conditionalFormatting->format()->isBorderVisible(Interface::bRight) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#24.3.2.1: format différentiel (right border)!", k_conditionalFormatting->format()->borderStyle(Interface::bRight) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#24.3.3.1: format différentiel (right border)!", k_conditionalFormatting->format()->borderColor(Interface::bRight) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#24.4.1.1: format différentiel (bottom border)!", k_conditionalFormatting->format()->isBorderVisible(Interface::bBottom) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#24.4.2.1: format différentiel (bottom border)!", k_conditionalFormatting->format()->borderStyle(Interface::bBottom) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#24.4.3.1: format différentiel (bottom border)!", k_conditionalFormatting->format()->borderColor(Interface::bBottom) == nullptr );

            } else if (k_conditionalFormatting->formula() == "F3>25") {
                Coordinates::MultiCellRange w_compare;
                w_compare.addRange(Coordinates::CellRange(nullptr, 5, 2, 5, 11));
                CPPUNIT_ASSERT_MESSAGE("#30: référence erronée!", k_conditionalFormatting->reference().isEqual(w_compare));

                CPPUNIT_ASSERT_MESSAGE("#31: format non assigné!", k_conditionalFormatting->format());
                CPPUNIT_ASSERT_MESSAGE("#32.1.1: format différentiel (font)!", k_conditionalFormatting->format()->isFontBolded() == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#32.2.1: format différentiel (font)!", k_conditionalFormatting->format()->isFontItalicized() == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#32.3.1: format différentiel (font)!", k_conditionalFormatting->format()->isFontUnderlined() == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#32.4.1: format différentiel (font)!", k_conditionalFormatting->format()->fontColor() == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#33.1.1: format différentiel (pattern)!", k_conditionalFormatting->format()->patternStyle() == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#33.2.1: format différentiel (pattern)!", k_conditionalFormatting->format()->foregroundColor() == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#33.3.1: format différentiel (pattern)!", k_conditionalFormatting->format()->backgroundColor() == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#34.1.1.1: format différentiel (left border)!", k_conditionalFormatting->format()->isBorderVisible(Interface::bLeft) );
                CPPUNIT_ASSERT_MESSAGE("#34.1.1.2: format différentiel (left border)!", *k_conditionalFormatting->format()->isBorderVisible(Interface::bLeft) );
                CPPUNIT_ASSERT_MESSAGE("#34.1.2.1: format différentiel (left border)!", k_conditionalFormatting->format()->borderStyle(Interface::bLeft) );
                CPPUNIT_ASSERT_MESSAGE("#34.1.2.2: format différentiel (left border)!", *k_conditionalFormatting->format()->borderStyle(Interface::bLeft) == Interface::bsDashDot );
                CPPUNIT_ASSERT_MESSAGE("#34.1.3.1: format différentiel (left border)!", k_conditionalFormatting->format()->borderColor(Interface::bLeft) );
                CPPUNIT_ASSERT_MESSAGE("#34.1.3.2: format différentiel (left border)!", *k_conditionalFormatting->format()->borderColor(Interface::bLeft) == 0xFF000000);
                CPPUNIT_ASSERT_MESSAGE("#34.2.1.1: format différentiel (top border)!", k_conditionalFormatting->format()->isBorderVisible(Interface::bTop) );
                CPPUNIT_ASSERT_MESSAGE("#34.2.1.2: format différentiel (top border)!", *k_conditionalFormatting->format()->isBorderVisible(Interface::bTop) );
                CPPUNIT_ASSERT_MESSAGE("#34.2.2.1: format différentiel (top border)!", k_conditionalFormatting->format()->borderStyle(Interface::bTop) );
                CPPUNIT_ASSERT_MESSAGE("#34.2.2.2: format différentiel (top border)!", *k_conditionalFormatting->format()->borderStyle(Interface::bTop) == Interface::bsDashDot );
                CPPUNIT_ASSERT_MESSAGE("#34.2.3.1: format différentiel (top border)!", k_conditionalFormatting->format()->borderColor(Interface::bTop) );
                CPPUNIT_ASSERT_MESSAGE("#34.2.3.2: format différentiel (top border)!", *k_conditionalFormatting->format()->borderColor(Interface::bTop) == 0xFF000000);
                CPPUNIT_ASSERT_MESSAGE("#34.3.1.1: format différentiel (right border)!", k_conditionalFormatting->format()->isBorderVisible(Interface::bRight) );
                CPPUNIT_ASSERT_MESSAGE("#34.3.1.2: format différentiel (right border)!", *k_conditionalFormatting->format()->isBorderVisible(Interface::bRight) );
                CPPUNIT_ASSERT_MESSAGE("#34.3.2.1: format différentiel (right border)!", k_conditionalFormatting->format()->borderStyle(Interface::bRight) );
                CPPUNIT_ASSERT_MESSAGE("#34.3.2.2: format différentiel (right border)!", *k_conditionalFormatting->format()->borderStyle(Interface::bRight) == Interface::bsDashDot );
                CPPUNIT_ASSERT_MESSAGE("#34.3.3.1: format différentiel (right border)!", k_conditionalFormatting->format()->borderColor(Interface::bRight) );
                CPPUNIT_ASSERT_MESSAGE("#34.3.3.2: format différentiel (right border)!", *k_conditionalFormatting->format()->borderColor(Interface::bRight) == 0xFF000000);
                CPPUNIT_ASSERT_MESSAGE("#34.4.1.1: format différentiel (bottom border)!", k_conditionalFormatting->format()->isBorderVisible(Interface::bBottom) );
                CPPUNIT_ASSERT_MESSAGE("#34.4.1.2: format différentiel (bottom border)!", *k_conditionalFormatting->format()->isBorderVisible(Interface::bBottom) );
                CPPUNIT_ASSERT_MESSAGE("#34.4.2.1: format différentiel (bottom border)!", k_conditionalFormatting->format()->borderStyle(Interface::bBottom) );
                CPPUNIT_ASSERT_MESSAGE("#34.4.2.2: format différentiel (bottom border)!", *k_conditionalFormatting->format()->borderStyle(Interface::bBottom) == Interface::bsDashDot );
                CPPUNIT_ASSERT_MESSAGE("#34.4.3.1: format différentiel (bottom border)!", k_conditionalFormatting->format()->borderColor(Interface::bBottom) );
                CPPUNIT_ASSERT_MESSAGE("#34.4.3.2: format différentiel (bottom border)!", *k_conditionalFormatting->format()->borderColor(Interface::bBottom) == 0xFF000000);

            } else if (k_conditionalFormatting->formula() == "AND(H3>33,H3<38)") {
                Coordinates::MultiCellRange w_compare;
                w_compare.addRange(Coordinates::CellRange(nullptr, 7, 2, 7, 11));
                CPPUNIT_ASSERT_MESSAGE("#40: référence erronée!", k_conditionalFormatting->reference().isEqual(w_compare));

                CPPUNIT_ASSERT_MESSAGE("#41: format non assigné!", k_conditionalFormatting->format());
                CPPUNIT_ASSERT_MESSAGE("#42.1.1: format différentiel (font)!", k_conditionalFormatting->format()->isFontBolded() == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#42.2.1: format différentiel (font)!", k_conditionalFormatting->format()->isFontItalicized() == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#42.3.1: format différentiel (font)!", k_conditionalFormatting->format()->isFontUnderlined() == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#42.4.1: format différentiel (font)!", k_conditionalFormatting->format()->fontColor() == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#43.1.1: format différentiel (pattern)!", k_conditionalFormatting->format()->patternStyle() == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#43.2.1: format différentiel (pattern)!", k_conditionalFormatting->format()->foregroundColor() == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#43.3.1: format différentiel (pattern)!", k_conditionalFormatting->format()->backgroundColor() == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#44.1.1.1: format différentiel (left border)!", k_conditionalFormatting->format()->isBorderVisible(Interface::bLeft) );
                CPPUNIT_ASSERT_MESSAGE("#44.1.1.2: format différentiel (left border)!", *k_conditionalFormatting->format()->isBorderVisible(Interface::bLeft) == false );
                CPPUNIT_ASSERT_MESSAGE("#44.1.2.1: format différentiel (left border)!", k_conditionalFormatting->format()->borderStyle(Interface::bLeft) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#44.1.3.1: format différentiel (left border)!", k_conditionalFormatting->format()->borderColor(Interface::bLeft) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#44.2.1.1: format différentiel (top border)!", k_conditionalFormatting->format()->isBorderVisible(Interface::bTop) );
                CPPUNIT_ASSERT_MESSAGE("#44.2.1.2: format différentiel (top border)!", *k_conditionalFormatting->format()->isBorderVisible(Interface::bTop) == false );
                CPPUNIT_ASSERT_MESSAGE("#44.2.2.1: format différentiel (top border)!", k_conditionalFormatting->format()->borderStyle(Interface::bTop) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#44.2.3.1: format différentiel (top border)!", k_conditionalFormatting->format()->borderColor(Interface::bTop) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#44.3.1.1: format différentiel (right border)!", k_conditionalFormatting->format()->isBorderVisible(Interface::bRight) );
                CPPUNIT_ASSERT_MESSAGE("#44.3.1.2: format différentiel (right border)!", *k_conditionalFormatting->format()->isBorderVisible(Interface::bRight) == false );
                CPPUNIT_ASSERT_MESSAGE("#44.3.2.1: format différentiel (right border)!", k_conditionalFormatting->format()->borderStyle(Interface::bRight) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#44.3.3.1: format différentiel (right border)!", k_conditionalFormatting->format()->borderColor(Interface::bRight) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#44.4.1.1: format différentiel (bottom border)!", k_conditionalFormatting->format()->isBorderVisible(Interface::bBottom) );
                CPPUNIT_ASSERT_MESSAGE("#44.4.1.2: format différentiel (bottom border)!", *k_conditionalFormatting->format()->isBorderVisible(Interface::bBottom) == false );
                CPPUNIT_ASSERT_MESSAGE("#44.4.2.1: format différentiel (bottom border)!", k_conditionalFormatting->format()->borderStyle(Interface::bBottom) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#44.4.3.1: format différentiel (bottom border)!", k_conditionalFormatting->format()->borderColor(Interface::bBottom) == nullptr );

            } else if (k_conditionalFormatting->formula() == "J3>45") {
                Coordinates::MultiCellRange w_compare;
                w_compare.addRange(Coordinates::CellRange(nullptr, 9, 2, 9, 11));
                CPPUNIT_ASSERT_MESSAGE("#50: référence erronée!", k_conditionalFormatting->reference().isEqual(w_compare));

                CPPUNIT_ASSERT_MESSAGE("#51: format non assigné!", k_conditionalFormatting->format());
                CPPUNIT_ASSERT_MESSAGE("#52.1.1: format différentiel (font)!", k_conditionalFormatting->format()->isFontBolded() == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#52.2.1: format différentiel (font)!", k_conditionalFormatting->format()->isFontItalicized() == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#52.3.1: format différentiel (font)!", k_conditionalFormatting->format()->isFontUnderlined() == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#52.4.1: format différentiel (font)!", k_conditionalFormatting->format()->fontColor() == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#53.1.1: format différentiel (pattern)!", k_conditionalFormatting->format()->patternStyle() );
                CPPUNIT_ASSERT_MESSAGE("#53.1.2: format différentiel (pattern)!", *k_conditionalFormatting->format()->patternStyle() == Interface::psSolid );
                CPPUNIT_ASSERT_MESSAGE("#53.2.1: format différentiel (pattern)!", k_conditionalFormatting->format()->foregroundColor() == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#53.3.1: format différentiel (pattern)!", k_conditionalFormatting->format()->backgroundColor() );
                CPPUNIT_ASSERT_MESSAGE("#53.3.2: format différentiel (pattern)!", *k_conditionalFormatting->format()->backgroundColor() == 0xFF92D050 );
                CPPUNIT_ASSERT_MESSAGE("#54.1.1.1: format différentiel (left border)!", k_conditionalFormatting->format()->isBorderVisible(Interface::bLeft) );
                CPPUNIT_ASSERT_MESSAGE("#54.1.1.2: format différentiel (left border)!", *k_conditionalFormatting->format()->isBorderVisible(Interface::bLeft) );
                CPPUNIT_ASSERT_MESSAGE("#54.1.2.1: format différentiel (left border)!", k_conditionalFormatting->format()->borderStyle(Interface::bLeft) );
                CPPUNIT_ASSERT_MESSAGE("#54.1.2.2: format différentiel (left border)!", *k_conditionalFormatting->format()->borderStyle(Interface::bLeft) == Interface::bsThin );
                CPPUNIT_ASSERT_MESSAGE("#54.1.3.1: format différentiel (left border)!", k_conditionalFormatting->format()->borderColor(Interface::bLeft) );
                CPPUNIT_ASSERT_MESSAGE("#54.1.3.2: format différentiel (left border)!", *k_conditionalFormatting->format()->borderColor(Interface::bLeft) == 0xFF000000 );
                CPPUNIT_ASSERT_MESSAGE("#54.2.1.1: format différentiel (top border)!", k_conditionalFormatting->format()->isBorderVisible(Interface::bTop) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#54.2.2.1: format différentiel (top border)!", k_conditionalFormatting->format()->borderStyle(Interface::bTop) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#54.2.3.1: format différentiel (top border)!", k_conditionalFormatting->format()->borderColor(Interface::bTop) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#54.3.1.1: format différentiel (right border)!", k_conditionalFormatting->format()->isBorderVisible(Interface::bRight) );
                CPPUNIT_ASSERT_MESSAGE("#54.3.1.2: format différentiel (right border)!", *k_conditionalFormatting->format()->isBorderVisible(Interface::bRight) );
                CPPUNIT_ASSERT_MESSAGE("#54.3.2.1: format différentiel (right border)!", k_conditionalFormatting->format()->borderStyle(Interface::bRight) );
                CPPUNIT_ASSERT_MESSAGE("#54.3.2.2: format différentiel (right border)!", *k_conditionalFormatting->format()->borderStyle(Interface::bRight) == Interface::bsThin);
                CPPUNIT_ASSERT_MESSAGE("#54.3.3.1: format différentiel (right border)!", k_conditionalFormatting->format()->borderColor(Interface::bRight) );
                CPPUNIT_ASSERT_MESSAGE("#54.3.3.2: format différentiel (right border)!", *k_conditionalFormatting->format()->borderColor(Interface::bRight) == 0xFF000000 );
                CPPUNIT_ASSERT_MESSAGE("#54.4.1.1: format différentiel (bottom border)!", k_conditionalFormatting->format()->isBorderVisible(Interface::bBottom) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#54.4.2.1: format différentiel (bottom border)!", k_conditionalFormatting->format()->borderStyle(Interface::bBottom) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#54.4.3.1: format différentiel (bottom border)!", k_conditionalFormatting->format()->borderColor(Interface::bBottom) == nullptr );

            } else if (k_conditionalFormatting->formula() == "MOD(C17,2)=0") {
                Coordinates::MultiCellRange w_compare;
                w_compare.addRange(Coordinates::CellRange(nullptr, 2, 16, 7, 16));
                w_compare.addRange(Coordinates::CellRange(nullptr, 2, 18, 7, 18));
                CPPUNIT_ASSERT_MESSAGE("#60: référence erronée!", k_conditionalFormatting->reference().isEqual(w_compare));

                CPPUNIT_ASSERT_MESSAGE("#51: format non assigné!", k_conditionalFormatting->format());
                CPPUNIT_ASSERT_MESSAGE("#52.1.1: format différentiel (font)!", k_conditionalFormatting->format()->isFontBolded() == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#52.2.1: format différentiel (font)!", k_conditionalFormatting->format()->isFontItalicized() == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#52.3.1: format différentiel (font)!", k_conditionalFormatting->format()->isFontUnderlined() == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#52.4.1: format différentiel (font)!", k_conditionalFormatting->format()->fontColor() == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#53.1.1: format différentiel (pattern)!", k_conditionalFormatting->format()->patternStyle() );
                CPPUNIT_ASSERT_MESSAGE("#53.1.2: format différentiel (pattern)!", *k_conditionalFormatting->format()->patternStyle() == Interface::psSolid );
                CPPUNIT_ASSERT_MESSAGE("#53.2.1: format différentiel (pattern)!", k_conditionalFormatting->format()->foregroundColor() == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#53.3.1: format différentiel (pattern)!", k_conditionalFormatting->format()->backgroundColor() );
                CPPUNIT_ASSERT_MESSAGE("#54.1.1.1: format différentiel (left border)!", k_conditionalFormatting->format()->isBorderVisible(Interface::bLeft) == nullptr);
                CPPUNIT_ASSERT_MESSAGE("#54.1.2.1: format différentiel (left border)!", k_conditionalFormatting->format()->borderStyle(Interface::bLeft) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#54.1.3.1: format différentiel (left border)!", k_conditionalFormatting->format()->borderColor(Interface::bLeft) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#54.2.1.1: format différentiel (top border)!", k_conditionalFormatting->format()->isBorderVisible(Interface::bTop) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#54.2.2.1: format différentiel (top border)!", k_conditionalFormatting->format()->borderStyle(Interface::bTop) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#54.2.3.1: format différentiel (top border)!", k_conditionalFormatting->format()->borderColor(Interface::bTop) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#54.3.1.1: format différentiel (right border)!", k_conditionalFormatting->format()->isBorderVisible(Interface::bRight) == nullptr);
                CPPUNIT_ASSERT_MESSAGE("#54.3.2.1: format différentiel (right border)!", k_conditionalFormatting->format()->borderStyle(Interface::bRight) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#54.3.3.1: format différentiel (right border)!", k_conditionalFormatting->format()->borderColor(Interface::bRight) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#54.4.1.1: format différentiel (bottom border)!", k_conditionalFormatting->format()->isBorderVisible(Interface::bBottom) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#54.4.2.1: format différentiel (bottom border)!", k_conditionalFormatting->format()->borderStyle(Interface::bBottom) == nullptr );
                CPPUNIT_ASSERT_MESSAGE("#54.4.3.1: format différentiel (bottom border)!", k_conditionalFormatting->format()->borderColor(Interface::bBottom) == nullptr );

            } else
                CPPUNIT_ASSERT_MESSAGE("#100: formule inconnue!", false);
        }


    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxReaderTestClass::testValidations()
{
    try {

        using namespace Invoke::XLSX;

        SimpleWorkbook::SimpleWorkbook w_workbook;
        loadXlsxFile(XLSX_PATH "I.excel_validations.xlsx", &w_workbook);

        const Interface::Read::Worksheet* w_sheet = w_workbook.worksheet(0);

        CPPUNIT_ASSERT_MESSAGE("#01", w_sheet->validationCount() == 7);

        for (unsigned int i = 0; i < 7; ++i) {
            Interface::Read::Validation const * const k_validation = w_sheet->validation(i);

            if (k_validation->reference().name(w_sheet) == "D4") {
                Interface::Read::ListValidation const * const k_listValidation = dynamic_cast<const Interface::Read::ListValidation *>(k_validation);
                CPPUNIT_ASSERT_MESSAGE("#10", k_listValidation != nullptr);

                CPPUNIT_ASSERT_MESSAGE("#11", k_listValidation->isValid());
                CPPUNIT_ASSERT_MESSAGE("#12", k_listValidation->isPromptShown());
                CPPUNIT_ASSERT_MESSAGE("#13", k_listValidation->isAlertShown());
                CPPUNIT_ASSERT_MESSAGE("#13.1", k_listValidation->alertType() == Interface::atError);
                CPPUNIT_ASSERT_MESSAGE("#14", k_listValidation->isBlankAllowed());

                CPPUNIT_ASSERT_MESSAGE("#15 - "+ k_listValidation->rangeReference()->name(w_sheet), k_listValidation->rangeReference()->name(w_sheet) == "$B$4:$B$15");

                SimpleWorkbook::SimpleListValidation const * const k_simpleValidation = dynamic_cast<const SimpleWorkbook::SimpleListValidation*>(k_validation);
                CPPUNIT_ASSERT_MESSAGE("#16", k_simpleValidation != nullptr);

                const Interface::valueList_t w_values = k_simpleValidation->values(&w_workbook, w_sheet);
                CPPUNIT_ASSERT_MESSAGE("#17", w_values[0] == "Bélier");
                CPPUNIT_ASSERT_MESSAGE("#18", w_values[1] == "Taureau");
                CPPUNIT_ASSERT_MESSAGE("#19", w_values[2] == "Gémeaux");

            } else if (k_validation->reference().name(w_sheet) == "F4:F6") {
                Interface::Read::ListValidation const * const k_listValidation = dynamic_cast<const Interface::Read::ListValidation *>(k_validation);
                CPPUNIT_ASSERT_MESSAGE("#20", k_listValidation != nullptr);

                CPPUNIT_ASSERT_MESSAGE("#21", k_listValidation->isValid());
                CPPUNIT_ASSERT_MESSAGE("#22", k_listValidation->isPromptShown());
                CPPUNIT_ASSERT_MESSAGE("#22.1", k_listValidation->promptTitle() == "Les signes du zodiaques");
                CPPUNIT_ASSERT_MESSAGE("#22.2", k_listValidation->promptMessage() == "Choisissez votre signe...");
                CPPUNIT_ASSERT_MESSAGE("#23", k_listValidation->isAlertShown() == false);
                CPPUNIT_ASSERT_MESSAGE("#24", k_listValidation->isBlankAllowed());

                CPPUNIT_ASSERT_MESSAGE("#25 - "+ k_listValidation->rangeReference()->name(w_sheet), k_listValidation->rangeReference()->name(w_sheet) == "$B$4:$B$15");

                SimpleWorkbook::SimpleListValidation const * const k_simpleValidation = dynamic_cast<const SimpleWorkbook::SimpleListValidation*>(k_validation);
                CPPUNIT_ASSERT_MESSAGE("#26", k_simpleValidation != nullptr);

                const Interface::valueList_t w_values = k_simpleValidation->values(&w_workbook, w_sheet);
                CPPUNIT_ASSERT_MESSAGE("#27", w_values[3] == "Cancer");
                CPPUNIT_ASSERT_MESSAGE("#28", w_values[4] == "Lion");
                CPPUNIT_ASSERT_MESSAGE("#29", w_values[5] == "Vierge");

            } else if (k_validation->reference().name(w_sheet) == "E8:G8") {
                Interface::Read::ListValidation const * const k_listValidation = dynamic_cast<const Interface::Read::ListValidation *>(k_validation);
                CPPUNIT_ASSERT_MESSAGE("#30", k_listValidation != nullptr);

                CPPUNIT_ASSERT_MESSAGE("#31", k_listValidation->isValid());
                CPPUNIT_ASSERT_MESSAGE("#32", k_listValidation->isPromptShown() == false);
                CPPUNIT_ASSERT_MESSAGE("#33", k_listValidation->isAlertShown());
                CPPUNIT_ASSERT_MESSAGE("#33.1", k_listValidation->alertType() == Interface::atWarning);
                CPPUNIT_ASSERT_MESSAGE("#33.2", k_listValidation->alertTitle() == "Avertissement");
                CPPUNIT_ASSERT_MESSAGE("#33.3", k_listValidation->alertMessage() == "C'est pas bon!!");
                CPPUNIT_ASSERT_MESSAGE("#34", k_listValidation->isBlankAllowed());

                CPPUNIT_ASSERT_MESSAGE("#35 - "+ k_listValidation->rangeReference()->name(w_sheet), k_listValidation->rangeReference()->name(w_sheet) == "$B$4:$B$15");

                SimpleWorkbook::SimpleListValidation const * const k_simpleValidation = dynamic_cast<const SimpleWorkbook::SimpleListValidation*>(k_validation);
                CPPUNIT_ASSERT_MESSAGE("#36", k_simpleValidation != nullptr);

                const Interface::valueList_t w_values = k_simpleValidation->values(&w_workbook, w_sheet);
                CPPUNIT_ASSERT_MESSAGE("#37", w_values[6] == "Balance");
                CPPUNIT_ASSERT_MESSAGE("#38", w_values[7] == "Scorpion");
                CPPUNIT_ASSERT_MESSAGE("#39", w_values[8] == "Sagittaire");

            } else if (k_validation->reference().name(w_sheet) == "H4:I6") {
                Interface::Read::ListValidation const * const k_listValidation = dynamic_cast<const Interface::Read::ListValidation *>(k_validation);
                CPPUNIT_ASSERT_MESSAGE("#40", k_listValidation != nullptr);

                CPPUNIT_ASSERT_MESSAGE("#41", k_listValidation->isValid());
                CPPUNIT_ASSERT_MESSAGE("#42", k_listValidation->isPromptShown() == false);
                CPPUNIT_ASSERT_MESSAGE("#43", k_listValidation->isAlertShown());
                CPPUNIT_ASSERT_MESSAGE("#43.1", k_listValidation->alertType() == Interface::atError);
                CPPUNIT_ASSERT_MESSAGE("#43.2", k_listValidation->alertTitle() == "Arrêt");
                CPPUNIT_ASSERT_MESSAGE("#43.3", k_listValidation->alertMessage() == "C'est pas bon!!");
                CPPUNIT_ASSERT_MESSAGE("#44", k_listValidation->isBlankAllowed());

                CPPUNIT_ASSERT_MESSAGE("#45 - "+ k_listValidation->rangeReference()->name(w_sheet), k_listValidation->rangeReference()->name(w_sheet) == "$B$4:$B$15");

                SimpleWorkbook::SimpleListValidation const * const k_simpleValidation = dynamic_cast<const SimpleWorkbook::SimpleListValidation*>(k_validation);
                CPPUNIT_ASSERT_MESSAGE("#46", k_simpleValidation != nullptr);

                const Interface::valueList_t w_values = k_simpleValidation->values(&w_workbook, w_sheet);
                CPPUNIT_ASSERT_MESSAGE("#47", w_values[9] == "Capricorne");
                CPPUNIT_ASSERT_MESSAGE("#48", w_values[10] == "Verseau");
                CPPUNIT_ASSERT_MESSAGE("#49", w_values[11] == "Poissons");

            } else if (k_validation->reference().name(w_sheet) == "K4:K6,M4:M6") {
                Interface::Read::ListValidation const * const k_listValidation = dynamic_cast<const Interface::Read::ListValidation *>(k_validation);
                CPPUNIT_ASSERT_MESSAGE("#50", k_listValidation != nullptr);

                CPPUNIT_ASSERT_MESSAGE("#51", k_listValidation->isValid());
                CPPUNIT_ASSERT_MESSAGE("#52", k_listValidation->isPromptShown());
                CPPUNIT_ASSERT_MESSAGE("#52.1", k_listValidation->promptTitle() == "Signes du zodiaque");
                CPPUNIT_ASSERT_MESSAGE("#52.2", k_listValidation->promptMessage() == "Choisissez votre signe...");
                CPPUNIT_ASSERT_MESSAGE("#53", k_listValidation->isAlertShown());
                CPPUNIT_ASSERT_MESSAGE("#53.1", k_listValidation->alertType() == Interface::atInformation);
                CPPUNIT_ASSERT_MESSAGE("#53.2", k_listValidation->alertTitle() == "Informations");
                CPPUNIT_ASSERT_MESSAGE("#53.3", k_listValidation->alertMessage() == "C'est pas bon!!");
                CPPUNIT_ASSERT_MESSAGE("#54", k_listValidation->isBlankAllowed());

                CPPUNIT_ASSERT_MESSAGE("#55 - "+ k_listValidation->rangeReference()->name(w_sheet), k_listValidation->rangeReference()->name(w_sheet) == "$B$4:$B$15");

                SimpleWorkbook::SimpleListValidation const * const k_simpleValidation = dynamic_cast<const SimpleWorkbook::SimpleListValidation*>(k_validation);
                CPPUNIT_ASSERT_MESSAGE("#56", k_simpleValidation != nullptr);

                const Interface::valueList_t w_values = k_simpleValidation->values(&w_workbook, w_sheet);
                CPPUNIT_ASSERT_MESSAGE("#57", w_values[0] == "Bélier");
                CPPUNIT_ASSERT_MESSAGE("#58", w_values[4] == "Lion");
                CPPUNIT_ASSERT_MESSAGE("#59", w_values[11] == "Poissons");

            } else if (k_validation->reference().name(w_sheet) == "D12:M12") {
                Interface::Read::CustomValidation const * const k_customValidation = dynamic_cast<const Interface::Read::CustomValidation *>(k_validation);
                CPPUNIT_ASSERT_MESSAGE("#60", k_customValidation != nullptr);

                CPPUNIT_ASSERT_MESSAGE("#61", k_customValidation->isValid());
                CPPUNIT_ASSERT_MESSAGE("#62", k_customValidation->isPromptShown());
                CPPUNIT_ASSERT_MESSAGE("#62.1", k_customValidation->promptTitle() == "un nombre supérieur à 9");
                CPPUNIT_ASSERT_MESSAGE("#62.2", k_customValidation->promptMessage() == "s'il te plait...");
                CPPUNIT_ASSERT_MESSAGE("#63", k_customValidation->isAlertShown());
                CPPUNIT_ASSERT_MESSAGE("#63.1", k_customValidation->alertType() == Interface::atError);
                CPPUNIT_ASSERT_MESSAGE("#63.2", k_customValidation->alertTitle() == "Mais non...");
                CPPUNIT_ASSERT_MESSAGE("#63.3", k_customValidation->alertMessage() == "... supérieur à 9 !!");
                CPPUNIT_ASSERT_MESSAGE("#64", k_customValidation->isBlankAllowed() == false);

                SimpleWorkbook::SimpleCustomValidation const * const k_simpleValidation = dynamic_cast<const SimpleWorkbook::SimpleCustomValidation*>(k_validation);
                CPPUNIT_ASSERT_MESSAGE("#66", k_simpleValidation != nullptr);

                CPPUNIT_ASSERT_MESSAGE("#67", k_simpleValidation->formula() == "D12>9");

            } else if (k_validation->reference().name(w_sheet) == "E18:G23") {
                Interface::Read::ListValidation const * const k_listValidation = dynamic_cast<const Interface::Read::ListValidation *>(k_validation);
                CPPUNIT_ASSERT_MESSAGE("#70", k_listValidation != nullptr);

                CPPUNIT_ASSERT_MESSAGE("#71", k_listValidation->isValid());
                CPPUNIT_ASSERT_MESSAGE("#72", k_listValidation->isPromptShown());
                CPPUNIT_ASSERT_MESSAGE("#72.1", k_listValidation->promptTitle() == "TMNT");
                CPPUNIT_ASSERT_MESSAGE("#72.2", k_listValidation->promptMessage() == "Teenage mutant ninja turtles");
                CPPUNIT_ASSERT_MESSAGE("#73", k_listValidation->isAlertShown());
                CPPUNIT_ASSERT_MESSAGE("#73.1", k_listValidation->alertType() == Interface::atError);
                CPPUNIT_ASSERT_MESSAGE("#74", k_listValidation->isBlankAllowed());

                CPPUNIT_ASSERT_MESSAGE("#75 - "+ k_listValidation->rangeReference()->name(w_sheet), k_listValidation->rangeReference()->name(w_sheet) == "'Feuil2'!$C$3:$C$6");

                SimpleWorkbook::SimpleListValidation const * const k_simpleValidation = dynamic_cast<const SimpleWorkbook::SimpleListValidation*>(k_validation);
                CPPUNIT_ASSERT_MESSAGE("#76", k_simpleValidation != nullptr);

                const Interface::valueList_t w_values = k_simpleValidation->values(&w_workbook, w_sheet);
                CPPUNIT_ASSERT_MESSAGE("#77", w_values[0] == "LEONARDO");
                CPPUNIT_ASSERT_MESSAGE("#78", w_values[1] == "DONATELLO");
                CPPUNIT_ASSERT_MESSAGE("#79", w_values[2] == "MICHELANGELO");
                CPPUNIT_ASSERT_MESSAGE("#80", w_values[3] == "RAPHAEL");

            } else
                CPPUNIT_ASSERT_MESSAGE("#100: règle de validation inconnue!", false);

        }


    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxReaderTestClass::testImages()
{
    try {

        using namespace Invoke::XLSX;

        SimpleWorkbook::SimpleWorkbook w_workbook;
        loadXlsxFile(XLSX_PATH "J.excel_images.xlsx", &w_workbook);

        // sheet BMP (/!\ Excel remplace les BMP par des PNG /!\)
        const Interface::Read::Worksheet* w_sheet = w_workbook.worksheet(0);

        CPPUNIT_ASSERT_MESSAGE("#01.01", w_sheet->imageCount() == 1);

        const Interface::Read::Image* w_image0 = w_sheet->image(0);
        CPPUNIT_ASSERT_MESSAGE("#01.02", w_image0->isValid());

        CPPUNIT_ASSERT_MESSAGE("#01.03", w_image0->topLeft().column() == 1);
        CPPUNIT_ASSERT_MESSAGE("#01.04", w_image0->topLeft().row() == 1);

        CPPUNIT_ASSERT_MESSAGE("#01.05", w_image0->rightBottom());
        CPPUNIT_ASSERT_MESSAGE("#01.06", w_image0->rightBottom()->column() == 10);
        CPPUNIT_ASSERT_MESSAGE("#01.07", w_image0->rightBottom()->row() == 29);

        CPPUNIT_ASSERT_MESSAGE("#01.08", w_image0->cropRectangle() == nullptr);

        CPPUNIT_ASSERT_MESSAGE("#01.09", w_image0->property() == Interface::ipMoveWithCells);

        // sheet GIF
        w_sheet = w_workbook.worksheet(1);

        CPPUNIT_ASSERT_MESSAGE("#02.01", w_sheet->imageCount() == 1);

        const Interface::Read::Image* w_image1 = w_sheet->image(0);
        CPPUNIT_ASSERT_MESSAGE("#02.02", w_image1->isValid());

        CPPUNIT_ASSERT_MESSAGE("#02.03", w_image1->topLeft().column() == 1);
        CPPUNIT_ASSERT_MESSAGE("#02.04", w_image1->topLeft().row() == 1);

        CPPUNIT_ASSERT_MESSAGE("#02.05", w_image1->rightBottom());
        CPPUNIT_ASSERT_MESSAGE("#02.06", w_image1->rightBottom()->column() == 8);
        CPPUNIT_ASSERT_MESSAGE("#02.07", w_image1->rightBottom()->row() == 23);

        CPPUNIT_ASSERT_MESSAGE("#02.08", w_image1->cropRectangle() == nullptr);

        CPPUNIT_ASSERT_MESSAGE("#02.09", w_image1->property() == Interface::ipMoveWithCells);

        CPPUNIT_ASSERT_MESSAGE("#02.10", w_image1->type() == Interface::itGIF);

        // sheet JPG
        w_sheet = w_workbook.worksheet(2);

        CPPUNIT_ASSERT_MESSAGE("#03.01", w_sheet->imageCount() == 1);

        const Interface::Read::Image* w_image2 = w_sheet->image(0);
        CPPUNIT_ASSERT_MESSAGE("#03.02", w_image2->isValid());

        CPPUNIT_ASSERT_MESSAGE("#03.03", w_image2->topLeft().column() == 1);
        CPPUNIT_ASSERT_MESSAGE("#03.04", w_image2->topLeft().row() == 1);

        CPPUNIT_ASSERT_MESSAGE("#03.05", w_image2->rightBottom());
        CPPUNIT_ASSERT_MESSAGE("#03.06", w_image2->rightBottom()->column() == 10);
        CPPUNIT_ASSERT_MESSAGE("#03.07", w_image2->rightBottom()->row() == 29);

        CPPUNIT_ASSERT_MESSAGE("#03.08", w_image2->cropRectangle() == nullptr);

        CPPUNIT_ASSERT_MESSAGE("#03.09", w_image2->property() == Interface::ipMoveWithCells);

        CPPUNIT_ASSERT_MESSAGE("#03.10", w_image2->type() == Interface::itJPG);

        // sheet PNG
        w_sheet = w_workbook.worksheet(3);

        CPPUNIT_ASSERT_MESSAGE("#04.01", w_sheet->imageCount() == 1);

        const Interface::Read::Image* w_image3 = w_sheet->image(0);
        CPPUNIT_ASSERT_MESSAGE("#04.02", w_image3->isValid());

        CPPUNIT_ASSERT_MESSAGE("#04.03", w_image3->topLeft().column() == 1);
        CPPUNIT_ASSERT_MESSAGE("#04.04", w_image3->topLeft().row() == 1);

        CPPUNIT_ASSERT_MESSAGE("#04.05", w_image3->rightBottom());
        CPPUNIT_ASSERT_MESSAGE("#04.06", w_image3->rightBottom()->column() == 8);
        CPPUNIT_ASSERT_MESSAGE("#04.07", w_image3->rightBottom()->row() == 23);

        CPPUNIT_ASSERT_MESSAGE("#04.08", w_image3->cropRectangle() == nullptr);

        CPPUNIT_ASSERT_MESSAGE("#04.09", w_image3->property() == Interface::ipMoveWithCells);

        CPPUNIT_ASSERT_MESSAGE("#04.10", w_image3->type() == Interface::itPNG);

        // sheet Déplacement
        w_sheet = w_workbook.worksheet(4);

        CPPUNIT_ASSERT_MESSAGE("#05.01", w_sheet->imageCount() == 2);

        const Interface::Read::Image* w_image41 = w_sheet->image(0);
        CPPUNIT_ASSERT_MESSAGE("#05.02", w_image41->isValid());

        CPPUNIT_ASSERT_MESSAGE("#05.03", w_image41->topLeft().column() == 1);
        CPPUNIT_ASSERT_MESSAGE("#05.04", w_image41->topLeft().row() == 1);

        CPPUNIT_ASSERT_MESSAGE("#05.05", w_image41->rightBottom());
        CPPUNIT_ASSERT_MESSAGE("#05.06", w_image41->rightBottom()->column() == 3);
        CPPUNIT_ASSERT_MESSAGE("#05.07", w_image41->rightBottom()->row() == 9);

        CPPUNIT_ASSERT_MESSAGE("#05.08", w_image41->cropRectangle() == nullptr);

        CPPUNIT_ASSERT_MESSAGE("#05.09", w_image41->property() == Interface::ipStatic);

        CPPUNIT_ASSERT_MESSAGE("#05.10", w_image41->type() == Interface::itPNG);

        const Interface::Read::Image* w_image42 = w_sheet->image(1);
        CPPUNIT_ASSERT_MESSAGE("#05.11", w_image42->isValid());

        CPPUNIT_ASSERT_MESSAGE("#05.12", w_image42->topLeft().column() == 5);
        CPPUNIT_ASSERT_MESSAGE("#05.13", w_image42->topLeft().row() == 1);

        CPPUNIT_ASSERT_MESSAGE("#05.14", w_image42->rightBottom());
        CPPUNIT_ASSERT_MESSAGE("#05.15", w_image42->rightBottom()->column() == 7);
        CPPUNIT_ASSERT_MESSAGE("#05.16", w_image42->rightBottom()->row() == 9);

        CPPUNIT_ASSERT_MESSAGE("#05.17", w_image42->cropRectangle() == nullptr);

        CPPUNIT_ASSERT_MESSAGE("#05.18", w_image42->property() == Interface::ipMoveAndResizeWithCells);

        CPPUNIT_ASSERT_MESSAGE("#05.19", w_image42->type() == Interface::itJPG);

        // sheet Rogner
        w_sheet = w_workbook.worksheet(5);

        CPPUNIT_ASSERT_MESSAGE("#06.01", w_sheet->imageCount() == 1);

        const Interface::Read::Image* w_image5 = w_sheet->image(0);
        CPPUNIT_ASSERT_MESSAGE("#06.02", w_image5->isValid());

        CPPUNIT_ASSERT_MESSAGE("#06.03", w_image5->topLeft().column() == 1);
        CPPUNIT_ASSERT_MESSAGE("#06.04", w_image5->topLeft().row() == 5);

        CPPUNIT_ASSERT_MESSAGE("#06.05", w_image5->rightBottom());
        CPPUNIT_ASSERT_MESSAGE("#06.06", w_image5->rightBottom()->column() == 4);
        CPPUNIT_ASSERT_MESSAGE("#06.07", w_image5->rightBottom()->row() == 10);

        CPPUNIT_ASSERT_MESSAGE("#06.08", w_image5->cropRectangle());

        CPPUNIT_ASSERT_MESSAGE("#06.09", w_image5->property() == Interface::ipMoveWithCells);

        CPPUNIT_ASSERT_MESSAGE("#06.10", w_image5->type() == Interface::itPNG);

    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxReaderTestClass::testHyperlinks()
{
    try {

        using namespace Invoke::XLSX;

        SimpleWorkbook::SimpleWorkbook w_workbook;
        loadXlsxFile(XLSX_PATH "K.excel_hyperlinks.xlsx", &w_workbook);

        const Interface::Read::Worksheet* w_sheet = w_workbook.worksheet(0);

        CPPUNIT_ASSERT_MESSAGE("#00", w_sheet->hyperlinkCount() == 9);

        const Interface::Read::Hyperlink* w_hyperlink = w_sheet->hyperlink(0);
        CPPUNIT_ASSERT_MESSAGE("#01.01", w_hyperlink->reference().name(w_sheet) == "C4");
        CPPUNIT_ASSERT_MESSAGE("#01.02", w_hyperlink->display() == "Feuil1!G4");
        CPPUNIT_ASSERT_MESSAGE("#01.03", w_hyperlink->tooltip() == "");
        CPPUNIT_ASSERT_MESSAGE("#01.04", w_hyperlink->location()->name(w_sheet) == "G4");

        w_hyperlink = w_sheet->hyperlink(1);
        CPPUNIT_ASSERT_MESSAGE("#02.01", w_hyperlink->reference().name(w_sheet) == "C6");
        CPPUNIT_ASSERT_MESSAGE("#02.02", w_hyperlink->display() == "Feuil1!F6:H6");
        CPPUNIT_ASSERT_MESSAGE("#02.03", w_hyperlink->tooltip() == "info-bulle");
        CPPUNIT_ASSERT_MESSAGE("#02.04", w_hyperlink->location()->name(w_sheet) == "F6:H6");

        w_hyperlink = w_sheet->hyperlink(2);
        CPPUNIT_ASSERT_MESSAGE("#03.01", w_hyperlink->reference().name(w_sheet) == "C8");
        CPPUNIT_ASSERT_MESSAGE("#03.02", w_hyperlink->display() == "ICI");
        CPPUNIT_ASSERT_MESSAGE("#03.03", w_hyperlink->tooltip() == "");
        CPPUNIT_ASSERT_MESSAGE("#03.04", w_hyperlink->definedName()->name() == "ICI");

        w_hyperlink = w_sheet->hyperlink(3);
        CPPUNIT_ASSERT_MESSAGE("#04.01", w_hyperlink->reference().name(w_sheet) == "C10");
        CPPUNIT_ASSERT_MESSAGE("#04.02", w_hyperlink->display() == "");
        CPPUNIT_ASSERT_MESSAGE("#04.03", w_hyperlink->tooltip() == "");

        std::string w_mail;
        std::string w_subject;
        CPPUNIT_ASSERT_MESSAGE("#04.04", w_hyperlink->getMailLocation(w_mail, w_subject));
        CPPUNIT_ASSERT_MESSAGE("#04.05", w_mail == "bill.gates@microsoft.com");
        CPPUNIT_ASSERT_MESSAGE("#04.06", w_subject == "coucou");

        w_hyperlink = w_sheet->hyperlink(4);
        CPPUNIT_ASSERT_MESSAGE("#05.01", w_hyperlink->reference().name(w_sheet) == "C12");
        CPPUNIT_ASSERT_MESSAGE("#05.02", w_hyperlink->display() == "");
        CPPUNIT_ASSERT_MESSAGE("#05.03", w_hyperlink->tooltip() == "");
        CPPUNIT_ASSERT_MESSAGE("#05.04", *w_hyperlink->fileLocation() == "C:\\Windows\\notepad.exe");

        w_hyperlink = w_sheet->hyperlink(5);
        CPPUNIT_ASSERT_MESSAGE("#06.01", w_hyperlink->reference().name(w_sheet) == "C16:E20");
        CPPUNIT_ASSERT_MESSAGE("#06.02", w_hyperlink->display() == "Feuil1!K16:M20");
        CPPUNIT_ASSERT_MESSAGE("#06.03", w_hyperlink->tooltip() == "");
        CPPUNIT_ASSERT_MESSAGE("#06.04", w_hyperlink->location()->name(nullptr) == "'Feuil1'!K16:M20");

        w_hyperlink = w_sheet->hyperlink(6);
        CPPUNIT_ASSERT_MESSAGE("#07.01", w_hyperlink->reference().name(nullptr) == "D18");
        CPPUNIT_ASSERT_MESSAGE("#07.02", w_hyperlink->display() == "Feuil1!P16:R20");
        CPPUNIT_ASSERT_MESSAGE("#07.03", w_hyperlink->tooltip() == "");
        CPPUNIT_ASSERT_MESSAGE("#07.04", w_hyperlink->location()->name(nullptr) == "'Feuil1'!P16:R20");

        w_hyperlink = w_sheet->hyperlink(7);
        CPPUNIT_ASSERT_MESSAGE("#08.01", w_hyperlink->reference().name(nullptr) == "C24");
        CPPUNIT_ASSERT_MESSAGE("#08.02", w_hyperlink->display() == "Feuil2!C5:D8");
        CPPUNIT_ASSERT_MESSAGE("#08.03", w_hyperlink->tooltip() == "");
        CPPUNIT_ASSERT_MESSAGE("#08.04", w_hyperlink->location()->name(w_sheet) == "'Feuil2'!C5:D8");

        w_hyperlink = w_sheet->hyperlink(8);
        CPPUNIT_ASSERT_MESSAGE("#09.01", w_hyperlink->reference().name(nullptr) == "C26");
        CPPUNIT_ASSERT_MESSAGE("#09.02", w_hyperlink->display() == "PURPLE");
        CPPUNIT_ASSERT_MESSAGE("#09.03", w_hyperlink->tooltip() == "");
        CPPUNIT_ASSERT_MESSAGE("#09.04", w_hyperlink->definedName()->name() == "PURPLE");

    } catch (CppUnit::Exception) {
        throw;
    } catch (std::exception& w_exception) {
        CPPUNIT_ASSERT_MESSAGE(std::string(std::string("standard exception ! <") + w_exception.what() + std::string(">")).c_str(), false);
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxReaderTestClass::testAXAGS()
{
    try {

        using namespace Invoke::XLSX;

        SimpleWorkbook::SimpleWorkbook w_workbook;
        loadXlsxFile(XLSX_PATH "L.axags_strange.xlsx", &w_workbook);

        CPPUNIT_ASSERT_MESSAGE("#01", w_workbook.worksheetCount() == 2);
        CPPUNIT_ASSERT_MESSAGE("#02", w_workbook.worksheet(0)->name() == "SE020117");
        CPPUNIT_ASSERT_MESSAGE("#02", w_workbook.worksheet(1)->name() == "Context");

        const Interface::Read::Worksheet* w_worksheet = w_workbook.worksheet(0);

        const Interface::Read::CellFormat* w_format = w_worksheet->cellFormat(1, 14);
        CPPUNIT_ASSERT_MESSAGE("#03", w_format != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#04", w_format->fontName() == "Arial");
        CPPUNIT_ASSERT_MESSAGE("#05", w_format->fontSize() == 5);
        CPPUNIT_ASSERT_MESSAGE("#06", w_format->fontColor() == 0xFF000000);
        CPPUNIT_ASSERT_MESSAGE("#07", w_format->isFontBolded() == true);
        CPPUNIT_ASSERT_MESSAGE("#08", w_format->isFontItalicized() == false);
        CPPUNIT_ASSERT_MESSAGE("#09", w_format->isFontUnderlined() == false);

    } catch (CppUnit::Exception) {
        throw;
    } catch (std::exception& w_exception) {
        CPPUNIT_ASSERT_MESSAGE(std::string(std::string("standard exception ! <") + w_exception.what() + std::string(">")).c_str(), false);
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxReaderTestClass::testCASA()
{
    try {

        using namespace Invoke::XLSX;

        SimpleWorkbook::SimpleWorkbook w_workbook;
        loadXlsxFile(XLSX_PATH "M.casa_strange.xlsx", &w_workbook);

        CPPUNIT_ASSERT_MESSAGE("#01", w_workbook.worksheetCount() == 33);
        CPPUNIT_ASSERT_MESSAGE("#02", w_workbook.worksheet(0)->name() == "S040101010");
        CPPUNIT_ASSERT_MESSAGE("#02", w_workbook.worksheet(32)->name() == "CONTEXT");

        const Interface::Read::Worksheet* w_worksheet = w_workbook.worksheet(0);

        const Interface::Read::CellValue* w_value = w_worksheet->cellValue(0, 10);
        CPPUNIT_ASSERT_MESSAGE("#03", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#04", w_value->type() == Interface::ctString);
        CPPUNIT_ASSERT_MESSAGE("#05", w_value->string() == "S.04.01.01.01 - Entreprises et toutes les succursales");

        w_value = w_worksheet->cellValue(5, 17);
        CPPUNIT_ASSERT_MESSAGE("#06", w_value != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#07", w_value->type() == Interface::ctString);
        CPPUNIT_ASSERT_MESSAGE("#08", w_value->string() == "56000,000");

    } catch (CppUnit::Exception) {
        throw;
    } catch (std::exception& w_exception) {
        CPPUNIT_ASSERT_MESSAGE(std::string(std::string("standard exception ! <") + w_exception.what() + std::string(">")).c_str(), false);
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxReaderTestClass::testComments()
{
    try {

        using namespace Invoke::XLSX;

        SimpleWorkbook::SimpleWorkbook w_workbook;
        loadXlsxFile(XLSX_PATH "N.excel_comments.xlsx", &w_workbook);

        CPPUNIT_ASSERT_MESSAGE("#00", w_workbook.worksheetCount() == 6);

        // sheet 1
        const Interface::Read::Worksheet* w_sheet = w_workbook.worksheet(0);
        CPPUNIT_ASSERT_MESSAGE("#01.00", w_sheet->commentCount() == 5);
        for (unsigned int i = 0; i < 5; ++i) {
            const Interface::Read::Comment* w_comment = w_sheet->comment(i);

            if (w_comment->reference().name(w_sheet) == "C5") {
                CPPUNIT_ASSERT_MESSAGE("#01.01.1", w_comment->runCount() == 1);
                CPPUNIT_ASSERT_MESSAGE("#01.01.2", w_comment->runText(0) != nullptr);
                CPPUNIT_ASSERT_MESSAGE("#01.01.3", w_comment->runText(0)->substr(0, 9) == "Art. 1er.");
                CPPUNIT_ASSERT_MESSAGE("#01.01.4", w_comment->visibility() == Interface::vHidden);

            } else if (w_comment->reference().name(w_sheet) == "C10") {
                CPPUNIT_ASSERT_MESSAGE("#01.02.1", w_comment->runCount() == 1);
                CPPUNIT_ASSERT_MESSAGE("#01.02.2", w_comment->runText(0) != nullptr);
                CPPUNIT_ASSERT_MESSAGE("#01.02.3", w_comment->runText(0)->substr(0, 7) == "Art. 2.");
                CPPUNIT_ASSERT_MESSAGE("#01.02.4", w_comment->visibility() == Interface::vVisible);

            } else if (w_comment->reference().name(w_sheet) == "H5") {
                CPPUNIT_ASSERT_MESSAGE("#01.03.1", w_comment->runCount() == 1);
                CPPUNIT_ASSERT_MESSAGE("#01.03.2", w_comment->runText(0) != nullptr);
                CPPUNIT_ASSERT_MESSAGE("#01.03.3", w_comment->runText(0)->substr(0, 7) == "Art. 3.");
                CPPUNIT_ASSERT_MESSAGE("#01.03.4", w_comment->property() == Interface::cpMoveAndResizeWithCells);

            } else if (w_comment->reference().name(w_sheet) == "H10") {
                CPPUNIT_ASSERT_MESSAGE("#01.04.1", w_comment->runCount() == 1);
                CPPUNIT_ASSERT_MESSAGE("#01.04.2", w_comment->runText(0) != nullptr);
                CPPUNIT_ASSERT_MESSAGE("#01.04.3", w_comment->runText(0)->substr(0, 7) == "Art. 4.");
                CPPUNIT_ASSERT_MESSAGE("#01.04.4", w_comment->property() == Interface::cpMoveWithCells);

            } else if (w_comment->reference().name(w_sheet) == "H15") {
                CPPUNIT_ASSERT_MESSAGE("#01.05.1", w_comment->runCount() == 1);
                CPPUNIT_ASSERT_MESSAGE("#01.05.2", w_comment->runText(0) != nullptr);
                CPPUNIT_ASSERT_MESSAGE("#01.05.3", w_comment->runText(0)->substr(0, 7) == "Art. 5.");
                CPPUNIT_ASSERT_MESSAGE("#01.05.4", w_comment->property() == Interface::cpStatic);

            } else
                CPPUNIT_ASSERT_MESSAGE("#100: commentaire inconnu!", false);
        }

        const Interface::Read::Comment* w_comment = w_sheet->comment(2, 4);
        CPPUNIT_ASSERT_MESSAGE("#01.06.0", w_comment != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#01.06.1", w_comment->runCount() == 1);
        CPPUNIT_ASSERT_MESSAGE("#01.06.2", w_comment->runText(0) != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#01.06.3", w_comment->runText(0)->substr(0, 9) == "Art. 1er.");
        CPPUNIT_ASSERT_MESSAGE("#01.06.4", w_comment->visibility() == Interface::vHidden);

        w_comment = w_sheet->comment(1, 1);
        CPPUNIT_ASSERT_MESSAGE("#01.07.1", w_comment == nullptr);

        // sheet 2
        w_sheet = w_workbook.worksheet(1);
        CPPUNIT_ASSERT_MESSAGE("#02.00", w_sheet->commentCount() == 2);
        for (unsigned int i = 0; i < 2; ++i) {
            const Interface::Read::Comment* w_comment = w_sheet->comment(i);

            if (w_comment->reference().name(w_sheet) == "C4") {
                CPPUNIT_ASSERT_MESSAGE("#02.01.1", w_comment->runCount() == 1);
                CPPUNIT_ASSERT_MESSAGE("#02.01.2", w_comment->runText(0) != nullptr);
                CPPUNIT_ASSERT_MESSAGE("#02.01.3", w_comment->runText(0)->substr(0, 7) == "Art. 6.");
                CPPUNIT_ASSERT_MESSAGE("#02.01.4", w_comment->autoSize() == true);

            } else if (w_comment->reference().name(w_sheet) == "C10") {
                CPPUNIT_ASSERT_MESSAGE("#02.02.1", w_comment->runCount() == 1);
                CPPUNIT_ASSERT_MESSAGE("#02.02.2", w_comment->runText(0) != nullptr);
                CPPUNIT_ASSERT_MESSAGE("#02.02.3", w_comment->runText(0)->substr(0, 7) == "Art. 7.");
                CPPUNIT_ASSERT_MESSAGE("#02.02.4", w_comment->autoSize() == false);
                CPPUNIT_ASSERT_MESSAGE("#02.02.5", w_comment->topLeft().column() == 5);
                CPPUNIT_ASSERT_MESSAGE("#02.02.6", w_comment->topLeft().row() == 14);
                CPPUNIT_ASSERT_MESSAGE("#02.02.7", w_comment->rightBottom().column() == 9);
                CPPUNIT_ASSERT_MESSAGE("#02.02.8", w_comment->rightBottom().row() == 20);

            } else
                CPPUNIT_ASSERT_MESSAGE("#200: commentaire inconnu!", false);
        }

        // sheet 3
        w_sheet = w_workbook.worksheet(2);
        CPPUNIT_ASSERT_MESSAGE("#03.00", w_sheet->commentCount() == 2);
        for (unsigned int i = 0; i < 2; ++i) {
            const Interface::Read::Comment* w_comment = w_sheet->comment(i);

            if (w_comment->reference().name(w_sheet) == "C5") {
                CPPUNIT_ASSERT_MESSAGE("#03.01.01", w_comment->runCount() == 5);
                CPPUNIT_ASSERT_MESSAGE("#03.01.02", w_comment->runText(0) != nullptr);
                CPPUNIT_ASSERT_MESSAGE("#03.01.03", w_comment->runText(0)->substr(0, 7) == "Art. 8.");
                CPPUNIT_ASSERT_MESSAGE("#03.01.04", w_comment->runText(1) != nullptr);
                CPPUNIT_ASSERT_MESSAGE("#03.01.05", w_comment->runText(1)->substr(0, 24) == " La Loi ne doit \xC3\xA9tablir");
                CPPUNIT_ASSERT_MESSAGE("#03.01.06", w_comment->runText(2) != nullptr);
                CPPUNIT_ASSERT_MESSAGE("#03.01.07", *w_comment->runText(2) == "\r\n");
                CPPUNIT_ASSERT_MESSAGE("#03.01.08", w_comment->runText(3) != nullptr);
                CPPUNIT_ASSERT_MESSAGE("#03.01.09", w_comment->runText(3)->substr(0, 7) == "Art. 9.");
                CPPUNIT_ASSERT_MESSAGE("#03.01.10", w_comment->runText(4) != nullptr);
                CPPUNIT_ASSERT_MESSAGE("#03.01.11", w_comment->runText(4)->substr(0, 7) == " Tout h");
                CPPUNIT_ASSERT_MESSAGE("#03.01.12", w_comment->runFont(0)->name == "Tahoma");
                CPPUNIT_ASSERT_MESSAGE("#03.01.13", w_comment->runFont(0)->size == 12);
                CPPUNIT_ASSERT_MESSAGE("#03.01.14", w_comment->runFont(0)->color == 0xFF000000);
                CPPUNIT_ASSERT_MESSAGE("#03.01.15", w_comment->runFont(0)->bold);
                CPPUNIT_ASSERT_MESSAGE("#03.01.16", w_comment->runFont(0)->italic);
                CPPUNIT_ASSERT_MESSAGE("#03.01.17", w_comment->runFont(0)->underline);
                CPPUNIT_ASSERT_MESSAGE("#03.01.18", w_comment->runFont(1)->size == 9);
                CPPUNIT_ASSERT_MESSAGE("#03.01.19", w_comment->runFont(3)->name == "Arial Rounded MT Bold");
                CPPUNIT_ASSERT_MESSAGE("#03.01.20", w_comment->runFont(3)->size == 12);
                CPPUNIT_ASSERT_MESSAGE("#03.01.21", w_comment->runFont(3)->color == 0xFF3366FF);
                CPPUNIT_ASSERT_MESSAGE("#03.01.22", w_comment->runFont(3)->bold);
                CPPUNIT_ASSERT_MESSAGE("#03.01.23", w_comment->runFont(3)->italic == false);
                CPPUNIT_ASSERT_MESSAGE("#03.01.24", w_comment->runFont(3)->underline == false);
                CPPUNIT_ASSERT_MESSAGE("#03.01.25", w_comment->runFont(4)->size == 9);
                CPPUNIT_ASSERT_MESSAGE("#03.01.26", w_comment->hyperlink() == "");

            } else if (w_comment->reference().name(w_sheet) == "C11") {
                CPPUNIT_ASSERT_MESSAGE("#03.02.1", w_comment->runCount() == 1);
                CPPUNIT_ASSERT_MESSAGE("#03.02.2", w_comment->runText(0) != nullptr);
                CPPUNIT_ASSERT_MESSAGE("#03.02.3", *w_comment->runText(0) == "https://www.legifrance.gouv.fr/Droit-francais/Constitution/Declaration-des-Droits-de-l-Homme-et-du-Citoyen-de-1789");
                CPPUNIT_ASSERT_MESSAGE("#03.02.4", w_comment->hyperlink() == "https://www.legifrance.gouv.fr/Droit-francais/Constitution/Declaration-des-Droits-de-l-Homme-et-du-Citoyen-de-1789#https://www.legifrance.gouv.fr/Droit-francais/Constitution/Declaration-des-Droits-de-l-Homme-et-du-Citoyen-de-1789");

            } else
                CPPUNIT_ASSERT_MESSAGE("#300: commentaire inconnu!", false);
        }

        // sheet 4
        w_sheet = w_workbook.worksheet(3);
        CPPUNIT_ASSERT_MESSAGE("#04.00", w_sheet->commentCount() == 2);
        for (unsigned int i = 0; i < 2; ++i) {
            const Interface::Read::Comment* w_comment = w_sheet->comment(i);

            if (w_comment->reference().name(w_sheet) == "C4") {
                CPPUNIT_ASSERT_MESSAGE("#04.01.1", w_comment->fillColor() == 0xFF000FC0);

            } else if (w_comment->reference().name(w_sheet) == "C10") {
                CPPUNIT_ASSERT_MESSAGE("#04.02.1", w_comment->fillColor() == 0xFF000C9F);

            } else
                CPPUNIT_ASSERT_MESSAGE("#400: commentaire inconnu!", false);
        }

        // sheet 5
        w_sheet = w_workbook.worksheet(4);
        CPPUNIT_ASSERT_MESSAGE("#05.00", w_sheet->commentCount() == 2);
        for (unsigned int i = 0; i < 2; ++i) {
            const Interface::Read::Comment* w_comment = w_sheet->comment(i);

            if (w_comment->reference().name(w_sheet) == "C5") {
                CPPUNIT_ASSERT_MESSAGE("#05.01.1", w_comment->author() == "Jean-Christophe PHILIPPE");

            } else if (w_comment->reference().name(w_sheet) == "E8") {
                CPPUNIT_ASSERT_MESSAGE("#05.02.1", w_comment->author() == "Adrien DEGRANGE");

            } else
                CPPUNIT_ASSERT_MESSAGE("#500: commentaire inconnu!", false);
        }

        // sheet 6
        w_sheet = w_workbook.worksheet(5);
        CPPUNIT_ASSERT_MESSAGE("#06.00", w_sheet->commentCount() == 2);
        for (unsigned int i = 0; i < 2; ++i) {
            const Interface::Read::Comment* w_comment = w_sheet->comment(i);

            if (w_comment->reference().name(w_sheet) == "C8") {
                CPPUNIT_ASSERT_MESSAGE("#06.01.1", w_comment->alignment() == Interface::haCenter);

            } else if (w_comment->reference().name(w_sheet) == "C16") {
                CPPUNIT_ASSERT_MESSAGE("#06.02.1", w_comment->alignment() == Interface::haRight);

            } else
                CPPUNIT_ASSERT_MESSAGE("#600: commentaire inconnu!", false);
        }

    } catch (CppUnit::Exception) {
        throw;
    } catch (std::exception& w_exception) {
        CPPUNIT_ASSERT_MESSAGE(std::string(std::string("standard exception ! <") + w_exception.what() + std::string(">")).c_str(), false);
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxReaderTestClass::testFilters()
{
    try {

        using namespace Invoke::XLSX;

        SimpleWorkbook::SimpleWorkbook w_workbook;
        loadXlsxFile(XLSX_PATH "O.excel_filters.xlsx", &w_workbook);

        CPPUNIT_ASSERT_MESSAGE("#00", w_workbook.worksheetCount() == 1);

        const Interface::Read::Worksheet* w_sheet = w_workbook.worksheet(0);
        const Interface::Read::Filter* k_filter = w_sheet->filter();
        
        CPPUNIT_ASSERT_MESSAGE("#01", k_filter != nullptr);
        CPPUNIT_ASSERT_MESSAGE("#02", k_filter->rangeReference()->name(nullptr) == "France!B2:E105"); 

    } catch (CppUnit::Exception) {
        throw;
    } catch (std::exception& w_exception) {
        CPPUNIT_ASSERT_MESSAGE(std::string(std::string("standard exception ! <") + w_exception.what() + std::string(">")).c_str(), false);
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxReaderTestClass::testRichText()
{
	try {

		using namespace Invoke::XLSX;

		SimpleWorkbook::SimpleWorkbook w_workbook;
		loadXlsxFile(XLSX_PATH "P.excel_richtext.xlsx", &w_workbook);

		CPPUNIT_ASSERT_MESSAGE("#00", w_workbook.worksheetCount() == 1);
		const Interface::Read::Worksheet* w_worksheet = w_workbook.worksheet(0);

		const Interface::Read::CellValue* w_value = nullptr;

		w_value = w_worksheet->cellValue(3, 2);
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.01", w_value != nullptr);
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.02", w_value->type() == Interface::ctRichText);
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.03 <" + w_value->string() + ">", w_value->string() == "Flatterie regarda les indicateurs. Timberlake se trouvait dans les cellules d’hibernation, à présent, mais il ne bougeait pas - il s’était arrêté.");

		const Interface::Read::RichText* w_richtext = w_value->text();
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.04", w_richtext != nullptr);
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.05", w_richtext->text() == "Flatterie regarda les indicateurs. Timberlake se trouvait dans les cellules d’hibernation, à présent, mais il ne bougeait pas - il s’était arrêté.");
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.06", w_richtext->runCount() == 12);

		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.07.00", *(w_richtext->runText(0)) == "Flatterie");
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.07.01", *(w_richtext->runText(1)) == " regarda les ");
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.07.02", *(w_richtext->runText(2)) == "indicateurs");
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.07.03", *(w_richtext->runText(3)) == ". ");
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.07.04", *(w_richtext->runText(4)) == "Timberlake");
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.07.05", *(w_richtext->runText(5)) == " se trou");
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.07.06", *(w_richtext->runText(6)) == "vait dans les cell");
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.07.07", *(w_richtext->runText(7)) == "ules d’");
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.07.08", *(w_richtext->runText(8)) == "hibernation");
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.07.09", *(w_richtext->runText(9)) == ", à présent, mais il ne bougeait pas - ");
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.07.10", *(w_richtext->runText(10)) == "il s’était arrêté");
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.07.11", *(w_richtext->runText(11)) == ".");
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.07.12", w_richtext->runText(12) == nullptr);

		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.08.00", *(w_richtext->runFont(0)) == Interface::font_t({ "Times New Roman", 16, 0xFF000000, true, false, false }));
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.08.01", *(w_richtext->runFont(1)) == Interface::font_t({ "Times New Roman", 16, 0xFF000000, false, false, false }));
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.08.02", *(w_richtext->runFont(2)) == Interface::font_t({ "Times New Roman", 16, 0xFF000000, false, false, true }));
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.08.03", *(w_richtext->runFont(3)) == Interface::font_t({ "Times New Roman", 16, 0xFF000000, false, false, false }));
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.08.04", *(w_richtext->runFont(4)) == Interface::font_t({ "Times New Roman", 16, 0xFF5B9BD5, true, false, false }));
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.08.05", *(w_richtext->runFont(5)) == Interface::font_t({ "Times New Roman", 16, 0xFF000000, false, false, false }));
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.08.06", *(w_richtext->runFont(6)) == Interface::font_t({ "Times New Roman", 16, 0xFF000000, false, true, false }));
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.08.07", *(w_richtext->runFont(7)) == Interface::font_t({ "Times New Roman", 16, 0xFF000000, false, false, false }));
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.08.08", *(w_richtext->runFont(8)) == Interface::font_t({ "Broadway", 20, 0xFF000000, false, false, false }));
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.08.09", *(w_richtext->runFont(9)) == Interface::font_t({ "Times New Roman", 16, 0xFF000000, false, false, false }));
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.08.10", *(w_richtext->runFont(10)) == Interface::font_t({ "Times New Roman", 20, 0xFFFF0000, false, true, false }));
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.08.11", *(w_richtext->runFont(11)) == Interface::font_t({ "Times New Roman", 16, 0xFF000000, false, false, false }));
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.08.12", w_richtext->runFont(12) == nullptr);


		w_value = w_worksheet->cellValue(3, 6);
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.09", w_value != nullptr);
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.10", w_value->type() == Interface::ctString);
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.11 <" + w_value->string() + ">", w_value->string() == "Si seulement c’était aussi simple, dit Flatterie.");

		w_richtext = w_value->text();
		CPPUNIT_ASSERT_MESSAGE("#RICHTEXT.12", w_richtext == nullptr);


	} catch (CppUnit::Exception) {
		throw;
	} catch (std::exception& w_exception) {
		CPPUNIT_ASSERT_MESSAGE(std::string(std::string("standard exception ! <") + w_exception.what() + std::string(">")).c_str(), false);
	} catch (...) {
		CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
	}
}
