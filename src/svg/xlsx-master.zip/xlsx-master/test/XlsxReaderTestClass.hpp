/*!
 * \file        InvXlsxReaderTestClass.hpp
 * \author      Invoke - Jean-Christophe PHILIPPE (jcphilippe\@invoke.fr)
 * \date        Juillet 2015
 * \copyright   SA Invoke
 */

#ifndef InvXlsxReaderTestClass_hpp
#define InvXlsxReaderTestClass_hpp

#include "xlsx/WorkbookWriteInterface.hpp"

#include <cppunit/extensions/HelperMacros.h>

class XlsxReaderTestClass : public CPPUNIT_NS::TestFixture {
    CPPUNIT_TEST_SUITE(XlsxReaderTestClass);

    CPPUNIT_TEST(testNull);
    CPPUNIT_TEST(testValues);
    CPPUNIT_TEST(testFormats);
    CPPUNIT_TEST(testColumnsAndRows);
    CPPUNIT_TEST(testDefinedNames);
    CPPUNIT_TEST(testSelections);
    CPPUNIT_TEST(testPageSetting);
    CPPUNIT_TEST(testConditionalFormatting);
    CPPUNIT_TEST(testValidations);
    CPPUNIT_TEST(testImages);
    CPPUNIT_TEST(testHyperlinks);
    CPPUNIT_TEST(testAXAGS);
    CPPUNIT_TEST(testCASA);
    CPPUNIT_TEST(testComments);
    CPPUNIT_TEST(testFilters);
	CPPUNIT_TEST(testRichText);

    CPPUNIT_TEST_SUITE_END();

private:
    void loadXlsxFile(const std::string&, Invoke::XLSX::Interface::Write::Workbook*) const;

private:
    void testNull();
    void testValues();
    void testFormats();
    void testColumnsAndRows();
    void testDefinedNames();
    void testSelections();
    void testPageSetting();
    void testConditionalFormatting();
    void testValidations();
    void testImages();
    void testHyperlinks();
    void testAXAGS();
    void testCASA();
    void testComments();
    void testFilters();
	void testRichText();
};

#endif  /* InvXlsxReaderTestClass_hpp */

