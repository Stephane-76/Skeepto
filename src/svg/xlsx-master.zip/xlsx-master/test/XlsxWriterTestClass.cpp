/*!
 * \file        XlsxWriterTestClass.cpp
 * \author      Invoke - Jean-Christophe PHILIPPE (jcphilippe\@invoke.fr)
 * \date        Octobre 2014
 * \copyright   SA Invoke
 */

#include "XlsxWriterTestClass.hpp"

#include "xlsx/XlsxWriter.hpp"
#include "xlsx/SimpleWorkbook.hpp"

#include <cstring>
#include <cstdio>
#include <fstream>
#include <ios>
#include <iostream>
#include <chrono>
#include <algorithm> // pour Visual Studio: C2039 & C3861

#define XLSX_PATH "../../../test/resource/"
//#define GENERATE_XLSX
#define GENERATE_TEST

CPPUNIT_TEST_SUITE_REGISTRATION(XlsxWriterTestClass);

bool XlsxWriterTestClass::areStreamEqual(std::istream& p_stream1, std::istream& p_stream2) const
{
    const std::istream::pos_type k_size1 = p_stream1.seekg(0, std::istream::end).tellg();
    const std::istream::pos_type k_size2 = p_stream2.seekg(0, std::istream::end).tellg();

    if (k_size1 != k_size2)
        return false;

    if (!k_size1)
        return true;

    p_stream1.seekg(0, std::istream::beg);
    p_stream2.seekg(0, std::istream::beg);

    const size_t k_maxBlockSize = 4096;
    char w_buffer1[k_maxBlockSize];
    char w_buffer2[k_maxBlockSize];

    size_t w_remaining = static_cast<size_t>(k_size1);

    while (w_remaining) {
        const size_t k_blockSize = std::min(k_maxBlockSize, w_remaining);

        p_stream1.read(w_buffer1, k_blockSize);
        p_stream2.read(w_buffer2, k_blockSize);

        if (memcmp(w_buffer1, w_buffer2, k_blockSize))
            return false;

        w_remaining -= k_blockSize;
    }

    return true;
}

bool XlsxWriterTestClass::areZipEqual(std::istream& p_zip1, std::istream& p_zip2) const
{
    typedef std::shared_ptr<Invoke::Zip::ZipArchiveReader> zipReader_t;

    zipReader_t w_reader1( Invoke::Zip::openZipArchive(p_zip1) );
    const Invoke::Zip::ZipArchiveReader::fileList_t k_fileList1 = w_reader1->fileList();

    zipReader_t w_reader2( Invoke::Zip::openZipArchive(p_zip2) );
    const Invoke::Zip::ZipArchiveReader::fileList_t k_fileList2 = w_reader2->fileList();

    if (k_fileList1.size() != k_fileList2.size())
        return false;

    for (unsigned int w_it = 0; w_it < k_fileList1.size(); ++w_it) {
        std::stringstream w_stream1;
        std::stringstream w_stream2;

        if (!w_reader1->extractToStream(k_fileList1[w_it], &w_stream1))
            return false;
        if (!w_reader2->extractToStream(k_fileList1[w_it], &w_stream2))
            return false;

        if (!areStreamEqual(w_stream1, w_stream2))
            return false;
    }

    return true;
}

bool XlsxWriterTestClass::isWorkbookValid(const Invoke::XLSX::Interface::Read::Workbook* p_workbook, const std::string& p_refFilename) const
{
    bool w_result = false;

    std::fstream w_ref(p_refFilename.c_str(), std::fstream::binary | std::fstream::in);
    try {

        const std::string k_tmpWorkbookName = XLSX_PATH ".00.~workbook.xlsx";

        // fichier
        saveWorkbook(p_workbook, k_tmpWorkbookName, true);
        try {

            std::fstream w_tmpFile(k_tmpWorkbookName.c_str(), std::fstream::binary | std::fstream::in);
            w_result = areStreamEqual(w_tmpFile, w_ref);
            if (!w_result)
                w_result = areZipEqual(w_tmpFile, w_ref);
            w_tmpFile.close();

        } catch(...) {
            remove(k_tmpWorkbookName.c_str());
            throw;
        }
        remove(k_tmpWorkbookName.c_str());

        // flux
        if (w_result) {
            try {
                std::fstream w_xlsxStream(k_tmpWorkbookName.c_str(), std::fstream::binary | std::fstream::out);
                saveWorkbook(p_workbook, w_xlsxStream, true);
                w_xlsxStream.close();

                std::fstream w_tmpFile(k_tmpWorkbookName.c_str(), std::fstream::binary | std::fstream::in);
                w_result = areStreamEqual(w_tmpFile, w_ref);
                if (!w_result)
                    w_result = areZipEqual(w_tmpFile, w_ref);
                w_tmpFile.close();
            } catch(...) {
                remove(k_tmpWorkbookName.c_str());
                throw;
            }
            remove(k_tmpWorkbookName.c_str());
        }

        // memory
        if (w_result) {
            Invoke::Zip::byte_t* w_memory;
            unsigned int w_size;
            try {
                saveWorkbook(p_workbook, w_memory, w_size, true);

                std::fstream w_xlsxStream(k_tmpWorkbookName.c_str(), std::fstream::binary | std::fstream::out);
                w_xlsxStream.write(static_cast<const char*>(w_memory), w_size);
                w_xlsxStream.close();

                std::fstream w_tmpFile(k_tmpWorkbookName.c_str(), std::fstream::binary | std::fstream::in);
                w_result = areStreamEqual(w_tmpFile, w_ref);
                if (!w_result)
                    w_result = areZipEqual(w_tmpFile, w_ref);
                w_tmpFile.close();
            } catch(...) {
                remove(k_tmpWorkbookName.c_str());
                free(w_memory);
                throw;
            }
            remove(k_tmpWorkbookName.c_str());
            free(w_memory);
        }

    } catch (...) {
        w_ref.close();
        throw;
    }
    w_ref.close();

    return w_result;
}

void XlsxWriterTestClass::saveWorkbook(const Invoke::XLSX::Interface::Read::Workbook* p_workbook, const std::string& p_filenamme, bool p_chrono) const
{
    struct tm w_PhilaeLanding;
    w_PhilaeLanding.tm_year = 2014 - 1900;
    w_PhilaeLanding.tm_mon = 11 - 1;
    w_PhilaeLanding.tm_mday = 12;
    w_PhilaeLanding.tm_hour = 17;
    w_PhilaeLanding.tm_min = 04;
    w_PhilaeLanding.tm_sec = 00;
    w_PhilaeLanding.tm_isdst = -1;
    time_t w_creationDate = mktime(&w_PhilaeLanding);

    const std::chrono::high_resolution_clock::time_point k_start = std::chrono::high_resolution_clock::now();
    Invoke::XLSX::Writer::save(p_workbook, p_filenamme, w_creationDate);
    const std::chrono::high_resolution_clock::time_point k_stop = std::chrono::high_resolution_clock::now();

    if (p_chrono) {
        const std::chrono::duration<double> k_timeSpan = std::chrono::duration_cast<std::chrono::duration<double>>(k_stop - k_start);
        std::cout << " [file: " << k_timeSpan.count() << "s]";
    }
}

void XlsxWriterTestClass::saveWorkbook(const Invoke::XLSX::Interface::Read::Workbook* p_workbook, std::ostream& o_stream, bool p_chrono) const
{
    struct tm w_PhilaeLanding;
    w_PhilaeLanding.tm_year = 2014 - 1900;
    w_PhilaeLanding.tm_mon = 11 - 1;
    w_PhilaeLanding.tm_mday = 12;
    w_PhilaeLanding.tm_hour = 17;
    w_PhilaeLanding.tm_min = 04;
    w_PhilaeLanding.tm_sec = 00;
    w_PhilaeLanding.tm_isdst = -1;
    time_t w_creationDate = mktime(&w_PhilaeLanding);

    const std::chrono::high_resolution_clock::time_point k_start = std::chrono::high_resolution_clock::now();
    Invoke::XLSX::Writer::save(p_workbook, o_stream, w_creationDate);
    const std::chrono::high_resolution_clock::time_point k_stop = std::chrono::high_resolution_clock::now();

    if (p_chrono) {
        const std::chrono::duration<double> k_timeSpan = std::chrono::duration_cast<std::chrono::duration<double>>(k_stop - k_start);
        std::cout << " [stream: " << k_timeSpan.count() << "s]";
    }
}

void XlsxWriterTestClass::saveWorkbook(const Invoke::XLSX::Interface::Read::Workbook* p_workbook, Invoke::Zip::byte_t*& o_memory, unsigned int& o_size, bool p_chrono) const
{
    struct tm w_PhilaeLanding;
    w_PhilaeLanding.tm_year = 2014 - 1900;
    w_PhilaeLanding.tm_mon = 11 - 1;
    w_PhilaeLanding.tm_mday = 12;
    w_PhilaeLanding.tm_hour = 17;
    w_PhilaeLanding.tm_min = 04;
    w_PhilaeLanding.tm_sec = 00;
    w_PhilaeLanding.tm_isdst = -1;
    time_t w_creationDate = mktime(&w_PhilaeLanding);

    const std::chrono::high_resolution_clock::time_point k_start = std::chrono::high_resolution_clock::now();
    Invoke::XLSX::Writer::save(p_workbook, o_memory, o_size, w_creationDate);
    const std::chrono::high_resolution_clock::time_point k_stop = std::chrono::high_resolution_clock::now();

    if (p_chrono) {
        const std::chrono::duration<double> k_timeSpan = std::chrono::duration_cast<std::chrono::duration<double>>(k_stop - k_start);
        std::cout << " [memory: " << k_timeSpan.count() << "s]";
    }
}

void XlsxWriterTestClass::testTest()
{
#if defined(GENERATE_XLSX)
    const bool k_testOk = false;
#else
    const bool k_testOk = true;
#endif

    CPPUNIT_ASSERT_MESSAGE( "MAKING XLSX", k_testOk );
}

void XlsxWriterTestClass::testNull()
{
    try {

#if defined(GENERATE_TEST)
        saveWorkbook(nullptr, XLSX_PATH "00.файл.test.xlsx");
#endif

#if defined(GENERATE_XLSX)
        saveWorkbook(nullptr, XLSX_PATH "00.null1.xlsx");
#endif
#if defined(GENERATE_TEST)
        saveWorkbook(nullptr, XLSX_PATH "00.null1.test.xlsx");
#endif

        CPPUNIT_ASSERT_MESSAGE( "Test null", isWorkbookValid(nullptr, XLSX_PATH "00.null1.xlsx") );

        Invoke::XLSX::SimpleWorkbook::SimpleWorkbook w_workbook;

#if defined(GENERATE_XLSX)
        saveWorkbook(&w_workbook, XLSX_PATH "00.null2.xlsx");
#endif
#if defined(GENERATE_TEST)
        saveWorkbook(&w_workbook, XLSX_PATH "00.null2.test.xlsx");
#endif

        CPPUNIT_ASSERT_MESSAGE( "Test empty", isWorkbookValid(&w_workbook, XLSX_PATH "00.null2.xlsx") );

    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxWriterTestClass::testEmpty()
{
    try {

        Invoke::XLSX::SimpleWorkbook::SimpleWorkbook w_workbook;
        w_workbook.newWorksheet("sheet1");


#if defined(GENERATE_XLSX)
        saveWorkbook(&w_workbook, XLSX_PATH "01.empty.xlsx");
#endif
#if defined(GENERATE_TEST)
        saveWorkbook(&w_workbook, XLSX_PATH "01.empty.test.xlsx");
#endif

        CPPUNIT_ASSERT_MESSAGE( "Test empty", isWorkbookValid(&w_workbook, XLSX_PATH "01.empty.xlsx") );

    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxWriterTestClass::testSheets()
{
    try {

        using namespace Invoke::XLSX::Interface;
        using namespace Invoke::XLSX::SimpleWorkbook;

        SimpleWorkbook w_workbook;

        Write::Worksheet* w_hiddenSheet1 = static_cast<Write::Worksheet*>(w_workbook.newWorksheet("hidden"));
        w_hiddenSheet1->setHidden(true);

        SimpleWorksheet* w_sheet1 = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("sheet1"));
        CPPUNIT_ASSERT_MESSAGE("Test sheets - #01", w_sheet1->name() == "sheet1");

        CPPUNIT_ASSERT_MESSAGE("Test sheets - #02", w_workbook.worksheet(1) == w_sheet1);

        SimpleWorksheet* w_sheet2 = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("sheet1"));
        CPPUNIT_ASSERT_MESSAGE("Test sheets - #03", w_sheet2->name() == "sheet2");

        SimpleWorksheet* w_upperSheet1 = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("SHEET1"));
        CPPUNIT_ASSERT_MESSAGE("Test sheets - #04", w_upperSheet1->name() == "SHEET3");

        SimpleWorksheet* w_sheet001 = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("sheet001"));
        CPPUNIT_ASSERT_MESSAGE("Test sheets - #05", w_sheet001->name() == "sheet001");

        SimpleWorksheet* w_sheet002 = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("sheet001"));
        CPPUNIT_ASSERT_MESSAGE("Test sheets - #06", w_sheet002->name() == "sheet002");

        SimpleWorksheet* w_sheetUtf8 = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("Ктулху"));
        CPPUNIT_ASSERT_MESSAGE("Test sheets - #07", w_sheetUtf8->name() == "Ктулху");

        SimpleWorksheet* w_hiddenSheet2 = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("hidden"));
        w_hiddenSheet2->setHidden(true);

        SimpleWorksheet* w_number1 = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("789"));
        CPPUNIT_ASSERT_MESSAGE("Test sheets - #08", w_number1->name() == "789");

        SimpleWorksheet* w_number2 = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("789"));
        CPPUNIT_ASSERT_MESSAGE("Test sheets - #09", w_number2->name() == "790");

        SimpleWorksheet* w_noSheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("NON!"));
        CPPUNIT_ASSERT_MESSAGE("Test sheets - #10", w_noSheet->name() == "NON!");

        SimpleWorksheet* w_strange = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("LX-ID010"));  // " " = 0x19
        CPPUNIT_ASSERT_MESSAGE("Test sheets - #11", w_strange->name() == "LX-ID010");

        SimpleWorksheet* w_tooLongSheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("un nom beaucoup trop long pour une feuille !!"));
        CPPUNIT_ASSERT_MESSAGE("Test sheets - #12", w_tooLongSheet->name() == "un nom beaucoup trop long pour…");

        SimpleWorksheet* w_tooLongSheep = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("un nom beaucoup trop long pour un mouton !!"));
        CPPUNIT_ASSERT_MESSAGE("Test sheets - #13", w_tooLongSheep->name() == "un nom beaucoup trop long pou…1");

        SimpleWorksheet* w_tooLongShip = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("un nom beaucoup trop long pour un bateau !!"));
        CPPUNIT_ASSERT_MESSAGE("Test sheets - #14", w_tooLongShip->name() == "un nom beaucoup trop long pou…2");

        SimpleWorksheet* w_31characters1 = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("nom de trente et un caractères."));
        CPPUNIT_ASSERT_MESSAGE("Test sheets - #15", w_31characters1->name() == "nom de trente et un caractères.");

        SimpleWorksheet* w_31characters2 = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("nom de trente et un caractères."));
        CPPUNIT_ASSERT_MESSAGE("Test sheets - #16", w_31characters2->name() == "nom de trente et un caractère…1");

        SimpleWorksheet* w_31characters3 = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("nom de feuille finissant par 99"));
        CPPUNIT_ASSERT_MESSAGE("Test sheets - #17", w_31characters3->name() == "nom de feuille finissant par 99");

        SimpleWorksheet* w_31characters4 = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("nom de feuille finissant par 99"));
        CPPUNIT_ASSERT_MESSAGE("Test sheets - #18", w_31characters4->name() == "nom de feuille finissant pa…100");

        SimpleWorksheet* w_tooLongSheet2 = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("nom de feuille très long finissant par 012"));
        CPPUNIT_ASSERT_MESSAGE("Test sheets - #19", w_tooLongSheet2->name() == "nom de feuille très long fi…012");

        SimpleWorksheet* w_tooLongSheet3 = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("nom de feuille très long finissant par 012"));
        CPPUNIT_ASSERT_MESSAGE("Test sheets - #20", w_tooLongSheet3->name() == "nom de feuille très long fi…013");


#if defined(GENERATE_XLSX)
        saveWorkbook(&w_workbook, XLSX_PATH "02.sheets.xlsx");
#endif
#if defined(GENERATE_TEST)
        saveWorkbook(&w_workbook, XLSX_PATH "02.sheets.test.xlsx");
#endif

        CPPUNIT_ASSERT_MESSAGE( "Test sheets", isWorkbookValid(&w_workbook, XLSX_PATH "02.sheets.xlsx") );

    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxWriterTestClass::testValues()
{
    try {

        using namespace Invoke::XLSX::SimpleWorkbook;

        SimpleWorkbook w_workbook;

        SimpleWorksheet* w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("sheet1"));
        w_sheet->setStringValue(0, 0, "A1");
        w_sheet->setStringValue(1, 1, "♔♕♖♗♘♙");

        CPPUNIT_ASSERT_MESSAGE( "Test values - #01", w_sheet->minBounds() == Invoke::XLSX::Coordinates::CellRange(w_sheet, 0, 0, 1, 1) );
        w_sheet->setStringValue(2, 5, "sheet1!Cell C6");
        CPPUNIT_ASSERT_MESSAGE( "Test values - #02", w_sheet->minBounds() == Invoke::XLSX::Coordinates::CellRange(w_sheet, 0, 0, 2, 5) );
        w_sheet->setNumberValue(3, 6, 12.34);
        w_sheet->setNumberValue(3, 7, 123);
        w_sheet->setNumberValue(3, 8, 0, "=D7+D8");
        CPPUNIT_ASSERT_MESSAGE( "Test values - #03", w_sheet->minBounds() == Invoke::XLSX::Coordinates::CellRange(w_sheet, 0, 0, 3, 8) );

        w_sheet->setBooleanValue(3, 10, false);
        w_sheet->setBooleanValue(4, 10, true);

        w_sheet->setErrorValue(3, 11, Invoke::XLSX::Interface::ceDIV0);
        w_sheet->setErrorValue(4, 11, Invoke::XLSX::Interface::ceNULL);
        w_sheet->setErrorValue(5, 11, Invoke::XLSX::Interface::ceVALUE);
        w_sheet->setErrorValue(6, 11, Invoke::XLSX::Interface::ceREF);
        w_sheet->setErrorValue(7, 11, Invoke::XLSX::Interface::ceNAME);
        w_sheet->setErrorValue(8, 11, Invoke::XLSX::Interface::ceNUM);
        w_sheet->setErrorValue(9, 11, Invoke::XLSX::Interface::ceNA);

        w_sheet->forceDateValue(3, 13, 37845);
        w_sheet->forceDateValue(4, 13, 40293);

        w_sheet->setNumberValue(3, 15, 4661177.5);

        CPPUNIT_ASSERT_MESSAGE( "Test values - #04", w_sheet->minBounds() == Invoke::XLSX::Coordinates::CellRange(w_sheet, 0, 0, 9, 15) );

        w_sheet->setStringValue(3, 17, "   3 espaces avant...");
        w_sheet->setStringValue(3, 18, "3 espaces après...   ");
        w_sheet->setStringValue(3, 19, "chaîne avec\nretour à la ligne..."); // necessite de spécifier, au niveau du format de la cellule, un retour à la ligne automatique.

        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("sheet2"));
        w_sheet->setStringValue(0, 0, "A1 ?");
        w_sheet->setStringValue(0, 0, "A1"); // sheet2!A1 doit apparaître qu'une fois dans le fichier
        w_sheet->setStringValue(2, 5, "sheet2!Cell C6");
        w_sheet->setNumberValue(3, 6, -12.34);
        w_sheet->setNumberValue(3, 7, -123);
        CPPUNIT_ASSERT_MESSAGE( "Test values - #05", w_sheet->minBounds() == Invoke::XLSX::Coordinates::CellRange(w_sheet, 0, 0, 3, 7) );
        w_sheet->setNumberValue(3, 8, 0, "=D7+D8");
        CPPUNIT_ASSERT_MESSAGE( "Test values - #06", w_sheet->minBounds() == Invoke::XLSX::Coordinates::CellRange(w_sheet, 0, 0, 3, 8) );

        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("AB £€"));
        w_sheet->setStringValue(0, 0, "A1");
        w_sheet->setNumberValue(3, 6, 42);
        w_sheet->setNumberValue(3, 8, 0, "=sheet1!D9+sheet2!D9+'AB £€'!D7");

        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("merge"));
        w_sheet->setStringValue(0, 0, "merge -> D4:H8");
        CPPUNIT_ASSERT_MESSAGE( "Test values - #07", w_sheet->minBounds() == Invoke::XLSX::Coordinates::CellRange(w_sheet, 0, 0, 0, 0) );
        w_sheet->setMerge( Invoke::XLSX::Coordinates::CellRange(w_sheet, 1, 1, 1, 1) ); // B2, ne doit pas être inscrit dans le fichier
        CPPUNIT_ASSERT_MESSAGE( "Test values - #08", w_sheet->minBounds() == Invoke::XLSX::Coordinates::CellRange(w_sheet, 0, 0, 0, 0) );
        w_sheet->setMerge( Invoke::XLSX::Coordinates::CellRange(w_sheet, 3, 3, 7, 7) ); // D4:H8
        CPPUNIT_ASSERT_MESSAGE( "Test values - #09", w_sheet->minBounds() == Invoke::XLSX::Coordinates::CellRange(w_sheet, 0, 0, 7, 7) );
        CPPUNIT_ASSERT_MESSAGE( "Test values - #10", w_sheet->mergeCount() == 1 );

        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("merge"));
        w_sheet->setStringValue(0, 0, "merge -> B2:G7 + B14:D18");
        w_sheet->setMerge( Invoke::XLSX::Coordinates::CellRange(w_sheet, 1, 1, 3, 3) ); // B2:D4
        w_sheet->setMerge( Invoke::XLSX::Coordinates::CellRange(w_sheet, 4, 4, 6, 6) ); // E5:G7
        w_sheet->setMerge( Invoke::XLSX::Coordinates::CellRange(w_sheet, 5, 5, 6, 6) ); // F6:G7 -> dans E5:G7
        w_sheet->setMerge( Invoke::XLSX::Coordinates::CellRange(w_sheet, 2, 2, 5, 5) ); // C3:F6 -> final = B2:G7

        w_sheet->setMerge( Invoke::XLSX::Coordinates::CellRange(w_sheet, 3, 17, 1, 13) ); // B14:D18 mais à l'envers.

        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("formulas"));
        w_sheet->setBooleanValue(1, 1, true);
        w_sheet->setBooleanValue(2, 1, false);
        w_sheet->setNumberValue(1, 2, 1.61803398875);
        w_sheet->setNumberValue(2, 2, 3.14159265359);
        w_sheet->setNumberValue(3, 2, 42);
        w_sheet->setStringValue(1, 3, "TEXT");
        w_sheet->setStringValue(2, 3, "TEXT");
        w_sheet->setStringValue(3, 3, "text");

        w_sheet->setNullValue(5, 0, "B1");
        w_sheet->setBooleanValue(5, 1, true, "B2");
        w_sheet->setBooleanValue(6, 1, false, "C2");
        w_sheet->setBooleanValue(7, 1, true, "B4=C4");
        w_sheet->setBooleanValue(8, 1, true, "B4=D4");
        w_sheet->setNumberValue(5, 2, 2.61803398875, "B3*B3");
        w_sheet->setNumberValue(6, 2, 42, "D3");
        w_sheet->setStringValue(5, 3, "TEXT = text", "B4 & \" = \" & D4");


        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("show formulas"));
        w_sheet->showFormulas(true);
        w_sheet->setBooleanValue(1, 1, true);
        w_sheet->setStringValue(1, 2, "TRUE", "IF(B2,\"TRUE\",\"FALSE\")");

#if defined(GENERATE_XLSX)
        saveWorkbook(&w_workbook, XLSX_PATH "03.values.xlsx");
#endif
#if defined(GENERATE_TEST)
        saveWorkbook(&w_workbook, XLSX_PATH "03.values.test.xlsx");
#endif

        CPPUNIT_ASSERT_MESSAGE( "Test values", isWorkbookValid(&w_workbook, XLSX_PATH "03.values.xlsx") );

    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxWriterTestClass::testFormats()
{
    try {

        using namespace Invoke::XLSX;

        SimpleWorkbook::SimpleWorkbook w_workbook;

        // font
        Interface::Write::Worksheet* w_sheet = w_workbook.newWorksheet("font");

        SimpleWorkbook::SimpleCellFormat w_format;
        w_sheet->setStringValue(1, 1, w_format.stringCode());
        w_sheet->setFormat(1, 1, w_format);

        w_format = SimpleWorkbook::SimpleCellFormat();
        w_format.setFontName("Courier New");
        w_sheet->setStringValue(1, 2, w_format.stringCode());
        w_sheet->setFormat(1, 2, w_format);

        w_format = SimpleWorkbook::SimpleCellFormat();
        w_format.setFontSize(20);
        w_sheet->setStringValue(1, 3, w_format.stringCode());
        w_sheet->setFormat(1, 3, w_format);

        w_format = SimpleWorkbook::SimpleCellFormat();
        w_format.setFontColor(0xFF0000);
        w_sheet->setStringValue(1, 4, w_format.stringCode());
        w_sheet->setFormat(1, 4, w_format);

        w_format = SimpleWorkbook::SimpleCellFormat();
        w_format.setFontStyle(true, true, true);
        w_sheet->setStringValue(1, 5, w_format.stringCode());
        w_sheet->setFormat(1, 5, w_format);

        // number format
        w_sheet = w_workbook.newWorksheet("number format");

        w_format = SimpleWorkbook::SimpleCellFormat();
        w_format.setNumberFormat("#,##0.00;(#,##0.00);0");

        w_sheet->setStringValue(1, 1, w_format.stringCode());
        w_sheet->setNumberValue(1, 2, 12);
        w_sheet->setNumberValue(1, 3, 0);
        w_sheet->setNumberValue(1, 4, -12);

        w_sheet->setFormat(1, 1, w_format);
        w_sheet->setFormat(1, 2, w_format);
        w_sheet->setFormat(1, 3, w_format);
        w_sheet->setFormat(1, 4, w_format);

        w_format = SimpleWorkbook::SimpleCellFormat();
        w_format.setNumberFormat("dd/mm/yyyy;(#,##0.00);0\" €\";\"texte:\"@");

        w_sheet->setFormat(1, 6, w_format);
        w_sheet->setFormat(1, 7, w_format);
        w_sheet->setFormat(1, 8, w_format);
        w_sheet->setFormat(1, 9, w_format);

        w_sheet->setStringValue(1, 6, w_format.stringCode());
        w_sheet->setNumberValue(1, 7, 12);
        w_sheet->setNumberValue(1, 8, 0);
        w_sheet->setNumberValue(1, 9, -12);

        // background color
        w_sheet = w_workbook.newWorksheet("background color");

        w_format = SimpleWorkbook::SimpleCellFormat();
        w_format.setSolidBackColor(0xFFFF0000);

        w_sheet->setStringValue(1, 1, w_format.stringCode());
        w_sheet->setFormat(1, 1, w_format);

        w_format = SimpleWorkbook::SimpleCellFormat();
        w_format.setSolidBackColor(0xFF00FF00);

        w_sheet->setStringValue(1, 2, w_format.stringCode());
        w_sheet->setFormat(1, 2, w_format);

        w_format = SimpleWorkbook::SimpleCellFormat();
        w_format.setSolidBackColor(0xFF0000FF);

        w_sheet->setStringValue(1, 3, w_format.stringCode());
        w_sheet->setFormat(1, 3, w_format);

        for (unsigned int w_iStyle = 0; w_iStyle < 19; ++w_iStyle) {
            w_format = SimpleWorkbook::SimpleCellFormat();
            w_format.setPatternStyle( (Interface::patternStyle_t)w_iStyle );
            w_format.setForegroundColor(0xFF0000FF);
            w_format.setBackgroundColor(0xFFFF0000);

            w_sheet->setFormat(1, 5+w_iStyle, w_format);
        }

        // border
        w_sheet = w_workbook.newWorksheet("border");

        const Interface::color_t k_colors[4] = { 0xFF000000, 0xFFFF0000, 0xFF00FF00, 0xFF0000FF };

        for (int w_iColor = 0; w_iColor < 4; ++w_iColor)
            for (unsigned int w_iStyle = 0; w_iStyle < 13; ++w_iStyle)
                for (unsigned int w_iBorder = 0; w_iBorder < 6; ++w_iBorder) {

                    w_format = SimpleWorkbook::SimpleCellFormat();
                    w_format.setBorderVisible((Interface::border_t)w_iBorder, true);
                    w_format.setBorderStyle((Interface::border_t)w_iBorder, (Interface::borderStyle_t)w_iStyle);
                    w_format.setBorderColor((Interface::border_t)w_iBorder, k_colors[w_iColor]);

                    w_sheet->setFormat( 1 + w_iBorder * 2, 1 + w_iStyle * 2 + w_iColor * 26, w_format );

                }

        // alignment
        w_sheet = w_workbook.newWorksheet("alignment");

        for (unsigned int w_iHorizontal = 0; w_iHorizontal < 4; ++w_iHorizontal)
            for (unsigned int w_iVertical = 0; w_iVertical < 3; ++w_iVertical) {

                w_format = SimpleWorkbook::SimpleCellFormat();
                w_format.setFontSize(5);
                w_format.setHorizontalAlignment((Interface::horizontalAlignment_t)w_iHorizontal);
                w_format.setVerticalAlignment((Interface::verticalAlignment_t)w_iVertical);

                w_sheet->setStringValue(w_iHorizontal + 1, w_iVertical + 1, "X");
                w_sheet->setFormat(w_iHorizontal + 1, w_iVertical + 1, w_format);

            }

        w_format = SimpleWorkbook::SimpleCellFormat();
        w_format.setHorizontalAlignment(Interface::haLeft);
        w_format.setTextIndent(1);
        w_sheet->setStringValue(1, 5, "L 1");
        w_sheet->setFormat(1, 5, w_format);

        w_format = SimpleWorkbook::SimpleCellFormat();
        w_format.setHorizontalAlignment(Interface::haLeft);
        w_format.setTextIndent(2);
        w_sheet->setStringValue(1, 6, "L 2");
        w_sheet->setFormat(1, 6, w_format);

        w_format = SimpleWorkbook::SimpleCellFormat();
        w_format.setHorizontalAlignment(Interface::haRight);
        w_format.setTextIndent(1);
        w_sheet->setStringValue(2, 5, "R 1");
        w_sheet->setFormat(2, 5, w_format);

        w_format = SimpleWorkbook::SimpleCellFormat();
        w_format.setHorizontalAlignment(Interface::haRight);
        w_format.setTextIndent(2);
        w_sheet->setStringValue(2, 6, "R 2");
        w_sheet->setFormat(2, 6, w_format);

        // rotation
        w_sheet = w_workbook.newWorksheet("rotation");

        w_format = SimpleWorkbook::SimpleCellFormat();
        w_format.setTextRotation(-90);

        w_sheet->setStringValue(1, 5, "rotation = -90°");
        w_sheet->setFormat(1, 5, w_format);

        w_format = SimpleWorkbook::SimpleCellFormat();
        w_format.setTextRotation(-45);

        w_sheet->setStringValue(3, 5, "rotation = -45°");
        w_sheet->setFormat(3, 5, w_format);

        w_format = SimpleWorkbook::SimpleCellFormat();
        w_format.setTextRotation(0);

        w_sheet->setStringValue(5, 5, "rotation = 0°");
        w_sheet->setFormat(5, 5, w_format);

        w_format = SimpleWorkbook::SimpleCellFormat();
        w_format.setTextRotation(45);

        w_sheet->setStringValue(7, 5, "rotation = 45°");
        w_sheet->setFormat(7, 5, w_format);

        w_format = SimpleWorkbook::SimpleCellFormat();
        w_format.setTextRotation(90);

        w_sheet->setStringValue(9, 5, "rotation = 90°");
        w_sheet->setFormat(9, 5, w_format);

        // wrap text
        w_sheet = w_workbook.newWorksheet("wrap text");

        w_format = SimpleWorkbook::SimpleCellFormat();
        w_format.setFontSize(8);
        w_format.setWrapText(false);

        w_sheet->setStringValue(1, 1, w_format.stringCode());
        w_sheet->setFormat(1, 1, w_format);

        w_format = SimpleWorkbook::SimpleCellFormat();
        w_format.setFontSize(8);
        w_format.setWrapText(true);

        w_sheet->setStringValue(1, 3, w_format.stringCode());
        w_sheet->setFormat(1, 3, w_format);


#if defined(_MSC_VER)
#define _XLSX_SUFFIX    "windows"
#else
#define _XLSX_SUFFIX    "linux"
#endif

#if defined(GENERATE_XLSX)
        saveWorkbook(&w_workbook, XLSX_PATH "04.formats." _XLSX_SUFFIX ".xlsx");
#endif
#if defined(GENERATE_TEST)
        saveWorkbook(&w_workbook, XLSX_PATH "04.formats." _XLSX_SUFFIX ".test.xlsx");
#endif

        CPPUNIT_ASSERT_MESSAGE( "Test formats", isWorkbookValid(&w_workbook, XLSX_PATH "04.formats." _XLSX_SUFFIX ".xlsx") );

#undef _XLSX_SUFFIX

    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxWriterTestClass::testColumnsAndRows()
{
    try {

        using namespace Invoke::XLSX::Interface;
        using namespace Invoke::XLSX::SimpleWorkbook;

        SimpleWorkbook w_workbook;

        // size
        Write::Worksheet* w_sheet = w_workbook.newWorksheet("size (B4)");

        const double k_columnWidth = 20;
        const double k_rowHeight = 30;

        w_sheet->setColumnWidth(1, &k_columnWidth);
        w_sheet->setRowHeight(3, &k_rowHeight);

        // size 2 (Correction #8065)
        w_sheet = w_workbook.newWorksheet("size");

        const double k_defaultColumnWidth = 10;
        const double k_defaultRowHeight = 15;

        w_sheet->setColumnWidth(0, &k_defaultColumnWidth);
        w_sheet->setColumnWidth(1, &k_defaultColumnWidth);

        w_sheet->setRowHeight(0, &k_defaultRowHeight);
        w_sheet->setRowHeight(1, &k_defaultRowHeight);

        const double k_columnSpecialWidth = 10.1428571428571;
        w_sheet->setColumnWidth(2, &k_columnSpecialWidth);

        w_sheet->setStringValue(2, 2, "XXX");

        // visible
        w_sheet = w_workbook.newWorksheet("hidden (B4)");

        w_sheet->setColumnVisible(1, false);
        w_sheet->setRowVisible(3, false);

        // formats
        w_sheet = w_workbook.newWorksheet("formats");

        SimpleCellFormat w_columnFormat;
        w_columnFormat.setPatternStyle(psLightVertical);
        w_columnFormat.setBackgroundColor(0xFFFFFF00);
        w_columnFormat.setForegroundColor(0xFFFF0000);
        w_columnFormat.setBorderVisible(bLeft, true);
        w_columnFormat.setBorderStyle(bLeft, bsMediumDashDot);
        w_columnFormat.setBorderColor(bLeft, 0xFF000000);
        w_columnFormat.setBorderVisible(bRight, true);
        w_columnFormat.setBorderStyle(bRight, bsMediumDashDot);
        w_columnFormat.setBorderColor(bRight, 0xFF000000);

        w_sheet->setColumnFormat(3, &w_columnFormat);

        SimpleCellFormat w_rowFormat;
        w_rowFormat.setPatternStyle(psLightHorizontal);
        w_rowFormat.setBackgroundColor(0xFFFFFF00);
        w_rowFormat.setForegroundColor(0xFFFF0000);
        w_rowFormat.setBorderVisible(bTop, true);
        w_rowFormat.setBorderStyle(bTop, bsMediumDashDot);
        w_rowFormat.setBorderColor(bTop, 0xFF000000);
        w_rowFormat.setBorderVisible(bBottom, true);
        w_rowFormat.setBorderStyle(bBottom, bsMediumDashDot);
        w_rowFormat.setBorderColor(bBottom, 0xFF000000);

        w_sheet->setRowFormat(7, &w_rowFormat);

        SimpleCellFormat w_crossFormat;
        w_crossFormat.setPatternStyle(psLightGrid);
        w_crossFormat.setBackgroundColor(0xFFFFFF00);
        w_crossFormat.setForegroundColor(0xFFFF0000);

        w_sheet->setFormat(3, 7, w_crossFormat);

        // xSplit
        w_sheet = w_workbook.newWorksheet("xSplit");

        w_sheet->setStringValue(1, 4, "fixe");
        w_sheet->setStringValue(4, 4, "mobile");
        w_sheet->setXSplit(2);

        // ySplit
        w_sheet = w_workbook.newWorksheet("ySplit");

        w_sheet->setStringValue(4, 1, "fixe");
        w_sheet->setStringValue(4, 4, "mobile");
        w_sheet->setYSplit(2);

        // xySplit
        w_sheet = w_workbook.newWorksheet("xySplit");

        w_sheet->setStringValue(1, 1, "fixe");
        w_sheet->setStringValue(4, 4, "mobile");
        w_sheet->setXSplit(2);
        w_sheet->setYSplit(2);


#if defined(_MSC_VER)
#define _XLSX_SUFFIX    "windows"
#else
#define _XLSX_SUFFIX    "linux"
#endif

#if defined(GENERATE_XLSX)
        saveWorkbook(&w_workbook, XLSX_PATH "05.columnsAndRows." _XLSX_SUFFIX ".xlsx");
#endif
#if defined(GENERATE_TEST)
        saveWorkbook(&w_workbook, XLSX_PATH "05.columnsAndRows." _XLSX_SUFFIX ".test.xlsx");
#endif

        CPPUNIT_ASSERT_MESSAGE( "Test columns and rows", isWorkbookValid(&w_workbook, XLSX_PATH "05.columnsAndRows." _XLSX_SUFFIX ".xlsx") );

#undef _XLSX_SUFFIX

    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxWriterTestClass::testOutlines()
{
    try {

        using namespace Invoke::XLSX::Interface;
        using namespace Invoke::XLSX::SimpleWorkbook;

        SimpleWorkbook w_workbook;

        // outlines
        Write::Worksheet* w_sheet = w_workbook.newWorksheet("outlines");

        for (unsigned short w_iOutline = 1; w_iOutline < 8; ++w_iOutline) {
            for (int w_iCol = 1 + w_iOutline; w_iCol < 17 - w_iOutline; ++w_iCol)
                w_sheet->setColumnOutlineLevel(w_iCol, w_iOutline);
        }

        for (unsigned short w_iOutline = 1; w_iOutline < 8; ++w_iOutline) {
            for (int w_iRow = 1 + w_iOutline; w_iRow < 17 - w_iOutline; ++w_iRow)
                w_sheet->setRowOutlineLevel(w_iRow, w_iOutline);
        }

        // simple column outline - right
        w_sheet = w_workbook.newWorksheet("simple column outline - right");
        w_sheet->setOutlineSummaryRight(true);

        for (unsigned int w_iCol = 1; w_iCol < 6; ++w_iCol) {
            bool w_collapsed = false;
            unsigned short w_outlines = 0;

            switch (w_iCol) {
            case 1: w_outlines = 1; w_collapsed = true; break;
            case 2: w_outlines = 1; break;
            case 4: w_outlines = 1; break;
            case 5: w_outlines = 1; break;
            default: ;
            }

            if (w_outlines) {
                w_sheet->setColumnOutlineLevel(w_iCol, w_outlines);
                w_sheet->setColumnCollapsed(w_iCol, w_collapsed);
            }
        }

        // simple column outline - left
        w_sheet = w_workbook.newWorksheet("simple column outline - left");
        w_sheet->setOutlineSummaryRight(false);

        for (unsigned int w_iCol = 1; w_iCol < 6; ++w_iCol) {
            bool w_collapsed = false;
            unsigned short w_outlines = 0;

            switch (w_iCol) {
            case 1: w_outlines = 1; w_collapsed = true; break;
            case 2: w_outlines = 1; break;
            case 4: w_outlines = 1; break;
            case 5: w_outlines = 1; break;
            default: ;
            }

            if (w_outlines) {
                w_sheet->setColumnOutlineLevel(w_iCol, w_outlines);
                w_sheet->setColumnCollapsed(w_iCol, w_collapsed);
            }
        }

        // complex column outline - right
        w_sheet = w_workbook.newWorksheet("complex column outline - right");
        w_sheet->setOutlineSummaryRight(true);

        for (unsigned int w_iCol = 1; w_iCol < 20; ++w_iCol) {
            bool w_collapsed = false;
            unsigned short w_outlines = 0;

            switch (w_iCol) {
            case 1: w_outlines = 1; break;
            case 2: w_outlines = 2; break;
            case 3: w_outlines = 2; break;
            case 4: w_outlines = 1; break;
            case 6: w_outlines = 1; break;
            case 7: w_outlines = 2; w_collapsed = true; break;
            case 8: w_outlines = 2; break;
            case 9: w_outlines = 1; break;
            case 11: w_outlines = 1; w_collapsed = true; break;
            case 12: w_outlines = 2; break;
            case 13: w_outlines = 2; break;
            case 14: w_outlines = 1; break;
            case 16: w_outlines = 1; w_collapsed = true; break;
            case 17: w_outlines = 2; w_collapsed = true; break;
            case 18: w_outlines = 2; break;
            case 19: w_outlines = 1; break;
            default: ;
            }

            if (w_outlines) {
                w_sheet->setColumnOutlineLevel(w_iCol, w_outlines);
                w_sheet->setColumnCollapsed(w_iCol, w_collapsed);
            }
        }

        // complex column outline - left
        w_sheet = w_workbook.newWorksheet("complex column outline - left");
        w_sheet->setOutlineSummaryRight(false);

        for (unsigned int w_iCol = 1; w_iCol < 20; ++w_iCol) {
            bool w_collapsed = false;
            unsigned short w_outlines = 0;

            switch (w_iCol) {
            case 1: w_outlines = 1; break;
            case 2: w_outlines = 2; break;
            case 3: w_outlines = 2; break;
            case 4: w_outlines = 1; break;
            case 6: w_outlines = 1; break;
            case 7: w_outlines = 2; w_collapsed = true; break;
            case 8: w_outlines = 2; break;
            case 9: w_outlines = 1; break;
            case 11: w_outlines = 1; w_collapsed = true; break;
            case 12: w_outlines = 2; break;
            case 13: w_outlines = 2; break;
            case 14: w_outlines = 1; break;
            case 16: w_outlines = 1; w_collapsed = true; break;
            case 17: w_outlines = 2; w_collapsed = true; break;
            case 18: w_outlines = 2; break;
            case 19: w_outlines = 1; break;
            default: ;
            }

            if (w_outlines) {
                w_sheet->setColumnOutlineLevel(w_iCol, w_outlines);
                w_sheet->setColumnCollapsed(w_iCol, w_collapsed);
            }
        }

        // simple row outline - below
        w_sheet = w_workbook.newWorksheet("simple row outline - below");
        w_sheet->setOutlineSummaryBelow(true);

        for (unsigned int w_iRow = 1; w_iRow < 6; ++w_iRow) {
            bool w_collapsed = false;
            unsigned short w_outlines = 0;

            switch (w_iRow) {
            case 1: w_outlines = 1; w_collapsed = true; break;
            case 2: w_outlines = 1; break;
            case 4: w_outlines = 1; break;
            case 5: w_outlines = 1; break;
            default: ;
            }

            if (w_outlines) {
                w_sheet->setRowOutlineLevel(w_iRow, w_outlines);
                w_sheet->setRowCollapsed(w_iRow, w_collapsed);
            }
        }

        // simple row outline - above
        w_sheet = w_workbook.newWorksheet("simple row outline - above");
        w_sheet->setOutlineSummaryBelow(false);

        for (unsigned int w_iRow = 1; w_iRow < 6; ++w_iRow) {
            bool w_collapsed = false;
            unsigned short w_outlines = 0;

            switch (w_iRow) {
            case 1: w_outlines = 1; w_collapsed = true; break;
            case 2: w_outlines = 1; break;
            case 4: w_outlines = 1; break;
            case 5: w_outlines = 1; break;
            default: ;
            }

            if (w_outlines) {
                w_sheet->setRowOutlineLevel(w_iRow, w_outlines);
                w_sheet->setRowCollapsed(w_iRow, w_collapsed);
            }
        }

        // complex row outline - below
        w_sheet = w_workbook.newWorksheet("complex row outline - below");
        w_sheet->setOutlineSummaryBelow(true);

        for (unsigned int w_iRow = 1; w_iRow < 20; ++w_iRow) {
            bool w_collapsed = false;
            unsigned short w_outlines = 0;

            switch (w_iRow) {
            case 1: w_outlines = 1; break;
            case 2: w_outlines = 2; break;
            case 3: w_outlines = 2; break;
            case 4: w_outlines = 1; break;
            case 6: w_outlines = 1; break;
            case 7: w_outlines = 2; w_collapsed = true; break;
            case 8: w_outlines = 2; break;
            case 9: w_outlines = 1; break;
            case 11: w_outlines = 1; w_collapsed = true; break;
            case 12: w_outlines = 2; break;
            case 13: w_outlines = 2; break;
            case 14: w_outlines = 1; break;
            case 16: w_outlines = 1; w_collapsed = true; break;
            case 17: w_outlines = 2; w_collapsed = true; break;
            case 18: w_outlines = 2; break;
            case 19: w_outlines = 1; break;
            default: ;
            }

            if (w_outlines) {
                w_sheet->setRowOutlineLevel(w_iRow, w_outlines);
                w_sheet->setRowCollapsed(w_iRow, w_collapsed);
            }
        }

        // complex row outline - above
        w_sheet = w_workbook.newWorksheet("complex row outline - above");
        w_sheet->setOutlineSummaryBelow(false);

        for (unsigned int w_iRow = 1; w_iRow < 20; ++w_iRow) {
            bool w_collapsed = false;
            unsigned short w_outlines = 0;

            switch (w_iRow) {
            case 1: w_outlines = 1; break;
            case 2: w_outlines = 2; break;
            case 3: w_outlines = 2; break;
            case 4: w_outlines = 1; break;
            case 6: w_outlines = 1; break;
            case 7: w_outlines = 2; w_collapsed = true; break;
            case 8: w_outlines = 2; break;
            case 9: w_outlines = 1; break;
            case 11: w_outlines = 1; w_collapsed = true; break;
            case 12: w_outlines = 2; break;
            case 13: w_outlines = 2; break;
            case 14: w_outlines = 1; break;
            case 16: w_outlines = 1; w_collapsed = true; break;
            case 17: w_outlines = 2; w_collapsed = true; break;
            case 18: w_outlines = 2; break;
            case 19: w_outlines = 1; break;
            default: ;
            }

            if (w_outlines) {
                w_sheet->setRowOutlineLevel(w_iRow, w_outlines);
                w_sheet->setRowCollapsed(w_iRow, w_collapsed);
            }
        }

        // very complex row outline - above
        w_sheet = w_workbook.newWorksheet("very complex row outline - above");
        w_sheet->setOutlineSummaryBelow(false);

        for (unsigned int w_iRow = 0; w_iRow < 39; ++w_iRow) {
            unsigned short w_outlines = 0;

            switch (w_iRow) {
            case 1:  w_outlines = 1; break;
            case 2:  w_outlines = 1; break;
            case 3:  w_outlines = 2; break;
            case 4:  w_outlines = 1; break;
            case 5:  w_outlines = 2; break;
            case 6:  w_outlines = 3; break;
            case 7:  w_outlines = 4; break;
            case 8:  w_outlines = 4; break;
            case 9:  w_outlines = 4; break;
            case 10: w_outlines = 5; break;
            case 11: w_outlines = 5; break;
            case 12: w_outlines = 4; break;
            case 13: w_outlines = 5; break;
            case 14: w_outlines = 5; break;
            case 15: w_outlines = 2; break;
            case 16: w_outlines = 3; break;
            case 17: w_outlines = 4; break;
            case 18: w_outlines = 4; break;
            case 19: w_outlines = 4; break;
            case 20: w_outlines = 5; break;
            case 21: w_outlines = 5; break;
            case 22: w_outlines = 5; break;
            case 23: w_outlines = 4; break;
            case 24: w_outlines = 5; break;
            case 25: w_outlines = 5; break;
            case 26: w_outlines = 4; break;
            case 27: w_outlines = 5; break;
            case 28: w_outlines = 5; break;
            case 29: w_outlines = 5; break;
            case 30: w_outlines = 6; break;
            case 31: w_outlines = 6; break;
            case 32: w_outlines = 6; break;
            case 33: w_outlines = 5; break;
            case 34: w_outlines = 6; break;
            case 35: w_outlines = 6; break;
            case 36: w_outlines = 3; break;
            case 37: w_outlines = 4; break;
            case 38: w_outlines = 4; break;
            default: ;
            }

            if (w_outlines) {
                w_sheet->setRowOutlineLevel(w_iRow, w_outlines);
                w_sheet->setRowCollapsed(w_iRow, true);
            }
        }

        // too deep outlines
        w_sheet = w_workbook.newWorksheet("too deep outlines");

        for (unsigned int w_iColumnRow = 0; w_iColumnRow < 15; ++w_iColumnRow) {
            w_sheet->setColumnOutlineLevel(w_iColumnRow+1, w_iColumnRow);
            w_sheet->setRowOutlineLevel(w_iColumnRow+1, w_iColumnRow);
        }


#if defined(GENERATE_XLSX)
        saveWorkbook(&w_workbook, XLSX_PATH "06.outlines.xlsx");
#endif
#if defined(GENERATE_TEST)
        saveWorkbook(&w_workbook, XLSX_PATH "06.outlines.test.xlsx");
#endif

        CPPUNIT_ASSERT_MESSAGE( "Test outlines", isWorkbookValid(&w_workbook, XLSX_PATH "06.outlines.xlsx") );

    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxWriterTestClass::testPageSetting()
{
    try {

        using namespace Invoke::XLSX;

        SimpleWorkbook::SimpleWorkbook w_workbook;

        SimpleWorkbook::SimpleCellFormat w_red;
        w_red.setSolidBackColor(0xFFFF0000);

        SimpleWorkbook::SimpleCellFormat w_green;
        w_green.setSolidBackColor(0xFF00FF00);

        // simple print area
        SimpleWorkbook::SimpleWorksheet* w_sheet = static_cast<SimpleWorkbook::SimpleWorksheet*>(w_workbook.newWorksheet("simple print area"));

        const Coordinates::CellRange k_redRange(w_sheet, 0, 0, 9, 19);
        const Coordinates::CellRange k_greenRange(w_sheet, 2, 5, 7, 14);

        Coordinates::MultiCellRange w_printArea;
        w_printArea.addRange( k_greenRange );

        w_workbook.setFormat(k_redRange, w_red);
        w_workbook.setFormat(w_printArea, w_green);

        SimpleWorkbook::SimplePageSetting w_pageSetting1;
        w_pageSetting1.setPrintArea( &w_printArea );
        w_sheet->setPageSetting(w_pageSetting1);

        // complex print area
        w_sheet = static_cast<SimpleWorkbook::SimpleWorksheet*>(w_workbook.newWorksheet("complex print area"));

        const Coordinates::CellRange k_redRange2(w_sheet, 0, 0, 9, 19);
        const Coordinates::CellRange k_greenRange21(w_sheet, 2, 5, 3, 8);
        const Coordinates::CellRange k_greenRange22(w_sheet, 6, 5, 7, 8);
        const Coordinates::CellRange k_greenRange23(w_sheet, 2, 12, 3, 15);
        const Coordinates::CellRange k_greenRange24(w_sheet, 6, 12, 7, 15);

        w_printArea = Coordinates::MultiCellRange();
        w_printArea.addRange( k_greenRange21 );
        w_printArea.addRange( k_greenRange22 );
        w_printArea.addRange( k_greenRange23 );
        w_printArea.addRange( k_greenRange24 );

        w_workbook.setFormat(k_redRange2, w_red);
        w_workbook.setFormat(w_printArea, w_green);

        SimpleWorkbook::SimplePageSetting w_pageSetting2;
        w_pageSetting2.setPrintArea( &w_printArea );
        w_sheet->setPageSetting(w_pageSetting2);

        // headers
        w_sheet = static_cast<SimpleWorkbook::SimpleWorksheet*>(w_workbook.newWorksheet("headers"));

        w_sheet->setStringValue(4,  1, "HEADER 1");
        w_sheet->setStringValue(8,  1, "HEADER 2");
        w_sheet->setStringValue(0,  7, "HEADER A");
        w_sheet->setStringValue(0, 14, "HEADER B");

        const Coordinates::CellRange k_redRange3(w_sheet, 2, 2, 11, 21);
        const Coordinates::CellRange k_greenRange31(w_sheet, 4, 7, 5, 10);
        const Coordinates::CellRange k_greenRange32(w_sheet, 8, 7, 9, 10);
        const Coordinates::CellRange k_greenRange33(w_sheet, 4, 14, 5, 17);
        const Coordinates::CellRange k_greenRange34(w_sheet, 8, 14, 9, 17);

        w_printArea = Coordinates::MultiCellRange();
        w_printArea.addRange( k_greenRange31 );
        w_printArea.addRange( k_greenRange32 );
        w_printArea.addRange( k_greenRange33 );
        w_printArea.addRange( k_greenRange34 );

        w_workbook.setFormat(k_redRange3, w_red);
        w_workbook.setFormat(w_printArea, w_green);

        SimpleWorkbook::SimplePageSetting w_pageSetting3;
        w_pageSetting3.setPrintArea( &w_printArea );
        Coordinates::ColumnRowRange w_columnHeader = Coordinates::ColumnRowRange(Coordinates::Index::itColumn, w_sheet, 0, 1);
        Coordinates::ColumnRowRange w_rowHeader = Coordinates::ColumnRowRange(Coordinates::Index::itRow, w_sheet, 0, 1);
        w_pageSetting3.setHeader( &w_columnHeader );
        w_pageSetting3.setHeader( &w_rowHeader );
        w_sheet->setPageSetting(w_pageSetting3);

        // orientation et adjust
        w_sheet = static_cast<SimpleWorkbook::SimpleWorksheet*>(w_workbook.newWorksheet("portrait"));

        SimpleWorkbook::SimplePageSetting w_pageSetting4;
        w_pageSetting4.setPageOrientation(Invoke::XLSX::Interface::poPortrait);
        w_sheet->setPageSetting(w_pageSetting4);

        w_workbook.setFormat( Coordinates::CellRange(w_sheet, 0, 0, 20, 0), w_green );

        w_sheet = static_cast<SimpleWorkbook::SimpleWorksheet*>(w_workbook.newWorksheet("landscape"));

        SimpleWorkbook::SimplePageSetting w_pageSetting5;
        w_pageSetting5.setPageOrientation(Interface::poLandscape);
        w_sheet->setPageSetting(w_pageSetting5);

        w_workbook.setFormat( Coordinates::CellRange(w_sheet, 0, 0, 20, 0), w_green );

        w_sheet = static_cast<SimpleWorkbook::SimpleWorksheet*>(w_workbook.newWorksheet("portrait 2"));

        SimpleWorkbook::SimplePageSetting w_pageSetting6;
        w_pageSetting6.setPageOrientation(Interface::poPortrait);
        w_pageSetting6.setFitToHeight(1);
        w_pageSetting6.setFitToWidth(1);
        w_sheet->setPageSetting(w_pageSetting6);

        w_workbook.setFormat( Coordinates::CellRange(w_sheet, 0, 0, 20, 0), w_green );

        w_sheet = static_cast<SimpleWorkbook::SimpleWorksheet*>(w_workbook.newWorksheet("landscape 2"));

        SimpleWorkbook::SimplePageSetting w_pageSetting7;
        w_pageSetting7.setPageOrientation(Interface::poLandscape);
        w_pageSetting7.setFitToHeight(1);
        w_pageSetting7.setFitToWidth(1);
        w_sheet->setPageSetting(w_pageSetting7);

        w_workbook.setFormat( Coordinates::CellRange(w_sheet, 0, 0, 20, 0), w_green );

        // headers & footers
        w_sheet = static_cast<SimpleWorkbook::SimpleWorksheet*>(w_workbook.newWorksheet("header - footer (1)"));

        SimpleWorkbook::SimplePageSetting w_pageSetting8;
        Interface::Write::PageHeaderFooter* w_pageHeaderFooter = w_pageSetting8.createPageHeaderFooter();
        try {
            w_pageHeaderFooter->setHeader("HEADER LEFT", "HEADER CENTER", "HEADER RIGHT");
            w_pageHeaderFooter->setFooter("FOOTER LEFT", "FOOTER CENTER", "FOOTER RIGHT");
            w_pageSetting8.setPageHeaderFooter(*w_pageHeaderFooter);

            delete w_pageHeaderFooter;
        } catch (...) {
            delete w_pageHeaderFooter;
            throw;
        }
        w_sheet->setPageSetting(w_pageSetting8);

        w_sheet->setStringValue( 3, 3, "-1-");
        w_sheet->setStringValue(10, 3, "-2-");
        w_workbook.setFormat( Coordinates::CellRange(w_sheet, 3,  3,  3, 55), w_green );
        w_workbook.setFormat( Coordinates::CellRange(w_sheet, 10, 3, 10, 55), w_red );

        w_sheet = static_cast<SimpleWorkbook::SimpleWorksheet*>(w_workbook.newWorksheet("header - footer (2)"));

        SimpleWorkbook::SimplePageSetting w_pageSetting9;
        w_pageHeaderFooter = w_pageSetting9.createPageHeaderFooter();
        try {
            w_pageHeaderFooter->setHeader("ODD HEADER LEFT", "ODD HEADER CENTER", "ODD HEADER RIGHT");
            w_pageHeaderFooter->setFooter("ODD FOOTER LEFT", "ODD FOOTER CENTER", "ODD FOOTER RIGHT");
            w_pageHeaderFooter->setEvenHeader("EVEN HEADER LEFT", "EVEN HEADER CENTER", "EVEN HEADER RIGHT");
            w_pageHeaderFooter->setEvenFooter("EVEN FOOTER LEFT", "EVEN FOOTER CENTER", "EVEN FOOTER RIGHT");
            w_pageHeaderFooter->setFirstHeader("FIRST HEADER LEFT", "FIRST HEADER CENTER", "FIRST HEADER RIGHT");
            w_pageHeaderFooter->setFirstFooter("FIRST FOOTER LEFT", "FIRST FOOTER CENTER", "FIRST FOOTER RIGHT");
            w_pageSetting9.setPageHeaderFooter(*w_pageHeaderFooter);

            delete w_pageHeaderFooter;
        } catch (...) {
            delete w_pageHeaderFooter;
            throw;
        }
        w_sheet->setPageSetting(w_pageSetting9);

        w_sheet->setStringValue( 3, 3, "-1-");
        w_sheet->setStringValue(10, 3, "-2-");
        w_sheet->setStringValue(17, 3, "-3-");
        w_sheet->setStringValue(24, 3, "-4-");
        w_sheet->setStringValue(31, 3, "-5-");
        w_workbook.setFormat( Coordinates::CellRange(w_sheet, 3,  3,  3, 55), w_green );
        w_workbook.setFormat( Coordinates::CellRange(w_sheet, 10, 3, 10, 55), w_red );
        w_workbook.setFormat( Coordinates::CellRange(w_sheet, 17, 3, 17, 55), w_green );
        w_workbook.setFormat( Coordinates::CellRange(w_sheet, 24, 3, 24, 55), w_red );
        w_workbook.setFormat( Coordinates::CellRange(w_sheet, 31, 3, 31, 55), w_green );

        w_sheet = static_cast<SimpleWorkbook::SimpleWorksheet*>(w_workbook.newWorksheet("header - footer (3)"));

        SimpleWorkbook::SimplePageSetting w_pageSettingA;
        w_pageHeaderFooter = w_pageSetting8.createPageHeaderFooter();
        try {
            w_pageHeaderFooter->setHeader(Interface::code(Interface::hfcPath) + Interface::code(Interface::hfcFile), "", Interface::code(Interface::hfcSheet));
            w_pageHeaderFooter->setFooter("", Interface::code(Interface::hfcDate) +" "+ Interface::code(Interface::hfcTime), Interface::code(Interface::hfcPage) +" / "+ Interface::code(Interface::hfcPages));
            w_pageHeaderFooter->setEvenHeader("", "", Interface::headerFooterFontCode("Arial", 12, 0xFF0000FF) + "BLUE!");
            w_pageSettingA.setPageHeaderFooter(*w_pageHeaderFooter);

            delete w_pageHeaderFooter;
        } catch (...) {
            delete w_pageHeaderFooter;
            throw;
        }
        w_sheet->setPageSetting(w_pageSettingA);

        w_sheet->setStringValue( 3, 3, "-1-");
        w_sheet->setStringValue(10, 3, "-2-");
        w_workbook.setFormat( Coordinates::CellRange(w_sheet, 3,  3,  3, 55), w_green );
        w_workbook.setFormat( Coordinates::CellRange(w_sheet, 10, 3, 10, 55), w_red );


#if defined(GENERATE_XLSX)
        saveWorkbook(&w_workbook, XLSX_PATH "07.pageSetting.xlsx");
#endif
#if defined(GENERATE_TEST)
        saveWorkbook(&w_workbook, XLSX_PATH "07.pageSetting.test.xlsx");
#endif

        CPPUNIT_ASSERT_MESSAGE( "Test page setting", isWorkbookValid(&w_workbook, XLSX_PATH "07.pageSetting.xlsx") );

    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxWriterTestClass::testDefinedNames()
{
    try {

        using namespace Invoke::XLSX::SimpleWorkbook;
        using namespace Invoke::XLSX::Coordinates;
        using namespace Invoke::XLSX::Interface;


        CPPUNIT_ASSERT_MESSAGE("valid #01", !isDefinedNameValid("Zone d'impression"));
        CPPUNIT_ASSERT_MESSAGE("valid #02", !isDefinedNameValid("B12"));
        CPPUNIT_ASSERT_MESSAGE("valid #03", !isDefinedNameValid("B12:C$32"));
        CPPUNIT_ASSERT_MESSAGE("valid #04", !isDefinedNameValid("12"));
        CPPUNIT_ASSERT_MESSAGE("valid #05", !isDefinedNameValid("invalid!"));
        CPPUNIT_ASSERT_MESSAGE("valid #06", !isDefinedNameValid("L32_OK"));
        CPPUNIT_ASSERT_MESSAGE("valid #07", !isDefinedNameValid("C42_PLOP"));
        CPPUNIT_ASSERT_MESSAGE("valid #08", !isDefinedNameValid(""));
        CPPUNIT_ASSERT_MESSAGE("valid #09", isDefinedNameValid("valid"));
        CPPUNIT_ASSERT_MESSAGE("valid #10", isDefinedNameValid("ma_plage_préférée"));

        CPPUNIT_ASSERT_MESSAGE("correct #01", correctDefinedName("Zone d'impression") == "Zone_d_impression");
        CPPUNIT_ASSERT_MESSAGE("correct #02", correctDefinedName("B12") == "_B12");
        CPPUNIT_ASSERT_MESSAGE("correct #03", correctDefinedName("B12:C$32") == "B12_C_32");
        CPPUNIT_ASSERT_MESSAGE("correct #04", correctDefinedName("12") == "_12");
        CPPUNIT_ASSERT_MESSAGE("correct #05", correctDefinedName("invalid!") == "invalid_");
        CPPUNIT_ASSERT_MESSAGE("correct #06", correctDefinedName("L32_OK") == "_L32_OK");
        CPPUNIT_ASSERT_MESSAGE("correct #07", correctDefinedName("C42_PLOP") == "_C42_PLOP");
        CPPUNIT_ASSERT_MESSAGE("correct #08", correctDefinedName("") == "_");
        CPPUNIT_ASSERT_MESSAGE("correct #09", correctDefinedName("valid") == "valid");


        SimpleWorkbook w_workbook;

        SimpleCellFormat w_blue;
        w_blue.setSolidBackColor(0xFF0000FF);

        // JCP
        SimpleWorksheet* w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("JCP"));

        MultiCellRange w_ranges;
        w_ranges.addRange( Cell(w_sheet, 2, 10, true) );
        w_ranges.addRange( Cell(w_sheet, 3, 11, true) );
        w_ranges.addRange( CellRange(w_sheet, 4, 3, 4, 10, true) );
        const SimpleDefinedName k_J("_J", w_ranges);

        w_ranges = MultiCellRange();
        w_ranges.addRange( CellRange(w_sheet, 6, 4, 6, 10, true) );
        w_ranges.addRange( Cell(w_sheet, 7, 3, true) );
        w_ranges.addRange( Cell(w_sheet, 7, 11, true) );
        w_ranges.addRange( Cell(w_sheet, 8, 4, true) );
        w_ranges.addRange( Cell(w_sheet, 8, 10, true) );
        const SimpleDefinedName k_C("C", w_ranges); // devient "_C"

        w_ranges = MultiCellRange();
        w_ranges.addRange( CellRange(w_sheet, 10, 3, 10, 11, true) );
        w_ranges.addRange( Cell(w_sheet, 11, 3, true) );
        w_ranges.addRange( Cell(w_sheet, 11, 7, true) );
        w_ranges.addRange( CellRange(w_sheet, 12, 4, 12, 6, true) );
        const SimpleDefinedName k_P("_P", w_ranges);

        w_ranges = MultiCellRange();
        w_ranges.addRange(k_J.zone());
        w_ranges.addRange(k_C.zone());
        w_ranges.addRange(k_P.zone());
        const SimpleDefinedName k_JCP("JCP", w_ranges);
        const SimpleDefinedName k_text("TEXTE", w_ranges);

        w_workbook.setFormat(k_JCP.zone(), w_blue);

        w_workbook.addDefinedName(k_J);
        w_workbook.addDefinedName(k_C);
        w_workbook.addDefinedName(k_P);
        w_workbook.addDefinedName(k_JCP);
        w_workbook.addDefinedName(k_text);

        w_ranges = MultiCellRange();
        w_ranges.addRange( Cell(w_sheet, 0, 0, true) );
        const SimpleDefinedName k_JCP2("JCP", w_ranges);
        w_workbook.addDefinedName(k_JCP2); // ne doit pas apparaitre dans le fichier...

        // 1
        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("1"));

        w_ranges = MultiCellRange();
        w_ranges.addRange( Cell(w_sheet, 2, 5, true) );
        w_ranges.addRange( Cell(w_sheet, 2, 11, true) );
        w_ranges.addRange( CellRange(w_sheet, 3, 3, 3, 11, true) );
        w_ranges.addRange( Cell(w_sheet, 4, 11, true) );
        const SimpleDefinedName k_1("1", w_ranges); // devient "_1"

        // 2
        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("2"));

        w_ranges = MultiCellRange();
        w_ranges.addRange( Cell(w_sheet, 2, 4, true) );
        w_ranges.addRange( CellRange(w_sheet, 2, 9, 2, 11, true) );
        w_ranges.addRange( Cell(w_sheet, 3, 3, true) );
        w_ranges.addRange( Cell(w_sheet, 3, 8, true) );
        w_ranges.addRange( Cell(w_sheet, 3, 11, true) );
        w_ranges.addRange( CellRange(w_sheet, 4, 4, 4, 7, true) );
        w_ranges.addRange( Cell(w_sheet, 4, 11, true) );
        const SimpleDefinedName k_2("_2", w_ranges);

        w_ranges = MultiCellRange();
        w_ranges.addRange(k_1.zone());
        w_ranges.addRange(k_2.zone());
        const SimpleDefinedName k_12("_12", w_ranges);

        w_workbook.setFormat(k_12.zone(), w_blue);

        w_workbook.addDefinedName(k_1);
        w_workbook.addDefinedName(k_2);
        w_workbook.addDefinedName(k_12);  // ne cause pas d'erreurs mais est ignoré par Excel (plage nommées sur plusieurs feuilles).


#if defined(GENERATE_XLSX)
        saveWorkbook(&w_workbook, XLSX_PATH "08.definedNames.xlsx");
#endif
#if defined(GENERATE_TEST)
        saveWorkbook(&w_workbook, XLSX_PATH "08.definedNames.test.xlsx");
#endif

        CPPUNIT_ASSERT_MESSAGE("Test defined name", isWorkbookValid(&w_workbook, XLSX_PATH "08.definedNames.xlsx"));

    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxWriterTestClass::testCharacters()
{
    try {

        using namespace Invoke::XLSX::SimpleWorkbook;
        using namespace Invoke::XLSX::Interface;

        SimpleWorkbook w_workbook;

        Write::Worksheet* w_sheet = w_workbook.newWorksheet("< \" > &");

        w_sheet->setStringValue(1, 1, "< \" > &");
        w_sheet->setNumberValue(1, 2, 0, "IF(AND(A1 < 0, A2 > 0), \"OK\", \"NOT \" & \"OK\")");


#if defined(GENERATE_XLSX)
        saveWorkbook(&w_workbook, XLSX_PATH "09.characters.xlsx");
#endif
#if defined(GENERATE_TEST)
        saveWorkbook(&w_workbook, XLSX_PATH "09.characters.test.xlsx");
#endif

        CPPUNIT_ASSERT_MESSAGE( "Test characters", isWorkbookValid(&w_workbook, XLSX_PATH "09.characters.xlsx") );

    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxWriterTestClass::testConditionalFormatting()
{
    try {

        using namespace Invoke::XLSX::SimpleWorkbook;
        using namespace Invoke::XLSX::Coordinates;
        using namespace Invoke::XLSX::Interface;

        SimpleWorkbook w_workbook;

        Write::Worksheet* w_sheet = w_workbook.newWorksheet("Formats conditionnels");

        for (unsigned int i = 0; i < 11; ++i) {
            w_sheet->setNumberValue(1, i+1, i);
            w_sheet->setNumberValue(3, i+1, i);
            w_sheet->setNumberValue(5, i+1, i);
            w_sheet->setNumberValue(7, i+1, i);
            w_sheet->setNumberValue(9, i+1, i);
        }

        SimpleCellFormat w_format;
        w_format.setBorderVisible(bLeft, true);
        w_format.setBorderColor(bLeft, 0xFF000000);
        w_format.setBorderStyle(bLeft, bsSlantDashDot);
        w_format.setBorderVisible(bTop, true);
        w_format.setBorderColor(bTop, 0xFF000000);
        w_format.setBorderStyle(bTop, bsSlantDashDot);
        w_format.setBorderVisible(bRight, true);
        w_format.setBorderColor(bRight, 0xFF000000);
        w_format.setBorderStyle(bRight, bsSlantDashDot);
        w_format.setBorderVisible(bBottom, true);
        w_format.setBorderColor(bBottom, 0xFF000000);
        w_format.setBorderStyle(bBottom, bsSlantDashDot);
        w_workbook.setFormat( CellRange( static_cast<SimpleWorksheet*>(w_sheet), 5, 1, 5, 11 ), w_format );
        w_workbook.setFormat( CellRange( static_cast<SimpleWorksheet*>(w_sheet), 7, 1, 7, 11 ), w_format );

        // format 1
        SimpleDifferentialCellFormat w_diffFormat1;
        w_diffFormat1.setFontColor(0xFFFFFFFF);
        w_diffFormat1.setFontBold(true);
        w_diffFormat1.setFontItalic(false);
        w_diffFormat1.setFontUnderline(true);
//        wFormat.setNumberFormat("\"DXF\"* #");    // TODO: à corriger
        w_diffFormat1.setSolidBackColor(0xFF000000);
        w_diffFormat1.setBorderVisible(bLeft, true);
        w_diffFormat1.setBorderStyle(bLeft, bsMedium);
        w_diffFormat1.setBorderColor(bLeft, 0xFFFF0000);
        w_diffFormat1.setBorderVisible(bRight, true);
        w_diffFormat1.setBorderStyle(bRight, bsMedium);
        w_diffFormat1.setBorderColor(bRight, 0xFFFF0000);
        w_diffFormat1.setBorderVisible(bBottom, false);

        MultiCellRange w_reference1;
        w_reference1.addRange( CellRange(nullptr, 1, 1, 1, 11) );

        SimpleConditionalFormatting w_conditionnalFormatting1;
        w_conditionnalFormatting1.setFormat(w_diffFormat1);
        w_conditionnalFormatting1.setReference(w_reference1);
        w_conditionnalFormatting1.setFormula("B2 > 5");

        w_sheet->addConditionalFormatting(w_conditionnalFormatting1);

        // format 2
        SimpleDifferentialCellFormat w_diffFormat2;
        w_diffFormat2.setPatternStyle(psLightVertical);
        w_diffFormat2.setForegroundColor(0xFFFF0000);

        MultiCellRange w_reference2;
        w_reference2.addRange( CellRange(nullptr, 3, 1, 3, 11) );

        SimpleConditionalFormatting w_conditionnalFormatting2;
        w_conditionnalFormatting2.setFormat(w_diffFormat2);
        w_conditionnalFormatting2.setReference(w_reference2);
        w_conditionnalFormatting2.setFormula("D2 > 5");

        w_sheet->addConditionalFormatting(w_conditionnalFormatting2);

        // format 3
        SimpleDifferentialCellFormat w_diffFormat3;
        w_diffFormat3.setBorderVisible(bLeft, false);
        w_diffFormat3.setBorderVisible(bRight, false);

        MultiCellRange w_reference3;
        w_reference3.addRange( CellRange(nullptr, 5, 1, 5, 11) );

        SimpleConditionalFormatting w_conditionnalFormatting3;
        w_conditionnalFormatting3.setFormat(w_diffFormat3);
        w_conditionnalFormatting3.setReference(w_reference3);
        w_conditionnalFormatting3.setFormula("F2 > 5");

        w_sheet->addConditionalFormatting(w_conditionnalFormatting3);

        // format 4
        SimpleDifferentialCellFormat w_diffFormat4;
        w_diffFormat4.setBorderVisible(bLeft, false);
        w_diffFormat4.setBorderVisible(bTop, false);
        w_diffFormat4.setBorderVisible(bRight, false);
        w_diffFormat4.setBorderVisible(bBottom, false);

        MultiCellRange w_reference4;
        w_reference4.addRange( CellRange(nullptr, 7, 1, 7, 11) );

        SimpleConditionalFormatting w_conditionnalFormatting4;
        w_conditionnalFormatting4.setFormat(w_diffFormat4);
        w_conditionnalFormatting4.setReference(w_reference4);
        w_conditionnalFormatting4.setFormula("H2 > 5");

        w_sheet->addConditionalFormatting(w_conditionnalFormatting4);

        // format 5
        SimpleDifferentialCellFormat w_diffFormat5;
        w_diffFormat5.setBorderVisible(bLeft, true);
        w_diffFormat5.setBorderStyle(bLeft, bsMedium);
        w_diffFormat5.setBorderVisible(bTop, true);
        w_diffFormat5.setBorderStyle(bTop, bsMedium);
        w_diffFormat5.setBorderVisible(bRight, true);
        w_diffFormat5.setBorderStyle(bRight, bsMedium);
        w_diffFormat5.setBorderVisible(bBottom, true);
        w_diffFormat5.setBorderStyle(bBottom, bsMedium);

        MultiCellRange w_reference5;
        w_reference5.addRange( CellRange(nullptr, 9, 1, 9, 11) );

        SimpleConditionalFormatting w_conditionnalFormatting5;
        w_conditionnalFormatting5.setFormat(w_diffFormat5);
        w_conditionnalFormatting5.setReference(w_reference5);
        w_conditionnalFormatting5.setFormula("J2 > 5");

        w_sheet->addConditionalFormatting(w_conditionnalFormatting5);


#if defined(GENERATE_XLSX)
        saveWorkbook(&w_workbook, XLSX_PATH "10.conditionalFormatting.xlsx");
#endif
#if defined(GENERATE_TEST)
        saveWorkbook(&w_workbook, XLSX_PATH "10.conditionalFormatting.test.xlsx");
#endif

        CPPUNIT_ASSERT_MESSAGE( "Test conditional formatting", isWorkbookValid(&w_workbook, XLSX_PATH "10.conditionalFormatting.xlsx") );

    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxWriterTestClass::testValidations()
{
    try {

        using namespace Invoke::XLSX::SimpleWorkbook;
        using namespace Invoke::XLSX::Coordinates;
        using namespace Invoke::XLSX::Interface;

        SimpleWorkbook w_workbook;

        SimpleWorksheet* w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("validations"));

        SimpleCellFormat w_format;
        w_format.setSolidBackColor(0xFFFFFF00);

        // validation 1
        MultiCellRange w_reference1;
        w_reference1.addRange( CellRange(w_sheet, 1, 2, 2, 12) );

        w_workbook.setFormat( w_reference1, w_format );

        SimpleCustomValidation w_validation1;
        w_validation1.setReference(w_reference1);

        w_validation1.setFormula("AND((B3 > -1), (B3 < 10))");

        w_sheet->addValidation(&w_validation1);

        // validation 2
        MultiCellRange w_reference2;
        w_reference2.addRange( CellRange(w_sheet, 4, 2, 5, 12) );

        w_workbook.setFormat( w_reference2, w_format );

        SimpleListValidation w_validation2;
        w_validation2.setReference(w_reference2);

        valueList_t w_list1;
        w_list1.push_back("Mercure");
        w_list1.push_back("Vénus");
        w_list1.push_back("Terre");
        w_list1.push_back("Mars");
        w_list1.push_back("Jupiter");
        w_list1.push_back("Saturne");
        w_list1.push_back("Uranus");
        w_list1.push_back("Neptune");
        w_validation2.setList(w_list1);

        w_sheet->addValidation(&w_validation2);

        // validation 3
        MultiCellRange w_reference3;
        w_reference3.addRange( CellRange(w_sheet, 1, 22, 2, 32) );

        SimpleCustomValidation w_validation3;
        w_validation3.setReference(w_reference3);

        w_validation3.setFormula("AND((B23 > -1), (B23 < 10))");

        w_sheet->addValidation(&w_validation3);

        // validation 4
        MultiCellRange w_reference4;
        w_reference4.addRange( CellRange(w_sheet, 4, 22, 5, 32) );

        SimpleListValidation w_validation4;
        w_validation4.setReference(w_reference4);

        valueList_t w_list2;
        w_list2.push_back("eau");
        w_list2.push_back("terre");
        w_list2.push_back("feu");
        w_list2.push_back("air");
        w_validation4.setList(w_list2);

        w_sheet->addValidation(&w_validation4);

        // validation 5
        MultiCellRange w_reference5;
        w_reference5.addRange( CellRange(w_sheet, 7, 2, 8, 12) );

        w_workbook.setFormat( w_reference5, w_format );

        SimpleListValidation w_validation5;
        w_validation5.setReference(w_reference5);

        valueList_t w_list3;
        w_list3.push_back("Lorem ipsum dolor sit amet, consectetur adipiscing elit.");
        w_list3.push_back("Vestibulum ultrices a odio et imperdiet.");
        w_list3.push_back("Quisque sit amet erat elit.");
        w_list3.push_back("Curabitur nec ante quis magna auctor ullamcorper quis nec lectus.");
        w_list3.push_back("Mauris sit amet ipsum risus.");
        w_list3.push_back("Suspendisse euismod libero semper ex efficitur ultrices.");
        w_list3.push_back("Fusce a nisl elit.");
        w_list3.push_back("Curabitur ut urna vitae quam porta viverra sed nec dui.");
        w_list3.push_back("Aenean ut eros facilisis, tempor ante eget, elementum augue.");
        w_validation5.setList(w_list3);

        w_sheet->addValidation(&w_validation5);

        // validation 6
        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("validations"));

        MultiCellRange w_reference6;
        w_reference6.addRange( CellRange(w_sheet, 4, 2, 5, 12) );

        w_workbook.setFormat( w_reference6, w_format );

        SimpleListValidation w_validation6;
        w_validation6.setReference(w_reference6);
        w_validation6.setList(w_list1);

        w_sheet->addValidation(&w_validation6);

        // validations 7
        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("validations"));

        valueList_t w_list4;
        w_list4.push_back("lundi");
        w_list4.push_back("mardi");
        w_list4.push_back("mercredi");
        w_list4.push_back("jeudi");
        w_list4.push_back("vendredi");
        w_list4.push_back("samedi");
        w_list4.push_back("dimanche");

        typedef std::unordered_set<const Cell*> cells_t;
        cells_t w_cells = {
            new Cell(w_sheet, 3, 4),
            new Cell(w_sheet, 7, 2),
            new Cell(w_sheet, 1, 3),
            new Cell(w_sheet, 5, 2),
            new Cell(w_sheet, 8, 4),
            new Cell(w_sheet, 4, 2),
            new Cell(w_sheet, 5, 4),
            new Cell(w_sheet, 7, 3),
            new Cell(w_sheet, 1, 2),
            new Cell(w_sheet, 8, 3),
            new Cell(w_sheet, 3, 2),
            new Cell(w_sheet, 8, 2),
            new Cell(w_sheet, 1, 4),
            new Cell(w_sheet, 7, 4)
        };
        try {
            for (cells_t::const_iterator w_it = w_cells.begin(); w_it != w_cells.end(); ++w_it) {
                MultiCellRange w_reference7;
                w_reference7.addRange( **w_it );

                SimpleListValidation w_validation7;
                w_validation7.setReference(w_reference7);
                w_validation7.setList(w_list4);
                w_sheet->addValidation(&w_validation7);

                w_workbook.setFormat(**w_it, w_format);
            }

            for (cells_t::const_iterator w_it = w_cells.begin(); w_it != w_cells.end(); ++w_it)
                delete *w_it;
        } catch (...) {
            for (cells_t::const_iterator w_it = w_cells.begin(); w_it != w_cells.end(); ++w_it)
                delete *w_it;
            throw;
        }

        // validation 8
        w_sheet->setStringValue(1, 11, "Frodon Sacquet");
        w_sheet->setStringValue(1, 12, "Samsagace Gamegie");
        w_sheet->setStringValue(1, 13, "Peregrin Touque");
        w_sheet->setStringValue(1, 14, "Meriadoc Brandebouc");
        w_sheet->setStringValue(1, 15, "Aragon");
        w_sheet->setStringValue(1, 16, "Boromir");
        w_sheet->setStringValue(1, 17, "Legolas");
        w_sheet->setStringValue(1, 18, "Gimli");
        w_sheet->setStringValue(1, 19, "Gandalf");

        MultiCellRange w_reference8;
        w_reference8.addRange( CellRange(w_sheet, 3, 11, 4, 19) );

        SimpleListValidation w_validation8;
        w_validation8.setReference(w_reference8);
        w_validation8.setRangeReference( CellRange(w_sheet, 1, 11, 1, 19, true) );
        w_sheet->addValidation(&w_validation8);

        w_workbook.setFormat( w_reference8, w_format );


#if defined(_MSC_VER)
#define _XLSX_SUFFIX    "windows"
#else
#define _XLSX_SUFFIX    "linux"
#endif

#if defined(GENERATE_XLSX)
        saveWorkbook(&w_workbook, XLSX_PATH "11.validations." _XLSX_SUFFIX ".xlsx");
#endif
#if defined(GENERATE_TEST)
        saveWorkbook(&w_workbook, XLSX_PATH "11.validations." _XLSX_SUFFIX ".test.xlsx");
#endif

        CPPUNIT_ASSERT_MESSAGE( "Test validations", isWorkbookValid(&w_workbook, XLSX_PATH "11.validations." _XLSX_SUFFIX ".xlsx") );

#undef _XLSX_SUFFIX

    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

bool loadImage(const std::string& p_fileName, unsigned char*& o_memory, unsigned int& o_size)
{
    o_memory = nullptr;
    o_size = 0;

    try {
        std::fstream w_file(p_fileName, std::fstream::binary | std::fstream::in);
        o_size = static_cast<unsigned int>(w_file.seekg(0, std::ios_base::end).tellg());

        o_memory = (unsigned char*)malloc(o_size * sizeof(unsigned char));
        w_file.seekg(0, std::ios_base::beg);
        w_file.read((char*)o_memory, o_size);
        w_file.close();
    } catch (...) {
        free(o_memory);

        o_memory = nullptr;
        o_size = 0;
        return false;
    }

    return true;
}

void testImageSize(const Invoke::XLSX::Interface::imageType_t p_type)
{
    using namespace Invoke::XLSX::SimpleWorkbook;
    using namespace Invoke::XLSX::Coordinates;
    using namespace Invoke::XLSX::Interface;

    const std::string k_strType = stringImageType(p_type);
    const unsigned int k_imageWidth = 594;
    const unsigned int k_imageHeight = 446;

    unsigned char* w_memory = nullptr;
    unsigned int w_size = 0;

    imageType_t w_type = itUnknown;
    unsigned int w_width = 0;
    unsigned int w_height = 0;

    loadImage(XLSX_PATH "mire." + k_strType, w_memory, w_size);
    try {
        CPPUNIT_ASSERT_MESSAGE("Test images ("+ k_strType +") #1", getImageProperties(w_memory, w_size, w_type, w_width, w_height));

        free(w_memory);
    } catch (...) {
        free(w_memory);
        throw;
    }

    CPPUNIT_ASSERT_MESSAGE("Test images ("+ k_strType +") #2", ((w_type == p_type) && (w_width == k_imageWidth) && (w_height == k_imageHeight)));
}

void insertImage(Invoke::XLSX::SimpleWorkbook::SimpleWorksheet* p_worksheet, Invoke::XLSX::Interface::imageType_t p_type, const Invoke::XLSX::Coordinates::CellPoint& p_topLeft, const Invoke::XLSX::Coordinates::CellPoint* p_rightBottom, Invoke::XLSX::Interface::imageProperty_t p_property, const Invoke::XLSX::Interface::pixelRectangle_t* p_cropRectangle)
{
    using namespace Invoke::XLSX::SimpleWorkbook;
    using namespace Invoke::XLSX::Coordinates;
    using namespace Invoke::XLSX::Interface;

    const std::string k_strType = stringImageType(p_type);

    unsigned char* w_memory = nullptr;
    unsigned int w_size = 0;

    loadImage(XLSX_PATH "mire."+ k_strType, w_memory, w_size);
    try {
        SimpleImage w_image;

        w_image.setImage(w_memory, w_size, false);
        w_memory = nullptr;

        w_image.setTopLeft(p_topLeft);
        w_image.setRightBottom(p_rightBottom);

        w_image.setProperty(p_property);

        w_image.setCropRectangle(p_cropRectangle);

        p_worksheet->addImage(&w_image);
    } catch (...) {
        free(w_memory);
        throw;
    }
}

void XlsxWriterTestClass::testImages()
{
    try {

        using namespace Invoke::XLSX::SimpleWorkbook;
        using namespace Invoke::XLSX::Coordinates;
        using namespace Invoke::XLSX::Interface;

        // tests sur les images
        testImageSize(itJPG);
        testImageSize(itGIF);
        testImageSize(itPNG);
        testImageSize(itBMP);

        SimpleWorkbook w_workbook;
        SimpleWorksheet* w_sheet;

        const double k_columnWidth = 20;
        const double k_rowHeight = 30;

        // jpg
        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("jpg"));
        insertImage(w_sheet, itJPG, CellPoint(w_sheet, 2, 2, 0, 0), nullptr, ipStatic, nullptr);

        // gif
        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("gif"));
        w_sheet->setColumnWidth(5, &k_columnWidth);
        insertImage(w_sheet, itGIF, CellPoint(w_sheet, 2, 2, 0, 0), nullptr, ipStatic, nullptr);

        // png
        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("png"));
        w_sheet->setRowHeight(10, &k_rowHeight);
        insertImage(w_sheet, itPNG, CellPoint(w_sheet, 2, 2, 0, 0), nullptr, ipStatic, nullptr);

        // bmp
        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("bmp"));
        w_sheet->setColumnWidth(5, &k_columnWidth);
        w_sheet->setRowHeight(10, &k_rowHeight);
        insertImage(w_sheet, itBMP, CellPoint(w_sheet, 2, 2, 0, 0), nullptr, ipStatic, nullptr);

        // propriétés
        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("propriétés"));
        CellPoint w_rightBottom = CellPoint(w_sheet, 5, 7, 0, 0);
        insertImage(w_sheet, itPNG, CellPoint(w_sheet, 2, 2, 0, 0), &w_rightBottom, ipStatic, nullptr);
        w_rightBottom = CellPoint(w_sheet, 5, 14, 0, 0);
        insertImage(w_sheet, itPNG, CellPoint(w_sheet, 2, 9, 0, 0), &w_rightBottom, ipMoveWithCells, nullptr);
        w_rightBottom = CellPoint(w_sheet, 5, 21, 0, 0);
        insertImage(w_sheet, itJPG, CellPoint(w_sheet, 2, 16, 0, 0), &w_rightBottom, ipMoveAndResizeWithCells, nullptr);

        w_sheet->setColumnWidth(7, &k_columnWidth);
        w_sheet->setRowHeight(25, &k_rowHeight);
        w_sheet->setRowHeight(32, &k_rowHeight);
        w_sheet->setRowHeight(39, &k_rowHeight);

        w_rightBottom = CellPoint(w_sheet, 9, 28, 0, 0);
        insertImage(w_sheet, itPNG, CellPoint(w_sheet, 6, 23, 0, 0), &w_rightBottom, ipStatic, nullptr);
        w_rightBottom = CellPoint(w_sheet, 9, 35, 0, 0);
        insertImage(w_sheet, itPNG, CellPoint(w_sheet, 6, 30, 0, 0), &w_rightBottom, ipMoveWithCells, nullptr);
        w_rightBottom = CellPoint(w_sheet, 9, 42, 0, 0);
        insertImage(w_sheet, itJPG, CellPoint(w_sheet, 6, 37, 0, 0), &w_rightBottom, ipMoveAndResizeWithCells, nullptr);

        w_sheet->setMerge(CellRange(w_sheet, 10, 2, 13, 7));
        w_sheet->setMerge(CellRange(w_sheet, 10, 9, 13, 14));
        w_sheet->setMerge(CellRange(w_sheet, 10, 16, 13, 21));

        w_rightBottom = CellPoint(w_sheet, 13, 7, 0, 0);
        insertImage(w_sheet, itGIF, CellPoint(w_sheet, 10, 2, 0, 0), &w_rightBottom, ipStatic, nullptr);
        w_rightBottom = CellPoint(w_sheet, 13, 14, 0, 0);
        insertImage(w_sheet, itGIF, CellPoint(w_sheet, 10, 9, 0, 0), &w_rightBottom, ipMoveWithCells, nullptr);
        w_rightBottom = CellPoint(w_sheet, 13, 21, 0, 0);
        insertImage(w_sheet, itGIF, CellPoint(w_sheet, 10, 16, 0, 0), &w_rightBottom, ipMoveAndResizeWithCells, nullptr);

        // rognage
        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("rognage"));

        pixelRectangle_t w_crop;
        w_crop.left = 228;
        w_crop.top = 32;
        w_crop.width = 140;
        w_crop.height = 33;

        w_rightBottom = CellPoint(w_sheet, 4, 3, 0, CellPoint::pixelToEMU(5));
        insertImage(w_sheet, itJPG, CellPoint(w_sheet, 2, 2, 0, 0), &w_rightBottom, ipMoveAndResizeWithCells, &w_crop);

        insertImage(w_sheet, itJPG, CellPoint(w_sheet, 2, 6, 0, 0), nullptr, ipMoveAndResizeWithCells, &w_crop);


#if defined(GENERATE_XLSX)
        saveWorkbook(&w_workbook, XLSX_PATH "12.images.xlsx");
#endif
#if defined(GENERATE_TEST)
        saveWorkbook(&w_workbook, XLSX_PATH "12.images.test.xlsx");
#endif

        CPPUNIT_ASSERT_MESSAGE( "Test images", isWorkbookValid(&w_workbook, XLSX_PATH "12.images.xlsx") );

    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxWriterTestClass::testHyperlinks()
{
    try {

        using namespace Invoke::XLSX::SimpleWorkbook;
        using namespace Invoke::XLSX::Coordinates;
        using namespace Invoke::XLSX::Interface;

        SimpleWorkbook w_workbook;
        SimpleWorksheet* w_sheet;

        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("links"));
        w_workbook.newWorksheet("far away");


        const Cell k_location1 = Cell(w_sheet, 4, 2);
        const CellRange k_location2 = CellRange(w_sheet, 4, 4, 6, 4);
        const CellRange k_location3 = CellRange(w_sheet, 4, 6, 6, 8);
        const CellRange k_location4 = CellRange(w_workbook.worksheet(1), 2, 2, 4, 4);

        MultiCellRange w_zone1;
        w_zone1.addRange(k_location2);
        const SimpleDefinedName k_definedName1 = SimpleDefinedName("RANGE_E5G5", w_zone1);

        MultiCellRange w_zone2;
        w_zone2.addRange(k_location1);
        w_zone2.addRange(k_location2);
        w_zone2.addRange(k_location3);
        const SimpleDefinedName k_definedName2 = SimpleDefinedName("MULTI_E3_E5G5_E7G9", w_zone2);

        w_workbook.addDefinedName(k_definedName1);
        w_workbook.addDefinedName(k_definedName2);

        SimpleCellFormat w_green;
        w_green.setSolidBackColor(0xFF00FF00);
        w_workbook.setFormat(k_location1, w_green);
        w_workbook.setFormat(k_location2, w_green);
        w_workbook.setFormat(k_location3, w_green);
        w_workbook.setFormat(k_location4, w_green);

        SimpleCellFormat w_red;
        w_red.setSolidBackColor(0xFFFF0000);
        SimpleCellFormat w_blue;
        w_blue.setSolidBackColor(0xFF0000FF);

        const CellRange k_range1 = CellRange(w_sheet, 2, 13, 4, 20);
        const CellRange k_range2 = CellRange(w_sheet, 6, 13, 6, 20);
        const Cell k_range3 = Cell(w_sheet, 3, 16);
        const Cell k_range4 = Cell(w_sheet, 8, 13);
        w_workbook.setFormat(k_range1, w_red);
        w_workbook.setFormat(k_range2, w_red);
        w_workbook.setFormat(k_range3, w_blue);
        w_workbook.setFormat(k_range4, w_blue);

        w_sheet->setStringValue(2, 2, "LIEN VERS E3");
        SimpleHyperlink w_link1;
        w_link1.setReference(Cell(w_sheet, 2, 2));
        w_link1.setLocation(k_location1);
        w_link1.setDisplay("LINK 1");
        w_link1.setTooltip("LINK 1 TOOLTIP");
        w_sheet->addHyperlink(&w_link1);

        w_sheet->setStringValue(2, 3, "LIEN VERS E5:G5");
        SimpleHyperlink w_link2;
        w_link2.setReference(Cell(w_sheet, 2, 3));
        w_link2.setLocation(k_location2);
        w_sheet->addHyperlink(&w_link2);

        w_sheet->setStringValue(2, 4, "LIEN VERS E7:G9");
        SimpleHyperlink w_link3;
        w_link3.setReference(Cell(w_sheet, 2, 4));
        w_link3.setLocation(k_location3);
        w_link3.setDisplay("LINK 3 -> E7:G9");
        w_sheet->addHyperlink(&w_link3);

        w_sheet->setStringValue(2, 5, k_location4.name(nullptr));
        SimpleHyperlink w_link4;
        w_link4.setReference(Cell(w_sheet, 2, 5));
        w_link4.setLocation(k_location4);
        w_link4.setDisplay("LINK 4");
        w_sheet->addHyperlink(&w_link4);


        w_sheet->setStringValue(2, 7, "RANGE_E5G5");
        SimpleHyperlink w_link5;
        w_link5.setReference(Cell(w_sheet, 2, 7));
        w_link5.setLocation(k_definedName1);
        w_link5.setDisplay("LINK 5 -> RANGE_E5G5");
        w_sheet->addHyperlink(&w_link5);

        w_sheet->setStringValue(2, 8, "Multi range");
        SimpleHyperlink w_link6;
        w_link6.setReference(Cell(w_sheet, 2, 8));
        w_link6.setLocation(k_definedName2);
        w_link6.setDisplay("LINK 6 -> MULTI_E3_E5G5_E7G9");
        w_sheet->addHyperlink(&w_link6);


        w_sheet->setStringValue(2, 10, "WIN.INI");
        SimpleHyperlink w_link7;
        w_link7.setReference(Cell(w_sheet, 2, 10));
        w_link7.setFileLocation("c:\\Windows\\win.ini");
        w_link7.setDisplay("FILE");
        w_sheet->addHyperlink(&w_link7);

        w_sheet->setStringValue(2, 11, "UN MAIL");
        SimpleHyperlink w_link8;
        w_link8.setReference(Cell(w_sheet, 2, 11));
        w_link8.setMailLocation("jcphilippe@invoke.fr", "mail from Excel");
        w_link8.setDisplay("MAIL");
        w_sheet->addHyperlink(&w_link8);


        SimpleHyperlink w_link9;
        w_link9.setReference(k_range1);
        w_link9.setLocation(k_range2);
        w_sheet->addHyperlink(&w_link9);

        SimpleHyperlink w_link10;
        w_link10.setReference(k_range3);
        w_link10.setLocation(k_range4);
        w_sheet->addHyperlink(&w_link10);


#if defined(GENERATE_XLSX)
        saveWorkbook(&w_workbook, XLSX_PATH "13.hyperlinks.xlsx");
#endif
#if defined(GENERATE_TEST)
        saveWorkbook(&w_workbook, XLSX_PATH "13.hyperlinks.test.xlsx");
#endif

        CPPUNIT_ASSERT_MESSAGE( "Test hypers liens", isWorkbookValid(&w_workbook, XLSX_PATH "13.hyperlinks.xlsx") );

    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxWriterTestClass::testSelections()
{
    try {

        using namespace Invoke::XLSX::SimpleWorkbook;
        using namespace Invoke::XLSX::Coordinates;
        using namespace Invoke::XLSX::Interface;

        SimpleWorkbook w_workbook;
        SimpleWorksheet* w_sheet;

        SimpleCellFormat w_red;
        w_red.setSolidBackColor(0xFFFF0000);

        MultiCellRange w_range;
        Cell w_cell = Cell(nullptr, 0, 0);

        // cell
        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("cell"));

        w_cell = Cell(w_sheet, 2, 3);

        w_workbook.setFormat(w_cell, w_red);

        w_sheet->setStringValue(w_cell.column(), w_cell.row(), "C4");
        w_sheet->setActiveCell( w_cell );

        // simple range
        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("simple range"));

        w_range = MultiCellRange();
        w_range.addRange( CellRange(w_sheet, 2, 3, 4, 6) );
        w_cell = Cell(w_sheet, 2, 3);

        w_workbook.setFormat(w_range, w_red);

        w_sheet->setStringValue(w_cell.column(), w_cell.row(), "C4");
        w_sheet->setSelection( w_range );
        w_sheet->setActiveCell( w_cell );

        // range
        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("range"));

        w_range = MultiCellRange();
        w_range.addRange( CellRange(w_sheet, 2, 3, 4, 6) );
        w_cell = Cell(w_sheet, 3, 4);

        w_workbook.setFormat(w_range, w_red);

        w_sheet->setStringValue(w_cell.column(), w_cell.row(), "D5");
        w_sheet->setSelection( w_range );
        w_sheet->setActiveCell( w_cell );

        // multi selection
        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("multi selection"));

        w_range = MultiCellRange();
        w_range.addRange( CellRange(w_sheet, 2, 3, 3, 4) );
        w_range.addRange( CellRange(w_sheet, 2, 8, 6, 8) );
        w_range.addRange( CellRange(w_sheet, 5, 3, 6, 4) );
        w_cell = Cell(w_sheet, 4, 8);

        w_workbook.setFormat(w_range, w_red);

        w_sheet->setStringValue(w_cell.column(), w_cell.row(), "E9");
        w_sheet->setSelection( w_range );
        w_sheet->setActiveCell( w_cell );

        // split
        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("split"));
        w_sheet->setXSplit(1);

        w_range = MultiCellRange();
        w_range.addRange( CellRange(w_sheet, 2, 3, 4, 6) );
        w_cell = Cell(w_sheet, 2, 3);

        w_workbook.setFormat(w_range, w_red);

        w_sheet->setStringValue(w_cell.column(), w_cell.row(), "C4");
        w_sheet->setSelection( w_range );
        w_sheet->setActiveCell( w_cell );


#if defined(GENERATE_XLSX)
        saveWorkbook(&w_workbook, XLSX_PATH "14.selections.xlsx");
#endif
#if defined(GENERATE_TEST)
        saveWorkbook(&w_workbook, XLSX_PATH "14.selections.test.xlsx");
#endif

        CPPUNIT_ASSERT_MESSAGE( "Test sélections", isWorkbookValid(&w_workbook, XLSX_PATH "14.selections.xlsx") );

    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxWriterTestClass::testComments()
{
    try {

        using namespace Invoke::XLSX::SimpleWorkbook;
        using namespace Invoke::XLSX::Coordinates;
        using namespace Invoke::XLSX::Interface;

        SimpleWorkbook w_workbook;
        SimpleWorksheet* w_sheet;
        SimpleComment w_comment;

        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("auteurs"));

        w_comment.setReference( Cell(w_sheet, 2, 2) );
        w_comment.setAuthor("INVOKE");
        w_comment.addRun( {"Arial", 8, 0x000000, false, false, false}, "Get ahead" );
        w_sheet->addComment(&w_comment);

        w_comment.reset();
        w_comment.setReference( Cell(w_sheet, 2, 8) );
        w_comment.setAuthor("Buzz Lightyear");
        w_comment.addRun( {"Arial", 8, 0x000000, false, false, false}, "To infinity, and beyond!");
        CPPUNIT_ASSERT_MESSAGE("comment #01", w_sheet->addComment(&w_comment));

        w_comment.reset();
        w_comment.setReference( Cell(w_sheet, 2, 2) );
        w_comment.setAuthor("Mister Magoo");
        w_comment.addRun( {"Arial", 8, 0x000000, false, false, false}, "Oups! there is already a comment here!" );
        CPPUNIT_ASSERT_MESSAGE("comment #02", !w_sheet->addComment(&w_comment));

        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("alignement"));

        w_comment.reset();
        w_comment.setReference( Cell(w_sheet, 2, 2) );
        w_comment.setAuthor("Yoda");
        w_comment.addRun( {"Arial", 8, 0x000000, false, false, false}, "Wars not make one great." );
        w_sheet->addComment(&w_comment);

        w_comment.reset();
        w_comment.setReference( Cell(w_sheet, 2, 4) );
        w_comment.setAuthor("Yoda");
        w_comment.addRun( {"Arial", 8, 0x000000, false, false, false}, "Do.\nOr do not.\nThere is no try.");
        w_comment.setAlignment(haCenter);
        w_sheet->addComment(&w_comment);

        w_comment.reset();
        w_comment.setReference( Cell(w_sheet, 2, 6) );
        w_comment.setAuthor("Yoda");
        w_comment.addRun( {"Arial", 8, 0x000000, false, false, false}, "Truly wonderful,\nthe mind of a child is." );
        w_comment.setAlignment(haRight);
        w_sheet->addComment(&w_comment);

        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("paragraphes"));

        w_comment.reset();
        w_comment.setReference( Cell(w_sheet, 2, 2) );
        w_comment.setAuthor("Gandalf");
        w_comment.addRun( {"Arial", 8, 0x000000, true, false, false}, "You cannot pass!\n");
        w_comment.addRun( {"Arial", 8, 0x000000, false, true, false}, "I am a servant of the Secret Fire, wielder of the Flame of Anor.\n");
        w_comment.addRun( {"Arial", 8, 0xFF0000, false, false, false}, "The dark fire will not avail you, Flame of Udun!\n");
        w_comment.addRun( {"Arial", 12, 0x000000, false, false, false}, "Go back to ");
        w_comment.addRun( {"Arial", 12, 0x000000, false, false, true}, "the shadow.\n" );
        w_comment.addRun( {"Impact", 8, 0x000000, false, false, false}, "You shall not pass!");
        w_comment.setAutoSize(true);
        w_sheet->addComment(&w_comment);

        w_comment.reset();
        w_comment.setReference( Cell(w_sheet, 4, 2) );
        w_comment.setAuthor("Monty Python");
        w_comment.addRun( {"Arial", 8, 0x0000FF, false, false, true}, "We are the knights who say 'Ni!'" );
        w_comment.setHyperlink("https://en.wikipedia.org/wiki/Holy_Grail");
        w_comment.setVisibility(vVisible);
        w_sheet->addComment(&w_comment);

        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("tailles"));

        w_comment.reset();
        w_comment.setReference( Cell(w_sheet, 2, 2) );
        w_comment.setAuthor("Richard Simon");
        w_comment.addRun( {"Arial", 8, 0x000000, false, false, false}, "Au fin fond de l'Univers, à des années et des années-lumière de la Terre,\n");
        w_comment.addRun( {"Arial", 8, 0x000000, false, false, false}, "Veille celui que le gouvernement intersidéral appelle\n" );
        w_comment.addRun( {"Arial", 8, 0x000000, false, false, false}, "Quand il n'est plus capable de trouver une solution à ses problèmes,\n" );
        w_comment.addRun( {"Arial", 8, 0x000000, false, false, false}, "Quand il ne reste plus aucun espoir :\n" );
        w_comment.addRun( {"Arial", 8, 0x000000, false, false, false}, "le Capitaine FLAM !" );
        w_comment.setAutoSize(true);
        w_sheet->addComment(&w_comment);

        w_comment.reset();
        w_comment.setReference( Cell(w_sheet, 2, 6) );
        w_comment.setAuthor("Nick Carr");
        w_comment.addRun( {"Arial", 8, 0x000000, false, false, false}, "Va Jayce, conquérant du lointain. Recherche ton père. Illumine les chemins obscurs de l´univers.\n" );
        w_comment.addRun( {"Arial", 8, 0x000000, false, false, false}, "Va Jayce, conquérant de demain. La racine que tu portes à ton coeur doit s´unir à celle que porte ton père.\n" );
        w_comment.addRun( {"Arial", 8, 0x000000, false, false, false}, "Va Jayce, conquérant du bonheur, vient libérer le monde de la terreur des monstroplantes." );
        w_comment.setTopLeft( CellPoint(w_sheet, 4, 8, 100000, 100000) );
        w_comment.setRightBottom( CellPoint(w_sheet, 11, 11, 100000, 100000) );
        w_comment.setVisibility(vVisible);
        w_sheet->addComment(&w_comment);

        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("propriétés"));

        w_comment.reset();
        w_comment.setReference( Cell(w_sheet, 2, 2) );
        w_comment.setAuthor("HAL");
        w_comment.addRun( {"Arial", 8, 0x000000, false, false, false}, "I’m sorry, Dave.\nI’m afraid I can’t do that." );
        w_comment.setVisibility(vVisible);
        w_sheet->addComment(&w_comment);

        w_comment.reset();
        w_comment.setReference( Cell(w_sheet, 2, 8) );
        w_comment.setAuthor("Homer Simpson");
        w_comment.addRun( {"Arial", 8, 0xFFFF00, true, false, false}, "Beer: The cause of, and solution to, all of life's problems." );
        w_comment.setProperty(cpMoveAndResizeWithCells);
        w_comment.setFillColor(0x0000FF);
        w_comment.setVisibility(vVisible);
        w_sheet->addComment(&w_comment);

        w_comment.reset();
        w_comment.setReference( Cell(w_sheet, 5, 8) );
        w_comment.setAuthor("Homer Simpson");
        w_comment.addRun( {"Arial", 8, 0x000000, true, false, false}, "It takes two to lie : one to lie and one to listen." );
        w_comment.setProperty(cpMoveWithCells);
        w_comment.setFillColor(0xFFFFFF);
        w_comment.setVisibility(vVisible);
        w_sheet->addComment(&w_comment);

        w_comment.reset();
        w_comment.setReference( Cell(w_sheet, 8, 8) );
        w_comment.setAuthor("Homer Simpson");
        w_comment.addRun( {"Arial", 8, 0x00FFFF, true, false, false}, "Donuts. Is there anything they can't do?" );
        w_comment.setProperty(cpStatic);
        w_comment.setFillColor(0xFF0000);
        w_comment.setVisibility(vVisible);
        w_sheet->addComment(&w_comment);


#if defined(GENERATE_XLSX)
        saveWorkbook(&w_workbook, XLSX_PATH "15.comments.xlsx");
#endif
#if defined(GENERATE_TEST)
        saveWorkbook(&w_workbook, XLSX_PATH "15.comments.test.xlsx");
#endif

        CPPUNIT_ASSERT_MESSAGE( "Test commentaires", isWorkbookValid(&w_workbook, XLSX_PATH "15.comments.xlsx") );

    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxWriterTestClass::testRedmine70163()
{
    try {

        using namespace Invoke::XLSX::SimpleWorkbook;
        using namespace Invoke::XLSX::Coordinates;
        using namespace Invoke::XLSX::Interface;

        SimpleWorkbook w_workbook;
        SimpleWorksheet* w_sheet;

        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("image"));

        const double k_largeWidth = 100;
        w_sheet->setColumnWidth(1, &k_largeWidth);

        insertImage(w_sheet, itPNG, CellPoint(w_sheet, 1, 1, 5400000, 60000), nullptr, ipStatic, nullptr);


#if defined(GENERATE_XLSX)
        saveWorkbook(&w_workbook, XLSX_PATH "16.redmine70163.xlsx");
#endif
#if defined(GENERATE_TEST)
        saveWorkbook(&w_workbook, XLSX_PATH "16.redmine70163.test.xlsx");
#endif

        CPPUNIT_ASSERT_MESSAGE( "Test redmine 70163", isWorkbookValid(&w_workbook, XLSX_PATH "16.redmine70163.xlsx") );

    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxWriterTestClass::testFilters()
{
    try {

        using namespace Invoke::XLSX::SimpleWorkbook;
        using namespace Invoke::XLSX::Coordinates;
        using namespace Invoke::XLSX::Interface;

        SimpleWorkbook w_workbook;
        SimpleWorksheet* w_sheet;

        // filtre
        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("planètes"));

        w_sheet->setStringValue(1,  2, "Planètes");
        w_sheet->setStringValue(1,  3, "Mercure");
        w_sheet->setStringValue(1,  4, "Vénus");
        w_sheet->setStringValue(1,  5, "Terre");
        w_sheet->setStringValue(1,  6, "Mars");
        w_sheet->setStringValue(1,  7, "Jupiter");
        w_sheet->setStringValue(1,  8, "Saturne");
        w_sheet->setStringValue(1,  9, "Uranus");
        w_sheet->setStringValue(1, 10, "Neptune");
        
        SimpleFilter w_filter;
        w_filter.setRangeReference(Invoke::XLSX::Coordinates::CellRange(w_sheet->proxy(), 1, 2, 1, 10));
        w_sheet->setFilter(w_filter);

        // filtre multi-colonnes
        w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("planètes & lunes"));

        const std::string k_planets[83][2] = {
            {"Planètes", "Lunes"},
            
            {"Mercure", ""},
            
            {"Vénus", ""},
            
            {"Terre", "Lune"},

            {"Mars", "Phobos"},
            {"Mars", "Déimos"},

            {"Jupiter", "Ganymède"},
            {"Jupiter", "Callisto"},
            {"Jupiter", "Europe"},
            {"Jupiter", "Io"},
            {"Jupiter", "Amalthée"},
            {"Jupiter", "Himalia"},
            {"Jupiter", "Thébé"},
            {"Jupiter", "Sinopé"},
            {"Jupiter", "Pasiphaé"},
            {"Jupiter", "Carmé"},
            {"Jupiter", "Ananké"},
            {"Jupiter", "Élara"},
            {"Jupiter", "Lysithéa"},
            {"Jupiter", "Léda"},
            {"Jupiter", "Adrastée"},
            {"Jupiter", "Métis"},

            {"Saturne", "Titan"},
            {"Saturne", "Japet"},
            {"Saturne", "Rhéa"},
            {"Saturne", "Dioné"},
            {"Saturne", "Téthys"},
            {"Saturne", "Phœbé"},
            {"Saturne", "Hypérion"},
            {"Saturne", "Encelade"},
            {"Saturne", "Mimas"},
            {"Saturne", "Janus"},
            {"Saturne", "Épiméthée"},
            {"Saturne", "Pandore"},
            {"Saturne", "Prométhée"},
            {"Saturne", "Hélène"},
            {"Saturne", "Calypso"},
            {"Saturne", "Télesto"},
            {"Saturne", "Atlas"},
            {"Saturne", "Pan"},
            {"Saturne", "Pollux"},
            {"Saturne", "Kiviuq"},
            {"Saturne", "Ijiraq"},
            {"Saturne", "Paaliaq"},
            {"Saturne", "Albiorix"},
            {"Saturne", "Siarnaq"},
            {"Saturne", "Tarvos"},
            {"Saturne", "Ymir"},

            {"Uranus", "Ariel"},
            {"Uranus", "Umbriel"},
            {"Uranus", "Titania"},
            {"Uranus", "Obéron"},
            {"Uranus", "Sycorax"},
            {"Uranus", "Miranda"},
            {"Uranus", "Puck"},
            {"Uranus", "Portia"},
            {"Uranus", "Setebos"},
            {"Uranus", "Prospero"},
            {"Uranus", "Stephano"},
            {"Uranus", "Caliban"},
            {"Uranus", "Perdita"},
            {"Uranus", "Belinda"},
            {"Uranus", "Rosalinde"},
            {"Uranus", "Juliette"},
            {"Uranus", "Desdémone"},
            {"Uranus", "Cressida"},
            {"Uranus", "Bianca"},
            {"Uranus", "Cordélia"},
            {"Uranus", "Ophélie"},

            {"Neptune", "Triton"},
            {"Neptune", "Protée"},
            {"Neptune", "Néréide"},
            {"Neptune", "Larissa"},
            {"Neptune", "Galatée"},
            {"Neptune", "Despina"},
            {"Neptune", "Thalassa"},
            {"Neptune", "Naïade"},
            {"Neptune", "Halimède"},
            {"Neptune", "Néso"},
            {"Neptune", "Sao"},
            {"Neptune", "Laomédie"},
            {"Neptune", "Psamathée"},
            {"Neptune", "S/2004 N 1"}
        };

        for (unsigned int w_it = 0; w_it < 83; ++w_it) {
            w_sheet->setStringValue(1,  2 + w_it, k_planets[w_it][0]);
            if (k_planets[w_it][1] != "")
                w_sheet->setStringValue(2,  2 + w_it, k_planets[w_it][1]);
        }

        w_filter.setRangeReference(Invoke::XLSX::Coordinates::CellRange(w_sheet->proxy(), 1, 2, 2, 85));
        w_sheet->setFilter(w_filter);

#if defined(GENERATE_XLSX)
        saveWorkbook(&w_workbook, XLSX_PATH "17.filters.xlsx");
#endif
#if defined(GENERATE_TEST)
        saveWorkbook(&w_workbook, XLSX_PATH "17.filters.test.xlsx");
#endif

        CPPUNIT_ASSERT_MESSAGE( "Test filters", isWorkbookValid(&w_workbook, XLSX_PATH "17.filters.xlsx") );

    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void XlsxWriterTestClass::testRichText()
{
	try {

		using namespace Invoke::XLSX::SimpleWorkbook;
		using namespace Invoke::XLSX::Interface;

		SimpleWorkbook w_workbook;

		SimpleWorksheet* w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("sheet1"));

		// rich text
		Write::RichText* w_richText = w_sheet->createRichText();
		try {
			w_richText->addRun({ "Calibri", 12, 0xFF000000, false, false, false }, "L’aube");
			w_richText->addRun({ "Calibri", 12, 0xFF000000, true, false, false }, " allait pointer ");
			w_richText->addRun({ "Calibri", 12, 0xFF000000, false, true, false }, "dans deux heures.");
			w_richText->addRun({ "Impact", 12, 0xFF000000, false, false, false }, " J’attendais dans la cuisine");
			w_richText->addRun({ "Impact", 12, 0xFF000000, false, true, true }, " dont les murs s’écaillaient");
			w_richText->addRun({ "Time New Roman", 8, 0xFF000000, false, false, false }, " en fumant une des cigarettes");
			w_richText->addRun({ "Calibri", 12, 0xFF000000, false, false, false }, " de ");
			w_richText->addRun({ "Calibri", 20, 0xFFFF0000, false, false, false }, "Sarah, ");
			w_richText->addRun({ "Calibri", 12, 0xFF00FF00, true, false, false }, "bercé par le ryt");
			w_richText->addRun({ "Courier New", 12, 0xFF0000FF, false, true, false }, "hme du cyclone.");

			w_sheet->setRichTextValue(3, 3, w_richText, "");

			delete w_richText;
		} catch (...) {
			delete w_richText;
			throw;
		}

		// formule
		w_richText = w_sheet->createRichText();
		try {
			w_richText->addRun({ "Calibri", 12, 0xFF000000, false, false, false }, "La plupart des ");
			w_richText->addRun({ "Calibri", 16, 0xFFFF0000, true, false, true }, "chargeurs éta");
			w_richText->addRun({ "Calibri", 12, 0xFF000000, false, true, false }, "ient noirs.");

			w_sheet->setRichTextValue(3, 5, w_richText, "=\"La plupart des chargeurs étaient noirs.\"");

			delete w_richText;
		} catch (...) {
			delete w_richText;
			throw;
		}

		// format
		w_richText = w_sheet->createRichText();
		try {
			w_richText->addRun({ "Calibri", 12, 0xFF0000FF, true, false, false }, "— C’est toi qui as le plus long canon, Tak.\n");
			w_richText->addRun({ "Calibri", 12, 0xFF00FF00, false, true, false }, "— Ce n’est pas la taille qui…\n");
			w_richText->addRun({ "Calibri", 12, 0xFF000000, true, true, false }, "Nous l’avons entendu en même temps.");

			w_sheet->setRichTextValue(3, 7, w_richText, "");

			delete w_richText;
		} catch (...) {
			delete w_richText;
			throw;
		}

		SimpleCellFormat w_format = SimpleCellFormat();
		w_format.setFontName("Courier New");
		w_format.setFontSize(10);
		w_format.setFontColor(0xFF00FF);
		w_format.setFontStyle(false, false, true);
		w_format.setWrapText(true);
		w_sheet->setFormat(3, 7, w_format);

		double w_width = 45;
		w_sheet->setColumnWidth(3, &w_width);

		// simple
		w_richText = w_sheet->createRichText();
		try {
			w_richText->setText("J’ai fermé les yeux et j’ai pris mon arme sur la table.");

			w_sheet->setRichTextValue(3, 9, w_richText, "");

			delete w_richText;
		} catch (...) {
			delete w_richText;
			throw;
		}


#if defined(GENERATE_XLSX)
		saveWorkbook(&w_workbook, XLSX_PATH "18.richtext.xlsx");
#endif
#if defined(GENERATE_TEST)
		saveWorkbook(&w_workbook, XLSX_PATH "18.richtext.test.xlsx");
#endif

		CPPUNIT_ASSERT_MESSAGE("Test rich text", isWorkbookValid(&w_workbook, XLSX_PATH "18.richtext.xlsx"));

	} catch (CppUnit::Exception) {
		throw;
	} catch (...) {
		CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
	}
}
