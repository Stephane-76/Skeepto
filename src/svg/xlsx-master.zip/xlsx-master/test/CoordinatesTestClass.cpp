/*!
 * \file        CoordinatesTestClass.cpp
 * \author      invoke
 * \date        23 avr. 2015, 16:30:25
 * \copyright   SA Invoke
 */

#include "CoordinatesTestClass.hpp"

#include "xlsx/Coordinates.hpp"
#include "xlsx/SimpleWorkbook.hpp"
#include "string/UtfString.hpp"

CPPUNIT_TEST_SUITE_REGISTRATION(CoordinatesTestClass);

using namespace Invoke::XLSX::Coordinates;
using namespace Invoke::XLSX::SimpleWorkbook;

class Coordinates {
public:
    Coordinates() : m_type(Parser::ctNull), m_coordinates(nullptr) {}
    Coordinates(const Cell& p_cell) : m_type(Parser::ctCell), m_coordinates( new Cell(p_cell) ) {}
    Coordinates(const CellRange& p_cellRange) : m_type(Parser::ctCellRange), m_coordinates( new CellRange(p_cellRange) ) {}
    Coordinates(const MultiCellRange& p_multiCellRange) : m_type(Parser::ctMultiCellRange), m_coordinates( new MultiCellRange(p_multiCellRange) ) {}
    Coordinates(const ColumnRow& p_columnRow) : m_type(Parser::ctColumnRow), m_coordinates( new ColumnRow(p_columnRow) ) {}
    Coordinates(const ColumnRowRange& p_columnRowRange) : m_type(Parser::ctColumnRowRange), m_coordinates( new ColumnRowRange(p_columnRowRange) ) {}
    Coordinates(const MultiColumnRowRange& p_multiColumnRowRange) : m_type(Parser::ctMultiColumnRowRange), m_coordinates( new MultiColumnRowRange(p_multiColumnRowRange) ) {}

    ~Coordinates()
    {
        switch (m_type) {
        case Parser::ctNull:
            break;
        case Parser::ctCell:
            delete static_cast<Cell*>(m_coordinates);
            break;
        case Parser::ctCellRange:
            delete static_cast<CellRange*>(m_coordinates);
            break;
        case Parser::ctMultiCellRange:
            delete static_cast<MultiCellRange*>(m_coordinates);
            break;
        case Parser::ctColumnRow:
            delete static_cast<ColumnRow*>(m_coordinates);
            break;
        case Parser::ctColumnRowRange:
            delete static_cast<ColumnRowRange*>(m_coordinates);
            break;
        case Parser::ctMultiColumnRowRange:
            delete static_cast<MultiColumnRowRange*>(m_coordinates);
        }
    }

    Parser::coordType_t type() const
    {
        return m_type;
    }

    const Cell* cell() const
    {
        if (m_type == Parser::ctCell)
            return static_cast<Cell*>(m_coordinates);
        return nullptr;
    }

    const CellRange* cellRange() const
    {
        if (m_type == Parser::ctCellRange)
            return static_cast<CellRange*>(m_coordinates);
        return nullptr;
    }

    const MultiCellRange* multiCellRange() const
    {
        if (m_type == Parser::ctMultiCellRange)
            return static_cast<MultiCellRange*>(m_coordinates);
        return nullptr;
    }

    const ColumnRow* columnRow() const
    {
        if (m_type == Parser::ctColumnRow)
            return static_cast<ColumnRow*>(m_coordinates);
        return nullptr;
    }

    const ColumnRowRange* columnRowRange() const
    {
        if (m_type == Parser::ctColumnRowRange)
            return static_cast<ColumnRowRange*>(m_coordinates);
        return nullptr;
    }

    const MultiColumnRowRange* multiColumnRowRange() const
    {
        if (m_type == Parser::ctMultiColumnRowRange)
            return static_cast<MultiColumnRowRange*>(m_coordinates);
        return nullptr;
    }

private:
    Parser::coordType_t m_type;
    void* m_coordinates;
};

void emptyTest()
{
	Parser w_parser("", nullptr);
	CPPUNIT_ASSERT_MESSAGE("\"\" - #01", !w_parser.parseResult());
}

void parse(const utf8String_t& p_ref,
           const WorkbookProxy* p_proxy,
           bool p_parseResult,
           unsigned char p_warnings,
           const Coordinates& p_result,
           int p_read =-1
           )
{
    Parser w_parser(p_ref, p_proxy);
    CPPUNIT_ASSERT_MESSAGE("\""+ p_ref +"\" - #01", w_parser.parseResult() == p_parseResult);

    if (p_parseResult) {
        CPPUNIT_ASSERT_MESSAGE("\""+ p_ref +"\" - #02", w_parser.warnings() == p_warnings);

        if (!(w_parser.warnings() & Parser::wIncompleteParse))
            CPPUNIT_ASSERT_MESSAGE("\""+ p_ref +"\" - #03", w_parser.readCharacters() == Invoke::UtfString::length(p_ref));
        else if (p_read != -1)
            CPPUNIT_ASSERT_MESSAGE("\""+ p_ref +"\" - #04", w_parser.readCharacters() == p_read);

        CPPUNIT_ASSERT_MESSAGE("\""+ p_ref +"\" - #05", w_parser.type() == p_result.type());

        if (p_result.type() == Parser::ctCell)
            CPPUNIT_ASSERT_MESSAGE("\""+ p_ref +"\" - #06.CELL", w_parser.cell()->name(nullptr) == p_result.cell()->name(nullptr));
        else if (p_result.type() == Parser::ctCellRange)
            CPPUNIT_ASSERT_MESSAGE("\""+ p_ref +"\" - #06.CELLRANGE", w_parser.cellRange()->name(nullptr) == p_result.cellRange()->name(nullptr));
        else if (p_result.type() == Parser::ctMultiCellRange)
            CPPUNIT_ASSERT_MESSAGE("\""+ p_ref +"\" - #06.MULTICELLRANGE", w_parser.multiCellRange()->name(nullptr) == p_result.multiCellRange()->name(nullptr));
        else if (p_result.type() == Parser::ctColumnRow)
            CPPUNIT_ASSERT_MESSAGE("\""+ p_ref +"\" - #06.COLUMNROW", w_parser.columnRow()->name(nullptr) == p_result.columnRow()->name(nullptr));
        else if (p_result.type() == Parser::ctColumnRowRange)
            CPPUNIT_ASSERT_MESSAGE("\""+ p_ref +"\" - #06.COLUMNROWRANGE", w_parser.columnRowRange()->name(nullptr) == p_result.columnRowRange()->name(nullptr));
        else if (p_result.type() == Parser::ctMultiColumnRowRange)
            CPPUNIT_ASSERT_MESSAGE("\""+ p_ref +"\" - #06.MULTICOLUMNROWRANGE", w_parser.multiColumnRowRange()->name(nullptr) == p_result.multiColumnRowRange()->name(nullptr));
    }
}

void CoordinatesTestClass::testCoordinates()
{
    try {

		emptyTest();

        parse("A1", nullptr, true, 1, Coordinates(Cell(nullptr, 0, 0, false)));
        parse("$C18", nullptr, true, 1, Coordinates(Cell(nullptr, Index(2, true), Index(17, false))));
        parse("AA$3", nullptr, true, 1, Coordinates(Cell(nullptr, Index(26, false), Index(2, true))));
        parse("$AA$13", nullptr, true, 1, Coordinates(Cell(nullptr, 26, 12, true)));

        parse("Feuil1!B2", nullptr, true, 1, Coordinates(Cell(nullptr, 1, 1, false)));
        parse("'la feuille'!B2", nullptr, true, 1, Coordinates(Cell(nullptr, 1, 1, false)));
        parse("'Aujourd''hui'!B2", nullptr, true, 1, Coordinates(Cell(nullptr, 1, 1, false)));

        parse("A1:H6", nullptr, true, 1, Coordinates(CellRange(nullptr, 0, 0, 7, 5, false)));
        parse("Feuil!$A$1:$H$6", nullptr, true, 1, Coordinates(CellRange(nullptr, 0, 0, 7, 5, true)));

        parse("R1C1", nullptr, true, 1, Coordinates(Cell(nullptr, 0, 0, false)));
        parse("R1:C1", nullptr, true, 1, Coordinates(CellRange(nullptr, 17, 0, 2, 0, false)));

        parse("R(-1)C(3)", nullptr, true, 5, Coordinates(Cell(nullptr, 3, 0, false)));

        MultiCellRange w_multiCellRange1;
        w_multiCellRange1.addRange( Cell(nullptr, 1, 1, false) );
        w_multiCellRange1.addRange( Cell(nullptr, Index(2, true), Index(2, false)) );
        w_multiCellRange1.addRange( Cell(nullptr, Index(3, false), Index(3, true)) );
        w_multiCellRange1.addRange( Cell(nullptr, 4, 4, true) );
        parse("B2,$C3,Feuil!D$4,$E$5", nullptr, true, 1, Coordinates(w_multiCellRange1));

        parse("R", nullptr, true, 1, Coordinates(ColumnRow(Index::itRow, nullptr, 0, false)));
        parse("R(3)", nullptr, true, 1, Coordinates(ColumnRow(Index::itRow, nullptr, 3, false)));
        parse("R(-1)", nullptr, true, 5, Coordinates(ColumnRow(Index::itRow, nullptr, 0, false)));
        parse("C", nullptr, true, 1, Coordinates(ColumnRow(Index::itColumn, nullptr, 0, false)));
        parse("C(+5)", nullptr, true, 1, Coordinates(ColumnRow(Index::itColumn, nullptr, 5, false)));
        parse("C(-5)", nullptr, true, 5, Coordinates(ColumnRow(Index::itColumn, nullptr, 0, false)));

        parse("2:5", nullptr, true, 1, Coordinates(ColumnRowRange(Index::itRow, nullptr, 1, 4, false)));
        parse("A:Z", nullptr, true, 1, Coordinates(ColumnRowRange(Index::itColumn, nullptr, 0, 25, false)));

        parse("R1C2:R(3)C", nullptr, true, 5, Coordinates(CellRange(nullptr, 1, 0, 0, 3, false)));

        parse("A0", nullptr, true, 5, Coordinates(Cell(nullptr, 0, 0, false)));
        parse("R0C0", nullptr, true, 5, Coordinates(Cell(nullptr, 0, 0, false)));

        parse("10", nullptr, false, 0, Coordinates());
        parse("$4", nullptr, false, 0, Coordinates());
        parse("AA", nullptr, false, 0, Coordinates());
        parse("$F", nullptr, false, 0, Coordinates());
        parse("Feuil1!", nullptr, false, 0, Coordinates());

        parse("A1:R(1)C", nullptr, true, 9, Coordinates(Cell(nullptr, 0, 0, false)), 2);

        MultiCellRange w_multiCellRange2;
        w_multiCellRange2.addRange( Cell(nullptr, 0, 0, false) );
        w_multiCellRange2.addRange( Cell(nullptr, Index(1, true), Index(1, false)) );
        w_multiCellRange2.addRange( Cell(nullptr, 2, 3, false) );
        parse("A1,$B2,'€'!C4,n'importe quoi", nullptr, true, 9, Coordinates(Coordinates(w_multiCellRange2)), 13);

    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void CoordinatesTestClass::testCoordinates2()
{
    try {

        SimpleWorkbook w_workbook;
        SimpleWorksheet* w_sheet = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("sheet1"));
        SimpleWorksheet* w_sheet2 = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("Aujourd'hui"));
        SimpleWorksheet* w_sheet3 = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("NON!"));

        w_workbook.selectWorksheetIndex(1);

        w_sheet->setActiveCell( Cell(w_sheet, 5, 5) );
        w_sheet2->setActiveCell( Cell(w_sheet2, 4, 4) );
        w_sheet3->setActiveCell( Cell(w_sheet3, 3, 3) );

        parse("'Aujourd''hui'!B2", &w_workbook, true, 0, Coordinates(Cell(w_sheet2, 1, 1, false)));
        parse("'NON!'!B2:B4", &w_workbook, true, 0, Coordinates(CellRange(w_sheet3, 1, 1, 1, 3, false)));
        parse("imaginaire!B2", &w_workbook, true, Parser::wSheetNameUnknown, Coordinates(Cell(nullptr, 1, 1, false)));

        parse("sheet1!R(-1)C(3)", &w_workbook, true, 0, Coordinates(Cell(w_sheet, 8, 4, false)));
        parse("sheet1!R(1)C(-6)", &w_workbook, true, Parser::wInvalidResult, Coordinates(Cell(w_sheet, 0, 6, false)));
        parse("R(1)C(1)", &w_workbook, true, 0, Coordinates(Cell(w_sheet2, 5, 5, false)));

    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}

void CoordinatesTestClass::testUnionAndIntersection()
{
    try {

        CellRange w_range1(nullptr, 1, 1, 3, 3);
        CellRange w_range2(nullptr, 2, 2, 4, 4);
        CellRange w_range3(nullptr, 5, 5, 6, 6);
        CellRange w_range4((WorksheetProxy*)0x1, 2, 2, 4, 4);

        CPPUNIT_ASSERT_MESSAGE("#01 - intersectWith", w_range1.intersectWith(w_range2));
        CPPUNIT_ASSERT_MESSAGE("#02 - intersectWith", !w_range1.intersectWith(w_range3));
        CPPUNIT_ASSERT_MESSAGE("#03 - intersectWith", !w_range1.intersectWith(w_range4));

        CellRange* w_intersect = nullptr;
        try {
            CPPUNIT_ASSERT_MESSAGE("#04.1 - getIntersect", w_range1.getIntersection(w_range2, w_intersect));
            CPPUNIT_ASSERT_MESSAGE("#04.2 - getIntersect", w_intersect != nullptr);
            CPPUNIT_ASSERT_MESSAGE("#04.3 - getIntersect", *w_intersect == CellRange(nullptr, 2, 2, 3, 3));
            delete w_intersect;
            w_intersect = nullptr;

            CPPUNIT_ASSERT_MESSAGE("#05.1 - getIntersect", !w_range1.getIntersection(w_range3, w_intersect));
            CPPUNIT_ASSERT_MESSAGE("#05.2 - getIntersect", w_intersect == nullptr);

            CPPUNIT_ASSERT_MESSAGE("#06.1 - getIntersect", !w_range1.getIntersection(w_range4, w_intersect));
            CPPUNIT_ASSERT_MESSAGE("#06.2 - getIntersect", w_intersect == nullptr);
        } catch (...) {
            delete w_intersect;
            throw;
        }

        CPPUNIT_ASSERT_MESSAGE("#07 - unionWith", w_range1.unionWith(w_range2));
        CPPUNIT_ASSERT_MESSAGE("#08 - unionWith", w_range1.unionWith(w_range3));
        CPPUNIT_ASSERT_MESSAGE("#09 - unionWith", !w_range1.unionWith(w_range4));

        CellRange* w_union = nullptr;
        try {
            CPPUNIT_ASSERT_MESSAGE("#10.1 - getUnion", w_range1.getUnion(w_range2, w_union));
            CPPUNIT_ASSERT_MESSAGE("#10.2 - getUnion", w_union != nullptr);
            CPPUNIT_ASSERT_MESSAGE("#10.3 - getUnion", *w_union == CellRange(nullptr, 1, 1, 4, 4));
            delete w_union;
            w_union = nullptr;

            CPPUNIT_ASSERT_MESSAGE("#11.1 - getUnion", w_range1.getUnion(w_range3, w_union));
            CPPUNIT_ASSERT_MESSAGE("#11.2 - getUnion", w_union != nullptr);
            CPPUNIT_ASSERT_MESSAGE("#11.3 - getUnion", *w_union == CellRange(nullptr, 1, 1, 6, 6));
            delete w_union;
            w_union = nullptr;

            CPPUNIT_ASSERT_MESSAGE("#12.1 - getUnion", !w_range1.getUnion(w_range4, w_union));
            CPPUNIT_ASSERT_MESSAGE("#12.2 - getUnion", w_union == nullptr);
        } catch (...) {
            delete w_union;
            throw;
        }

    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", true);
    }
}

void CoordinatesTestClass::testReduceMultiCellRange()
{
    try {

        MultiCellRange* w_ranges = nullptr;
        try {

            w_ranges = new MultiCellRange();
            w_ranges->addRange(Cell(nullptr, 2, 1));
            w_ranges->addRange(Cell(nullptr, 0, 0));
            w_ranges->reduce();
            CPPUNIT_ASSERT_MESSAGE("#01 - <"+ w_ranges->name() +">", w_ranges->name() == "A1,C2");
            delete w_ranges;

            w_ranges = new MultiCellRange();
            w_ranges->addRange(Cell(nullptr, 0, 0));
            w_ranges->addRange(Cell(nullptr, 2, 1));
            w_ranges->addRange(Cell(nullptr, 0, 1));
            w_ranges->reduce();
            CPPUNIT_ASSERT_MESSAGE("#02 - <"+ w_ranges->name() +">", w_ranges->name() == "A1:A2,C2");
            delete w_ranges;

            w_ranges = new MultiCellRange();
            w_ranges->addRange(Cell(nullptr, 0, 0));
            w_ranges->addRange(Cell(nullptr, 2, 1));
            w_ranges->addRange(Cell(nullptr, 1, 0));
            w_ranges->reduce();
            CPPUNIT_ASSERT_MESSAGE("#03 - <"+ w_ranges->name() +">", w_ranges->name() == "A1:B1,C2");
            delete w_ranges;

            w_ranges = new MultiCellRange();
            w_ranges->addRange(Cell(nullptr, 0, 0));
            w_ranges->addRange(Cell(nullptr, 2, 1));
            w_ranges->addRange(Cell(nullptr, 1, 0));
            w_ranges->addRange(Cell(nullptr, 2, 0));
            w_ranges->reduce();
            CPPUNIT_ASSERT_MESSAGE("#04 - <"+ w_ranges->name() +">", w_ranges->name() == "A1:B1,C1:C2");
            delete w_ranges;

            w_ranges = new MultiCellRange();
            w_ranges->addRange(Cell(nullptr, 0, 1));
            w_ranges->addRange(Cell(nullptr, 1, 2));
            w_ranges->addRange(Cell(nullptr, 0, 2));
            w_ranges->addRange(Cell(nullptr, 1, 0));
            w_ranges->addRange(Cell(nullptr, 1, 1));
            w_ranges->addRange(Cell(nullptr, 0, 0));
            w_ranges->reduce();
            CPPUNIT_ASSERT_MESSAGE("#05 - <"+ w_ranges->name() +">", w_ranges->name() == "A1:B3");
            delete w_ranges;

            SimpleWorkbook w_workbook;
            SimpleWorksheet* w_sheet1 = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("sheet1"));
            SimpleWorksheet* w_sheet2 = static_cast<SimpleWorksheet*>(w_workbook.newWorksheet("sheet2"));

            w_ranges = new MultiCellRange();
            w_ranges->addRange(Cell(w_sheet1, 2, 0));
            w_ranges->addRange(Cell(w_sheet2, 1, 0));
            w_ranges->addRange(Cell(w_sheet1, 0, 2));
            w_ranges->addRange(Cell(w_sheet2, 3, 0));
            w_ranges->addRange(Cell(w_sheet2, 2, 3));
            w_ranges->addRange(Cell(w_sheet1, 2, 2));
            w_ranges->addRange(Cell(w_sheet2, 1, 3));
            w_ranges->addRange(Cell(w_sheet1, 2, 3));
            w_ranges->addRange(Cell(w_sheet2, 0, 1));
            w_ranges->addRange(Cell(w_sheet2, 2, 0));
            w_ranges->addRange(Cell(w_sheet1, 2, 4));
            w_ranges->addRange(Cell(w_sheet2, 0, 2));
            w_ranges->addRange(Cell(w_sheet1, 2, 1));
            w_ranges->addRange(Cell(w_sheet2, 0, 0));
            w_ranges->addRange(Cell(w_sheet1, 1, 2));
            w_ranges->addRange(Cell(w_sheet2, 3, 2));
            w_ranges->addRange(Cell(w_sheet1, 3, 2));
            w_ranges->addRange(Cell(w_sheet2, 3, 1));
            w_ranges->addRange(Cell(w_sheet1, 4, 2));
            w_ranges->addRange(Cell(w_sheet2, 0, 3));
            w_ranges->addRange(Cell(w_sheet2, 3, 3));
            w_ranges->reduce();
            CPPUNIT_ASSERT_MESSAGE("#06 - <"+ w_ranges->name() +">", w_ranges->name() == "'sheet1'!C1:C5,'sheet1'!A3:B3,'sheet1'!D3:E3,'sheet2'!A1:A4,'sheet2'!B1:C1,'sheet2'!D1:D4,'sheet2'!B4:C4");
            delete w_ranges;

            w_ranges = new MultiCellRange();
            w_ranges->addRange(Cell(nullptr, 3, 4));
            w_ranges->addRange(Cell(nullptr, 7, 2));
            w_ranges->addRange(Cell(nullptr, 1, 3));
            w_ranges->addRange(Cell(nullptr, 5, 2));
            w_ranges->addRange(Cell(nullptr, 8, 4));
            w_ranges->addRange(Cell(nullptr, 4, 2));
            w_ranges->addRange(Cell(nullptr, 5, 4));
            w_ranges->addRange(Cell(nullptr, 7, 3));
            w_ranges->addRange(Cell(nullptr, 1, 2));
            w_ranges->addRange(Cell(nullptr, 8, 3));
            w_ranges->addRange(Cell(nullptr, 3, 2));
            w_ranges->addRange(Cell(nullptr, 8, 2));
            w_ranges->addRange(Cell(nullptr, 1, 4));
            w_ranges->addRange(Cell(nullptr, 7, 4));
            w_ranges->reduce();
            CPPUNIT_ASSERT_MESSAGE("#07 - <"+ w_ranges->name() +">", w_ranges->name() == "B3:B5,D3:F3,H3:I5,D5,F5");
            delete w_ranges;

        } catch (...) {
            delete w_ranges;
            throw;
        }

    } catch (CppUnit::Exception) {
        throw;
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", true);
    }
}