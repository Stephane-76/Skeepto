/*!
 * \file        CoordinatesTestClass.hpp
 * \author      invoke
 * \date        23 avr. 2015, 16:30:24
 * \copyright   SA Invoke
 */

#ifndef CoordinatesTestClass_hpp
#define CoordinatesTestClass_hpp

#include <cppunit/extensions/HelperMacros.h>

class CoordinatesTestClass : public CPPUNIT_NS::TestFixture {
    CPPUNIT_TEST_SUITE(CoordinatesTestClass);

    CPPUNIT_TEST(testCoordinates);
    CPPUNIT_TEST(testCoordinates2);
    CPPUNIT_TEST(testUnionAndIntersection);
    CPPUNIT_TEST(testReduceMultiCellRange);

    CPPUNIT_TEST_SUITE_END();

private:
    void testCoordinates();
    void testCoordinates2();
    void testUnionAndIntersection();
    void testReduceMultiCellRange();
};

#endif  /* CoordinatesTestClass_hpp */

