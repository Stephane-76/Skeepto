/*!
 * \file        XlsxTestClass.cpp
 * \author      Invoke - Jean-Christophe PHILIPPE (jcphilippe\@invoke.fr)
 * \date        Février 2016
 * \copyright   SA Invoke
 */

#include "XlsxTestClass.hpp"

#include "xlsx/XlsxReader.hpp"
#include "xlsx/XlsxWriter.hpp"
#include "xlsx/SimpleWorkbook.hpp"

#include <cstring>
#include <cstdio>
#include <fstream>
#include <ios>
#include <iostream>
#include <algorithm> // pour Visual Studio: C2039 & C3861

#define XLSX_PATH "../../../test/resource/"

CPPUNIT_TEST_SUITE_REGISTRATION(XlsxTestClass);

bool XlsxTestClass::areStreamEqual(std::istream& p_stream1, std::istream& p_stream2) const
{
    const std::istream::pos_type k_size1 = p_stream1.seekg(0, std::istream::end).tellg();
    const std::istream::pos_type k_size2 = p_stream2.seekg(0, std::istream::end).tellg();

    if (k_size1 != k_size2)
        return false;

    if (!k_size1)
        return true;

    p_stream1.seekg(0, std::istream::beg);
    p_stream2.seekg(0, std::istream::beg);

    const size_t k_maxBlockSize = 4096;
    char w_buffer1[k_maxBlockSize];
    char w_buffer2[k_maxBlockSize];

    size_t w_remaining = static_cast<size_t>(k_size1);

    while (w_remaining) {
        const size_t k_blockSize = std::min(k_maxBlockSize, w_remaining);

        p_stream1.read(w_buffer1, k_blockSize);
        p_stream2.read(w_buffer2, k_blockSize);

        if (memcmp(w_buffer1, w_buffer2, k_blockSize))
            return false;

        w_remaining -= k_blockSize;
    }

    return true;
}

bool XlsxTestClass::areZipEqual(std::istream& p_zip1, std::istream& p_zip2) const
{
    typedef std::shared_ptr<Invoke::Zip::ZipArchiveReader> zipReader_t;

    zipReader_t w_reader1( Invoke::Zip::openZipArchive(p_zip1) );
    const Invoke::Zip::ZipArchiveReader::fileList_t k_fileList1 = w_reader1->fileList();

    zipReader_t w_reader2( Invoke::Zip::openZipArchive(p_zip2) );
    const Invoke::Zip::ZipArchiveReader::fileList_t k_fileList2 = w_reader2->fileList();

    if (k_fileList1.size() != k_fileList2.size())
        return false;

    for (unsigned int w_it = 0; w_it < k_fileList1.size(); ++w_it) {
        std::stringstream w_stream1;
        std::stringstream w_stream2;

        if (!w_reader1->extractToStream(k_fileList1[w_it], &w_stream1))
            return false;
        if (!w_reader2->extractToStream(k_fileList1[w_it], &w_stream2))
            return false;

        if (!areStreamEqual(w_stream1, w_stream2))
            return false;
    }

    return true;
}

void XlsxTestClass::saveWorkbook(const Invoke::XLSX::Interface::Read::Workbook* p_workbook, const std::string& p_filenamme) const
{
    struct tm w_PhilaeLanding;
    w_PhilaeLanding.tm_year = 2014 - 1900;
    w_PhilaeLanding.tm_mon = 11 - 1;
    w_PhilaeLanding.tm_mday = 12;
    w_PhilaeLanding.tm_hour = 17;
    w_PhilaeLanding.tm_min = 04;
    w_PhilaeLanding.tm_sec = 00;
    w_PhilaeLanding.tm_isdst = -1;
    time_t w_creationDate = mktime(&w_PhilaeLanding);

    Invoke::XLSX::Writer::save(p_workbook, p_filenamme, w_creationDate);
}

void XlsxTestClass::test()
{
#if defined(_MSC_VER) && defined(_WIN32)
#define _XLSX_SUFFIX    "windows"
#else
#define _XLSX_SUFFIX    "linux"
#endif

    try {

        using namespace Invoke::XLSX;

        // lecture du fichier créé par Excel
        std::ifstream w_excelFile(XLSX_PATH "@.excel.xlsx", std::fstream::binary | std::fstream::in);
        SimpleWorkbook::SimpleWorkbook w_excelWorkbook;
        Reader::load(w_excelFile, &w_excelWorkbook);

        // sauvegarde
        saveWorkbook(&w_excelWorkbook, XLSX_PATH "@.invoke." _XLSX_SUFFIX ".test.xlsx");

        // comparaison
        std::ifstream w_zipFile1(XLSX_PATH "@.invoke." _XLSX_SUFFIX ".xlsx", std::fstream::binary | std::fstream::in);
        std::ifstream w_zipFile2(XLSX_PATH "@.invoke." _XLSX_SUFFIX ".test.xlsx", std::fstream::binary | std::fstream::in);

        if (!w_zipFile1)
            CPPUNIT_ASSERT_MESSAGE("Complete test - fichier référence introuvable !", false);

        CPPUNIT_ASSERT_MESSAGE("Complete test", areZipEqual(w_zipFile1, w_zipFile2));

    } catch (CppUnit::Exception) {
        throw;
    } catch (std::exception& w_exception) {
        CPPUNIT_ASSERT_MESSAGE(std::string(std::string("standard exception ! <") + w_exception.what() + std::string(">")).c_str(), false);
    } catch (...) {
        CPPUNIT_ASSERT_MESSAGE("unexpected exception !", false);
    }
}
