/*!
 * \file        XlsxTestClass.hpp
 * \author      Invoke - Jean-Christophe PHILIPPE (jcphilippe\@invoke.fr)
 * \date        F�vrier 2016
 * \copyright   SA Invoke
 */

#ifndef XlsxTestClass_hpp
#define XlsxTestClass_hpp

#include <cppunit/extensions/HelperMacros.h>

#include "xlsx/WorkbookReadInterface.hpp"
#include "zip/zip.hpp"

#include <iostream>

class XlsxTestClass : public CPPUNIT_NS::TestFixture {
    CPPUNIT_TEST_SUITE(XlsxTestClass);

    CPPUNIT_TEST(test);

    CPPUNIT_TEST_SUITE_END();

private:
    bool areStreamEqual(std::istream&, std::istream&) const;
    bool areZipEqual(std::istream&, std::istream&) const;
    void saveWorkbook(const Invoke::XLSX::Interface::Read::Workbook*, const std::string&) const;

private:
    void test();
};

#endif  /* XlsxTestClass_hpp */

