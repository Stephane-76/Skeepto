/*!
 * \file        XlsxReader.hpp
 * \author      Invoke - Jean-Christophe PHILIPPE (jcphilippe\@invoke.fr)
 * \date        Juin 2015
 * \copyright   SA Invoke
 */

#ifndef invoke_xlsx_xlsxReader_hpp
#define invoke_xlsx_xlsxReader_hpp

#include "xlsx/WorkbookInterface.hpp"
#include "xlsx/WorkbookWriteInterface.hpp"
#include "zip/zip.hpp"

#include <xmldom/structure/Document.hpp>
#include <xpath/expression/Expression.hpp>

#include <string>
#include <sstream>
#include <iostream>
#include <unordered_map>

namespace Invoke {
namespace XLSX {

/*!
 * \class Reader
 * \brief Permet de lire un fichier xlsx à partir d'une interface Workbook
 */
class Reader {

// Coordonnées
private:
    typedef std::shared_ptr<Coordinates::Cell> coordinatesCell_t;
    typedef std::shared_ptr<Coordinates::CellRange> coordinatesCellRange_t;
    typedef std::shared_ptr<Coordinates::MultiCellRange> coordinatesMultiCellRange_t;

    static coordinatesCell_t parseCellCoordinates(const std::string&, const Coordinates::WorkbookProxy*);
    static coordinatesCellRange_t parseCellRangeCoordinates(const std::string&, const Coordinates::WorkbookProxy*);
    static coordinatesMultiCellRange_t parseMultiCellRangeCoordinates(const std::string&, const Coordinates::WorkbookProxy*, char32_t =',');

// Fichier d'index
private:
    typedef struct {
        std::string id;
        std::string type;
        std::string target;
    } relation_t;
    typedef std::unordered_map<std::string, relation_t> relationsMap_t;
    typedef std::shared_ptr<relationsMap_t> relations_t;

    static relations_t rels(Zip::ZipArchiveReader&, const std::string&);

    typedef enum {
        rtExtendedProperties,
        rtCoreProperties,
        rtOfficeDocument,
        rtStyles,
        rtTheme,
        rtSharedStrings,
        rtWorksheet,
        rtDrawing,
        rtComments,
        rtVmlDrawing
    } relsType_t;

    static std::string targetFromRels(const relations_t&, relsType_t);

// Thème
private:
    static const int COLOR_LT1      =  0;
    static const int COLOR_DK1      =  1;
    static const int COLOR_LT2      =  2;
    static const int COLOR_DK2      =  3;
    static const int COLOR_ACCENT1  =  4;
    static const int COLOR_ACCENT2  =  5;
    static const int COLOR_ACCENT3  =  6;
    static const int COLOR_ACCENT4  =  7;
    static const int COLOR_ACCENT5  =  8;
    static const int COLOR_ACCENT6  =  9;
    static const int COLOR_HLINK    = 10;
    static const int COLOR_FOLHLINK = 11;
    static const int COLOR_COUNT    = 12;

    typedef struct {
        Interface::color_t colors[COLOR_COUNT];
    } colorSchemeStruct_t;
    typedef std::shared_ptr<colorSchemeStruct_t> colorScheme_t;

    static colorScheme_t colorScheme(Zip::ZipArchiveReader&, const std::string&);

// RichText
private:
	typedef struct {
		Interface::font_t font;
		Interface::utf8String_t text;
	} run_t;
	typedef std::vector<run_t> runsVector_t;
	typedef std::shared_ptr<runsVector_t> runs_t;

	static runs_t richText(const XML::DOM::Node*, const colorScheme_t&);

	static void assignRichText(Interface::Write::RichText*, const runsVector_t&);

// Chaînes partagées
private:
	typedef std::vector<runsVector_t> sharedStringsVector_t;
	typedef std::shared_ptr<sharedStringsVector_t> sharedStrings_t;

    static sharedStrings_t sharedStrings(Zip::ZipArchiveReader&, const std::string&, const colorScheme_t&);

// Liste de validation
private:
    typedef struct {
        std::string range;
        Interface::Write::Worksheet* worksheet;
        std::shared_ptr<Interface::Write::ListValidation> validation;
    } refListValidationsStruct_t;
    typedef std::vector<refListValidationsStruct_t> refListValidations_t;

// Style
private:
    // lecture des couleurs
    static Interface::color_t color(const XML::DOM::Node*, const colorScheme_t&, Interface::color_t);

    // chaînes de format
    typedef std::unordered_map<unsigned int, std::string> numFmtsMap_t;
    typedef std::shared_ptr<numFmtsMap_t> numFmts_t;

    static numFmts_t numFmts(XML::DOM::Document&);

    // polices
    typedef struct {
        Interface::utf8String_t name;
        unsigned int size;
        Interface::color_t color;
        bool bold;
        bool italic;
        bool underline;
    } font_t;
    typedef std::vector<font_t> fontsVector_t;
    typedef std::shared_ptr<fontsVector_t> fonts_t;

    static fonts_t fonts(XML::DOM::Document&, const colorScheme_t&);

    // motifs
    typedef std::unordered_map<std::string, Interface::patternStyle_t> patternStyleMap_t;
    static const patternStyleMap_t patternStyleMap();

    typedef struct {
        Interface::patternStyle_t style;
        Interface::color_t fgColor;
        Interface::color_t bgColor;
    } pattern_t;
    typedef std::vector<pattern_t> patternsVector_t;
    typedef std::shared_ptr<patternsVector_t> patterns_t;

    static patterns_t patterns(XML::DOM::Document&, const colorScheme_t&);

    // bordures
    typedef std::unordered_map<std::string, Interface::borderStyle_t> borderStyleMap_t;
    static const borderStyleMap_t borderStyleMap();

    typedef struct {
        Interface::borderStyle_t style;
        Interface::color_t color;
    } border_t;
    typedef std::unordered_map<std::string, Interface::borderStyle_t> strBorderStyles_t;
    static border_t border(const XML::DOM::Node*, const strBorderStyles_t&, const colorScheme_t&);

    typedef struct {
        border_t top;
        border_t left;
        border_t right;
        border_t bottom;
        border_t diagonalUp;
        border_t diagonalDown;
    } cellBorders_t;
    typedef std::vector<cellBorders_t> bordersVector_t;
    typedef std::shared_ptr<bordersVector_t> borders_t;

    static borders_t borders(XML::DOM::Document&, const colorScheme_t&);

    // style de cellules
    typedef struct {
        unsigned int* numFmtId;
        unsigned int* fontId;
        unsigned int* fillId;
        unsigned int* borderId;
        Interface::horizontalAlignment_t* horizontalAlignment;
        Interface::verticalAlignment_t* verticalAlignment;
        unsigned short* indent;
        short* rotation;
        bool* wrap;
    } cellStyle_t;
    typedef std::vector<cellStyle_t> cellStyles_t;
    static void freeCellStyles(const cellStyles_t&);

    // formats de cellules
    typedef struct {
        std::string numFmt;
        font_t font;
        pattern_t pattern;
        border_t borders[6];
        Interface::horizontalAlignment_t horizontalAlignment;
        Interface::verticalAlignment_t verticalAlignment;
        unsigned short indent;
        short rotation;
        bool wrap;
    } cellFormat_t;
    typedef std::vector<cellFormat_t> cellFormats_t;

    // formats de cellules différentiels
    typedef struct {
        std::string* numFmt;
        Interface::color_t* fontColor;
        bool* fontBold;
        bool* fontItalic;
        bool* fontUnderline;
        Interface::patternStyle_t* patternStyle;
        Interface::color_t* patternForegroundColor;
        Interface::color_t* patternBackgroundColor;
        bool* borderVisible[6];
        Interface::borderStyle_t* borderStyle[6];
        Interface::color_t* borderColor[6];
    } diffCellFormat_t;
    typedef std::vector<diffCellFormat_t> diffCellFormats_t;

    // ...
    typedef struct {
        font_t defaultFont;
        cellFormats_t formats;
        diffCellFormats_t diffFormats;
    } stylesStruct_t;
    typedef std::shared_ptr<stylesStruct_t> styles_t;

    static void getDiffBorder(const XML::DOM::Node*, const borderStyleMap_t&, const colorScheme_t&, bool*&, Interface::borderStyle_t*&, Interface::color_t*&);
    static styles_t styles(Zip::ZipArchiveReader&, const std::string&, const colorScheme_t&);
    static void freeStyles(const styles_t&);

// Images
private:
    typedef struct {
        unsigned int left;
        unsigned int top;
        unsigned int right;
        unsigned int bottom;
    } rectangle_t;

    typedef struct {
        Coordinates::CellPoint topLeft;
        Coordinates::CellPoint rightBottom;
        std::shared_ptr<rectangle_t> blipFillSrcRect;
        Interface::imageProperty_t property;
        std::string filename;
    } imageStruct_t;

    typedef struct {
        std::string id;
        std::vector<imageStruct_t> images;
    } images_t;

    static images_t images(Zip::ZipArchiveReader&, const Interface::Write::Worksheet*, const std::string&);
    static void addImages(Zip::ZipArchiveReader&, Interface::Write::Worksheet*, const images_t&);

// Hyperliens
private:
    typedef struct {
        Interface::Write::Worksheet* worksheet;
        Coordinates::CellRange ref;
        std::string display;
        std::string tooltip;
        std::string location;
        std::string target;
    } hyperlinkStruct_t;
    typedef std::vector<hyperlinkStruct_t> hyperlinks_t;

    static void hyperlinks(Zip::ZipArchiveReader&, const XML::DOM::Node*, Interface::Write::Worksheet*, const std::string&, hyperlinks_t&);

// Comments
private:
    typedef struct {
        std::string reference;
        Interface::utf8String_t author;
        runs_t runs;
		Interface::utf8String_t href;
        Interface::horizontalAlignment_t alignment;
        Coordinates::CellPoint topLeft;
        Coordinates::CellPoint rightBottom;
        bool autoSize;
        Interface::color_t color;
        Interface::visibility_t visibility;
        Interface::commentProperty_t property;
    } comment_t;
    typedef std::unordered_map<std::string, comment_t> comments_t;

    static comments_t comments(Zip::ZipArchiveReader&, const Interface::Write::Worksheet*, const std::string&, const colorScheme_t&);
    static void addComments(Interface::Write::Worksheet*, const comments_t&);

// Workbook
private:
    typedef struct {
        Interface::utf8String_t name;
        std::string id;
        bool hidden;
    } sheet_t;
    typedef std::vector<sheet_t> sheets_t;

    typedef std::unordered_map<std::string, std::string> definedNames_t;

    typedef std::unordered_map<std::string, std::string> printAreas_t;
    typedef std::unordered_map<std::string, std::string> printTitles_t;

    typedef struct {
        sheets_t sheets;
        definedNames_t definedNames;
        printAreas_t printAreas;
        printTitles_t printTitles;
    } workbookStruct_t;
    typedef std::shared_ptr<workbookStruct_t> workbook_t;

    static workbook_t workbook(Zip::ZipArchiveReader&, const std::string&);

// Sheet
private:
    static Interface::Write::CellFormat* createCellFormat(const Interface::Write::Worksheet*, const cellFormat_t&);
    static Interface::Write::DifferentialCellFormat* createDifferentialFormat(const Interface::Write::Worksheet*, const diffCellFormat_t&);
    static void columns(XML::DOM::Document&, const styles_t&, Interface::Write::Worksheet*);
    static void rows(XML::DOM::Document&, const styles_t&, Interface::Write::Worksheet*);
    static void headerFooterString(const std::string&, std::string&, std::string&, std::string&);
    static void headerFooter(XML::DOM::Document&, Interface::Write::PageSetting*);
    static void sheet(Zip::ZipArchiveReader&, const std::string&, const styles_t&, const sharedStrings_t&, const std::string&, const std::string&, const images_t&, const comments_t&, refListValidations_t&, hyperlinks_t&, Interface::Write::Worksheet*);

// XPath
private:
    typedef std::shared_ptr<XPath::Element> xPathElement_t;

    static xPathElement_t xpath(const XML::DOM::Node*, const std::string&);

    static const XMLSchema::Value* value(const xPathElement_t&);
    static const XML::DOM::Node* node(const xPathElement_t&);

    static int toInteger(const xPathElement_t&, int =0);
    static int toInteger(const XPath::Element*, int =0);
    static double toDouble(const xPathElement_t&, double =0);
    static double toDouble(const XPath::Element*, double =0);
    static std::string toString(const xPathElement_t&, const std::string& ="");
    static std::string toString(const XPath::Element*, const std::string& ="");

// XML
private:
    static void loadXMLDocument(Zip::ZipArchiveReader&, const std::string&, XML::DOM::Document&);

// Principal
private:
    static std::string path(const std::string&);
    static std::string name(const std::string&);
    static std::string absoluteName(const std::string&, const std::string&);

    static std::string officeDocument(Zip::ZipArchiveReader&);

    static void load(Zip::ZipArchiveReader&, Interface::Write::Workbook*);

public:
    /*!
     * \fn void load(const std::string& filename, Interface::Write::Workbook* workbook)
     * \brief Charger un fichier xlsx.
     * \param filename Le nom du fichier d'entrée.
     * \param workbook Pointeur sur le classeur résultant.
     */
    /*!
     * \fn void load(std::istream& xlsxStream, Interface::Write::Workbook* workbook)
     * \brief Charger un fichier xlsx.
     * \param xlsxStream Le flux xlsx.
     * \param workbook Pointeur sur le classeur résultant.
     */
    /*!
     * \fn void load(const Zip::byte_t* memory, unsigned int size, Interface::Write::Workbook* workbook)
     * \brief Charger un fichier xlsx.
     * \param memory Le flux xlsx.
     * \param size La taille du flux xlsx.
     * \param workbook Pointeur sur le classeur résultant.
     */
    static void load(const std::string&, Interface::Write::Workbook*);
    static void load(std::istream&, Interface::Write::Workbook*);
    static void load(const Zip::byte_t*, unsigned int, Interface::Write::Workbook*);
};

} // namespace XLSX
} // namespace Invoke

#endif  /* invoke_xlsx_xlsxReader_hpp */
