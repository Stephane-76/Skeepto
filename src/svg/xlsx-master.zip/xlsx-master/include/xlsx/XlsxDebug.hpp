/*!
 * \file        XlsxDebug.hpp
 * \author      Invoke - Jean-Christophe PHILIPPE (jcphilippe\@invoke.fr)
 * \date        Novembre 2017
 * \copyright   SA Invoke
 */

#ifndef invoke_xlsx_xlsxDebug_hpp
#define invoke_xlsx_xlsxDebug_hpp

#if defined(INVOKE_XLSX_LOGS)
#include <string>
#include <fstream>
#include <chrono>
#include <vector>
#include <unordered_map>
#if defined(_WIN32)
#define NOMINMAX
#include <windows.h>
#include <psapi.h>
#endif
#endif

#if defined(INVOKE_XLSX_TRACE)
#include <string>
#include <iostream>
#include <fstream>
#include <exception> 
#include <chrono>
#include <vector>
#include <stack>
#endif


namespace Invoke {
namespace XLSX {
namespace Debug {

#if defined(INVOKE_XLSX_LOGS)

class LogFile {
public:
    LogFile(const std::string&);
    ~LogFile();

    template<class T>
    LogFile& operator <<(T p_something) 
    { 
        m_logFile << p_something; 
        return *this; 
    }

private:
    std::ofstream m_logFile;
};

class HRChrono {
public:
    HRChrono();

    void start();
    std::chrono::duration<double> stop();
    std::chrono::duration<double> timeSpan() const;

private:
    std::chrono::high_resolution_clock::time_point m_start;
    std::chrono::high_resolution_clock::time_point m_stop;
};

class Logs {
public:
    void message(const std::string&);

    void startChrono(const std::string&);
    void stopChrono();

    void checkMemory();

private:
    HRChrono m_chrono;
    LogFile m_file;


// Singleton
public:
    static Logs& get() {
        static Logs s_logs;
        return s_logs;
    }

private:
    Logs();
};


class Object
{
public:
    Object(const std::string&);

    void add(size_t);

    std::string log() const;

private:
    std::string m_name;
    long double m_avgSize;
    size_t m_minSize;
    size_t m_maxSize;
    size_t m_count;
};

class Container
{
public:
    Container(const std::string&, size_t);
    ~Container();

    Container* addContainer(const std::string&, size_t);
    Object* addObject(const std::string&);

    Object* getObject(const std::string&) const;

    std::string log() const;
    void clear();

private:
    std::string m_name;
    size_t m_size;

    std::vector<Container*> m_containers;
    std::unordered_map<std::string, Object*> m_objects;
};

class Counter
{
public:
    Container* container();

    void log() const;
    void clear();

private:
    Container m_container;

// Singleton
public:
    static Counter& get() {
        static Counter s_counter;
        return s_counter;
    }

private:
    Counter();
};

#endif



#if defined(INVOKE_XLSX_TRACE)

class HRChrono {
public:
    typedef std::chrono::high_resolution_clock::time_point timePoint_t;
    typedef std::chrono::duration<double> duration_t;

public:
    HRChrono();

    void start();
    duration_t timeSpan() const;

private:
    timePoint_t m_start;
};

class Trace {
public:
    typedef std::vector<std::string> arguments_t;

public:
    static Trace& get();

public:
    Trace(const Trace&) = delete;
    void operator=(const Trace&) = delete;

    void beginFunction(const std::string&, const arguments_t&);
    void endFunction();
    void exception(const std::exception&);

    void writeInfos(const std::string&);

private:
    Trace(const std::string&);
    ~Trace();

    std::string textToXML(const std::string&);
    std::string timeToXML();

    void startChrono();
    double stopChrono();
    void writeChrono();

private:
    std::ofstream* m_outfile = nullptr;
    std::stack<HRChrono> m_chronos;
    unsigned int m_functions;
};

class TraceFunction {
public:
    TraceFunction(const std::string&, const Trace::arguments_t&);
    ~TraceFunction();

    void exception(const std::exception&);
    void writeInfos(const std::string&);
};

#endif  /* INVOKE_XLSX_TRACE */


} // namespace Debug
} // namespace XLSX
} // namespace Invoke

#endif  /* invoke_xlsx_xlsxDebug_hpp */