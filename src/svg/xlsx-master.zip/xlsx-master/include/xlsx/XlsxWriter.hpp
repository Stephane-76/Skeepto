/*!
 * \file        XlsxWriter.hpp
 * \author      Invoke - Jean-Christophe PHILIPPE (jcphilippe\@invoke.fr)
 * \date        Octobre 2014
 * \copyright   SA Invoke
 */

#ifndef invoke_xlsx_xlsxWriter_hpp
#define invoke_xlsx_xlsxWriter_hpp

#include "xlsx/WorkbookInterface.hpp"
#include "xlsx/WorkbookReadInterface.hpp"
#include "zip/zip.hpp"

#include <string>
#include <sstream>
#include <iostream>
#include <vector>
#include <unordered_map>

#if defined(WIN32)
#include <time.h>
#endif

namespace Invoke {
namespace XLSX {

/*!
 * \class Writer
 * \brief Permet d'écrire un fichier xlsx à partir d'une interface Workbook
 */
class Writer {
private:
    static std::string doubleToString(double);

    static std::string textToXML(const std::string&);
    static std::string textToXMLAttribute(const std::string&);

	static std::string colorToXML(Interface::color_t);

    class ListValidationParams {
    public:
        typedef std::unordered_map<const Interface::Read::ListValidation*, unsigned int> listPositions_t;

        ListValidationParams(const Interface::Read::Workbook*);
        ~ListValidationParams();

        bool isExist() const;
        Interface::utf8String_t name() const;
        size_t id() const;
        const listPositions_t* positions() const;

    private:
        const Interface::Read::Workbook* m_workbook;
        bool m_isExist;
        Interface::utf8String_t m_name;
        size_t m_id;
        listPositions_t* m_positions;
    };

    static std::istream* createContentTypes(const Interface::Read::Workbook*, const ListValidationParams&);
    static std::istream* createRels();
    static std::istream* createApp(const Interface::Read::Workbook*, const ListValidationParams&);
    static std::istream* createCore(time_t =time(0));
    static std::istream* createWorkbookRels(const Interface::Read::Workbook*, const ListValidationParams&);
    static unsigned int getFirstVisibleSheetIndex(const Interface::Read::Workbook*);

    typedef std::unordered_map<const Interface::Read::Image*, unsigned int> imagesMap_t;
    static void imagesInventory(const Interface::Read::Workbook*, imagesMap_t&);
    static void saveImages(const imagesMap_t&, Zip::ZipArchiveWriter*);
    static std::istream* createDrawing(const Interface::Read::Worksheet*, const imagesMap_t&);
    static std::istream* createDrawingRels(const Interface::Read::Worksheet*, const imagesMap_t&);

    static std::istream* createComments(const Interface::Read::Worksheet*);
    static std::istream* createVmlDrawing(const Interface::Read::Worksheet*, unsigned int);

    typedef std::unordered_map<const void*, unsigned int> relsMap_t;
    static std::istream* createWorksheetRels(const Interface::Read::Worksheet*, unsigned int, relsMap_t&);

    static std::istream* createWorkbook(const Interface::Read::Workbook*, const ListValidationParams&);

    typedef std::pair<void*, size_t> sstPair_t;
    typedef std::vector<sstPair_t> sst_t;
    static size_t SSTIndex(const sst_t&, void*);
	static std::string createShareString_toXml(const Interface::utf8String_t&);
	static std::string createShareString_toXml(const Interface::Read::RichText*);
    static std::istream* createSharedStrings(const Interface::Read::Workbook*, sst_t&);

    typedef std::unordered_map<const Interface::Read::CellFormat*, size_t> xfsMap_t;
    typedef std::unordered_map<const Interface::Read::DifferentialCellFormat*, size_t> dxfsMap_t;
    static std::string createStyles_DefaultFontToXML(const Interface::Read::Workbook*);
    static std::string createStyles_FontToXML(const Interface::Read::CellFormat*);
    static std::string createStyles_PatternStyleAttribute(Interface::patternStyle_t);
    static std::string createStyles_FillToXML(const Interface::Read::CellFormat*);
    static std::string createStyles_BorderMarkup(Interface::border_t);
    static std::string createStyles_BorderStyleAttribute(Interface::borderStyle_t);
    static std::string createStyles_BorderToXML(const Interface::Read::CellFormat*, Interface::border_t);
    static std::string createStyles_BordersToXML(const Interface::Read::CellFormat*);
    typedef std::vector<std::string> xfs_t;
    typedef std::vector<std::string> fonts_t;
    typedef std::vector<std::string> numFmts_t;
    typedef std::vector<std::string> fills_t;
    typedef std::vector<std::string> borders_t;
    typedef std::vector<std::string> dxfs_t;
    static void createStyles_XfsInventory(const Interface::Read::Workbook*, xfsMap_t&, xfs_t&, fonts_t&, numFmts_t&, fills_t&, borders_t&);
    static void createStyles_DxfsInventory(const Interface::Read::Workbook*, dxfsMap_t&, dxfs_t&);
    static std::istream* createStyles(const Interface::Read::Workbook*, xfsMap_t&, dxfsMap_t&);

    typedef enum { csNone = 0, csCollapsed = 1, csHidden = 2 } collapseState_t;
    typedef std::unordered_map<unsigned int, unsigned char> collapsed_t;
    typedef enum { crtColumn, crtRow } columnRowType_t;
    static void createSheet_CollapsedInventory(const Interface::Read::Worksheet*, unsigned int&, unsigned short&, collapsed_t&, columnRowType_t);
    static void createSheet_Outlines(const Interface::Read::Worksheet*, unsigned short&, unsigned short&, collapsed_t&, collapsed_t&);
    static std::string createSheet_SheetViews(const Interface::Read::Worksheet*, bool);
    static std::string createSheet_Columns(const Interface::Read::Worksheet*, const xfsMap_t&, const collapsed_t&);
    static std::string createSheet_RowAttributes(const Interface::Read::Worksheet*, unsigned int, const xfsMap_t&, unsigned char);
    static std::string createSheet_MergeCells(const Interface::Read::Worksheet*);
    static std::string createSheet_ConditionalFormatting(const Interface::Read::Worksheet*, const dxfsMap_t&);
    static std::string createSheet_Validations(const Interface::Read::Workbook*, const Interface::Read::Worksheet*, const ListValidationParams&, unsigned int&);
    static std::string createSheet_Hyperlinks(const Interface::Read::Worksheet*, const relsMap_t&);
    static std::string createSheet_Filters(const Interface::Read::Worksheet*);
    static std::istream* createSheet(const Interface::Read::Workbook*, const Interface::Read::Worksheet*, unsigned int, const sst_t&, const xfsMap_t&, const dxfsMap_t&, const ListValidationParams&, const relsMap_t&, bool);

    static std::istream* createListValidationSheet(const Interface::Read::Workbook*, const ListValidationParams&, const sst_t&);

    static std::istream* createNullSheet();

    static void save(const Interface::Read::Workbook*, Zip::ZipArchiveWriter*, time_t =time(0));

public:
    /*!
     * \fn static void save(const Interface::Read::Workbook* workbook, const std::string& filename, time_t creationDate)
     * \brief créer un fichier xlsx.
     * \param workbook Pointeur sur l'interface workbook.
     * \param filename Le nom du fichier de sortie.
     * \param creationDate La date de création du fichier (utilisé lors des tests pour avoir des fichiers ayant des dates de création identiques).
     */
    /*!
     * \fn static void save(const Interface::Read::Workbook* workbook, std::ostream& xlsxStream, time_t creationDate)
     * \brief créer un fichier xlsx.
     * \param workbook Pointeur sur l'interface workbook.
     * \param xlsxStream Le flux xlsx.
     * \param creationDate La date de création du fichier (utilisé lors des tests pour avoir des fichiers ayant des dates de création identiques).
     */
    /*!
     * \fn static void save(const Interface::Read::Workbook* workbook, Zip::byte_t*& memory, unsigned int& size, time_t creationDate)
     * \brief créer un fichier xlsx.
     * \param workbook Pointeur sur l'interface workbook.
     * \param memory Le flux xlsx.
     * \param size La taille du flux xlsx.
     * \param creationDate La date de création du fichier (utilisé lors des tests pour avoir des fichiers ayant des dates de création identiques).
     */
    static void save(const Interface::Read::Workbook*, const std::string&, time_t =time(0));
    static void save(const Interface::Read::Workbook*, std::ostream&, time_t =time(0));
    static void save(const Interface::Read::Workbook*, Zip::byte_t*&, unsigned int&, time_t =time(0));
};

} // namespace XLSX
} // namespace Invoke

#endif  /* invoke_xlsx_xlsxWriter_hpp */
