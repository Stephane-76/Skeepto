/*!
 * \file        WorkbookWriteInterface.hpp
 * \author      Invoke - Jean-Christophe PHILIPPE (jcphilippe\@invoke.fr)
 * \date        Juin 2015
 * \copyright   SA Invoke
 */

#ifndef invoke_xlsx_workbookWriteInterface_hpp
#define invoke_xlsx_workbookWriteInterface_hpp

#include "xlsx/WorkbookInterface.hpp"
#include "xlsx/Coordinates.hpp"

namespace Invoke {
namespace XLSX {
namespace Interface {
namespace Write {

/*!
 * \class RichText
 * \brief Définit un texte riche. 
 */
class RichText {
public:
	/*!
	 * \fn ~RichText()
	 * \brief Destructeur.
	 */
	virtual ~RichText() =0;

	/*!
	 * \fn void clear()
	 * \brief Effacer le contenu du texte.
	 */
	virtual void clear() =0;

	/*!
	 * \fn void addRun(const font_t& font, const utf8String_t& text)
	 * \brief Ajouter une portion de texte.
	 * \param font La police de caractères.
	 * \param text Le texte.
	 */
	virtual void addRun(const font_t&, const utf8String_t&) =0;

	/*!
	 * \fn void setText(const utf8String_t& text)
	 * \brief Assigner un texte avec une police par défaut.
	 * \param text Le texte.
	 */
	virtual void setText(const utf8String_t&) =0;
};

/*!
 * \class CellValue
 * \brief Définit la valeur d'une cellule.
 */
class CellValue {
public:
    /*!
     * \fn ~CellValue()
     * \brief Destructeur.
     */
    virtual ~CellValue() =0;

    /*!
     * \fn void setNull(const utf8String_t& formula)
     * \brief Assigner la valeur nulle.
     * \param formula La formule de calcul.
     */
    /*!
     * \fn void setBoolean(bool value, const utf8String_t& formula)
     * \brief Assigner la valeur booléenne de la cellule.
     * \param value La valeur booléenne.
     * \param formula La formule de calcul.
     */
    /*!
     * \fn void setNumber(double value, const utf8String_t& formula)
     * \brief Assigner la valeur numérique de la cellule.
     * \param value La valeur numérique.
     * \param formula La formule de calcul.
     */
    /*!
     * \fn void setString(const utf8String_t& value, const utf8String_t& formula)
     * \brief Assigner la valeur chaîne de la cellule.
     * \param value La valeur chaîne.
     * \param formula La formule de calcul.
     */
    /*!
     * \fn void setError(cellError_t value, const utf8String_t& formula)
     * \brief Assigner le type d'erreur de la cellule.
     * \param value Le type d'erreur.
     * \param formula La formule de calcul.
     */
    virtual void setNull(const utf8String_t& = "") =0;
    virtual void setBoolean(bool, const utf8String_t& = "") =0;
    virtual void setNumber(double, const utf8String_t& = "") =0;
    virtual void setString(const utf8String_t&, const utf8String_t& = "") =0;
    virtual void setError(cellError_t, const utf8String_t& = "") =0;

	/*!
	 * \fn void setText(const RichText* richtext, const utf8String_t& formula)
	 * \brief Assigner un texte riche à la cellule.
	 * \param richtext Le texte.
	 * \param formula La formule de calcul.
	 */
	virtual void setText(const RichText*, const utf8String_t& = "") =0;
};

/*!
 * \class DefinedName
 * \brief Définit un nom de zone
 */
class DefinedName {
public:
    /*!
     * \fn ~DefinedName()
     * \brief Destructeur.
     */
    virtual ~DefinedName() =0;

    /*!
     * \fn void setName(const utf8String_t& name)
     * \brief Assigned le nom de la zone.
     * \param name Le nom de la zone.
     */
    virtual void setName(const utf8String_t&) =0;

    /*!
     * \fn void setZone(const Coordinates::MultiCellRange& coordinates)
     * \brief Assigner les coordonnées de la zone.
     * \param coordinates Les coordonnées de la zone.
     */
    virtual void setZone(const Coordinates::MultiCellRange&) =0;
};

/*!
 * \class PageHeaderFooter
 * \brief Description des entêtes et pieds de page.
 */
class PageHeaderFooter {
public:
    /*!
     * \fn ~PageHeaderFooter()
     * \brief Destructeur.
     */
    virtual ~PageHeaderFooter() =0;

    /*!
     * \fn virtual void setFirstHeader(const utf8String_t& left, const utf8String_t& center, const utf8String_t& right)
     * \brief Spécifier l'entête de la première page s'il est différent des autres entêtes.
     * \param left Le texte à gauche.
     * \param center Le texte au centre.
     * \param right Le texte à droite.
     */
    /*!
     * \fn virtual void setFirstFooter(const utf8String_t& left, const utf8String_t& center, const utf8String_t& right)
     * \brief Spécifier le pied de la première page s'il est différent des autres pieds de page.
     * \param left Le texte à gauche.
     * \param center Le texte au centre.
     * \param right Le texte à droite.
     */
    virtual void setFirstHeader(const utf8String_t&, const utf8String_t&, const utf8String_t&) =0;
    virtual void setFirstFooter(const utf8String_t&, const utf8String_t&, const utf8String_t&) =0;

    /*!
     * \fn virtual void setEvenHeader(const utf8String_t& left, const utf8String_t& center, const utf8String_t& right)
     * \brief Spécifier l'entête des pages impaires s'ils sont différents des autres entêtes.
     * \param left Le texte à gauche.
     * \param center Le texte au centre.
     * \param right Le texte à droite.
     */
    /*!
     * \fn virtual void setEvenFooter(const utf8String_t& left, const utf8String_t& center, const utf8String_t& right)
     * \brief Spécifier le pied des pages impaires s'ils sont différents des autres pieds de page.
     * \param left Le texte à gauche.
     * \param center Le texte au centre.
     * \param right Le texte à droite.
     */
    virtual void setEvenHeader(const utf8String_t&, const utf8String_t&, const utf8String_t&) =0;
    virtual void setEvenFooter(const utf8String_t&, const utf8String_t&, const utf8String_t&) =0;

    /*!
     * \fn virtual void setHeader(const utf8String_t& left, const utf8String_t& center, const utf8String_t& right)
     * \brief Spécifier les entêtes de page.
     * \param left Le texte à gauche.
     * \param center Le texte au centre.
     * \param right Le texte à droite.
     */
    /*!
     * \fn virtual void setFooter(const utf8String_t& left, const utf8String_t& center, const utf8String_t& right)
     * \brief Spécifier les pieds de page.
     * \param left Le texte à gauche.
     * \param center Le texte au centre.
     * \param right Le texte à droite.
     */
    virtual void setHeader(const utf8String_t&, const utf8String_t&, const utf8String_t&) =0;
    virtual void setFooter(const utf8String_t&, const utf8String_t&, const utf8String_t&) =0;
};

/*!
 * \class PageSetting
 * \brief Définit les paramètres d'impression d'une feuille de calcul.
 */
class PageSetting {
public:
    /*!
     * \fn ~PageSetting()
     * \brief Destructeur.
     */
    virtual ~PageSetting() =0;

    /*!
     * \fn void setPrintArea(const Coordinates::MultiCellRange* coordinates)
     * \brief Définir les zones d'impression.
     * \param coordinates Une série de coordonnées de plage de cellules. NULL = pas de zone d'impression.
     */
    virtual void setPrintArea(const Coordinates::MultiCellRange*) =0;

    /*!
     * \fn void setHeader(const Coordinates::ColumnRowRange* range)
     * \brief Assigner les colonnes/lignes d'entête.
     * \param range Les coordonnées des colonnes/lignes d'entête. NULL = pas d'entête.
     */
    virtual void setHeader(const Coordinates::ColumnRowRange*) =0;

    /*!
     * \fn void setPageOrientation(pageOrientation_t orientation)
     * \brief Assigner l'orientation des pages.
     * \param orientation L'orientation des pages.
     */
    virtual void setPageOrientation(pageOrientation_t) =0;

    /*!
     * \fn void setFitToWidth(unsigned int pages)
     * \brief Assigner le nombre de pages sur lequel effectuer l'ajustement horizontal. 0 = pas d'ajustement.
     * \param pages Le nombre de page sur lequel est effectué le calcul de l'ajustement horizontal.
     */
    /*!
     * \fn void setFitToHeight(unsigned int pages)
     * \brief Assigenr le nombre de pages sur lequel effectuer l'ajustement vertical. 0 = pas d'ajustement.
     * \param pages Le nombre de page sur lequel est effectué le calcul de l'ajustement vertical.
     */
    virtual void setFitToWidth(unsigned int) =0;
    virtual void setFitToHeight(unsigned int) =0;

    /*!
     * \fn void setScale(const unsigned short* scale)
     * \brief Assigner l'échelle en %. Assigner une échelle invalide les ajustements.
     * \param scale L'échelle exprimée en % de la taille normale [10, 400] ou NULL pour supprimer l'échelle.
     */
    virtual void setScale(const unsigned short*) =0;

    /*!
     * \fn PageHeaderFooter* createPageHeaderFooter() const
     * \brief Créer des entêtes et des pieds de page.
     * \return Les entêtes et les pieds de page.
     */
    /*!
     * \fn void setPageHeaderFooter(const PageHeaderFooter& pageHeaderFooter)
     * \brief Assigner les entêtes et les pieds de page.
     * \param pageHeaderFooter Les entêtes et les pieds de page.
     */
    virtual PageHeaderFooter* createPageHeaderFooter() const =0;
    virtual void setPageHeaderFooter(const PageHeaderFooter&) =0;
};

/*!
 * \class CellFormat
 * \brief Définit un format de cellule.
 */
class CellFormat {
public:
    /*!
     * \fn ~CellFormat()
     * \brief Destructeur.
     */
    virtual ~CellFormat() =0;

    /*!
     * \fn void setFontName(const utf8String_t& name)
     * \brief Assigner le nom d'une police de caractères au format.
     * \param name Le nom de la police de caractères.
     */
    /*!
     * \fn void setFontSize(unsigned short size)
     * \brief Assigner la taille (en point) de la police de caractères au format.
     * \param size La taille de la police de caractères.
     */
    /*!
     * \fn void setFontColor(color_t color)
     * \brief Assigner la couleur de la police de caractères au format.
     * \param color La couleur de la police de caractères.
     */
    /*!
     * \fn void setFontStyle(bool bold, bool italic, bool underline)
     * \brief Assigner le style de la police de caractères au format.
     * \param bold Vrai si la police de caractères doit être grasse, faux sinon.
     * \param italic Vrai si la police de caractères doit être italique, faux sinon.
     * \param underline Vrai si la police de caractères doit être soulignée, faux sinon.
     */
    /*!
     * \fn void setFont(const utf8String_t& name, unsigned short size, color_t color, bool bold, bool italic, bool underline)
     * \brief Assigner une police de caractères au format.
     * \param name Le nom de la police de caractères.
     * \param size La taille (en point) de la police de caractères.
     * \param color La couleur de la police de caractères.
     * \param bold Vrai si la police de caractères doit être grasse, faux sinon.
     * \param italic Vrai si la police de caractères doit être italique, faux sinon.
     * \param underline Vrai si la police de caractères doit être soulignée, faux sinon.
     */
    virtual void setFontName(const utf8String_t&) =0;
    virtual void setFontSize(unsigned short) =0;
    virtual void setFontColor(color_t) =0;
    virtual void setFontStyle(bool, bool, bool) =0;
    virtual void setFont(const utf8String_t&, unsigned short, color_t, bool, bool, bool) =0;

    /*!
     * \fn void setNumberFormat(const utf8String_t& numberFormat)
     * \brief Assigner la chaîne de format des cellules.
     * \param numberFormat La chaîne de format des cellules (ex: #,##0.00).
     */
    /*!
     * \fn void setBuiltInNumberFormatId(unsigned short id)
     * \brief Assigner un format prédéfini à des cellules (cf. documentation de la fonction "Read::CellFormat::builtInNumberFormatId").
     * \param id Un identifiant compris entre [0, 164[.
     */
    virtual void setNumberFormat(const utf8String_t&) =0;
    virtual void setBuiltInNumberFormatId(unsigned short) =0;

    /*!
     * \fn void setPatternStyle(patternStyle_t style)
     * \brief Assigner le style du motif.
     * \param style Le style du motif.
     */
    /*!
     * \fn void setForegroundColor(color_t color)
     * \brief Assigner la couleur du motif.
     * \param color La couleur du motif au format 0xAARRGGBB (AA = alpha, RR = rouge, GG = vert et BB = bleu).
     */
    /*!
     * \fn void setBackgroundColor(color_t color)
     * \brief Assigner la couleur d'arrière plan.
     * \param color La couleur d'arrière plan au format 0xAARRGGBB (AA = alpha, RR = rouge, GG = vert et BB = bleu).
     */
    /*!
     * \fn void setSolidBackColor(color_t color)
     * \brief Assigner un motif solide de la couleur spécifié.
     * \param color La couleur du motif au format 0xAARRGGBB (AA = alpha, RR = rouge, GG = vert et BB = bleu).
     */
    virtual void setPatternStyle(patternStyle_t) =0;
    virtual void setForegroundColor(color_t) =0;
    virtual void setBackgroundColor(color_t) =0;

    virtual void setSolidBackColor(color_t) =0;

    /*!
     * \fn void setBorderVisible(border_t border, bool visible)
     * \brief Rendre une bordure visible ou invisible.
     * \param border La bordure à modifier.
     * \param visible Vrai pour afficher la bordure, faux sinon.
     */
    /*!
     * \fn void setBorderStyle(border_t border, borderStyle_t style)
     * \brief Assigner un style de bordure.
     * \param border La bordure à modifier.
     * \param style Le style de trait à assigner.
     */
    /*!
     * \fn void setBorderColor(border_t border, color_t color)
     * \brief Assigner une couleur de bordure.
     * \param border La bordure à modifier.
     * \param color La couleur de bordure à assigner.
     */
    virtual void setBorderVisible(border_t, bool) =0;
    virtual void setBorderStyle(border_t, borderStyle_t) =0;
    virtual void setBorderColor(border_t, color_t) =0;

    /*!
     * \fn void setHorizontalAlignment(horizontalAlignment_t alignment)
     * \brief Assigner l'alignement horizontal
     * \param alignment L'alignement à assigner.
     */
    /*!
     * \fn void setVerticalAlignment(verticalAlignment_t alignment)
     * \brief Assigner l'alignement vertical
     * \param alignment L'alignement à assigner.
     */
    /*!
     * \fn void setTextIndent(unsigned short indent)
     * \brief Assigner le retrait du texte.
     * \param indent Le retrait du texte.
     */
    virtual void setHorizontalAlignment(horizontalAlignment_t) =0;
    virtual void setVerticalAlignment(verticalAlignment_t) =0;
    virtual void setTextIndent(unsigned short) =0;

    /*!
     * \fn void setTextRotation(short angle)
     * \brief Assigner l'angle de rotation du contenu de la cellule. Il est exprimé en degré et doit être compris entre [-90°, 90°].
     * \param angle L'angle de rotation en degré.
     */
    virtual void setTextRotation(short) =0;

    /*!
     * \fn void setWrapText(bool wrap)
     * \brief Assigner le renvoi à la ligne automatique.
     * \param wrap Vrai pour un renvoi automatique, faux sinon.
     */
    virtual void setWrapText(bool) =0;
};

/*!
 * \class DifferentialCellFormat
 * \brief Définit un format différentiel (utilisé pour les formats conditionnels).
 */
class DifferentialCellFormat {
public:
    /*!
     * \fn ~DifferentialCellFormat()
     * \brief Destructeur.
     */
    virtual ~DifferentialCellFormat() =0;

    /*!
     * \fn void setFontColor(color_t color)
     * \brief Surcharger la propriété "couleur de police".
     * \param color La nouvelle valeur de la propriété.
     */
    /*!
     * \fn void setFontBold(bool bold)
     * \brief Surcharger la propriété "police grasse".
     * \param bold La nouvelle valeur de la propriété.
     */
    /*!
     * \fn void setFontItalic(bool italic)
     * \brief Surcharger la propriété "police italique".
     * \param italic La nouvelle valeur de la propriété.
     */
    /*!
     * \fn void setFontUnderline(bool underline)
     * \brief Surcharger la propriété "police soulignée".
     * \param underline La nouvelle valeur de la propriété.
     */
    /*!
     * \fn void unsetFontColor()
     * \brief Annuler la surcharge.
     */
    /*!
     * \fn void unsetFontBold()
     * \brief Annuler la surcharge.
     */
    /*!
     * \fn void unsetFontItalic()
     * \brief Annuler la surcharge.
     */
    /*!
     * \fn void unsetFontUnderline()
     * \brief Annuler la surcharge.
     */
    virtual void setFontColor(color_t) =0;
    virtual void setFontBold(bool) =0;
    virtual void setFontItalic(bool) =0;
    virtual void setFontUnderline(bool) =0;
    virtual void unsetFontColor() =0;
    virtual void unsetFontBold() =0;
    virtual void unsetFontItalic() =0;
    virtual void unsetFontUnderline() =0;

    /*!
     * \fn void setNumberFormat(const utf8String_t& numberFormat)
     * \brief Surcharger la propriété "format de nombre".
     * \param numberFormat La nouvelle valeur de la propriété.
     */
    /*!
     * \fn void setBuildInNumberFormatId(unsigned short numberFormatId)
     * \brief Surcharger la propriété "identifiant du format de nombre interne à Excel". Si la chaîne de format (fonction numberFormat) est assignée, cet identifiant n'est pas pris en compte.
     * \param numberFormatId La nouvelle valeur de la propriété comprise entre [0, 164[.
     *
     * (cf. documentation de la fonction "Read::CellFormat::builtInNumberFormatId").
     */
    /*!
     * \fn void unsetNumberFormat()
     * \brief Annuler la surcharge.
     */
    /*!
     * \fn void unsetBuildInNumberFormatId()
     * \brief Annuler la surcharge.
     */
    virtual void setNumberFormat(const utf8String_t&) =0;
    virtual void setBuildInNumberFormatId(unsigned short) =0;
    virtual void unsetNumberFormat() =0;
    virtual void unsetBuildInNumberFormatId() =0;

    /*!
     * \fn void setPatternStyle(patternStyle_t style)
     * \brief Surcharger la propriété "style du motif".
     * \param style Le style du motif.
     */
    /*!
     * \fn void unsetPatternStyle()
     * \brief Annuler la surcharge.
     */
    /*!
     * \fn void setForegroundColor(color_t color)
     * \brief Surcharger la propriété "couleur du motif".
     * \param color La couleur du motif au format 0xAARRGGBB (AA = alpha, RR = rouge, GG = vert et BB = bleu).
     */
    /*!
     * \fn void unsetForegroundColor()
     * \brief Annuler la surcharge.
     */
    /*!
     * \fn void setBackgroundColor(color_t color)
     * \brief Surcharger la propriété "couleur d'arrière plan".
     * \param color La couleur d'arrière plan au format 0xAARRGGBB (AA = alpha, RR = rouge, GG = vert et BB = bleu).
     */
    /*!
     * \fn void unsetBackgroundColor()
     * \brief Annuler la surcharge.
     */
    /*!
     * \fn void setSolidBackColor(color_t color)
     * \brief Assigner un motif solide de la couleur spécifié.
     * \param color La couleur du motif au format 0xAARRGGBB (AA = alpha, RR = rouge, GG = vert et BB = bleu).
     */
    virtual void setPatternStyle(patternStyle_t) =0;
    virtual void unsetPatternStyle() =0;
    virtual void setForegroundColor(color_t) =0;
    virtual void unsetForegroundColor() =0;
    virtual void setBackgroundColor(color_t) =0;
    virtual void unsetBackgroundColor() =0;

    virtual void setSolidBackColor(color_t) =0;

    /*!
     * \fn void setBorderVisible(border_t border, bool visible)
     * \brief Surcharger la propriété "bordure visible".
     * \param border La bordure concernée.
     * \param visible La nouvelle valeur de la propriété.
     */
    /*!
     * \fn void setBorderStyle(border_t border, borderStyle_t style)
     * \brief Surcharger la propriété "style de bordure".
     * \param border La bordure concernée.
     * \param style La nouvelle valeur de la propriété.
     */
    /*!
     * \fn void setBorderColor(border_t border, color_t color)
     * \brief Surcharger la propriété "couleur de bordure".
     * \param border La bordure concernée.
     * \param color La nouvelle valeur de la propriété.
     */
    /*!
     * \fn void unsetBorderVisible(border_t border)
     * \brief Annuler la surcharge.
     * \param border La bordure concernée.
     */
    /*!
     * \fn void unsetBorderStyle(border_t border)
     * \brief Annuler la surcharge.
     * \param border La bordure concernée.
     */
    /*!
     * \fn void unsetBorderColor(border_t border)
     * \brief Annuler la surcharge.
     * \param border La bordure concernée.
     */
    virtual void setBorderVisible(border_t, bool) =0;
    virtual void setBorderStyle(border_t, borderStyle_t) =0;
    virtual void setBorderColor(border_t, color_t) =0;
    virtual void unsetBorderVisible(border_t) =0;
    virtual void unsetBorderStyle(border_t) =0;
    virtual void unsetBorderColor(border_t) =0;
};

/*!
 * \class ConditionalFormatting
 * \brief Définit un format conditionnel.
 */
class ConditionalFormatting {
public:
    /*!
     * \fn ~ConditionalFormatting()
     * \brief Destructeur.
     */
    virtual ~ConditionalFormatting() =0;

    /*!
     * \fn void setFormat(const DifferentialCellFormat& format)
     * \brief Assigner le format différentiel.
     * \param format Le format différentiel à appliquer si la condition est vraie.
     */
    virtual void setFormat(const DifferentialCellFormat&) =0;

    /*!
     * \fn void setFormula(const utf8String_t& formula)
     * \brief Assigner la condition.
     * \param formula La condition (Elle ne commence pas par "=" et est au format "natif" Excel).
     */
    virtual void setFormula(const utf8String_t&) =0;

    /*!
     * \fn void setReference(const Coordinates::MultiCellRange& reference)
     * \brief Assigner la référence.
     * \param reference La référence sur laquelle s'applique le format si la condition est vraie. Les références aux worksheets sont ignorées (un format conditionnel n'agit que sur une feuille).
     */
    virtual void setReference(const Coordinates::MultiCellRange&) =0;
};

/*!
 * \class Validation
 * \brief Définit une règle de validation de données.
 */
class Validation {
public:
    /*!
     * \fn virtual ~Validation()
     * \brief Destructeur.
     */
    virtual ~Validation() =0;

    /*!
     * \fn void setReference(const Coordinates::MultiCellRange& reference)
     * \brief Assigner la référence.
     * \param reference La référence sur laquelle s'applique la validation. Les références aux worksheets sont ignorées (une validation n'agit que sur une feuille).
     */
    virtual void setReference(const Coordinates::MultiCellRange&) =0;

    /*!
     * \fn void allowBlank(bool allow)
     * \brief Autoriser ou non les valeurs vides.
     * \param allow Autorisation des valeurs vides si vrai, sinon les valeurs vides déclenchent une erreur.
     */
    virtual void allowBlank(bool) =0;

    /*!
     * \fn void showPrompt(bool show)
     * \brief Montrer ou non le texte de description.
     * \param show Montrer le texte de description si vrai.
     */
    virtual void showPrompt(bool) =0;

    /*!
     * \fn void setPrompt(const utf8String_t& title, const utf8String_t& message)
     * \brief Assigner le texte de description.
     * \param title Le titre.
     * \param message Le message.
     */
    virtual void setPrompt(const utf8String_t&, const utf8String_t&) =0;

    /*!
     * \fn void showAlert(bool show)
     * \brief Montrer ou non le message d'alerte.
     * \param show Montrer le message d'alerte si vrai.
     */
    virtual void showAlert(bool) =0;

    /*!
     * \fn void setAlertType(alertType_t type)
     * \brief Assigner le type d'alerte.
     * \param type Le type d'alerte.
     */
    virtual void setAlertType(alertType_t) =0;

    /*!
     * \fn void setAlert(const utf8String_t& title, const utf8String_t& message)
     * \brief Assigner le message d'alerte.
     * \param title Le titre.
     * \param message Le message.
     */
    virtual void setAlert(const utf8String_t&, const utf8String_t&) =0;
};

/*!
 * \class CustomValidation
 * \brief Définit une règle de validation de données à partir d'une formule.
 */
class CustomValidation : public virtual Validation {
public:
    /*!
     * \fn ~CustomValidation()
     * \brief Destructeur.
     */
    virtual ~CustomValidation() =0;

    /*!
     * \fn void setFormula(const utf8String_t& formula)
     * \brief Assigner la condition de validation.
     * \param formula La condition de validation (Elle ne commence pas par "=" et est au format "natif" Excel).
     */
    virtual void setFormula(const utf8String_t&) =0;
};

/*!
 * \class ListValidation
 * \brief Définit une règle de validation de données à partir d'une liste de valeur.
 */
class ListValidation : public virtual Validation {
public:
    /*!
     * \fn ~ListValidation()
     * \brief Destructeur.
     */
    virtual ~ListValidation() =0;

    /*!
     * \fn void setRangeReference(const Coordinates::CellRange& range);
     * \brief Assigner une plage de données de référence pour la liste de validation.
     * \param range La plage de données de référence.
     *
     * Assigner cette plage de cellules réinitialise la liste des valeurs possibles.
     */
    virtual void setRangeReference(const Coordinates::CellRange&) =0;

    /*!
     * \fn void setList(const valueList_t& list)
     * \brief Assigner la liste des valeurs possibles.
     * \param list La liste des valeurs possibles.
     *
     * Assigner une liste de valeur invalide la plage de référence.
     */
    virtual void setList(const valueList_t&) =0;
};

/*!
 * \class Filter
 * \brief Définit un filtre.
 */
class Filter {
public:
    /*!
     * \class Filter
     * \brief Destructeur.
     */
    virtual ~Filter() =0;

    /*!
     * \fn void setRangeReference(const Coordinates::CellRange& range);
     * \brief Assigner une plage de données de référence pour le filtre.
     * \param range La plage de données de référence.
     */
    virtual void setRangeReference(const Coordinates::CellRange&) =0;
};

/*!
 * \class Image
 * \brief Définit une image.
 */
class Image {
public:
    /*!
     * \fn ~Image()
     * \brief Destructeur.
     */
    virtual ~Image() =0;

    /*!
     * \fn void setImage(unsigned char* stream, unsigned int length, bool copy)
     * \brief Assigner le flux de l'image.
     * \param stream Le flux de l'image.
     * \param length La taille du flux.
     * \param copy Le flux doit il être recopié ?
     */
    virtual void setImage(unsigned char*, unsigned int, bool =true) =0;

    /*!
     * \fn void setTopLeft(const Coordinates::CellPoint& point)
     * \brief Assigner la position haut-gauche de l'image par rapport à la grille.
     * \param point La position haut-gauche de l'image.
     */
    /*!
     * \fn void setRightBottom(const Coordinates::CellPoint* point)
     * \brief Assigner la position bas-droite de l'image par rapport à la grille.
     * \param point La position bas-droite de l'image. Si NULL, la position sera calculée de façon à ce que l'image ne soit pas déformée.
     */
    virtual void setTopLeft(const Coordinates::CellPoint&) =0;
    virtual void setRightBottom(const Coordinates::CellPoint*) =0;

    /*!
     * \fn void setCropRectangle(const pixelRectangle_t* cropRectangle)
     * \brief Assigner le rectangle de rognage de l'image.
     * \param cropRectangle Le rectangle de rognage. Si NULL alors il n'y a pas de rognage.
     */
    virtual void setCropRectangle(const pixelRectangle_t*) =0;

    /*!
     * \fn void setProperty(imageProperty_t property)
     * \brief Assigner le comportement de l'image par rapport aux changements de la grille.
     * \param property La propriété de l'image.
     */
    virtual void setProperty(imageProperty_t) =0;
};

/*!
 * \class Hyperlink
 * \brief Définit un lien d'une cellule à une plage de cellules.
 */
class Hyperlink {
public:
    /*!
     * \fn ~Hyperlink
     * \brief Destructeur.
     */
    virtual ~Hyperlink() =0;

    /*!
     * \fn void setReference(const Coordinates::Cell& cell)
     * \brief Spécifier le lien à la cellule passée en paramètre. Annule et remplace les autres références spécifiées précédement.
     * \param cell La cellule sur laquelle repose le lien.
     */
    /*!
     * \fn void setReference(const Coordinates::CellRange& range)
     * \brief Spécifier le lien à la plage de cellules passée en paramètre. Annule et remplace les autres références spécifiées précédement.
     * \param range La plage de cellule sur laquelle repose le lien.
     */
    virtual void setReference(const Coordinates::Cell&) =0;
    virtual void setReference(const Coordinates::CellRange&) =0;

    /*!
     * \fn void setDisplay(const utf8String_t& text)
     * \brief Spécifier un texte à afficher par défaut.
     * \param text Le texte à afficher par défaut.
     */
    virtual void setDisplay(const utf8String_t&) =0;

    /*!
     * \fn void setLocation(const Coordinates::Cell& cell)
     * \brief Spécifier la destination du lien. Annule et remplace les autres actions spécifiées précédement.
     * \param cell La cellule destination du lien.
     */
    /*!
     * \fn void setLocation(const Coordinates::CellRange& range)
     * \brief Spécifier la destination du lien. Annule et remplace les autres actions spécifiées précédement.
     * \param range La plage de cellules destination du lien.
     */
    /*!
     * \fn void setLocation(const DefinedName& name)
     * \brief Spécifier la destination du lien. Annule et remplace les autres actions spécifiées précédement.
     * \param name La plage de cellules destination du lien.
     */
    virtual void setLocation(const Coordinates::Cell&) =0;
    virtual void setLocation(const Coordinates::CellRange&) =0;
    virtual void setLocation(const DefinedName&) =0;

    /*!
     * \fn void setFileLocation(const utf8String_t& filename)
     * \brief Spécifier le fichier à ouvrir. Annule et remplace les autres actions spécifiées précédement.
     * \param filename Le nom du fichier à ouvrir.
     */
    /*!
     * \fn void setMailLocation(const utf8String_t& mail, const utf8String_t& subject)
     * \brief Spécifier les paramètres du mail à préparer. Annule et remplace les autres actions spécifiée précédement.
     * \param mail L'adresse mail du destinataire.
     * \param subject L'objet du mail.
     */
    virtual void setFileLocation(const utf8String_t&) =0;
    virtual void setMailLocation(const utf8String_t&, const utf8String_t&) =0;

    /*!
     * \fn void setTooltip(const utf8String_t& text)
     * \brief Spécifier le texte de l'info bulle.
     * \param text Le texte de l'info bulle.
     */
    virtual void setTooltip(const utf8String_t&) =0;
};

/*!
 * \class Comment
 * \brief Définit un commentaire.
 */
class Comment {
public:
    /*!
     * \fn ~Comment()
     * \brief Destructeur.
     */
    virtual ~Comment() =0;

    /*!
     * \fn void setReference(const Coordinates::Cell& cell)
     * \brief Spécifier la cellule à laquelle est raccroché le commentaire.
     * \param cell La cellule à laquelle est raccroché le commentaire.
     */
    virtual void setReference(const Coordinates::Cell&) =0;

    /*!
     * \fn void setAuthor(const utf8String_t& author)
     * \brief Spécifier l'auteur du commentaire.
     * \param author L'auteur du commentaire.
     */
    virtual void setAuthor(const utf8String_t&) =0;

    /*!
     * \fn void addRun(const font_t& font, const utf8String_t& text)
     * \brief Ajouter une portion de texte.
     * \param font La police de caractères de la portion de texte.
     * \param text Le texte de la portion.
     */
    virtual void addRun(const font_t&, const utf8String_t&) =0;

    /*!
     * \fn void setHyperlink(const std::string& hyperlink)
     * \brief Assigner le lien hyper texte de la boite de commentaire.
     * \param hyperlink Le lien hyper texte.
     */
    virtual void setHyperlink(const std::string&) =0;

    /*!
     * \fn void setAlignment(Interface::horizontalAlignment_t alignment)
     * \brief Spécifier l'alignement du texte dans la boite de commentaire.
     * \param alignment L'alignement horizontal du texte.
     */
    virtual void setAlignment(Interface::horizontalAlignment_t) =0;

    /*!
     * \fn void setTopLeft(const Coordinates::CellPoint& point)
     * \brief Assigner la position haut-gauche de la boite de commentaire par rapport à la grille.
     * \param point La position haut-gauche de la boite de commentaire.
     */
    /*!
     * \fn void setRightBottom(const Coordinates::CellPoint& point)
     * \brief Assigner la position bas-droite de la boite de commentaire par rapport à la grille.
     * \param point La position bas-droite de la boite de commentaire.
     */
    /*!
     * \fn void setAutoSize(bool autoSize)
     * \brief Ajuster la taille de la boite de commentaire au texte.
     * \param autoSize Si Vrai, la taille de la boite de commentaire s'ajustera au texte.
     */
    virtual void setTopLeft(const Coordinates::CellPoint&) =0;
    virtual void setRightBottom(const Coordinates::CellPoint&) =0;
    virtual void setAutoSize(bool) =0;

    /*!
     * \fn void setFillColor(color_t color)
     * \brief Spécifier la couleur de fond de la boite de commentaire.
     * \param color La couleur de fond.
     */
    virtual void setFillColor(color_t) =0;

    /*!
     * \fn void setVisibility(visibility_t visibility)
     * \brief Spécifier la visibilité de la boite de commentaire (cachée ou toujours visible).
     * \param visibility La visibilité de la boite de commentaire.
     */
    virtual void setVisibility(visibility_t) =0;

    /*!
     * \fn void setProperty(commentProperty_t property)
     * \brief Spécifier le comportement de la boite de commentaire par rapport à la grille.
     * \param property Le comportement de la boite de commentaire par rapport à la grille.
     */
    virtual void setProperty(commentProperty_t) =0;
};

/*!
 * \class Worksheet
 * \brief Définit une feuille de calcul.
 */
class Worksheet {
public:
    /*!
     * \fn ~Worksheet()
     * \brief Destructeur.
     */
    virtual ~Worksheet() =0;

    /*!
     * \fn const Coordinates::WorksheetProxy* proxy() const
     * \brief Obtenir le proxy de la feuille.
     * \return Le proxy de la feuille.
     */
    virtual const Coordinates::WorksheetProxy* proxy() const =0;

    /*!
     * \fn void setHidden(bool hidden)
     * \brief Cacher ou rendre visible la feuille.
     * \param hidden Si vrai, la feuille est cachée.
     */
    virtual void setHidden(bool) =0;

    /*!
     * \fn void showFormulas(bool show)
     * \brief Rendre les formules visibles dans la feuille.
     * \param show Si vrai, les formules seront affichées.
     */
    virtual void showFormulas(bool) =0;

    /*!
     * \fn void showGridLines(bool show) 
     * \brief Rendre le quadrillage visible dans la feuille ?
     * \param show Si vrai, le quadrillage sera affiché.
     */
    virtual void showGridLines(bool) =0;

    /*!
     * \fn void showRowColHeaders(bool show)
     * \brief Rendre les entêtes de lignes et de colonnes visibles dans la feuille ?
     * \param show Si vrai, les entêtes de lignes et de colonnes seront affichés.
     */
    virtual void showRowColHeaders(bool) =0;

    /*!
     * \fn void showZeros(bool show)
     * \brief Afficher un zéro dans les cellules qui ont une valeur nulle.
     * \param show Si vrai, les zéros seront affichés.
     */
    virtual void showZeros(bool) =0;

    /*!
     * \fn void setActiveCell(const Coordinates::Cell& cell)
     * \brief Spécifier la cellule active.
     * \param cell Les coordonnées de la cellule active.
     * Si la cellule n'appartient pas à la selection, la selection est changée en la cellule active.
     */
    /*!
     * \fn void setSelection(const Coordinates::MultiCellRange& cell)
     * \brief Spécifier les cellules sélectionnées.
     * \param cell Les coordonnées des cellules sélectionnées.
     * Si la cellule active n'appartient pas à la selection, la cellule est changée en la coordonnée de la cellule en haut à droite de la première plage de sélection.
     */
    virtual void setActiveCell(const Coordinates::Cell&) =0;
    virtual void setSelection(const Coordinates::MultiCellRange&) =0;

    /*!
     * \fn PageSetting* createPageSetting() const
     * \brief Créer des paramètres d'impression de la feuille.
     * \return Les paramètres d'impression.
     */
    /*!
     * \fn void setPageSetting(const PageSetting& pageSetting)
     * \brief Assigner les paramètres d'impression de la feuille.
     * \param pageSetting Les paramètres d'impression de la feuille.
     */
    virtual PageSetting* createPageSetting() const =0;
    virtual void setPageSetting(const PageSetting&) =0;

    /*!
     * \fn void setColumnVisible(unsigned int index, bool visible)
     * \brief Rendre la colonne visible ou invisible.
     * \param index L'index de la colonne concernée ([0, ∞[).
     * \param visible Vrai si la colonne est visible, faux sinon.
     */
    /*!
     * \fn void setColumnWidth(unsigned int index, const double* size)
     * \brief Assigner la taille.
     * \param index L'index de la colonne concernée ([0, ∞[).
     * \param size La largeur de la colonne. Si NULL, la colonne aura la taille définie par défaut.
     *
     * La taille de la colonne correspond au nombre de chiffres maximum visibles dans la police de style normal.
     * Pour le calcul, Excel utilise la taille du chiffre le plus large.
     * Excel ajoute 2 pixels de marge de chaque côté et 1 pixel pour la grille.
     * Le calcul est : taille en pixel = trunc({size} * 7)
     */
    /*!
     * \fn void setColumnOutlineLevel(unsigned int index, unsigned short outlineLevel)
     * \brief Assigner le niveau de groupement.
     * \param index L'index de la colonne concernée ([0, ∞[).
     * \param outlineLevel Le niveau. Doit être compris entre [0-7].
     */
    /*!
     * \fn void setColumnCollapsed(unsigned int index, bool collapsed)
     * \brief Rendre le groupement masqué.
     * \param index L'index de la colonne concernée ([0, ∞[).
     * \param collapsed Vrai si le groupement doit être masqué, faux sinon.
     */
    /*!
     * \fn void setColumnFormat(unsigned int index, const CellFormat* format)
     * \brief Assigner un format de cellule à la colonne.
     * \param index L'index de la colonne concernée ([0, ∞[).
     * \param format Le format de cellule.
     */
    /*!
     * \fn bool setColumnChildrenCollapsed(unsigned int index, bool collapsed)
     * \brief Rendre les colonnes enfants de la colonne masquées.
     * \param index L'index de la colonne concernée ([0, ∞[).
     * \param collapsed Vrai si le groupement doit être masqué, faux sinon.
     * \return Vrai si la colonne a des enfants, faux sinon.
     *
     * Cette fonction tient compte de la valeur assignée par la fonction setOutlineSummaryRight.
     */
    virtual void setColumnVisible(unsigned int, bool) =0;
    virtual void setColumnWidth(unsigned int, const double*) =0;
    virtual void setColumnOutlineLevel(unsigned int, unsigned short) =0;
    virtual void setColumnCollapsed(unsigned int, bool) =0;
    virtual void setColumnFormat(unsigned int, const CellFormat*) =0;

    virtual bool setColumnChildrenCollapsed(unsigned int, bool) =0;

    /*!
     * \fn void setRowVisible(unsigned int index, bool visible)
     * \brief Rendre la ligne visible ou invisible.
     * \param index L'index de la ligne concernée ([0, ∞[).
     * \param visible Vrai si la ligne est visible, faux sinon.
     */
    /*!
     * \fn void setRowHeight(unsigned int index, const double* size)
     * \brief Assigner la taille.
     * \param index L'index de la ligne concernée ([0, ∞[).
     * \param size La hauteur de la ligne. Si NULL, la ligne aura la taille définie par défaut.
     *
     * La taille des lignes est exprimée en point.
     */
    /*!
     * \fn void setRowOutlineLevel(unsigned int index, unsigned short outlineLevel)
     * \brief Assigner le niveau de groupement.
     * \param index L'index de la ligne concernée ([0, ∞[).
     * \param outlineLevel Le niveau. Doit être compris entre [0-7].
     */
    /*!
     * \fn void setRowCollapsed(unsigned int index, bool collapsed)
     * \brief Rendre le groupement masqué.
     * \param index L'index de la ligne concernée ([0, ∞[).
     * \param collapsed Vrai si le groupement doit être masqué, faux sinon.
     */
    /*!
     * \fn void setRowFormat(unsigned int index, const CellFormat* format)
     * \brief Assigner un format de cellule à la ligne.
     * \param index L'index de la ligne concernée ([0, ∞[).
     * \param format Le format de cellule.
     */
    /*!
     * \fn bool setRowChildrenCollapsed(unsigned int index, bool collapsed)
     * \brief Rendre les lignes enfants de la ligne masquées.
     * \param index L'index de la ligne concernée ([0, ∞[).
     * \param collapsed Vrai si le groupement doit être masqué, faux sinon.
     * \return Vrai si la ligne a des enfants, faux sinon.
     *
     * Cette fonction tient compte de la valeur assignée par la fonction setOutlineSummaryBelow.
     */
    virtual void setRowVisible(unsigned int, bool) =0;
    virtual void setRowHeight(unsigned int, const double*) =0;
    virtual void setRowOutlineLevel(unsigned int, unsigned short) =0;
    virtual void setRowCollapsed(unsigned int, bool) =0;
    virtual void setRowFormat(unsigned int, const CellFormat*) =0;

    virtual bool setRowChildrenCollapsed(unsigned int, bool) =0;

    /*!
     * \fn void setDefaultColumnWidth(double width)
     * \brief Spécifier la taille par défaut des colonnes.
     * \param width La largeur par défaut des colonnes.
     *
     * La taille de la colonne correspond au nombre de chiffres maximum visibles dans la police de style normal.
     * Pour le calcul, Excel utilise la taille du chiffre le plus large.
     * Excel ajoute 2 pixels de marge de chaque côté et 1 pixel pour la grille.
     * Le calcul est : taille en pixel = trunc({size} * 7)
     */
    /*!
     * \fn void setDefaultRowHeight(double height)
     * \brief Spécifier la taille par défaut des lignes.
     * \param height La hauteur par défault des lignes (exprimée en point).
     */
    virtual void setDefaultColumnWidth(double) =0;
    virtual void setDefaultRowHeight(double) =0;

    /*!
     * \fn void setOutlineSummaryRight(bool summaryRight)
     * \brief Assigner la position de la colonne de récapitulation.
     * \param summaryRight Vrai si la colone de récapitulation doit être à droite, faux sinon.
     */
    /*!
     * \fn void setOutlineSummaryBelow(bool summaryBelow)
     * \brief Assigner la position de la ligne de récapitulation.
     * \param summaryBelow Vrai si la ligne de récapitulation doit être en bas, faux sinon.
     */
    virtual void setOutlineSummaryRight(bool) =0;
    virtual void setOutlineSummaryBelow(bool) =0;

    /*!
     * \fn void setXSplit(unsigned int column)
     * \brief Assigner la dernière colonne fixe.
     * \param column L'index de la dernière colone fixe ([0, ∞[).
     */
    /*!
     * \fn void unsetXSplit()
     * \brief Supprimer les colonnes fixes.
     */
    virtual void setXSplit(unsigned int) =0;
    virtual void unsetXSplit() =0;

    /*!
     * \fn void setYSplit(unsigned int row)
     * \brief Assigner la dernière ligne fixe.
     * \param row L'index de la dernière ligne fixe ([0, ∞[).
     */
    /*!
     * \fn void unsetYSplit()
     * \brief Supprimer les lignes fixes.
     */
    virtual void setYSplit(unsigned int) =0;
    virtual void unsetYSplit() =0;

    /*!
     * \fn CellFormat* createFormat() const
     * \brief Créer un format de cellule.
     * \return Un nouveau format de cellule.
     */
    /*!
     * \fn void setFormat(unsigned int column, unsigned int row, const CellFormat& format)
     * \brief Assigner un format à une cellule.
     * \param column L'index de la colonne.
     * \param row L'index de la ligne.
     * \param format Le format à assigner. Il sera ajouté au classeur.
     */
    virtual CellFormat* createFormat() const =0;
    virtual void setFormat(unsigned int, unsigned int, const CellFormat&) =0;

    /*!
     * \fn void setSimpleCellValue(unsigned int column, unsigned int row, const CellValue& value)
     * \brief Assigner une valeur à une cellule.
     * \param column L'index de la colonne.
     * \param row L'index de la ligne.
     * \param value La valeur à assigner.
     */
	/*!
	 * \fn void setNullValue(unsigned int column, unsigned int row, const utf8String_t& formula)
	 * \brief Assigner une valeur nulle à une cellule.
	 * \param column L'index de la colonne ([0, ∞[).
	 * \param row L'index de la ligne ([0, ∞[).
	 * \param formula La formule de calcul au format "natif" Excel.
	 */
	/*!
     * \fn void setBooleanValue(unsigned int column, unsigned int row, bool value, const utf8String_t& formula)
     * \brief Assigner une valeur à une cellule.
     * \param column L'index de la colonne ([0, ∞[).
     * \param row L'index de la ligne ([0, ∞[).
     * \param value La valeur booléenne.
     * \param formula La formule de calcul au format "natif" Excel.
     */
    /*!
     * \fn void setNumberValue(unsigned int column, unsigned int row, double value, const utf8String_t& formula)
     * \brief Assigner une valeur à une cellule.
     * \param column L'index de la colonne ([0, ∞[).
     * \param row L'index de la ligne ([0, ∞[).
     * \param value La valeur numérique.
     * \param formula La formule de calcul au format "natif" Excel.
     */
    /*!
     * \fn void setStringValue(unsigned int column, unsigned int row, const utf8String_t& value, const utf8String_t& formula)
     * \brief Assigner une valeur à une cellule.
     * \param column L'index de la colonne ([0, ∞[).
     * \param row L'index de la ligne ([0, ∞[).
     * \param value La valeur chaîne.
     * \param formula La formule de calcul au format "natif" Excel.
     */
    /*!
     * \fn void setErrorValue(unsigned int column, unsigned int row, cellError_t value, const utf8String_t& formula)
     * \brief Assigner une valeur à une cellule.
     * \param column L'index de la colonne ([0, ∞[).
     * \param row L'index de la ligne ([0, ∞[).
     * \param value Le type d'erreur.
     * \param formula La formule de calcul au format "natif" Excel.
     */
    /*!
     * \fn void forceDateValue(unsigned int column, unsigned int row, double value, const utf8String_t& formula)
     * \brief Assigner une valeur date à une cellule. Le format de la cellule sera édité pour pointer sur une chaîne de format "en dur dans Excel" qui représente le format date (format qui répond aux changements dans les paramètres régionnaux).
     * \param column L'index de la colonne ([0, ∞[).
     * \param row L'index de la ligne ([0, ∞[).
     * \param value La date.
     * \param formula La formule de calcul au format "natif" Excel.
     */
	/*!
	 * \fn RichText* createRichText() const
	 * \brief Créer un texte riche.
	 * \return Un nouveau texte riche.
	 */
	/*!
	 * \fn void setRichTextValue(unsigned int column, unsigned int row, const RichText* value, const utf8String_t& formula)
	 * \brief Assigner une valeur à une cellule.
	 * \param column L'index de la colonne ([0, ∞[).
	 * \param row L'index de la ligne ([0, ∞[).
	 * \param value La valeur texte riche.
	 * \param formula La formule de calcul au format "natif" Excel.
	 */
	virtual void setSimpleCellValue(unsigned int, unsigned int, const CellValue&) =0;
    virtual void setNullValue(unsigned int, unsigned int, const utf8String_t& ="") =0;
    virtual void setBooleanValue(unsigned int, unsigned int, bool, const utf8String_t& ="") =0;
    virtual void setNumberValue(unsigned int, unsigned int, double, const utf8String_t& ="") =0;
    virtual void setStringValue(unsigned int, unsigned int, const utf8String_t&, const utf8String_t& ="") =0;
    virtual void setErrorValue(unsigned int, unsigned int, cellError_t, const utf8String_t& ="") =0;

    virtual void forceDateValue(unsigned int, unsigned int, double, const utf8String_t& ="") =0;

	virtual RichText* createRichText() const =0;
	virtual void setRichTextValue(unsigned int, unsigned int, const RichText*, const utf8String_t& = "") =0;

    /*!
     * \fn void setMerge(const Coordinates::CellRange& merge)
     * \brief Ajouter une fusion de cellule.
     * \param merge La plage de cellules fusionnées.
     */
    virtual void setMerge(const Coordinates::CellRange&) =0;

    /*!
     * \fn DifferentialCellFormat* createDifferentialCellFormat() const
     * \brief Créer un format différentiel.
     * \return Un nouveau format différentiel.
     */
    /*!
     * \fn ConditionalFormatting* createConditionalFormatting() const
     * \brief Créer un format conditionnel.
     * \return Un nouveau format conditionnel.
     */
    /*!
     * \fn void addConditionalFormatting(const ConditionalFormatting& conditionalFormatting)
     * \brief Ajouter un format conditionnel.
     * \param conditionalFormatting Le format conditionnel à ajouter.
     */
    virtual DifferentialCellFormat* createDifferentialCellFormat() const =0;
    virtual ConditionalFormatting* createConditionalFormatting() const =0;
    virtual void addConditionalFormatting(const ConditionalFormatting&) =0;

    /*!
     * \fn CustomValidation* createCustomValidation() const
     * \brief Créer une règle de validation de données à partir d'une formule.
     * \return Une nouvelle règle de validation de données à partir d'une formule.
     */
    /*!
     * \fn ListValidation* createListValidation() const
     * \brief Créer une règle de validation de données à partir d'une liste.
     * \return Une nouvelle règle de validation de données à partir d'une liste.
     */
    /*!
     * \fn void addValidation(const Validation* validation)
     * \brief Ajouter une règle de validation.
     * \param validation La règle de validation.
     */
    virtual CustomValidation* createCustomValidation() const =0;
    virtual ListValidation* createListValidation() const =0;
    virtual void addValidation(const Validation*) =0;

    /*!
     * \fn Filter* createFilter() const
     * \brief Créer un filtre.
     * \return Un nouveau filtre.
     */
    /*!
     * \fn void setFilter(const Interface::Write::Filter& filter)
     * \brief Assigne un filtre.
     * \param filter Le filtre.
     */
    virtual Filter* createFilter() const =0;
    virtual void setFilter(const Filter&) =0;

    /*!
     * \fn Image* createImage() const
     * \brief Créer une image.
     * \return Une nouvelle image.
     */
    /*!
     * \fn void addImage(const Image* image)
     * \brief Ajouter une image (JPG, GIF, PNG ou BMP).
     * \param image L'image.
     */
    virtual Image* createImage() const =0;
    virtual void addImage(const Image*) =0;

    /*!
     * \fn Hyperlink* createHyperlink() const
     * \brief Créer un lien.
     * \return Un nouveau lien.
     */
    /*!
     * \fn void addHyperlink(const Hyperlink* hyperlink)
     * \brief Ajouter un lien.
     * \param hyperlink Les paramètres du lien.
     */
    virtual Hyperlink* createHyperlink() const =0;
    virtual void addHyperlink(const Hyperlink*) =0;

    /*!
     * \fn Comment* createComment() const
     * \brief Créer un commentaire.
     * \return Un nouveau commentaire.
     */
    /*!
     * \fn bool addComment(const Comment* comment)
     * \brief Ajouter un commentaire.
     * \param comment Les paramètres du commentaire.
     * \return Vrai si le commentaire a été ajouté, faux sinon (un commentaire existe déjà sur cette cellule).
     */
    virtual Comment* createComment() const =0;
    virtual bool addComment(const Comment*) =0;
};

/*!
 * \class Workbook
 * \brief Définit un classeur de feuilles de calcul.
 */
class Workbook {
public:
    /*!
     * \fn ~Workbook()
     * \brief Destructeur.
     */
    virtual ~Workbook() =0;

    /*!
     * \fn const Coordinates::WorkbookProxy* proxy() const
     * \brief Obtenir le proxy du classeur.
     * \return Le proxy du classeur.
     */
    virtual const Coordinates::WorkbookProxy* proxy() const =0;

    /*!
     * \fn Worksheet* newWorksheet(const utf8String_t& name)
     * \brief Ajouter une feuille de calcul au classeur.
     * \param name Le nom de la feuille de calcul a ajouter.
     * \return La feuille de calcul ajoutée. Le nom de la feuille a pu être modifié pour éviter les doublons.
     */
    virtual Worksheet* newWorksheet(const utf8String_t&) =0;

    /*!
     * \fn bool selectWorksheet(const Worksheet* worksheet)
     * \brief Selectionner la feuille active.
     * \param worksheet La feuille de calcul à selectionner.
     * \return Vrai si la feuille appartient au classeur, faux sinon.
     */
    /*!
     * \fn void selectWorksheetIndex(unsigned int index)
     * \brief Selectionner la feuille active.
     * \param index L'index de la feuille de calcul à selectionner.
     */
    virtual bool selectWorksheet(const Worksheet*) =0;
    virtual void selectWorksheetIndex(unsigned int) =0;

    /*!
     * \fn void setDefaultFont(const utf8String_t& name, unsigned short size, color_t color, bool bold, bool italic, bool underline)
     * \brief Assigner la police de caractères par défault.
     * \param name Le nom de la police.
     * \param size La taille de la police (en pt).
     * \param color La couleur de la police.
     * \param bold La police est-elle grasse ?
     * \param italic La police est-elle en italique ?
     * \param underline La police est-elle soulignée ?
     */
    virtual void setDefaultFont(const utf8String_t&, unsigned short, color_t, bool, bool, bool) =0;

    /*!
     * \fn CellFormat* createFormat() const
     * \brief Créer un format de cellule.
     * \return Un nouveau format de cellule.
     */
    /*!
     * \fn formatIdentifier_t addFormat(const CellFormat& format)
     * \brief Ajouter le format de cellule à la liste générale des formats de cellule.
     * \param format Le format de cellule à ajouter.
     * \return L'identifiant du format ajouté.
     */
    virtual CellFormat* createFormat() const =0;
    virtual formatIdentifier_t addFormat(const CellFormat&) =0;

    /*!
     * \fn void setFormat(const Coordinates::Cell& coordinate, const CellFormat& format)
     * \brief Assigner un format à une cellule.
     * \param coordinate La coordonnée de la cellule.
     * \param format Le format à assigner. Il sera ajouté au classeur.
     */
    /*!
     * \fn void setFormat(const Coordinates::CellRange& coordinates, const CellFormat& format)
     * \brief Assigner un format à une plage de cellules.
     * \param coordinates Les coordonnées de la plage de cellules.
     * \param format Le format à assigner. Il sera ajouté au classeur.
     */
    /*!
     * \fn void setFormat(const Coordinates::MultiCellRange& coordinates, const CellFormat& format)
     * \brief Assigner un format à plusieurs plages de cellules.
     * \param coordinates Les coordonnées des plages de cellules.
     * \param format Le format à assigner. Il sera ajouté au classeur.
     */
    virtual void setFormat(const Coordinates::Cell&, const CellFormat&) =0;
    virtual void setFormat(const Coordinates::CellRange&, const CellFormat&) =0;
    virtual void setFormat(const Coordinates::MultiCellRange&, const CellFormat&) =0;

    /*!
     * \fn DefinedName* createDefinedName() const
     * \brief Créer un nom de plage de cellules.
     * \return Un nouveau nom de plage de cellules.
     */
    /*!
     * \fn size_t addDefinedName(const DefinedName& definedName)
     * \brief Ajouter une plage de cellules nommée. Si elle existe déjà, rien n'est modifié.
     * \param definedName La plage de cellules nommée.
     * \return L'index de la plage nommée.
     *
     * Attention, les noms de plage ne sont pas tous valides (cf. méthode isDefinedNameValid).
     * Attention, les plages nommées sur plusieurs feuilles ne sont pas valides.
     * Attention, les plages nommées non bloquées (attribut locked) ont des comportements bizares dans Excel.
     */
    virtual DefinedName* createDefinedName() const =0;
    virtual size_t addDefinedName(const DefinedName&) =0;
};

} // namespace Write
} // namespace Interface
} // namespace XLSX
} // namespace Invoke

#endif  /* invoke_xlsx_workbookWriteInterface_hpp */
