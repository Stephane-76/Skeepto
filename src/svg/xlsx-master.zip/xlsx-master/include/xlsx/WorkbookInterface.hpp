/*!
 * \file        WorkbookInterface.hpp
 * \author      Invoke - Jean-Christophe PHILIPPE (jcphilippe\@invoke.fr)
 * \date        Octobre 2014
 * \copyright   SA Invoke
 */

#ifndef invoke_xlsx_workbookInterface_hpp
#define invoke_xlsx_workbookInterface_hpp

#include "string/SharedString.hpp"

#include <string>
#include <vector>

namespace Invoke {
namespace XLSX {
namespace Interface {

/*!
 * \typedef utf8String_t
 * \brief Les chaînes de caractères sont encodées en UTF-8.
 */
typedef std::string utf8String_t;

/*!
 * \typedef utf8SharedString_t
 * \brief Les chaînes de caractères sont encodées en UTF-8.
 */
typedef SharedString utf8SharedString_t;

/*!
 * \typedef color_t
 * \brief Les couleurs sont codées sur 4 octets : alpha, rouge, vert et bleu (0xAARRGGBB)
 */
typedef unsigned long color_t;

/*!
 * \enum cellType_t
 * \brief Types de cellule.
 */
typedef enum {
    ctNull,     /*!< Type null */
    ctBoolean,  /*!< Type booléen */
    ctNumber,   /*!< Type nombre */
    ctString,   /*!< Type chaîne de caractères */
    ctRichText, /*!< Type texte */
    ctError     /*!< Type erreur */
} cellType_t;

/*!
 * \enum cellError_t
 * \brief Types d'erreur.
 */
typedef enum {
    ceNONE,  /*!< Pas d'erreur */
    ceDIV0,  /*!< \c \#DIV/0! Erreur de division par zéro */
    ceNULL,  /*!< \c \#NULL! Erreur de valeur nulle */
    ceVALUE, /*!< \c \#VALUE! Erreur de valeur */
    ceREF,   /*!< \c \#REF! Erreur de référence de cellule non valide */
    ceNAME,  /*!< \c \#NAME? Erreur due à un nom non valide */
    ceNUM,   /*!< \c \#NUM! Erreur de nombre */
    ceNA     /*!< \c \#N/A Erreur de valeur manquante */
} cellError_t;

/*!
 * \enum headerFooterConstant_t
 * \brief Constantes pour les entêtes et pieds de page.
 */
typedef enum {
    hfcPage,    /*!< Numéro de page */
    hfcPages,   /*!< Nombre de pages */
    hfcDate,    /*!< Date */
    hfcTime,    /*!< Heure */
    hfcPath,    /*!< Chemin du fichier */
    hfcFile,    /*!< Nom du fichier */
    hfcSheet    /*!< Nom de la feuille */
} headerFooterConstant_t;

/*!
 * \fn utf8String_t code(headerFooterConstant_t constant)
 * \brief Traduire une constante en code compréhensible par Excel dans les entêtes et pieds de page.
 * \param constant La constante à traduire.
 * \return Le code de la constante.
 *
 * \code
 * hfcPage  = "&P"
 * hfcPages = "&N"
 * hfcDate  = "&D"
 * hfcTime  = "&T"
 * hfcPath, = "&Z"
 * hfcFile  = "&F"
 * hfcSheet = "&A"
 * \endcode
 */
utf8String_t code(headerFooterConstant_t);

/*!
 * \fn utf8String_t headerFooterFontCode(const utf8String_t& name, unsigned short size, color_t color)
 * \brief Traduire une police de caractères en code compréhensible par Excel dans les entêtes et pieds de page.
 * \param name Le nom de la police à traduire.
 * \param size La taille de la police à traduire.
 * \param color La couleur de la police à traduire.
 * \return Le code.
 */
utf8String_t headerFooterFontCode(const utf8String_t&, unsigned short, color_t);

/*!
 * \enum columnRowType_t
 * \brief Colonne ou ligne.
 */
typedef enum {
    crtColumn,  /*!< Colonne. */
    crtRow      /*!< Ligne. */
} columnRowType_t;

/*!
 * \enum pageOrientation_t
 * \brief Orientation des pages.
 */
typedef enum {
    poDefault,    /*!< Orientation par défaut (portrait) */
    poPortrait,   /*!< Orientation portrait */
    poLandscape   /*!< Orientation paysage */
} pageOrientation_t;

/*!
 * \enum patternStyle_t
 * \brief Type de remplissage.
 */
typedef enum {
    psNone = 0,         /*!< Non */
    psSolid,            /*!< Solide */
    psDarkGray,         /*!< Gris 75% */
    psMediumGray,       /*!< Gris 50% */
    psLightGray,        /*!< Gris 25% */
    psGray125,          /*!< Gris 12,5% */
    psGray0625,         /*!< Gris 6,25% */
    psDarkHorizontal,   /*!< Rayure horizontale */
    psDarkVertical,     /*!< Rayure verticale */
    psDarkDown,         /*!< Rayure diagonale inverse */
    psDarkUp,           /*!< Rayure diagonale */
    psDarkGrid,         /*!< Hachure croisée diagonale */
    psDarkTrellis,      /*!< Hachure croisée diagonale épaisse */
    psLightHorizontal,  /*!< Rayure horizontale fine */
    psLightVertical,    /*!< Rayure verticale fine */
    psLightDown,        /*!< Rayure diagonale inverse fine */
    psLightUp,          /*!< Rayure diagonale fine */
    psLightGrid,        /*!< Hachure croisée diagonale fine */
    psLightTrellis      /*!< Hachure croisée diagonale épaisse fine */
} patternStyle_t;

/*!
 * \enum border_t
 * \brief Type de bordure.
 */
typedef enum {
    bLeft = 0,      /*!< Bordure gauche */
    bRight,         /*!< Bordure droite */
    bTop,           /*!< Bordure en haut */
    bBottom,        /*!< Bordure en bas */
    bDiagonalUp,    /*!< Bordure diagonale montante */
    bDiagonalDown   /*!< Bordure diagonale descendante */
} border_t;

/*!
 * \enum borderStyle_t
 * \brief Style de bordure.
 */
typedef enum {
    bsHair = 0,         /*!< En pointillé fin (points) */
    bsDotted,           /*!< En pointillé fin (points serrés) */
    bsDashDotDot,       /*!< En pointillé fin (tiret-point-point) */
    bsDashDot,          /*!< En pointillé fin (tiret-point) */
    bsDashed,           /*!< En pointillé fin (tiret) */
    bsThin,             /*!< Fin */
    bsMediumDashDotDot, /*!< En pointillé moyen (tiret-point-point) */
    bsSlantDashDot,     /*!< En pointillé moyen italic (tiret-point) */
    bsMediumDashDot,    /*!< En pointillé moyen (tiret-point) */
    bsMediumDashed,     /*!< En pointillé moyen (tiret) */
    bsMedium,           /*!< Moyen */
    bsThick,            /*!< Gros */
    bsDouble            /*!< Double */
} borderStyle_t;

/*!
 * \enum horizontalAlignment_t
 * \brief Type d'alignement horizontal.
 */
typedef enum {
    haAuto,     /*!< Automatique (en fonction du type de donnée de la cellule) */
    haLeft,     /*!< Gauche */
    haCenter,   /*!< Centré */
    haRight     /*!< Droite */
} horizontalAlignment_t;

/*!
 * \enum verticalAlignment_t
 * \brief Type d'alignement vertical.
 */
typedef enum {
    vaTop,      /*!< Haut */
    vaCenter,   /*!< Centré */
    vaBottom    /*!< Bas */
} verticalAlignment_t;

/*!
 * \typedef formatIdentifier_t
 * \brief Identifiant de format.
 */
typedef const void* formatIdentifier_t;

/*!
 * \typedef alertType_t
 * \brief Type de message d'alerte.
 */
typedef enum {
    atError,        /*!< Erreur */
    atWarning,      /*!< Avertissement */
    atInformation   /*!< Information */
} alertType_t;

/*!
 * \typedef valueList_t
 * \brief Liste de valeur.
 */
typedef std::vector<utf8SharedString_t> valueList_t;

/*!
 * \fn bool isDefinedNameValid(const utf8String_t& name)
 * \brief Savoir si un nom de zone est valide.
 * \param name Le nom de zone à vérifier.
 * \return Vrai si le nom est valide, faux sinon.
 *
 * exemple : "A1", "R1C4", "L32a", "C42b", "A B", "Zone d'impression" ne sont pas des noms de zone valides.
 */
bool isDefinedNameValid(const utf8String_t&);

/*!
 * \fn utf8String_t correctDefinedName(const utf8String_t& name)
 * \brief Corrige le nom de zone s'il n'est pas valide.
 * \param name Le nom de zone à vérifier.
 * \return Le nom corrigé.
 *
 * On ajoute "_" au début du nom si besoin ("A1" -> "_A1", "R1C4" -> "_R1C4", ...).
 * On remplace les caractères interdits par "_" ("A B" -> "A_B", "Zone d'impression" -> "Zone_d_impression", ...).
 */
utf8String_t correctDefinedName(const utf8String_t&);

/*!
 * \struct pixelRectangle_t
 * \brief Rectangle exprimé en pixel.
 */
typedef struct {
    unsigned int left;      /*!< Position à gauche en pixel */
    unsigned int top;       /*!< Position en haut en pixel */
    unsigned int width;     /*!< Largeur en pixel */
    unsigned int height;    /*!< Hauteur en pixel */
} pixelRectangle_t;

/*!
 * \typedef imageProperty_t
 * \brief Type de comportement de l'image par rapport à la grille.
 */
typedef enum {
    ipMoveAndResizeWithCells,   /*!< Déplacer et dimensionner avec les cellules */
    ipMoveWithCells,            /*!< Déplacer sans dimensionner avec les cellules */
    ipStatic                    /*!< Ne pas déplacer ou dimensionner avec les cellules */
} imageProperty_t;

/*!
 * \typedef imageType_t
 * \brief Type d'image.
 */
typedef enum {
    itJPG,      /*!< JPEG */
    itPNG,      /*!< PNG */
    itGIF,      /*!< GIF */
    itBMP,      /*!< Bitmap */
    itUnknown   /*!< Inconnu */
} imageType_t;

/*!
 * \fn std::string stringImageType(imageType_t type)
 * \brief Obtenir l'extension du fichier image de type "type".
 * \param type Le type de l'image.
 * \return L'extension du fichier.
 */
std::string stringImageType(imageType_t);

/*!
 * \fn bool getImageProperties(const unsigned char* const memory, const unsigned int memorySize, imageType_t& type, unsigned int& width, unsigned int& height)
 * \brief Obtenir la taille d'une image en pixel (JPEG, PNG, GIF ou BMP).
 * \param memory Le flux de l'image.
 * \param memorySize La taille du flux de l'image.
 * \param type Le type de l'image.
 * \param width La largeur de l'image en pixel.
 * \param height La hauteur de l'image en pixel.
 * \return Vrai si la taille a pu être lue, faux sinon.
 */
bool getImageProperties(const unsigned char* const, const unsigned int, imageType_t&, unsigned int&, unsigned int&);

/*!
 * \struct font_t
 * \brief Police de caractères.
 */
typedef struct {
    std::string name;   /*!< Nom */
    unsigned int size;  /*!< Taille (en pt) */
    color_t color;      /*!< Couleur */
    bool bold;          /*!< Gras ? */
    bool italic;        /*!< Italique ? */
    bool underline;     /*!< Souligné ? */
} font_t;

/*!
 * \fn bool operator ==(const font_t& font1, const font_t& font2)
 * \brief Opérateur d'égalité entre les polices de caractères.
 * \param font1 Une police de caractères.
 * \param font2 Une police de caractères.
 * \return Vrai si les deux polices sont égales, faux sinon.
 */
bool operator ==(const font_t&, const font_t&);

/*!
 * \typedef visibility_t
 * \brief Visibilité du commentaire.
 */
typedef enum {
    vHidden,    /*!< Caché */
    vVisible    /*!< Visible */
} visibility_t;

/*!
 * \typedef commentProperty_t
 * \brief Type de comportement de la boite de commentaire par rapport à la grille.
 */
typedef enum {
    cpMoveAndResizeWithCells,   /*!< Déplacer et dimensionner avec les cellules */
    cpMoveWithCells,            /*!< Déplacer sans dimensionner avec les cellules */
    cpStatic                    /*!< Ne pas déplacer ou dimensionner avec les cellules */
} commentProperty_t;

} // namespace Interface
} // namespace XLSX
} // namespace Invoke

#endif  /* invoke_xlsx_workbookInterface_hpp */
