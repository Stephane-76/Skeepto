/*!
 * \file        Coordinates.hpp
 * \author      Invoke - Jean-Christophe PHILIPPE (jcphilippe\@invoke.fr)
 * \date        Avril 2015
 * \copyright   SA Invoke
 */

#ifndef invoke_xlsx_coordinates_hpp
#define invoke_xlsx_coordinates_hpp

#include <string>
#include <vector>

namespace Invoke {
namespace XLSX {
namespace Coordinates {

/*!
 * \typedef utf8String_t
 * \brief Les chaînes de caractères unicodes sont encodées en UTF-8.
 */
typedef std::string utf8String_t;

class Cell;

/*!
 * \class WorksheetProxy
 * \brief Procuration d'une feuille de calcul.
 */
class WorksheetProxy {
public:
    /*!
     * \fn ~WorksheetProxy()
     * \brief Destructeur.
     */
    virtual ~WorksheetProxy() =0;

    /*!
     * \fn utf8String_t name() const
     * \brief Obtenir le nom de la feuille.
     * \return Le nom de la feuille.
     */
    /*!
     * \fn utf8String_t quotedName() const
     * \brief Obtenir le nom de la feuille (mis entre quotes si nécessaire pour les descriptions de coordonnées).
     * \return Le nom de la feuille.
     */
    virtual utf8String_t name() const =0;
    utf8String_t quotedName() const;

    /*!
     * \fn const Cell* activeCell() const
     * \brief Obtenir la cellule active selectionnée.
     * \return Les coordonnées de la cellule active selectionnée.
     */
    virtual const Cell* activeCell() const =0;
};

/*!
 * \class WorkbookProxy
 * \brief Procuration d'un classeur.
 */
class WorkbookProxy {
public:
    /*!
     * \fn ~WorkbookProxy()
     * \brief Destructeur.
     */
    virtual ~WorkbookProxy() =0;

    /*!
     * \fn const WorksheetProxy* selectedWorksheet() const
     * \brief Obtenir une procuration sur la feuille de calcul active.
     * \return Une procuration sur la feuille de calcul.
     */
    virtual const WorksheetProxy* selectedWorksheet() const =0;

    /*!
     * \fn const WorksheetProxy* worksheet(const utf8String_t& sheetName) const
     * \brief Obtenir une procuration sur une feuille de calcul précisée en paramètre.
     * \param sheetName Le nom de la feuille.
     * \return Une procuration sur la feuille de calcul, NULL si la feuille n'existe pas.
     */
    virtual const WorksheetProxy* worksheet(const utf8String_t&) const =0;
};

/*!
 * \class Index
 * \brief Définit une coordonnée ligne ou colonne ([0, ∞[).
 */
class Index {
public:
    /*!
     * \fn utf8String_t columnNameFromIndex(unsigned int index)
     * \brief Traduire un index de coordonnée en nom de colonne Excel (0 -> A, 1 -> B, ...)
     * \param index L'index de la coordonnée de colonne ([0, ∞[).
     * \return Le nom de la colonne.
     */
    static utf8String_t columnNameFromIndex(unsigned int);

public:
    /*!
     * \fn Index()
     * \brief Constructeur. DELETE.
     */
    /*!
     * \fn Index(const Index& coordinate)
     * \brief Constructeur de recopie.
     * \param coordinate Coordonnée à recopier.
     */
    /*!
     * \fn Index& operator =(const Index& coordinate)
     * \brief Opérateur de recopie.
     * \param coordinate Coordonnée à recopier.
     * \return Cet index.
     */
    Index() = delete;
    Index(const Index&) = default;
    Index& operator =(const Index&) = default;

    /*!
     * \fn Index(unsigned int index, bool locked)
     * \brief Constructeur.
     * \param index Index de la coordonnée ([0, ∞[).
     * \param locked La coordonnée est-elle bloquée ?
     */
    Index(unsigned int, bool =false);

    /*!
     * \fn unsigned int index() const
     * \brief Obtenir l'index de la coordonnée.
     * \return L'index de la coordonnée ([0, ∞[).
     */
    /*!
     * \fn bool isLocked() const
     * \brief La coordonnée est-elle bloquée ?
     * \return Vrai si la coordonnée est bloquée, faux sinon.
     */
    unsigned int index() const;
    bool isLocked() const;

    /*!
     * \fn bool operator ==(const Index& coordinate) const
     * \brief Opérateur d'égalité.
     * \param coordinate La coordonnée à comparer.
     * \return Vrai si les coordonées sont égales, faux sinon (ne prend pas en compte la propriété "locked").
     */
    /*!
     * \fn bool operator !=(const Index& coordinate) const
     * \brief Opérateur d'inégalité.
     * \param coordinate La coordonnée à comparer.
     * \return Vrai si les coordonées sont différentes, faux sinon (ne prend pas en compte la propriété "locked").
     */
    bool operator ==(const Index&) const;
    bool operator !=(const Index&) const;

    /*!
     * \enum indexType_t
     * \brief Type de coordonnée.
     */
    /*!
     * \fn utf8String_t name(const indexType_t type) const
     * \brief Obtenir le nom de la coordonée (un nombre si c'est une coordonnée ligne, une chaîne sinon).
     * \param type Le type de la coordonnée.
     * \return Le nom de la coordonnée.
     */
    typedef enum {
        itColumn,   /*!< Colonne */
        itRow       /*!< Ligne */
    } indexType_t;
    utf8String_t name(indexType_t) const;

private:
    unsigned int m_index;
    bool m_locked;
};

/*!
 * \class Cell
 * \brief Définit les coordonnées d'une cellule.
 */
class Cell {
public:
    /*!
     * \fn Cell()
     * \brief Constructeur. DELETE.
     */
    /*!
     * \fn Cell(const Cell& coordinates)
     * \brief Constructeur de recopie.
     * \param coordinates Coordonnées à recopier.
     */
    /*!
     * \fn Cell& operator =(const Cell& coordinates)
     * \brief Opérateur de recopie.
     * \param coordinates Coordonnées à recopier.
     * \return Cette cellule.
     */
    Cell() = delete;
    Cell(const Cell&) = default;
    Cell& operator =(const Cell&) = default;

    /*!
     * \fn Cell(const WorksheetProxy* worksheet, const Index& col, const Index& row)
     * \brief Constructeur.
     * \param worksheet La feuille de calcul.
     * \param col L'index de la colonne.
     * \param row L'index de la ligne.
     */
    /*!
     * \fn Cell(const WorksheetProxy* worksheet, unsigned int col, unsigned int row, bool locked)
     * \brief Constructeur.
     * \param worksheet La feuille de calcul.
     * \param col L'index de la colonne ([0, ∞[).
     * \param row L'index de la ligne ([0, ∞[).
     * \param locked Les coordonnées doivent-elles être blocquées ?
     */
    Cell(const WorksheetProxy*, const Index&, const Index&);
    Cell(const WorksheetProxy*, unsigned int, unsigned int, bool =false);

    /*!
     * \fn const WorksheetProxy* worksheet() const
     * \brief Obtenir la feuille de calcul référencée.
     * \return La feuille de calcul.
     */
    /*!
     * \fn const Index& columnIndex() const
     * \brief Obtenir la coordonnée de la colonne.
     * \return La coordonnée de la colonne.
     */
    /*!
     * \fn const Index& rowIndex() const
     * \brief Obtenir la coordonnée de la ligne.
     * \return La coordonnée de la ligne.
     */
    /*!
     * \fn unsigned int column() const
     * \brief Obtenir l'index de la colonne.
     * \return L'index de la colonne ([0, ∞[).
     */
    /*!
     * \fn unsigned int row() const
     * \brief Obtenir l'index de la ligne.
     * \return L'index de la ligne ([0, ∞[).
     */
    const WorksheetProxy* worksheet() const;
    const Index& columnIndex() const;
    const Index& rowIndex() const;
    unsigned int column() const;
    unsigned int row() const;

    /*!
     * \fn bool operator ==(const Cell& coordinates) const
     * \brief Opérateur d'égalité.
     * \param coordinates Coordonnées à comparer.
     * \return Vrai si les deux coordonnées sont identique (on ne tient pas compte de la propriété "locked"), faux sinon.
     */
    /*!
     * \fn bool operator !=(const Cell& coordinates) const
     * \brief Opérateur d'inégalité.
     * \param coordinates Coordonnées à comparer.
     * \return Vrai si les deux coordonnées sont différentes (on ne tient pas compte de la propriété "locked"), faux sinon.
     */
    bool operator ==(const Cell&) const;
    bool operator !=(const Cell&) const;

    /*!
     * \fn utf8String_t name(const WorksheetProxy* worksheet) const
     * \brief Obtenir le nom de la coordonnée (ex: "Feuil1!E$6").
     * \param worksheet La feuille de calcul sur laquelle on veut afficher les coordonnées.
     * \return Les coordonnées de la cellule en chaîne de caeratères.
     */
    utf8String_t name(const WorksheetProxy* =nullptr) const;

private:
    const WorksheetProxy* m_worksheet;
    Index m_column;
    Index m_row;
};

/*!
 * \class CellRange
 * \brief Définit les coordonnées d'une plage de cellules.
 */
class CellRange {
public:
    /*!
     * \fn CellRange()
     * \brief Constructeur. DELETE.
     */
    /*!
     * \fn CellRange(const CellRange& coordinates)
     * \brief Constructeur de recopie.
     * \param coordinates Coordonnées à recopier.
     */
    /*!
     * \fn CellRange& operator =(const CellRange& coordinates)
     * \brief Opérateur de recopie.
     * \param coordinates Coordonnées à recopier.
     * \return Cette plage de cellules.
     */
    CellRange() = delete;
    CellRange(const CellRange&) = default;
    CellRange(CellRange&&) = default;
    CellRange& operator =(const CellRange&) = default;
    CellRange& operator =(CellRange&&) = default;
    /*!
     * \fn CellRange(const WorksheetProxy* worksheet, const Index& left, const Index& top, const Index& right, const Index& bottom)
     * \brief Constructeur.
     * \param worksheet La feuille de calcul.
     * \param left La coordonée colonne de gauche.
     * \param top La coordonnée ligne du haut.
     * \param right La coordonnée colonne de droite.
     * \param bottom La coordonnée ligne du bas.
     */
    /*!
     * \fn CellRange(const WorksheetProxy* worksheet, unsigned int left, unsigned int top, unsigned int right, unsigned int bottom, bool locked)
     * \brief Constructeur.
     * \param worksheet La feuille de calcul.
     * \param left L'index de la colonne de gauche ([0, ∞[).
     * \param top L'index de la ligne du haut ([0, ∞[).
     * \param right L'index de la colonne de droite ([0, ∞[).
     * \param bottom L'index de la ligne du bas ([0, ∞[).
     * \param locked Les coordonnées doivent-elles être blocquées ?
     */
    CellRange(const WorksheetProxy*, const Index&, const Index&, const Index&, const Index&);
    CellRange(const WorksheetProxy*, unsigned int, unsigned int, unsigned int, unsigned int, bool =false);

    /*!
     * \fn const WorksheetProxy* worksheet() const
     * \brief Obtenir la feuille de calcul référencée.
     * \return La feuille de calcul.
     */
    /*!
     * \fn Cell topLeft() const
     * \brief Obtenir les coordonnées de la cellule "haut-gauche".
     * \return Les coordonnées de la cellule "haut-gauche".
     */
    /*!
     * \fn Cell rightBottom() const
     * \brief Obtenir les coordonnées de la cellule "bas-droite".
     * \return Les coordonnées de la cellule "bas-droite".
     */
    /*!
     * \fn const Index& leftIndex() const
     * \brief Obtenir la coordonnée de la colonne de gauche.
     * \return La coordonnée de la colonne gauche.
     */
    /*!
     * \fn const Index& topIndex() const
     * \brief Obtenir la coordonnée de la ligne du haut.
     * \return La coordonnée de la ligne du haut.
     */
    /*!
     * \fn const Index& rightIndex() const
     * \brief Obtenir la coordonnée de la colonne de droite.
     * \return La coordonnée de la colonne droite.
     */
    /*!
     * \fn const Index& bottomIndex() const
     * \brief Obtenir la coordonnée de la ligne du bas.
     * \return La coordonnée de la ligne du bas.
     */
    /*!
     * \fn unsigned int left() const
     * \brief Obtenir l'index de la colonne de gauche.
     * \return L'index de la colonne de gauche ([0, ∞[).
     */
    /*!
     * \fn unsigned int top() const
     * \brief Obtenir l'index de la ligne du haut.
     * \return L'index de la ligne du haut ([0, ∞[).
     */
    /*!
     * \fn unsigned int right() const
     * \brief Obtenir l'index de la colonne de droite.
     * \return L'index de la colonne de droite ([0, ∞[).
     */
    /*!
     * \fn unsigned int bottom() const
     * \brief Obtenir l'index de la ligne du bas.
     * \return L'index de la ligne du bas ([0, ∞[).
     */
    const WorksheetProxy* worksheet() const;
    Cell topLeft() const;
    Cell rightBottom() const;
    const Index& leftIndex() const;
    const Index& topIndex() const;
    const Index& rightIndex() const;
    const Index& bottomIndex() const;
    unsigned int left() const;
    unsigned int top() const;
    unsigned int right() const;
    unsigned int bottom() const;

    /*!
     * \fn bool isCell() const
     * \brief La plage de cellule ne contient-elle qu'une cellule ?
     * \return Vrai si la plage contient qu'une seule cellule, faux sinon.
     */
    bool isCell() const;

    /*!
     * \fn bool intersectWith(const CellRange& range) const
     * \brief La plage de cellule est elle en intersection avec la plage passée en paramètre ?
     * \param range La plage de cellules à comparer.
     * \return Vrai si la plage est en intersection avec la plage de cellules passée en paramètre, faux sinon.
     */
    /*!
     * \fn bool getIntersection(const CellRange& range, CellRange*& intersection) const
     * \brief Obtenir l'intersection de la plage de cellule avec la plage passée en paramètre si elle existe.
     * \param range La plage de cellules à comparer.
     * \param intersection L'intersection des deux plages de cellules.
     * \return Vrai si la plage est en intersection avec la plage de cellules passée en paramètre, faux sinon.
     */
    bool intersectWith(const CellRange&) const;
    bool getIntersection(const CellRange&, CellRange*&) const;

    /*!
     * \fn bool unionWith(const CellRange& range) const
     * \brief La plage de cellule est elle en union avec la plage passée en paramètre ?
     * \param range La plage de cellules à comparer.
     * \return Vrai si une union existe avec la plage de cellules passée en paramètre, faux sinon.
     */
    /*!
     * \fn bool getUnion(const CellRange& range, CellRange*& union) const
     * \brief Obtenir l'union de la plage de cellule avec la plage passée en paramètre si elle existe.
     * \param range La plage de cellules à comparer.
     * \param union L'union des deux plages de cellules.
     * \return Vrai si une union existe, faux sinon.
     */
    bool unionWith(const CellRange&) const;
    bool getUnion(const CellRange&, CellRange*&) const;

    /*!
     * \fn bool operator ==(const CellRange& coordinates) const
     * \brief Opérateur d'égalité.
     * \param coordinates Coordonnées de plage à comparer.
     * \return Vrai si les coordonnées sont égales (les propriétés "locked" ne sont pas prises en compte), faux sinon.
     */
    /*!
     * \fn bool operator !=(const CellRange& coordinates) const
     * \brief Opérateur d'inégalité.
     * \param coordinates Coordonnées de plage à comparer.
     * \return Vrai si les coordonnées sont différentes (les propriétés "locked" ne sont pas prises en compte), faux sinon.
     */
    bool operator ==(const CellRange&) const;
    bool operator !=(const CellRange&) const;

    /*!
     * \fn utf8String_t name(const WorksheetProxy* worksheet) const
     * \brief Obtenir le nom de la plage de cellules (ex: Feuil1!A6:$C10).
     * \param worksheet La feuille de calcul où doit être affiché le nom de la plage de cellules.
     * \return Le nom de la plage de cellules.
     */
    utf8String_t name(const WorksheetProxy* =nullptr) const;

private:
    const WorksheetProxy* m_worksheet;
    Index m_left;
    Index m_top;
    Index m_right;
    Index m_bottom;
};

/*!
 * \class ColumnRow
 * \brief Définit une colonne ou une ligne.
 */
class ColumnRow {
public:
    /*!
     * \fn ColumnRow()
     * \brief Constructeur. DELETE.
     */
    /*!
     * \fn ColumnRow(const ColumnRow& coordinates)
     * \brief Constructeur de recopie.
     * \param coordinates Coordonnées à recopier.
     */
    /*!
     * \fn ColumnRow& operator =(const ColumnRow& coordinates)
     * \brief Opérateur de recopie.
     * \param coordinates Coordonnées à recopier.
     * \return Cette ligne ou colonne.
     */
    ColumnRow() = delete;
    ColumnRow(const ColumnRow&) = default;
    ColumnRow& operator =(const ColumnRow&) = default;

    /*!
     * \fn ColumnRow(Index::indexType_t type, const WorksheetProxy* worksheet, const Index& index)
     * \brief Constructeur.
     * \param type Le type de la coordonnée (colonne ou ligne).
     * \param worksheet La feuille de calcul.
     * \param index La coordonée.
     */
    /*!
     * \fn ColumnRow(Index::indexType_t type, const WorksheetProxy* worksheet, unsigned int index, bool locked)
     * \brief Constructeur.
     * \param type Le type de la coordonnée (colonne ou ligne).
     * \param worksheet La feuille de calcul.
     * \param index La coordonée.
     * \param locked La coordonée doit-elle être blocquée ?
     */
    ColumnRow(Index::indexType_t, const WorksheetProxy*, const Index&);
    ColumnRow(Index::indexType_t, const WorksheetProxy*, unsigned int, bool =false);

    /*!
     * \fn Index::indexType_t type() const
     * \brief Obtenir le type de la coordonnée.
     * \return Le type (colonne ou ligne) de la coordonnée.
     */
    /*!
     * \fn const WorksheetProxy* worksheet() const
     * \brief Obtenir la feuille de calcul référencée.
     * \return La feuille de calcul.
     */
    /*!
     * \fn const Index& index() const
     * \brief Obtenir la coordonnée de la colonne ou ligne.
     * \return La coordonnée de la colonne ou ligne.
     */
    Index::indexType_t type() const;
    const WorksheetProxy* worksheet() const;
    const Index& index() const;

    /*!
     * \fn bool operator ==(const ColumnRow& coordinates) const
     * \brief Opérateur d'égalité.
     * \param coordinates Coordonnées à comparer.
     * \return Vrai si les coordonnées sont égales (les propriétés "locked" ne sont pas prises en compte), faux sinon.
     */
    /*!
     * \fn bool operator !=(const ColumnRow& coordinates) const
     * \brief Opérateur d'inégalité.
     * \param coordinates Coordonnées à comparer.
     * \return Vrai si les coordonnées sont différentes (les propriétés "locked" ne sont pas prises en compte), faux sinon.
     */
    bool operator ==(const ColumnRow&) const;
    bool operator !=(const ColumnRow&) const;

    /*!
     * \fn utf8String_t name(const WorksheetProxy* worksheet) const
     * \brief Obtenir le nom de la colone ou ligne (ex: Feuil1!$F).
     * \param worksheet La feuille de calcul où doit être affiché le nom de la colonne ou ligne.
     * \return Le nom de la colonne ou ligne.
     */
    utf8String_t name(const WorksheetProxy* =nullptr) const;

private:
    Index::indexType_t m_type;
    const WorksheetProxy* m_worksheet;
    Index m_index;
};

/*!
 * \class ColumnRowRange
 * \brief Définit une plage de colonnes ou de lignes.
 */
class ColumnRowRange {
public:
    /*!
     * \fn ColumnRowRange()
     * \brief Constructeur. DELETE.
     */
    /*!
     * \fn ColumnRowRange(const ColumnRowRange& coordinates)
     * \brief Constructeur de recopie.
     * \param coordinates Coordonnées à recopier.
     */
    /*!
     * \fn ColumnRowRange& operator =(const ColumnRowRange& coordinates)
     * \brief Opérateur de recopie.
     * \param coordinates Coordonnées à recopier.
     * \return Cette plage de colonnes ou de lignes.
     */
    ColumnRowRange() = delete;
    ColumnRowRange(const ColumnRowRange&) = default;
    ColumnRowRange& operator =(const ColumnRowRange&) = default;

    /*!
     * \fn ColumnRowRange(Index::indexType_t type, const WorksheetProxy* worksheet, const Index& first, const Index& last)
     * \brief Constructeur.
     * \param type Type d'index.
     * \param worksheet La feuille de calcul.
     * \param first La première coordonée.
     * \param last La dernière coordonnée.
     */
    /*!
     * \fn ColumnRowRange(Index::indexType_t type, const WorksheetProxy* worksheet, unsigned int first, unsigned int last, bool locked)
     * \brief Constructeur.
     * \param type Type d'index.
     * \param worksheet La feuille de calcul.
     * \param first L'index de la première coordonnée ([0, ∞[).
     * \param last L'index de la dernière coordonnée ([0, ∞[).
     * \param locked Les coordonnées doivent-elles être blocquées ?
     */
    ColumnRowRange(Index::indexType_t, const WorksheetProxy*, const Index&, const Index&);
    ColumnRowRange(Index::indexType_t, const WorksheetProxy*, unsigned int, unsigned int, bool =false);

    /*!
     * \fn Index::indexType_t type() const
     * \brief Obtenir le type de coordonnées.
     * \return Le type de coordonnées.
     */
    /*!
     * \fn const WorksheetProxy* worksheet() const
     * \brief Obtenir la feuille de calcul référencée.
     * \return La feuille de calcul.
     */
    /*!
     * \fn const Index& firstIndex() const
     * \brief Obtenir la coordonnée de la première ligne ou colonne.
     * \return La coordonnée de la première ligne ou colonne.
     */
    /*!
     * \fn const Index& lastIndex() const
     * \brief Obtenir la coordonnée de la dernière ligne ou colonne.
     * \return La coordonnée de la dernière ligne ou colonne.
     */
    /*!
     * \fn unsigned int first() const
     * \brief Obtenir l'index de la première ligne ou colonne.
     * \return L'index de la première ligne ou colonne ([0, ∞[).
     */
    /*!
     * \fn unsigned int last() const
     * \brief Obtenir l'index de la dernière ligne ou colonne.
     * \return L'index de la dernière ligne ou colonne ([0, ∞[).
     */
    Index::indexType_t type() const;
    const WorksheetProxy* worksheet() const;
    const Index& firstIndex() const;
    const Index& lastIndex() const;
    unsigned int first() const;
    unsigned int last() const;

    /*!
     * \fn bool isColumRow() const
     * \brief La plage de colonnes ou lignes ne contient-elle qu'une cellule ?
     * \return Vrai si la plage contient qu'une seule colonne ou ligne, faux sinon.
     */
    bool isColumRow() const;

    /*!
     * \fn bool operator ==(const ColumnRowRange& coordinates) const
     * \brief Opérateur d'égalité.
     * \param coordinates Coordonnées de plage à comparer.
     * \return Vrai si les coordonnées sont égales (les propriétés "locked" ne sont pas prises en compte), faux sinon.
     */
    /*!
     * \fn bool operator !=(const ColumnRowRange& coordinates) const
     * \brief Opérateur d'inégalité.
     * \param coordinates Coordonnées de plage à comparer.
     * \return Vrai si les coordonnées sont différentes (les propriétés "locked" ne sont pas prises en compte), faux sinon.
     */
    bool operator ==(const ColumnRowRange&) const;
    bool operator !=(const ColumnRowRange&) const;

    /*!
     * \fn utf8String_t name(const WorksheetProxy* worksheet) const
     * \brief Obtenir le nom de la plage de colonnes ou lignes (ex: Feuil1!A:$C).
     * \param worksheet La feuille de calcul où doit être affiché le nom de la plage de cellules.
     * \return Le nom de la plage de cellules.
     */
    utf8String_t name(const WorksheetProxy* =nullptr) const;

private:
    Index::indexType_t m_type;
    const WorksheetProxy* m_worksheet;
    Index m_first;
    Index m_last;
};

/*!
 * \class MultiCellRange
 * \brief Définit une série de plage de cellules.
 */
class MultiCellRange {
public:
    /*!
     * \fn MultiCellRange()
     * \brief Constructeur.
     */
    /*!
     * \fn MultiCellRange(const MultiCellRange& coordinates)
     * \brief Constructeur de recopie.
     * \param coordinates Coordonnées à copier.
     */
    /*!
     * \fn MultiCellRange& operator =(const MultiCellRange& coordinates)
     * \brief Opérateur de recopie.
     * \param coordinates Coordonnées à copier.
     * \return Cette série plage de cellules.
     */
    MultiCellRange() = default;
    MultiCellRange(const MultiCellRange&);
    MultiCellRange& operator =(const MultiCellRange&);

    /*!
     * \fn ~MultiCellRange()
     * \brief Destructeur.
     */
    virtual ~MultiCellRange();

    /*!
     * \fn bool addRange(const Cell& coordinate)
     * \brief Ajouter une coordonée de cellule.
     * \param coordinate Coordonnée à ajouter.
     * \return Vrai si la coordonnée a bien été ajoutée, faux sinon (coordonnée déjà présente).
     */
    /*!
     * \fn bool addRange(const CellRange& coordinates)
     * \brief Ajouter une plage de cellules.
     * \param coordinates Coordonnées à ajouter.
     * \return Vrai si les coordonnées ont bien été ajoutées, faux sinon (coordonnées déjà présentes).
     */
    /*!
     * \fn unsigned int addRange(const MultiCellRange& coordinates)
     * \brief Ajouter une série de coordonnées de plage de cellules.
     * \param coordinates Série de coordonées à ajouter.
     * \return Le nombre de coordonnées de plage de cellules effetivement ajoutées.
     */
    bool addRange(const Cell&);
    bool addRange(const CellRange&);
    unsigned int addRange(const MultiCellRange&);

    /*!
     * \fn size_t rangeCount() const
     * \brief Obtenir le nombre de plages de cellules.
     * \return Le nombre de plages de cellules contenues dans cette instance.
     */
    /*!
     * \fn const CellRange* range(size_t index) const
     * \brief Obtenir une plage de cellules.
     * \param index L'index de la plage de cellules demandée (entre 0 et rangeCount()).
     * \return La coordonnée demandée, NULL si l'index est erroné.
     */
    size_t rangeCount() const;
    const CellRange* range(size_t) const;

    /*!
     * \fn bool operator ==(const MultiCellRange& coordinates) const
     * \brief Opérateur d'égalité.
     * \param coordinates Coordonnées de plage à comparer.
     * \return Vrai si les coordonnées sont égales (les propriétés "locked" ne sont pas prises en compte), faux sinon.
     */
    /*!
     * \fn bool operator !=(const MultiCellRange& coordinates) const
     * \brief Opérateur d'inégalité.
     * \param coordinates Coordonnées de plage à comparer.
     * \return Vrai si les coordonnées sont différentes (les propriétés "locked" ne sont pas prises en compte), faux sinon.
     */
    bool operator ==(const MultiCellRange&) const;
    bool operator !=(const MultiCellRange&) const;

    /*!
     * \fn bool isEqual(const MultiCellRange& coordinates) const
     * \brief Les plages de cellules recouvrent-elles les mêmes surface ?
     * \param coordinates Coordonnées de plage à comparer.
     * \return Vrai si les coordonnées sont identiques (les propriétés "locked" ne sont pas prises en compte), faux sinon.
     */
    bool isEqual(const MultiCellRange&) const;

    /*!
     * \fn bool isContaining(const Cell& cell) const
     * \brief La plage de cellules contient-elle la cellule ?
     * \param cell La cellule de référence.
     * \return Vrai si la cellule est contenue dans la plage de cellule, faux sinon.
     */
    bool isContaining(const Cell&) const;

    /*!
     * \fn void reduce()
     * \brief Resuit le nombre de plages de cellules en fusionnant celles qui sont contigües.
     */
    void reduce();

    /*!
     * \fn utf8String_t name(const WorksheetProxy* worksheet, char32_t separator) const
     * \brief Obtenir le nom de la série plages de cellules (ex: Feuil1!B8:F11,Feuil2!C4).
     * \param worksheet La feuille de calcul où doit être affiché le nom de la série de plages de cellules.
     * \param separator La chaîne de caractères de séparation des plages.
     * \return Le nom de la série de plages de cellules (ex: Feuil1!B8:F11,Feuil2!C4).
     */
    utf8String_t name(const WorksheetProxy* p_worksheet = nullptr, char32_t = ',') const;

private:
    typedef std::vector<const CellRange*> ranges_t;
    ranges_t m_ranges;
};

/*!
 * \class MultiColumnRowRange
 * \brief Définit une série de plages de colonnes ou de lignes.
 */
class MultiColumnRowRange {
public:
    /*!
     * \fn MultiColumnRowRange()
     * \brief Constructeur. DELETE.
     */
    /*!
     * \fn MultiColumnRowRange(const MultiColumnRowRange& coordinates)
     * \brief Constructeur de recopie.
     * \param coordinates Coordonnées à copier.
     */
    /*!
     * \fn MultiColumnRowRange& operator =(const MultiColumnRowRange& coordinates)
     * \brief Opérateur de recopie.
     * \param coordinates Coordonnées à copier.
     * \return Cette série de plages de colonnes ou de lignes.
     */
    MultiColumnRowRange() = delete;
    MultiColumnRowRange(const MultiColumnRowRange&);
    MultiColumnRowRange& operator =(const MultiColumnRowRange&);

    /*!
     * \fn MultiColumnRowRange(Index::indexType_t type)
     * \brief Constructeur.
     * \param type Type Colonne ou ligne.
     */
    MultiColumnRowRange(Index::indexType_t);

    /*!
     * \fn ~MultiColumnRowRange()
     * \brief Destructeur.
     */
    virtual ~MultiColumnRowRange();

    /*!
     * \fn Index::indexType_t type() const
     * \brief Obtenir le type coordonnées.
     * \return Le type de coordonnées.
     */
    Index::indexType_t type() const;

    /*!
     * \fn bool addRange(const ColumnRow& coordinate)
     * \brief Ajouter une coordonée de colonne ou ligne.
     * \param coordinate Coordonnée à ajouter.
     * \return Vrai si la coordonnée a bien été ajoutée, faux sinon (coordonnée déjà présente).
     */
    /*!
     * \fn bool addRange(const ColumnRowRange& coordinate)
     * \brief Ajouter une coordonée de plage de colonnes ou lignes.
     * \param coordinate Coordonnée à ajouter.
     * \return Vrai si la coordonnée a bien été ajoutée, faux sinon (coordonnée déjà présente ou type incorrect).
     */
    /*!
     * \fn unsigned int addRange(const MultiColumnRowRange& coordinates)
     * \brief Ajouter une série de plages de colonnes ou lignes.
     * \param coordinates Série de coordonées à ajouter.
     * \return Le nombre de plages de colonnes ou lignes effetivement ajoutées.
     */
    bool addRange(const ColumnRow&);
    bool addRange(const ColumnRowRange&);
    unsigned int addRange(const MultiColumnRowRange&);

    /*!
     * \fn size_t rangeCount() const
     * \brief Obtenir le nombre de plages de colonnes ou lignes.
     * \return Le nombre de plages de colonnes ou lignes contenues dans cette instance.
     */
    /*!
     * \fn const ColumnRowRange* range(size_t index) const
     * \brief Obtenir une plage de colonnes ou lignes.
     * \param index L'index de la plage de colonnes ou lignes demandée (entre 0 et rangeCount()).
     * \return La coordonnée demandée, NULL si l'index est erroné.
     */
    size_t rangeCount() const;
    const ColumnRowRange* range(size_t) const;

    /*!
     * \fn utf8String_t name(const WorksheetProxy* worksheet, char32_t separator) const
     * \brief Obtenir le nom de la série de plages de colonnes ou lignes (ex: Feuil1!B8:F11,Feuil2!C4).
     * \param worksheet La feuille de calcul où doit être affiché le nom de la série de plages de colonnes ou lignes.
     * \param separator La chaîne de caractères de séparation des plages.
     * \return Le nom de la série plages de colonnes ou lignes (ex: Feuil1!B:F,Feuil2!C).
     */
    utf8String_t name(const WorksheetProxy* p_worksheet = nullptr, char32_t = ',') const;

private:
    const Index::indexType_t m_type;

    typedef std::vector<const ColumnRowRange*> ranges_t;
    ranges_t m_ranges;
};

/*!
 * \class CellPoint
 * \brief Définit un point dans une cellule.
 */
class CellPoint {
public:
    /*!
     * \fn CellPoint()
     * \brief Constructeur. DELETE.
     */
    /*!
     * \fn CellPoint(const CellPoint& point)
     * \brief Constructeur de recopie.
     * \param point Point à recopier.
     */
    /*!
     * \fn CellPoint& operator =(const CellPoint& point)
     * \brief Opérateur de recopie.
     * \param point Point à recopier.
     * \return Ce point.
     */
    CellPoint() = delete;
    CellPoint(const CellPoint&) = default;
    CellPoint& operator =(const CellPoint&) = default;

    /*!
     * \fn CellPoint(const Cell& cell, unsigned long offsetX, unsigned long offsetY)
     * \brief Constructeur.
     * \param cell La cellule.
     * \param offsetX Le point X dans la cellule en EMU.
     * \param offsetY Le point Y dans la cellule en EMU.
     */
    /*!
     * \fn CellPoint(const WorksheetProxy* worksheet, unsigned int column, unsigned int row, unsigned long offsetX, unsigned long offsetY)
     * \brief Constructeur.
     * \param worksheet La feuille de calcul.
     * \param column L'index de la colonne ([0, ∞[).
     * \param row L'index de la ligne ([0, ∞[).
     * \param offsetX La coordonée X du point dans la cellule en EMU.
     * \param offsetY La coordonée Y du point dans la cellule en EMU.
     */
    CellPoint(const Cell&, unsigned long, unsigned long);
    CellPoint(const WorksheetProxy*, unsigned int, unsigned int, unsigned long, unsigned long);

    /*!
     * \fn const WorksheetProxy* worksheet() const
     * \brief Obtenir la feuille de calcul référencée.
     * \return La feuille de calcul.
     */
    /*!
     * \fn unsigned int column() const
     * \brief Obtenir l'index de la colonne.
     * \return L'index de la colonne ([0, ∞[).
     */
    /*!
     * \fn unsigned int row() const
     * \brief Obtenir l'index de la ligne.
     * \return L'index de la ligne ([0, ∞[).
     */
    /*!
     * \fn unsigned long offsetX() const
     * \brief Obtenir l'offset X du point dans la cellule.
     * \return L'offset X du point dans la cellule en EMU.
     */
    /*!
     * \fn unsigned long offsetY() const
     * \brief Obtenir l'offset Y du point dans la cellule.
     * \return L'offset Y du point dans la cellule en EMU.
     */
    const WorksheetProxy* worksheet() const;
    unsigned int column() const;
    unsigned int row() const;
    unsigned long offsetX() const;
    unsigned long offsetY() const;

    /*!
     * \fn long pixelToEMU(int pixel)
     * \brief Convertir une mesure en pixel en EMU (1 EMU = 914400 / 96 px).
     * \param pixel La mesure en pixel.
     * \return La mesure en EMU.
     */
    /*!
     * \fn int EMUToPixel(long emu)
     * \brief Convertir une mesure en EMU en pixel (1 EMU = 914400 / 96 px).
     * \param emu La mesure en EMU.
     * \return La mesure en pixel.
     */
    static long pixelToEMU(int);
    static int EMUToPixel(long);

private:
    const WorksheetProxy* m_worksheet;
    unsigned int m_column;
    unsigned int m_row;
    unsigned long m_offsetX;
    unsigned long m_offsetY;
};

/*!
* \class Parser
* \brief Interpréteur de coordonnées.
*/
class Parser {
public:
    /*!
     * \fn Parser()
     * \brief Constructeur. DELETE.
     */
    /*!
     * \fn Parser(const Parser& parser)
     * \brief Constructeur de recopie. DELETE.
     * \param parser le parser à recopier.
     */
    /*!
     * \fn Parser& operator =(const Parser& parser)
     * \brief Opérateur de recopie. DELETE.
     * \param parser le parser à recopier.
     * \return Ce parser.
     */
    Parser() = delete;
    Parser(const Parser&) = delete;
    Parser& operator =(const Parser&) = delete;

    /*!
     * \fn Parser(const utf8String_t& coordinates, const WorkbookProxy* proxy, char32_t separator)
     * \brief Constructeur.
     * \param coordinates La chaîne de caractères unicode à interpréter.
     * \param proxy Un proxy sur un workbook.
     * \param separator Le séparateur des plages de cellules dans la chaîne de caractères.
     */
    Parser(const utf8String_t&, const WorkbookProxy*, char32_t = ',');

    /*!
     * \fn ~Parser()
     * \brief Destructeur.
     */
    ~Parser();

    /*!
     * \fn bool parseResult() const
     * \brief Obtenir le résultat de l'interprétation de la chaîne de caractères.
     * \return Vrai si la chaîne est syntaxiquement correcte, faux sinon.
     */
    bool parseResult() const;

    /*!
     * \enum warnings_t
     * \brief Enumération des avertissements possibles.
     */
    /*!
     * \fn unsigned char warnings() const
     * \brief Obtenir les avertissements générés par l'interpréteur.
     * \return Un champs de bits contenant les avertissements.
     */
    typedef enum {
        wWorkbookUnknown = 1,   /*!< Le parseur n'a pas eu de référence sur le proxy workbook */
        wSheetNameUnknown = 2,  /*!< Le nom d'une feuille n'existe pas */
        wInvalidResult = 4,     /*!< Le résultat est invalide (ex: cellule sélectionnée = B2, coordonnées à parser = L(-3)C2) */
        wIncompleteParse = 8    /*!< Un résultat valide a été trouvé mais la chaîne n'a pas complétement été lue */
    } warnings_t;
    unsigned char warnings() const;

    /*!
     * \fn unsigned int readCharacters() const
     * \brief Obtenir le nombre de caractères unicode lus.
     * \return Le nombre de caractères unicode lus.
     */
    unsigned int readCharacters() const;

    /*!
     * \enum coordType_t
     * \brief Types de coordonnées possibles.
     */
    /*!
     * \fn coordType_t type() const
     * \brief Obtenir le type de coordonnées trouvées.
     * \return Le type de coordonnées trouvées.
     */
    typedef enum {
        ctNull,                 /*!< Rien */
        ctCell,                 /*!< Une cellule */
        ctCellRange,            /*!< Une place de cellules */
        ctMultiCellRange,       /*!< Une série de plages de cellules */
        ctColumnRow,            /*!< Une colonnes ou une lignes */
        ctColumnRowRange,       /*!< Une plage de colonnes ou de lignes */
        ctMultiColumnRowRange   /*!< Une série de plage de colonnes ou de lignes */
    } coordType_t;
    coordType_t type() const;

    /*!
     * \fn const Cell* cell() const
     * \brief Obtenir la coordonnée cellule.
     * \return La coordonnée de cellule interprétée, NULL sinon.
     */
    /*!
     * \fn const CellRange* cellRange() const
     * \brief Obtenir la plage de cellules.
     * \return La plage de cellules interprétée, NULL sinon.
     */
    /*!
     * \fn const MultiCellRange* multiCellRange() const
     * \brief Obtenir les plages de cellules.
     * \return Les plages de cellules interprétées, NULL sinon.
     */
    /*!
     * \fn const ColumnRow* columnRow() const
     * \brief Obtenir la colonne ou la ligne.
     * \return La colonne ou la ligne interprétée, NULL sinon.
     */
    /*!
     * \fn const ColumnRowRange* columnRowRange() const
     * \brief Obtenir la plage de colonnes ou de lignes.
     * \return La plage de colonnes ou de lignes interprétée, NULL sinon.
     */
    /*!
     * \fn const MultiColumnRowRange* multiColumnRowRange() const
     * \brief Obtenir les plages de colonnes ou de lignes.
     * \return Les plages de colonnes ou de lignes interprétées, NULL sinon.
     */
    const Cell* cell() const;
    const CellRange* cellRange() const;
    const MultiCellRange* multiCellRange() const;
    const ColumnRow* columnRow() const;
    const ColumnRowRange* columnRowRange() const;
    const MultiColumnRowRange* multiColumnRowRange() const;

private:
    bool m_parseResult;
    unsigned char m_warnings;
    unsigned int m_read;

    coordType_t m_type;
    void* m_coordinates;
};

} // namespace Coordinates
} // namespace XLSX
} // namespace Invoke

#endif  /* invoke_xlsx_coordinates_hpp */
