/*!
 * \file        WorkbookReadInterface.hpp
 * \author      Invoke - Jean-Christophe PHILIPPE (jcphilippe\@invoke.fr)
 * \date        Juin 2015
 * \copyright   SA Invoke
 */

#ifndef invoke_xlsx_workbookReadInterface_hpp
#define invoke_xlsx_workbookReadInterface_hpp

#include "xlsx/WorkbookInterface.hpp"
#include "xlsx/Coordinates.hpp"

namespace Invoke {
namespace XLSX {
namespace Interface {
namespace Read {

/*!
 * \class RichText
 * \brief Définit un texte riche.
 */
class RichText {
public:
	/*!
	 * \fn ~RichText()
	 * \brief Destructeur.
	 */
	virtual ~RichText() =0;

	/*!
	 * \fn size_t runCount() const
	 * \brief Obtenir le nombre de la portion de texte.
	 * \return Le nombre de portion de texte.
	 */
	/*!
	 * \fn const font_t* runFont(size_t index) const
	 * \brief Obtenir la police de caractères de la portion de texte.
	 * \param index L'index de la portion de texte ciblée (index doit être compris entre 0 et runCount() - 1).
	 * \return La police de caractères de la portion de texte à l'index "index".
	 */
	/*!
	 * \fn const utf8String_t* runText(size_t index) const
	 * \brief Obtenir le texte de la portion de texte.
	 * \param index L'index de la portion de texte ciblée (index doit être compris entre 0 et runCount() - 1).
	 * \return Le texte de la portion de texte à l'index "index".
	 */
	virtual size_t runCount() const =0;
	virtual const font_t* runFont(size_t) const =0;
	virtual const utf8String_t* runText(size_t) const =0;

	/*!
	 * \fn utf8String_t text() const
	 * \brief Obtenir le texte complet.
	 * \return Le texte.
	 */
	virtual utf8String_t text() const =0;

    /*!
     * \fn bool operator ==(const RichText* value) const
     * \brief Opérateur de comparaison.
     * \param value La valeur à comparer.
     * \return Vrai si la valeur est la même, faux sinon.
     */
    /*!
     * \fn bool operator <(const RichText* value) const
     * \brief Opérateur de comparaison.
     * \param value La valeur à comparer.
     * \return Vrai si la valeur texte est avant dans l'ordre alphabétique, faux sinon.
     */
    bool operator ==(const RichText*) const;
    bool operator <(const RichText*) const;
};

/*!
 * \class CellValue
 * \brief Définit la valeur d'une cellule.
 */
class CellValue {
public:
    /*!
     * \fn ~CellValue()
     * \brief Destructeur.
     */
    virtual ~CellValue() =0;

    /*!
     * \fn cellType_t type() const
     * \brief Obtenir le type de cellule.
     * \return Le type de cellule.
     */
    /*!
     * \fn bool boolean() const
     * \brief Obtenir la valeur booléenne de la cellule.
     * \return La valeur booléenne.
     */
    /*!
     * \fn double number() const
     * \brief Obtenir la valeur numérique de la cellule.
     * \return La valeur numérique.
     */
    /*!
     * \fn utf8String_t string() const
     * \brief Obtenir la valeur chaîne de la cellule.
     * \return La valeur chaîne.
     */
    /*!
     * \fn cellError_t error() const
     * \brief Obtenir le type d'erreur de la cellule.
     * \return Le type de l'erreur.
     */
    /*!
     * \fn utf8String_t formula() const
     * \brief Obtenir la formule de calcul de la cellule (au format "natif" d'Excel).
     * \return La formule de calcul.
     */
    virtual cellType_t type() const =0;
    virtual bool boolean() const =0;
    virtual double number() const =0;
    virtual utf8String_t string() const =0;
    virtual cellError_t error() const =0;
    virtual utf8String_t formula() const =0;

	/*!
	 * \fn const RichText* text() const 
	 * \brief Obtenir le texte contenu dans la cellule.
	 * \return Le texte.
	 */
	virtual const RichText* text() const =0;

    /*!
     * \fn bool operator ==(const CellValue* value) const
     * \brief Opérateur de comparaison.
     * \param value La valeur à comparer.
     * \return Vrai si la valeur est la même, faux sinon.
     */
    /*!
     * \fn bool operator <(const CellValue* value) const
     * \brief Opérateur de comparaison.
     * \param value La valeur à comparer.
     * \return Vrai si la valeur est inférieure, faux sinon.
     */
    bool operator ==(const CellValue*) const;
    bool operator <(const CellValue*) const;
};

/*!
 * \class DefinedName
 * \brief Définit un nom de zone
 */
class DefinedName {
public:
    /*!
     * \fn ~DefinedName()
     * \brief Destructeur.
     */
    virtual ~DefinedName() =0;

    /*!
     * \fn utf8String_t name() const
     * \brief Obtenir le nom de la zone.
     * \return Le nom de la zone.
     */
    virtual utf8String_t name() const =0;

    /*!
     * \fn const Coordinates::MultiCellRange& zone() const
     * \brief Obtenir les coordonnées de la zone.
     * \return Les coordonnées de la zone.
     */
    virtual const Coordinates::MultiCellRange& zone() const =0;
};

/*!
 * \class PageHeaderFooter
 * \brief Description des entêtes et pieds de page.
 */
class PageHeaderFooter {
public:
    /*!
     * \fn ~PageHeaderFooter()
     * \brief Destructeur.
     */
    virtual ~PageHeaderFooter() =0;

    /*!
     * \fn bool isDifferentFirst() const
     * \brief L'entête et pied de page de la première page sont ils différents des pages suivantes ?
     * \return Vrai si l'entête et le pied de page de la première page sont différents, faux sinon.
     */
    /*!
     * \fn bool isDifferentOddEven() const
     * \brief Les entêtes et pieds de page des pages paires et impaires sont ils différents ?
     * \return Vrai si les entêtes et les pieds de pages des pages paires sont différents des pages impaires, faux sinon.
     */
    virtual bool isDifferentFirst() const =0;
    virtual bool isDifferentOddEven() const =0;

    /*!
     * \fn const utf8String_t* leftFirstHeader() const
     * \brief Obtenir le texte à gauche dans l'entête de la première page.
     * \return Le texte à gauche dans l'entête de la première page, NULL si l'entête de la première page est identique aux autres.
     */
    /*!
     * \fn const utf8String_t* centerFirstHeader() const
     * \brief Obtenir le texte au centre dans l'entête de la première page.
     * \return Le texte au centre dans l'entête de la première page, NULL si l'entête de la première page est identique aux autres.
     */
    /*!
     * \fn const utf8String_t* rightFirstHeader() const
     * \brief Obtenir le texte à droite dans l'entête de la première page.
     * \return Le texte à droite dans l'entête de la première page, NULL si l'entête de la première page est identique aux autres.
     */
    /*!
     * \fn const utf8String_t* leftFirstFooter() const
     * \brief Obtenir le texte à gauche dans le pied de la première page.
     * \return Le texte à gauche dans le pied de la première page, NULL si le pied de la première page est identique aux autres.
     */
    /*!
     * \fn const utf8String_t* centerFirstFooter() const
     * \brief Obtenir le texte au centre dans l'entête de la première page.
     * \return Le texte au centre dans l'entête de la première page, NULL si l'entête de la première page est identique aux autres.
     */
    /*!
     * \fn const utf8String_t* rightFirstFooter() const
     * \brief Obtenir le texte à droite dans le pied de la première page.
     * \return Le texte à droite dans le pied de la première page, NULL si le pied de la première page est identique aux autres.
     */
    virtual const utf8String_t* leftFirstHeader() const =0;
    virtual const utf8String_t* centerFirstHeader() const =0;
    virtual const utf8String_t* rightFirstHeader() const =0;
    virtual const utf8String_t* leftFirstFooter() const =0;
    virtual const utf8String_t* centerFirstFooter() const =0;
    virtual const utf8String_t* rightFirstFooter() const =0;

    /*!
     * \fn const utf8String_t* leftEvenHeader() const
     * \brief Obtenir le texte à gauche dans l'entête des pages impaires.
     * \return Le texte à gauche dans l'entête des pages impaires, NULL si l'entête des pages impaires est identique aux autres.
     */
    /*!
     * \fn const utf8String_t* centerEvenHeader() const
     * \brief Obtenir le texte au centre dans l'entête des pages impaires.
     * \return Le texte au centre dans l'entête des pages impaires, NULL si l'entête des pages impaires est identique aux autres.
     */
    /*!
     * \fn const utf8String_t* rightEvenHeader() const
     * \brief Obtenir le texte à droite dans l'entête des pages impaires.
     * \return Le texte à droite dans l'entête des pages impaires, NULL si l'entête des pages impaires est identique aux autres.
     */
    /*!
     * \fn const utf8String_t* leftEvenFooter() const
     * \brief Obtenir le texte à gauche dans le pied des pages impaires.
     * \return Le texte à gauche dans le pied des pages impaires, NULL si le pied des pages impaires est identique aux autres.
     */
    /*!
     * \fn const utf8String_t* centerEvenFooter() const
     * \brief Obtenir le texte au centre dans le pied des pages impaires.
     * \return Le texte au centre dans le pied des pages impaires, NULL si le pied des pages impaires est identique aux autres.
     */
    /*!
     * \fn const utf8String_t* rightEvenFooter() const
     * \brief Obtenir le texte à droite dans le pied des pages impaires.
     * \return Le texte à droite dans le pied des pages impaires, NULL si le pied des pages impaires est identique aux autres.
     */
    virtual const utf8String_t* leftEvenHeader() const =0;
    virtual const utf8String_t* centerEvenHeader() const =0;
    virtual const utf8String_t* rightEvenHeader() const =0;
    virtual const utf8String_t* leftEvenFooter() const =0;
    virtual const utf8String_t* centerEvenFooter() const =0;
    virtual const utf8String_t* rightEvenFooter() const =0;

    /*!
     * \fn utf8String_t leftHeader() const
     * \brief Obtenir le texte à gauche dans l'entête des pages.
     * \return Le texte à gauche dans l'entête des pages.
     */
    /*!
     * \fn utf8String_t centerHeader() const
     * \brief Obtenir le texte au centre dans l'entête des pages.
     * \return Le texte au centre dans l'entête des pages.
     */
    /*!
     * \fn utf8String_t rightHeader() const
     * \brief Obtenir le texte à droite dans l'entête des pages.
     * \return Le texte à droite dans l'entête des pages.
     */
    /*!
     * \fn utf8String_t leftFooter() const
     * \brief Obtenir le texte à gauche dans le pied des pages.
     * \return Le texte à gauche dans le pied des pages.
     */
    /*!
     * \fn utf8String_t centerFooter() const
     * \brief Obtenir le texte au centre dans le pied des pages.
     * \return Le texte au centre dans le pied des pages.
     */
    /*!
     * \fn utf8String_t rightFooter() const
     * \brief Obtenir le texte à droite dans le pied des pages.
     * \return Le texte à droite dans le pied des pages.
     */
    virtual utf8String_t leftHeader() const =0;
    virtual utf8String_t centerHeader() const =0;
    virtual utf8String_t rightHeader() const =0;
    virtual utf8String_t leftFooter() const =0;
    virtual utf8String_t centerFooter() const =0;
    virtual utf8String_t rightFooter() const =0;
};

/*!
 * \class PageSetting
 * \brief Définit les paramètres d'impression d'une feuille de calcul.
 */
class PageSetting {
public:
    /*!
     * \fn ~PageSetting()
     * \brief Destructeur.
     */
    virtual ~PageSetting() =0;

    /*!
     * \fn const Coordinates::MultiCellRange* printArea() const
     * \brief Obtenir les plages de cellules définissant les zones d'impression.
     * \return Une série de coordonnées de plage de cellules.
     */
    virtual const Coordinates::MultiCellRange* printArea() const =0;

    /*!
     * \fn const Coordinates::ColumnRowRange* headerColumns() const
     * \brief Obtenir les colonnes d'entête colonne.
     * \return Les coordonnées des colonnes d'entête.
     */
    /*!
     * \fn const Coordinates::ColumnRowRange* headerRows() const
     * \brief Obtenir les lignes d'entête.
     * \return Les coordonnées des lignes d'entête.
     */
    virtual const Coordinates::ColumnRowRange* headerColumns() const =0;
    virtual const Coordinates::ColumnRowRange* headerRows() const =0;

    /*!
     * \fn pageOrientation_t pageOrientation() const
     * \brief Obtenir l'orientation des pages.
     * \return l'orientation des pages.
     */
    virtual pageOrientation_t pageOrientation() const =0;

    /*!
     * \fn unsigned int fitToWidth() const
     * \brief Obtenir le nombre de pages sur lequel effectuer l'ajustement horizontal. 0 = pas d'ajustement.
     * \return Le nombre de page sur lequel est effectué le calcul de l'ajustement horizontal.
     */
    /*!
     * \fn unsigned int fitToHeight() const
     * \brief Obtenir le nombre de pages sur lequel effectuer l'ajustement vertical. 0 = pas d'ajustement.
     * \return Le nombre de page sur lequel est effectué le calcul de l'ajustement vertical.
     */
    virtual unsigned int fitToWidth() const =0;
    virtual unsigned int fitToHeight() const =0;

    /*!
     * \fn const unsigned short* scale() const
     * \brief Obtenir l'échelle d'impression en % de la taille normale [10, 400].
     * \return L'échelle d'impression qui est comprise entre 10% et 400% inclus ou NULL si l'échelle n'est pas assignée.
     */
    virtual const unsigned short* scale() const =0;

    /*!
     * \fn const PageHeaderFooter* pageHeaderFooter() const
     * \brief Obtenir les entêtes et les pieds de page.
     * \return Les entêtes et les pieds de page, NULL s'il n'y en a pas.
     */
    virtual const PageHeaderFooter* pageHeaderFooter() const =0;
};

/*!
 * \class CellFormat
 * \brief Définit un format de cellule.
 */
class CellFormat {
public:
    /*!
     * \fn ~CellFormat()
     * \brief Destructeur.
     */
    virtual ~CellFormat() =0;

    /*!
     * \fn utf8String_t fontName() const
     * \brief Obtenir le nom de la police de caractères.
     * \return Le nom de la police de caractères.
     */
    /*!
     * \fn unsigned short fontSize() const
     * \brief Obtenir la taille de la police (en point).
     * \return La taille de la police en point.
     */
    /*!
     * \fn color_t fontColor() const
     * \brief Obtenir la couleur de la police.
     * \return La couleur de la police au format RGB.
     */
    /*!
     * \fn bool isFontBolded() const
     * \brief La police est-elle grasse ?
     * \return Vrai si la police est grasse, faux sinon.
     */
    /*!
     * \fn bool isFontItalicized() const
     * \brief La police est-elle en italic ?
     * \return Vrai si la police est en italic, faux sinon.
     */
    /*!
     * \fn bool isFontUnderlined() const
     * \brief La police est-elle soulignée ?
     * \return Vrai si la police est soulignée, faux sinon.
     */
    virtual utf8String_t fontName() const =0;
    virtual unsigned short fontSize() const =0;
    virtual color_t fontColor() const =0;
    virtual bool isFontBolded() const =0;
    virtual bool isFontItalicized() const =0;
    virtual bool isFontUnderlined() const =0;

    /*!
     * \fn utf8String_t numberFormat() const
     * \brief Obtenir la chaîne de format de nombre (ex: #,##0.0;(#,##0.0);).
     * \return La chaîne de format de nombre.
     */
    /*!
     * \fn unsigned short builtInNumberFormatId() const
     * \brief Obtenir l'identifiant du format interne à Excel. Si la chaîne de format (fonction numberFormat) est assignée, cet identifiant n'est pas pris en compte.
     * \return Un identifiant compris entre [0, 164[.
     *
     * \code
     *  0 : Général
     *  1 : 0
     *  2 : 0.00
     *  3 : #,##0
     *  4 : #,##0.00
     *  5 : #,##0 €;-#,##0 €
     *  6 : #,##0 €;[red]-#,##0 €
     *  7 : #,##0.00 €;-#,##0.00 €
     *  8 : #,##0.00 €;[red]-#,##0.00 €
     *  9 : 0%
     * 10 : 0.00%
     * 11 : 0.00E+00
     * 12 : # ?/?
     * 13 : # ??/??
     * 14 : dd/mm/yyyy
     * 15 : d-mmm-yy
     * 16 : d-mmm
     * 17 : mmm-yy
     * 18 : h:mm AM/PM
     * 19 : h:mm:ss AM/PM
     * 20 : h:mm
     * 21 : h:mm:ss
     * 22 : dd/mm/yyyy h:mm
     * 37 : #,##0 _€;-#,##0 _€
     * 38 : #,##0 _€;[red]-#,##0 _€
     * 39 : #,##0.00 _€;[red]-#,##0.00 _€
     * 40 : #,##0.00 _€;[red]-#,##0.00 _€
     * 41 : _-* #,##0 _€_-;-* #,##0 _€_-;_-* - _€_-;_-@_-
     * 42 : _-* #,##0 €_-;-* #,##0 €_-;_-* - _€_-;_-@_-
     * 43 : _-* #,##0.00 _€_-;-* #,##0.00 _€_-;_-* -?? _€_-;_-@_-
     * 44 : _-* #,##0.00 €_-;-* #,##0.00 €_-;_-* -?? €_-;_-@_-
     * 45 : mm:ss
     * 46 : [h]:mm:ss
     * 47 : mm:ss.0
     * 48 : ##0.0E+0
     * 49 : @
     * 50 à 163: ??
     * \endcode
     */
    virtual utf8String_t numberFormat() const =0;
    virtual unsigned short builtInNumberFormatId() const =0;

    /*!
     * \fn patternStyle_t patternStyle() const
     * \brief Obtenir le style du motif.
     * \return Le style du motif.
     */
    /*!
     * \fn color_t foregroundColor() const
     * \brief Obtenir la couleur du motif.
     * \return La couleur du motif au format RGB.
     */
    /*!
     * \fn color_t backgroundColor() const
     * \brief Obtenir la couleur d'arrière plan.
     * \return La couleur d'arrière plan au format RGB.
     */
    virtual patternStyle_t patternStyle() const =0;
    virtual color_t foregroundColor() const =0;
    virtual color_t backgroundColor() const =0;

    /*!
     * \fn bool isBorderVisible(border_t border) const
     * \brief La bordure est-elle visible ?
     * \param border La bordure concernée.
     * \return Vrai si la bordure est visible, faux sinon.
     */
    /*!
     * \fn borderStyle_t borderStyle(border_t border) const
     * \brief Obtenir le style de la bordure.
     * \param border La bordure concernée.
     * \return Le style de la bordure.
     */
    /*!
     * \fn color_t borderColor(border_t border) const
     * \brief Obtenir la couleur de la bordure.
     * \param border La bordure concernée.
     * \return La couleur RGB de la bordure.
     */
    virtual bool isBorderVisible(border_t) const =0;
    virtual borderStyle_t borderStyle(border_t) const =0;
    virtual color_t borderColor(border_t) const =0;

    /*!
     * \fn horizontalAlignment_t horizontalAlignment() const
     * \brief Obtenir l'alignement horizontal de la cellule.
     * \return L'alignement horizontal de la cellule.
     */
    virtual horizontalAlignment_t horizontalAlignment() const =0;

    /*!
     * \fn verticalAlignment_t verticalAlignment() const
     * \brief Obtenir l'alignement vertical de la cellule.
     * \return L'alignement vertical de la cellule.
     */
    virtual verticalAlignment_t verticalAlignment() const =0;

    /*!
     * \fn unsigned short textIndent() const
     * \brief Obtenir la valeur du retrait du texte.
     * \return La valeur du retrait du texte.
     */
    virtual unsigned short textIndent() const =0;

    /*!
     * \fn short textRotation() const
     * \brief Obtenir l'angle de rotation du texte.
     * \return L'angle de rotation du texte. Il est exprimé en degré et doit être compris entre [-90°, 90°].
     */
    virtual short textRotation() const =0;

    /*!
     * \fn bool wrapText() const
     * \brief Le texte doit-il être coupé en fonction de la taille de la cellule ?
     * \return Vrai si le format autorise les retours à la ligne automatique, faux sinon.
     */
    virtual bool wrapText() const =0;
};

/*!
 * \class DifferentialCellFormat
 * \brief Définit un format différentiel (utilisé pour les formats conditionnels).
 */
class DifferentialCellFormat {
public:
    /*!
     * \fn ~DifferentialCellFormat()
     * \brief Destructeur.
     */
    virtual ~DifferentialCellFormat() =0;

    /*!
     * \fn const color_t* fontColor() const
     * \brief Obtenir la couleur de la police.
     * \return La couleur de la police au format RGB ou NULL si cette propriété n'a pas été surchargée.
     */
    /*!
     * \fn const bool* isFontBolded() const
     * \brief La police est-elle grasse ?
     * \return Vrai si la police est grasse, faux sinon ou NULL si cette propriété n'a pas été surchargée.
     */
    /*!
     * \fn const bool* isFontItalicized() const
     * \brief La police est-elle en italic ?
     * \return Vrai si la police est en italic, faux sinon ou NULL si cette propriété n'a pas été surchargée.
     */
    /*!
     * \fn const bool* isFontUnderlined() const
     * \brief La police est-elle soulignée ?
     * \return Vrai si la police est soulignée, faux sinon ou NULL si cette propriété n'a pas été surchargée.
     */
    virtual const color_t* fontColor() const =0;
    virtual const bool* isFontBolded() const =0;
    virtual const bool* isFontItalicized() const =0;
    virtual const bool* isFontUnderlined() const =0;

    /*!
     * \fn const utf8String_t* numberFormat() const
     * \brief Obtenir la chaîne de format de nombre (ex: #,##0.0;(#,##0.0);).
     * \return La chaîne de format de nombre ou NULL si cette propriété n'a pas été surchargée.
     */
    /*!
     * \fn const unsigned short* builtInNumberFormatId() const
     * \brief Obtenir l'identifiant du format interne à Excel. Si la chaîne de format (fonction numberFormat) est assignée, cet identifiant n'est pas pris en compte.
     * \return Un identifiant compris entre [0, 164[ ou NULL si cette propriété n'a pas été surchargée.
     */
    virtual const utf8String_t* numberFormat() const =0;
    virtual const unsigned short* builtInNumberFormatId() const =0;

    /*!
     * \fn const patternStyle_t* patternStyle() const
     * \brief Obtenir le style du motif.
     * \return Le style du motif ou NULL si cette propriété n'a pas été surchargée.
     */
    /*!
     * \fn const color_t* foregroundColor() const
     * \brief Obtenir la couleur du motif.
     * \return La couleur du motif au format RGB ou NULL si cette propriété n'a pas été surchargée.
     */
    /*!
     * \fn const color_t* backgroundColor() const
     * \brief Obtenir la couleur d'arrière plan.
     * \return La couleur d'arrière plan au format RGB ou NULL si cette propriété n'a pas été surchargée.
     */
    virtual const patternStyle_t* patternStyle() const =0;
    virtual const color_t* foregroundColor() const =0;
    virtual const color_t* backgroundColor() const =0;

    /*!
     * \fn const bool* isBorderVisible(border_t border) const
     * \brief La bordure est-elle visible ?
     * \param border La bordure concernée.
     * \return Vrai si la bordure est visible, faux sinon ou NULL si cette propriété n'a pas été surchargée.
     */
    /*!
     * \fn const borderStyle_t* borderStyle(border_t border) const
     * \brief Obtenir le style de la bordure.
     * \param border La bordure concernée.
     * \return Le style de la bordure ou NULL si cette propriété n'a pas été surchargée.
     */
    /*!
     * \fn const color_t* borderColor(border_t border) const
     * \brief Obtenir la couleur de la bordure.
     * \param border La bordure concernée.
     * \return La couleur RGB de la bordure ou NULL si cette propriété n'a pas été surchargée.
     */
    virtual const bool* isBorderVisible(border_t) const =0;
    virtual const borderStyle_t* borderStyle(border_t) const =0;
    virtual const color_t* borderColor(border_t) const =0;
};

/*!
 * \class ConditionalFormatting
 * \brief Définit un format conditionnel.
 */
class ConditionalFormatting {
public:
    /*!
     * \fn ~ConditionalFormatting()
     * \brief Destructeur.
     */
    virtual ~ConditionalFormatting() =0;

    /*!
     * \fn const CellFormat* format() const
     * \brief Obtenir le format.
     * \return Le format à appliquer si la condition est vraie.
     */
    virtual const DifferentialCellFormat* format() const =0;

    /*!
     * \fn utf8String_t formula() const
     * \brief Obtenir la condition.
     * \return La condition au format "natif" Excel.
     */
    virtual utf8String_t formula() const =0;

    /*!
     * \fn const Coordinates::MultiCellRange& reference() const
     * \brief Les coordonnées des plages de cellules impactées.
     * \return Les coordonnées des plages de cellules impactées.
     */
    virtual const Coordinates::MultiCellRange& reference() const =0;

    /*!
     * \fn bool isValid() const
     * \brief Vérifier que tous les paramètres sont renseignés (formule non vide et référence non vide).
     * \return Vrai si le format conditionnel est valide, faux sinon.
     */
    virtual bool isValid() const;
};

/*!
 * \class Validation
 * \brief Définit une règle de validation de données.
 */
class Validation {
public:
    /*!
     * \fn virtual ~Validation()
     * \brief Destructeur.
     */
    virtual ~Validation() =0;

    /*!
     * \fn const Coordinates::MultiCellRange& reference() const
     * \brief Les coordonnées des plages de cellules impactées.
     * \return Les coordonnées des plages de cellules impactées.
     */
    virtual const Coordinates::MultiCellRange& reference() const =0;

    /*!
     * \fn bool isBlankAllowed() const
     * \brief Les valeurs vides sont-elles autorisées ?
     * \return Vrai si elles sont autorisées, faux sinon.
     */
    virtual bool isBlankAllowed() const =0;

    /*!
     * \fn bool isPromptShown() const
     * \brief Le texte de description est-il affiché ?
     * \return Vrai si il est affiché, faux sinon.
     */
    /*!
     * \fn utf8String_t promptTitle() const
     * \brief Obtenir le titre du texte de description.
     * \return Le titre du texte de description.
     */
    /*!
     * \fn utf8String_t promptMessage() const
     * \brief Obtenir le texte de description.
     * \return Le texte de description.
     */
    virtual bool isPromptShown() const =0;
    virtual utf8String_t promptTitle() const =0;
    virtual utf8String_t promptMessage() const =0;

    /*!
     * \fn bool isAlertShown() const
     * \brief Le message d'alerte est-il affiché ?
     * \return Vrai si il est affiché, faux sinon.
     */
    /*!
     * \fn alertType_t alertType() const
     * \brief Obtenir le type d'alerte.
     * \return Le type d'alerte.
     */
    /*!
     * \fn utf8String_t alertTitle() const
     * \brief Obtenir le titre du message d'alerte.
     * \return Le titre du message d'alerte.
     */
    /*!
     * \fn utf8String_t alertMessage() const
     * \brief Obtenir le texte du message d'alerte.
     * \return Le texte du message d'alerte.
     */
    virtual bool isAlertShown() const =0;
    virtual alertType_t alertType() const =0;
    virtual utf8String_t alertTitle() const =0;
    virtual utf8String_t alertMessage() const =0;

    /*!
     * \fn bool isValid() const
     * \brief Vérifier que tous les paramètres sont renseignés (formule non vide et référence non vide).
     * \return Vrai si la règle de validation est valide, faux sinon.
     */
    virtual bool isValid() const;
};

/*!
 * \class CustomValidation
 * \brief Définit une règle de validation de données à partir d'une formule.
 */
class CustomValidation : public virtual Validation {
public:
    /*!
     * \fn virtual ~CustomValidation()
     * \brief Destructeur.
     */
    virtual ~CustomValidation() =0;

    /*!
     * \fn utf8String_t formula() const
     * \brief Obtenir la condition de validation.
     * \return La condition de validation au format "natif" Excel.
     */
    virtual utf8String_t formula() const =0;

    /*!
     * \fn bool isValid() const
     * \brief Vérifier que tous les paramètres sont renseignés (formule non vide et référence non vide).
     * \return Vrai si la règle de validation est valide, faux sinon.
     */
    virtual bool isValid() const;
};

/*!
 * \class ListValidation
 * \brief Définit une règle de validation de données à partir d'une liste de valeur.
 */
class ListValidation : public virtual Validation {
public:
    /*!
     * \fn virtual ~ListValidation()
     * \brief Destructeur.
     */
    virtual ~ListValidation() =0;

    /*!
     * \fn const Coordinates::CellRange* rangeReference() const
     * \brief Obtenir la plage de données de référence.
     * \return La plage de données de référence.
     */
    virtual const Coordinates::CellRange* rangeReference() const =0;

    /*!
     * \fn const valueList_t* list() const
     * \brief Obtenir la liste de choix.
     * \return La liste des valeurs possibles.
     */
    virtual const valueList_t* list() const =0;

    /*!
     * \fn bool isValid() const
     * \brief Vérifier que tous les paramètres sont renseignés (formule non vide et référence non vide).
     * \return Vrai si la règle de validation est valide, faux sinon.
     */
    virtual bool isValid() const;
};

/*!
 * \class Filter
 * \brief Définit un filtre.
 */
class Filter {
public:
    /*!
     * \class Filter
     * \brief Destructeur.
     */
    virtual ~Filter() =0;

    /*!
     * \fn const Coordinates::CellRange* rangeReference() const
     * \brief Obtenir la plage de données de référence.
     * \return La plage de données de référence.
     */
    virtual const Coordinates::CellRange* rangeReference() const =0;
};

/*!
 * \class Image
 * \brief Définit une image.
 */
class Image {
public:
    /*!
     * \fn ~Image()
     * \brief Destructeur.
     */
    virtual ~Image() =0;

    /*!
     * \fn void getImageBuffer(unsigned char*& buffer, unsigned int& length) const
     * \brief Obtenir le flux de l'image.
     * \param buffer Le flux de l'image.
     * \param length La taille du flux.
     */
    virtual void getImageBuffer(unsigned char*&, unsigned int&) const =0;

    /*!
     * \fn imageType_t type() const
     * \brief Obtenir le type de l'image.
     * \return Le type de l'image (JPG, GIF, PNG ou BMP).
     */
    virtual imageType_t type() const =0;

    /*!
     * \fn unsigned int width() const
     * \brief Obtenir la largeur de l'image en pixel.
     * \return La largeur de l'image en pixel.
     */
    /*!
     * \fn unsigned int height() const
     * \brief Obtenir la hauteur de l'image en pixel.
     * \return La hauteur de l'image en pixel.
     */
    virtual unsigned int width() const =0;
    virtual unsigned int height() const =0;

    /*!
     * \fn const Coordinates::CellPoint& topLeft() const
     * \brief Obtenir la position haut-gauche de l'image par rapport à la grille.
     * \return La position haut-gauche de l'image.
     */
    /*!
     * \fn const Coordinates::CellPoint* rightBottom() const
     * \brief Obtenir la position bas-droite de l'image par rapport à la grille.
     * \return La position bas-droite de l'image. Si NULL alors la position sera calculée de façon à ce que l'image ne soit pas déformée.
     */
    virtual const Coordinates::CellPoint& topLeft() const =0;
    virtual const Coordinates::CellPoint* rightBottom() const =0;

    /*!
     * \fn const emuRectangle_t* cropRectangle() const
     * \brief Obtenir le rectangle de rognage de l'image.
     * \return Le rectangle de rognage. NULL si il n'y a pas de rectangle de rognage.
     */
    virtual const pixelRectangle_t* cropRectangle() const =0;

    /*!
     * \fn imageProperty_t property() const
     * \brief Obtenir le comportement de l'image par rapport aux changements de la grille.
     * \return La propriété de l'image.
     */
    virtual imageProperty_t property() const =0;

    /*!
     * \fn bool isValid() const
     * \brief L'image est elle valide ?
     * \return Vrai si l'image peut être intégrée au fichier, faux sinon.
     */
    virtual bool isValid() const =0;
};

/*!
 * \class Hyperlink
 * \brief Définit un lien d'une cellule à une plage de cellules.
 */
class Hyperlink {
public:
    /*!
     * \fn ~Hyperlink
     * \brief Destructeur.
     */
    virtual ~Hyperlink() =0;

    /*!
     * \fn const Coordinates::CellRange& reference() const
     * \brief Obtenir les coordonnées de la plage de cellules sur lesquelles le lien est positionné.
     * \return Les coordonnées de la plage de cellules.
     */
    virtual const Coordinates::CellRange& reference() const =0;

    /*!
     * \fn const utf8String_t& display() const
     * \brief Obtenir le texte à afficher par défaut.
     * \return Le texte à afficher par défaut.
     */
    virtual const utf8String_t& display() const =0;

    /*!
     * \fn const Coordinates::CellRange* location() const
     * \brief Obtenir les coordonnées de la plage de cellules vers lesquelles pointe le lien.
     * \return Les coordonnées de la plage de cellules vers lesquelles pointe le lien. NULL si il n'y a pas de coordonnées spécifiées.
     */
    /*!
     * \fn const DefinedName* definedName() const
     * \brief Obtenir la plage de cellules nommée vers laquelle le lien pointe.
     * \return La plage de cellules. NULL si le lien ne pointe pas vers une plage nommée.
     */
    /*!
     * \fn const utf8String_t* fileLocation() const
     * \brief Obtenir le nom du fichier à ouvrir.
     * \return Le nom du fichier à ouvrir. NULL si le lien ne pointe pas vers un fichier.
     */
    /*!
     * \fn bool getMailLocation(utf8String_t& mail, utf8String_t& object) const
     * \brief Obtenir les paramètres du mail à préparer.
     * \param mail L'adresse mail du destinataire.
     * \param object L'objet du mail.
     * \return Vrai si le lien est un lien de préparation de mail, faux sinon.
     */
    virtual const Coordinates::CellRange* location() const =0;
    virtual const DefinedName* definedName() const =0;
    virtual const utf8String_t* fileLocation() const =0;
    virtual bool getMailLocation(utf8String_t&, utf8String_t&) const =0;

    /*!
     * \fn const utf8String_t& tooltip() const
     * \brief Obtenir le texte de l'info bulle.
     * \return Le texte de l'info bulle.
     */
    virtual const utf8String_t& tooltip() const =0;

    /*!
     * \fn bool isValid() const
     * \brief Le lien est-il valide ?
     * \return Vrai si le lien est valide (si le lien est assigné), faux sinon.
     */
    virtual bool isValid() const =0;
};

/*!
 * \class Comment
 * \brief Définit un commentaire.
 */
class Comment {
public:
    /*!
     * \fn ~Comment()
     * \brief Destructeur.
     */
    virtual ~Comment() = 0;

    /*!
     * \fn const Coordinates::Cell& reference() const
     * \brief Obtenir les coordonées de la cellule sur laquelle est accroché le commentaire.
     * \return Les coordonnées de la cellule.
     */
    virtual const Coordinates::Cell& reference() const =0;

    /*!
     * \fn const utf8String_t& author() const
     * \brief Obtenir le nom de l'auteur.
     * \return Le nom de l'auteur.
     */
    virtual const utf8String_t& author() const =0;

    /*!
     * \fn size_t runCount() const
     * \brief Obtenir le nombre de portion de texte.
     * \return Le nombre de portion de texte.
     */
    /*!
     * \fn const font_t* runFont(size_t index) const
     * \brief Obtenir la police de caractères de la portion de texte.
     * \param index L'index de la portion de texte ciblée (index doit être compris entre 0 et runCount() - 1).
     * \return La police de caractères de la portion de texte à l'index "index".
     */
    /*!
     * \fn const utf8String_t* runText(size_t index) const
     * \brief Obtenir le texte de la portion de texte.
     * \param index L'index de la portion de texte ciblée (index doit être compris entre 0 et runCount() - 1).
     * \return Le texte de la portion de texte à l'index "index".
     */
	virtual size_t runCount() const =0;
    virtual const font_t* runFont(size_t) const =0;
    virtual const utf8String_t* runText(size_t) const =0;

    /*!
     * \fn const std::string& hyperlink() const
     * \brief Obtenir le lien hyper texte.
     * \return le lien hyper texte de la boite de commentaire ou chaîne vide.
     */
    virtual const std::string& hyperlink() const =0;

    /*!
     * \fn Interface::horizontalAlignment_t alignment() const
     * \brief Obtenir l'alignement horizontal de la boite de commentaire.
     * \return L'alignement du texte dans la boite de commentaire.
     */
    virtual Interface::horizontalAlignment_t alignment() const =0;

    /*!
     * \fn const Coordinates::CellPoint& topLeft() const
     * \brief Obtenir la position haut-gauche de la boite de commentaire par rapport à la grille.
     * \return La position haut-gauche de la boite de commentaire.
     */
    /*!
     * \fn const Coordinates::CellPoint& rightBottom() const
     * \brief Obtenir la position bas-droite de la boite de commentaire par rapport à la grille.
     * \return La position bas-droite de la boite de commentaire.
     */
    /*!
     * \fn bool autoSize() const
     * \brief La taille automatique est-elle activée ?
     * \return Vrai si la taille de la boite de commentaire sera ajustée au texte.
     */
    virtual const Coordinates::CellPoint& topLeft() const =0;
    virtual const Coordinates::CellPoint& rightBottom() const =0;
    virtual bool autoSize() const =0;

    /*!
     * \fn color_t fillColor() const
     * \brief Obtenir la couleur de fond de la boite de commentaire.
     * \return La couleur de fond de la boite de commentaire.
     */
    virtual color_t fillColor() const =0;

    /*!
     * \fn visibility_t visibility() const
     * \brief Obtenir la visibilité de la boite de commentaire (cachée ou visible).
     * \return La visibilité de la boite de commentaire (cachée ou visible).
     */
    virtual visibility_t visibility() const =0;

    /*!
     * \fn commentProperty_t property() const
     * \brief Obtenir le comportement de la boite de commentaire.
     * \return Le comportement de la boite de commentaire.
     */
    virtual commentProperty_t property() const =0;
};

/*!
 * \class Worksheet
 * \brief Définit une feuille de calcul.
 */
class Worksheet : public Coordinates::WorksheetProxy {
public:
    /*!
     * \fn ~Worksheet()
     * \brief Destructeur.
     */
    virtual ~Worksheet() =0;

    /*!
     * \fn utf8String_t name() const
     * \brief Obtenir le nom de la feuille de calcul.
     * \return Le nom de la feuille de calcul.
     */
    virtual utf8String_t name() const =0;

    /*!
     * \fn bool isHidden() const
     * \brief La feuille de calcul est-elle cachée ?
     * \return Vrai si la feuille est cachée, faux sinon.
     */
    virtual bool isHidden() const =0;

    /*!
     * \fn bool formulasShown() const
     * \brief Les formules de calcul sont-elles visibles dans la feuille ?
     * \return Vrai si les formules sont visibles, faux sinon.
     */
    virtual bool formulasShown() const =0;

    /*!
     * \fn bool gridLinesShown() const
     * \brief Le quadrillage est-il visible dans la feuille ?
     * \return Vrai si le quadrillage est visible, faux sinon.
     */
    virtual bool gridLinesShown() const =0;

    /*!
     * \fn bool rowColHeadersShown() const
     * \brief Les entêtes de lignes et de colonnes sont-ils visibles dans la feuille ?
     * \return Vrai si les entêtes de lignes et de colonnes sont visibles, faux sinon.
     */
    virtual bool rowColHeadersShown() const =0;

    /*!
     * \fn bool zerosShown() const
     * \brief Les zéros dans les cellules qui ont une valeur nulle sont-ils affichés ?
     * \return Vrai si les zéros sont affichés, faux sinon.
     */
    virtual bool zerosShown() const =0;

    /*!
     * \fn const Coordinates::Cell* activeCell() const
     * \brief Obtenir la cellule active selectionnée.
     * \return Les coordonnées de la cellule active selectionnée.
     */
    /*!
     * \fn const Coordinates::MultiCellRange* selection() const
     * \brief Obtenir la plage de cellules sélectionnée.
     * \return Les coordonnées de la plage de cellules sélectionnée.
     */
    virtual const Coordinates::Cell* activeCell() const =0;
    virtual const Coordinates::MultiCellRange* selection() const =0;

    /*!
     * \fn const PageSetting* pageSetting() const
     * \brief Obtenir les paramètres d'impression de la feuille de calcul.
     * \return Les paramètres d'impression de la feuille de calcul.
     */
    virtual const PageSetting* pageSetting() const =0;

    /*!
     * \fn const Coordinates::CellRange& minBounds() const
     * \brief Obtenir la plage de données non vide minimale.
     * \return La plage de données non vide minimale.
     */
    virtual const Coordinates::CellRange& minBounds() const =0;

    /*!
     * \fn bool isColumnVisible(unsigned int index) const
     * \brief La colonne est-elle visible ?
     * \param index L'index de la colonne demandée ([0, ∞[).
     * \return Vrai si la colonne est visible, faux sinon.
     */
    /*!
     * \fn double columnWidth(unsigned int index) const
     * \brief Obtenir la taille de la colonne.
     * \param index L'index de la colonne demandée ([0, ∞[).
     * \return La largeur de la colonne.
     *
     * La taille de la colonne correspond au nombre de chiffre maximum visibles dans la police de style normal.
     * Pour le calcul, Excel utilise la taille du chiffre le plus large, ajoute 2 pixel de marge de chaque côté et 1 pixel pour la grille.\n
     * Le calcul est : taille en pixel = trunc({size} * 7)
     */
    /*!
     * \fn unsigned short columnOutlineLevel(unsigned int index) const
     * \brief Obtenir le niveau de regroupement.
     * \param index L'index de la colonne demandée ([0, ∞[).
     * \return Le niveau de regroupement de la colonne.
     */
    /*!
     * \fn bool isColumnCollapsed(unsigned int index) const
     * \brief Le regroupement est-il masqué ?
     * \param index L'index de la colonne demandée ([0, ∞[).
     * \return Vrai si le regroupement est masqué, faux sinon.
     */
    /*!
     * \fn const CellFormat* columnCellFormat(unsigned int index) const
     * \brief Obtenir le format de cellule assigné à la colonne.
     * \param index L'index de la colonne demandée ([0, ∞[).
     * \return Le format de cellule assigné à la colonne, NULL si aucun format n'est assigné.
     */
    /*!
     * \fn bool isColumnDefault(unsigned int index) const
     * \brief Savoir si la colonne a les paramètres par défaut.
     * \param index L'index de la colonne demandée ([0, ∞[).
     * \return Vrai si la colonne a les paramètres par défaut, faux sinon.
     */
    /*!
     * \fn bool getColumnParentIndex(unsigned int index, unsigned int& parentIndex) const
     * \brief Obtenir l'index de la colonne parente d'une colonne.
     * \param index L'index de la colonne demandée ([0, ∞[).
     * \param parentIndex L'index de la colonne parente (si la colonne a une colonne parente).
     * \return Vrai si la colonne a une colonne parente, faux sinon.
     *
     * Cette fonction tient compte de la valeur retournée par la fonction outlineSummaryRight.
     */
    /*!
     * \fn bool hasColumnChildren(unsigned int index) const
     * \brief Savoir si la colonne a des colonnes enfants.
     * \param index L'index de la colonne demandée ([0, ∞[).
     * \return Vrai si la colonne a des colonnes enfants, faux sinon.
     *
     * Cette fonction tient compte de la valeur retournée par la fonction outlineSummaryRight.
     */
    /*!
     * \fn bool areColumnChildrenCollapsed(unsigned int index) const
     * \brief Savoir si les colonnes enfants sont repliées.
     * \param index L'index de la colonne demandée ([0, ∞[).
     * \return Vrai la colonne a des colonnes enfants et qu'elles sont repliées, faux sinon.
     *
     * Cette fonction tient compte de la valeur retournée par la fonction outlineSummaryRight.
     */
    virtual bool isColumnVisible(unsigned int) const =0;
    virtual double columnWidth(unsigned int) const =0;
    virtual unsigned short columnOutlineLevel(unsigned int) const =0;
    virtual bool isColumnCollapsed(unsigned int) const =0;
    virtual const CellFormat* columnCellFormat(unsigned int) const =0;

    virtual bool isColumnDefault(unsigned int) const =0;

    virtual bool getColumnParentIndex(unsigned int, unsigned int&) const =0;
    virtual bool hasColumnChildren(unsigned int) const =0;
    virtual bool areColumnChildrenCollapsed(unsigned int) const =0;

    /*!
     * \fn bool isRowVisible(unsigned int index) const
     * \brief La ligne est-elle visible ?
     * \param index L'index de la ligne demandée ([0, ∞[).
     * \return Vrai si la ligne est visible, faux sinon.
     */
    /*!
     * \fn double rowHeight(unsigned int index) const
     * \brief Obtenir la taille de la ligne.
     * \param index L'index de la ligne demandée ([0, ∞[).
     * \return La hauteur de la ligne.
     *
     * La taille des lignes est exprimée en point.
     */
    /*!
     * \fn unsigned short rowOutlineLevel(unsigned int index) const
     * \brief Obtenir le niveau de regroupement.
     * \param index L'index de la ligne demandée ([0, ∞[).
     * \return Le niveau de regroupement de la ligne.
     */
    /*!
     * \fn bool isRowCollapsed(unsigned int index) const
     * \brief Le regroupement est-il masqué ?
     * \param index L'index de la ligne demandée ([0, ∞[).
     * \return Vrai si le regroupement est masqué, faux sinon.
     */
    /*!
     * \fn const CellFormat* rowCellFormat(unsigned int index) const
     * \brief Obtenir le format de cellule assigné à la ligne.
     * \param index L'index de la ligne demandée ([0, ∞[).
     * \return Le format de cellule assigné à la ligne, NULL si aucun format n'est assigné.
     */
    /*!
     * \fn bool isRowDefault(unsigned int index) const
     * \brief Savoir si la ligne a les paramètres par défaut.
     * \param index L'index de la ligne demandée ([0, ∞[).
     * \return Vrai si la ligne a les paramètres par défaut, faux sinon.
     */
    /*!
     * \fn bool getRowParentIndex(unsigned int index, unsigned int& parentIndex) const
     * \brief Obtenir l'index de la ligne parente d'une ligne.
     * \param index L'index de la ligne demandée ([0, ∞[).
     * \param parentIndex L'index de la ligne parente (si la ligne a une ligne parente).
     * \return Vrai si la ligne a une ligne parente, faux sinon.
     *
     * Cette fonction tient compte de la valeur retournée par la fonction outlineSummaryBelow.
     */
    /*!
     * \fn bool hasRowChildren(unsigned int index) const
     * \brief Savoir si la ligne a des lignes enfants.
     * \param index L'index de la ligne demandée ([0, ∞[).
     * \return Vrai si la ligne a des lignes enfants, faux sinon.
     *
     * Cette fonction tient compte de la valeur retournée par la fonction outlineSummaryBelow.
     */
    /*!
     * \fn bool areRowChildrenCollapsed(unsigned int index) const
     * \brief Savoir si les lignes enfants sont repliées.
     * \param index L'index de la ligne demandée ([0, ∞[).
     * \return Vrai la ligne a des lignes enfants et qu'elles sont repliées, faux sinon.
     *
     * Cette fonction tient compte de la valeur retournée par la fonction outlineSummaryBelow.
     */
    virtual bool isRowVisible(unsigned int) const =0;
    virtual double rowHeight(unsigned int) const =0;
    virtual unsigned short rowOutlineLevel(unsigned int) const =0;
    virtual bool isRowCollapsed(unsigned int) const =0;
    virtual const CellFormat* rowCellFormat(unsigned int) const =0;

    virtual bool isRowDefault(unsigned int) const =0;

    virtual bool getRowParentIndex(unsigned int, unsigned int&) const =0;
    virtual bool hasRowChildren(unsigned int) const =0;
    virtual bool areRowChildrenCollapsed(unsigned int) const =0;

    /*!
     * \fn double defaultColumnWidth() const
     * \brief Obtenir la taille par défaut des colonnes.
     * \return La taille par défaut des colonnes.
     *
     * La taille de la colonne correspond au nombre de chiffres maximum visibles dans la police de style normal.
     * Pour le calcul, Excel utilise la taille du chiffre le plus large, ajoute 2 pixels de marge de chaque côté et 1 pixel pour la grille.\n
     * Le calcul est : taille en pixel = trunc({size} * 7)
     */
    /*!
     * \fn double defaultRowHeight() const
     * \brief Obtenir la taille par défaut des lignes.
     * \return La taille par défaut des lignes (exprimée en point).
     */
    virtual double defaultColumnWidth() const =0;
    virtual double defaultRowHeight() const =0;

    /*!
     * \fn bool outlineSummaryRight() const
     * \brief La colonne de récapitulation est elle à droite des colonnes plan ?
     * \return Vrai si cette colonne est à droite, faux sinon.
     */
    /*!
     * \fn bool outlineSummaryBelow() const
     * \brief La ligne de récapitulation est elle en dessous des lignes plan ?
     * \return Vrai si cette ligne est en dessous, faux sinon.
     */
    virtual bool outlineSummaryRight() const =0;
    virtual bool outlineSummaryBelow() const =0;

    /*!
     * \fn bool getXSplit(unsigned int& xSplitIndex) const
     * \brief Obtenir l'index de la dernière colonne fixe si il y en a.
     * \param xSplitIndex L'index de la dernière colonne fixe si il y en a ([0, ∞[).
     * \return Vrai si il y a des colonnes fixes et que le paramètre a été affecté, faux sinon.
     */
    /*!
     * \fn bool getYSplit(unsigned int& ySplitIndex) const
     * \brief Obtenir l'index de la dernière ligne fixe si il y en a.
     * \param ySplitIndex L'index de la dernière ligne fixe si il y en a ([0, ∞[).
     * \return Vrai si il y a des lignes fixes et que le paramètre a été affecté, faux sinon.
     */
    virtual bool getXSplit(unsigned int&) const =0;
    virtual bool getYSplit(unsigned int&) const =0;

    /*!
     * \fn size_t mergeCount() const
     * \brief Obtenir le nombre de fusions de cellules.
     * \return Le nombre de fusions de cellules.
     */
    /*!
     * \fn const Coordinates::CellRange* merge(size_t index) const
     * \brief Obtenir les coordonnées d'une fusion de cellules.
     * \param index Un index compris entre 0 et mergeCount().
     * \return Les coordonnées d'une fusion de cellules, NULL si l'index est erroné.
     */
    virtual size_t mergeCount() const =0;
    virtual const Coordinates::CellRange* merge(size_t) const =0;

    /*!
     * \fn const CellFormat* cellFormat(unsigned int col, unsigned int row) const
     * \brief Obtenir le format d'une cellule.
     * \param col L'index de la colonne de la cellule concernée ([0, ∞[).
     * \param row L'index de la ligne de la cellule concernée ([0, ∞[).
     * \return Le format de la cellule concernée.
     */
    /*!
     * \fn const CellValue* cellValue(unsigned int col, unsigned int row) const
     * \brief Obtenir la valeur d'une cellule.
     * \param col L'index de la colonne de la cellule concernée ([0, ∞[).
     * \param row L'index de la ligne de la cellule concernée ([0, ∞[).
     * \return La valeur de la cellule concernée.
     */
    virtual const CellFormat* cellFormat(unsigned int, unsigned int) const =0;
    virtual const CellValue* cellValue(unsigned int, unsigned int) const =0;

    /*!
     * \fn size_t conditionalFormattingCount() const
     * \brief Obtenir le nombre de formats conditionnels.
     * \return Le nombre de formats conditionnels.
     */
    /*!
     * \fn const ConditionalFormatting* conditionalFormatting(size_t index) const
     * \brief Obtenir un format conditionnel.
     * \param index Un index compris entre 0 et conditionalFormattingCount().
     * \return Un format conditionnel, NULL si l'index est erroné.
     */
    virtual size_t conditionalFormattingCount() const =0;
    virtual const ConditionalFormatting* conditionalFormatting(size_t) const =0;

    /*!
     * \fn size_t validationCount() const
     * \brief Obtenir le nombre de règles de validation.
     * \return Le nombre de règles de validation.
     */
    /*!
     * \fn const Validation* validation(size_t index) const
     * \brief Obtenir une règle de validation.
     * \param index Un index compris entre 0 et validationCount().
     * \return Une règle de validation, NULL si l'index est erroné.
     */
    virtual size_t validationCount() const =0;
    virtual const Validation* validation(size_t) const =0;

    /*!
     * \fn const Filter* filter() const
     * \brief Obtenir le filtre.
     * \return Le filtre ou NULL.
     */
    virtual const Filter* filter() const =0;

    /*!
     * \fn bool containsValidImages() const
     * \brief La feuille contient elle des images valides ?
     * \return Vrai si la feuille contient des images valides, faux sinon.
     */
    /*!
     * \fn size_t imageCount() const
     * \brief Obtenir le nombre d'images.
     * \return Le nombre d'images.
     */
    /*!
     * \fn const Image* image(size_t index) const
     * \brief Obtenir une image.
     * \param index Un index compris entre 0 et imageCount().
     * \return Une image, NULL si l'index est erroné.
     */
    virtual bool containsValidImages() const =0;
    virtual size_t imageCount() const =0;
    virtual const Image* image(size_t) const =0;

    /*!
     * \fn size_t hyperlinkCount() const
     * \brief Obtenir le nombre de liens.
     * \return Le nombre de liens.
     */
    /*!
     * \fn const Hyperlink* hyperlink(size_t index) const
     * \brief Obtenir les paramètres d'un lien.
     * \return Les paramètres du lien, NULL si l'index est erroné.
     */
    virtual size_t hyperlinkCount() const =0;
    virtual const Hyperlink* hyperlink(size_t) const =0;

    /*!
     * \fn size_t commentCount() const
     * \brief Obtenir le nombre de commentaires.
     * \return Le nombre de commentaires.
     */
    /*!
     * \fn const Comment* comment(size_t index) const
     * \brief Obtenir les paramètres d'un commentaire.
     * \return Les paramètres du commentaire, NULL si l'index est erroné.
     */
    /*!
     * \fn const Comment* comment(unsigned int col, unsigned int row) const
     * \brief Obtenir les paramètres d'un commentaire.
     * \param col L'index de la colonne de la cellule concernée ([0, ∞[).
     * \param row L'index de la ligne de la cellule concernée ([0, ∞[).
     * \return Les paramètres du commentaire, NULL si il n'y a pas de commentaire sur la cellule concernée.
     */
    virtual size_t commentCount() const =0;
    virtual const Comment* comment(size_t) const =0;
    virtual const Comment* comment(unsigned int, unsigned int) const =0;
};

/*!
 * \class Workbook
 * \brief Définit un classeur de feuilles de calcul.
 */
class Workbook : public Coordinates::WorkbookProxy {
public:
    /*!
     * \fn ~Workbook()
     * \brief Destructeur.
     */
    virtual ~Workbook() =0;

    /*!
     * \fn const Coordinates::WorksheetProxy* selectedWorksheet() const
     * \brief Obtenir une procuration sur la feuille de calcul active.
     * \return Une procuration sur la feuille de calcul.
     */
    virtual const Coordinates::WorksheetProxy* selectedWorksheet() const =0;

    /*!
     * \fn utf8String_t checkWorksheetName(const utf8String_t& name) const
     * \brief Verifier l'unicité d'un nom de feuille de calcul dans ce classeur.
     * \param name Le nom de la feuille de calcul.
     * \return Le nom de la feuille de calcul corrigé.
     */
    /*!
     * \fn size_t worksheetCount() const
     * \brief Obtenir le nombre de feuilles de calcul.
     * \return Le nombre de feuilles de calcul présentes dans le classeur.
     */
    /*!
     * \fn const Worksheet* worksheet(size_t index) const
     * \brief Obtenir une feuille de calcul.
     * \param index L'index de la feuille demandée (entre 0 et worksheetCount()).
     * \return La feuille demandée, NULL si l'index est erroné.
     */
    /*!
     * \fn const Coordinates::WorksheetProxy* worksheet(const utf8String_t& sheetName) const
     * \brief Obtenir une procuration sur une feuille de calcul précisée en paramètre.
     * \param sheetName Le nom de la feuille.
     * \return Une procuration sur la feuille de calcul, NULL si la feuille n'existe pas.
     */
    virtual utf8String_t checkWorksheetName(const utf8String_t&) const =0;
    virtual size_t worksheetCount() const =0;
    virtual const Worksheet* worksheet(size_t) const =0;
    virtual const Coordinates::WorksheetProxy* worksheet(const utf8String_t&) const =0;

    /*!
     * \fn void getDefaultFont(utf8String_t& name, unsigned short& size, color_t& color, bool& bold, bool& italic, bool& underline) const
     * \brief Obtenir la police de caractères par défaut.
     * \param name Le nom de la police.
     * \param size La taille de la police (en pt).
     * \param color La couleur de la police.
     * \param bold La police est-elle grasse ?
     * \param italic La police est-elle en italique ?
     * \param underline La police est-elle soulignée ?
     */
    virtual void getDefaultFont(utf8String_t&, unsigned short&, color_t&, bool&, bool&, bool&) const =0;

    /*!
     * \typedef cellFormatList_t
     * \brief Type liste des formats de cellule.
     */
    /*!
     * \fn cellFormatList_t formats() const
     * \brief Obtenir la liste des formats de cellule.
     * \return La liste des formats de cellule.
     */
    typedef std::vector<const CellFormat*> cellFormatList_t;
    virtual cellFormatList_t formats() const = 0;

    /*!
     * \fn size_t definedNameCount() const
     * \brief Obtenir le nombre de plages de cellules nommées.
     * \return Le nombre de plages de cellules nommées.
     */
    /*!
     * \fn const DefinedName* definedName(size_t index) const
     * \brief Obtenir une plage de cellules nommée.
     * \param index L'index de la plage de cellules nommée demandée (entre 0 et definedNameCount()).
     * \return La plage de cellules nommée demandée, NULL si l'index est erroné.
     */
    /*!
     * \fn const DefinedName* definedName(const utf8String_t& name) const
     * \brief Obtenir une plage de cellules nommée.
     * \param name Le nom de la plage de cellules nommée demandée.
     * \return La plage de cellules nommée demandée, NULL si le nom n'existe pas.
     */
    virtual size_t definedNameCount() const =0;
    virtual const DefinedName* definedName(size_t) const =0;
    virtual const DefinedName* definedName(const utf8String_t&) const =0;
};

} // namespace Read
} // namespace Interface
} // namespace XLSX
} // namespace Invoke

#endif  /* invoke_xlsx_workbookReadInterface_hpp */
