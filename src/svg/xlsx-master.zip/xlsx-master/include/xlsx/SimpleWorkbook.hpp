/*!
 * \file        SimpleWorkbook.hpp
 * \author      Invoke - Jean-Christophe PHILIPPE (jcphilippe\@invoke.fr)
 * \date        Novembre 2014
 * \copyright   SA Invoke
 */

#ifndef invoke_xlsx_simpleWorkbook_hpp
#define invoke_xlsx_simpleWorkbook_hpp

#include "xlsx/WorkbookInterface.hpp"
#include "xlsx/WorkbookReadInterface.hpp"
#include "xlsx/WorkbookWriteInterface.hpp"

#include <map>
#include <functional>
#include <unordered_map>
#include <unordered_set>


#if defined(INVOKE_XLSX_LOGS)
#include "xlsx/XlsxDebug.hpp"
#endif


namespace Invoke {
namespace XLSX {
namespace SimpleWorkbook {

/*!
 * \class Hasher
 * \brief Définit un template de base pour les fonctions de hachage
 */
template<class T>
class Hasher;

/*!
 * \class SimpleRichText
 * \brief Définit un texte riche.
 */
class SimpleRichText : public Interface::Read::RichText, public Interface::Write::RichText {
public:
	/*!
	 * \fn size_t runCount() const
	 * \brief Obtenir le nombre de la portion de texte.
	 * \return Le nombre de portion de texte.
	 */
	/*!
	 * \fn const Interface::font_t* runFont(size_t index) const
	 * \brief Obtenir la police de caractères de la portion de texte.
	 * \param index L'index de la portion de texte ciblée (index doit être compris entre 0 et runCount() - 1).
	 * \return La police de caractères de la portion de texte à l'index "index".
	 */
	/*!
	 * \fn const Interface::utf8String_t* runText(size_t index) const
	 * \brief Obtenir le texte de la portion de texte.
	 * \param index L'index de la portion de texte ciblée (index doit être compris entre 0 et runCount() - 1).
	 * \return Le texte de la portion de texte à l'index "index".
	 */
	virtual size_t runCount() const;
	virtual const Interface::font_t* runFont(size_t) const;
	virtual const Interface::utf8String_t* runText(size_t) const;

	/*!
	 * \fn Interface::utf8String_t text() const
	 * \brief Obtenir le texte complet.
	 * \return Le texte.
	 */
	virtual Interface::utf8String_t text() const;

public:
	/*!
	 * \fn void clear()
	 * \brief Effacer le contenu du texte.
	 */
	virtual void clear();

	/*!
	 * \fn void addRun(const Interface::font_t& font, const Interface::utf8String_t& text)
	 * \brief Ajouter une portion de texte.
	 * \param font La police de caractères.
	 * \param text Le texte.
	 */
	virtual void addRun(const Interface::font_t&, const Interface::utf8String_t&);

	/*!
	 * \fn void setText(const Interface::utf8String_t& text)
	 * \brief Assigner un texte avec une police par défaut.
	 * \param text Le texte.
	 */
	virtual void setText(const Interface::utf8String_t&);

public:
	/*!
	 * \fn SimpleRichText()
	 * \brief Constructeur.
	 */
	/*!
	 * \fn SimpleRichText(const SimpleRichText& value)
	 * \brief Constructeur de recopie.
	 * \param value La valeur à recopier.
	 */
	/*!
	 * \fn SimpleRichText& operator =(const SimpleRichText& value)
	 * \brief Opérateur de recopie.
	 * \param value La valeur à recopier.
	 * \return Cette valeur.
	 */
	SimpleRichText();
	SimpleRichText(const SimpleRichText&);
	SimpleRichText& operator =(const SimpleRichText&);

	/*!
	 * \fn ~SimpleRichText()
	 * \brief Destructeur.
	 */
	~SimpleRichText();

private:
	typedef struct {
		Interface::font_t font;
		Interface::utf8SharedString_t text;
	} run_t;
	typedef std::vector<run_t> runs_t;

	runs_t* m_runs;
	Interface::utf8SharedString_t* m_text;


#if defined(INVOKE_XLSX_LOGS)
public:
    size_t log_size() const;
    void log_scan(Debug::Container*) const;
#endif
};

/*!
 * \class SimpleCellValue
 * \brief Définit la valeur d'une cellule.
 */
class SimpleCellValue : public Interface::Read::CellValue, public Interface::Write::CellValue {
public:
    /*!
     * \fn Interface::cellType_t type() const
     * \brief Obtenir le type de cellule.
     * \return Le type de cellule.
     */
    /*!
     * \fn bool boolean() const
     * \brief Obtenir la valeur booléenne de la cellule.
     * \return La valeur booléenne.
     */
    /*!
     * \fn double number() const
     * \brief Obtenir la valeur numérique de la cellule.
     * \return La valeur numérique.
     */
    /*!
     * \fn Interface::utf8String_t string() const
     * \brief Obtenir la valeur chaîne de la cellule.
     * \return La valeur chaîne.
     */
    /*!
     * \fn Interface::cellError_t error() const
     * \brief Obtenir le type d'erreur de la cellule.
     * \return Le type de l'erreur.
     */
    /*!
     * \fn Interface::utf8String_t formula() const
     * \brief Obtenir la formule de calcul de la cellule (au format "natif" d'Excel).
     * \return La formule de calcul.
     */
    virtual Interface::cellType_t type() const;
    virtual bool boolean() const;
    virtual double number() const;
    virtual Interface::utf8String_t string() const;
    virtual Interface::cellError_t error() const;
    virtual Interface::utf8String_t formula() const;

	/*!
	 * \fn const Interface::Read::RichText* text() const
	 * \brief Obtenir le texte contenu dans la cellule.
	 * \return Le texte.
	 */
	virtual const Interface::Read::RichText* text() const;

public:
    /*!
     * \fn void setNull(const Interface::utf8String_t& formula)
     * \brief Assigner la valeur nulle.
     * \param formula La formule de calcul.
     */
    /*!
     * \fn void setBoolean(bool value, const Interface::utf8String_t& formula)
     * \brief Assigner la valeur booléenne de la cellule.
     * \param value La valeur booléenne.
     * \param formula La formule de calcul.
     */
    /*!
     * \fn void setNumber(double value, const Interface::utf8String_t& formula)
     * \brief Assigner la valeur numérique de la cellule.
     * \param value La valeur numérique.
     * \param formula La formule de calcul.
     */
    /*!
     * \fn void setString(const Interface::utf8String_t& value, const Interface::utf8String_t& formula)
     * \brief Assigner la valeur chaîne de la cellule.
     * \param value La valeur chaîne.
     * \param formula La formule de calcul.
     */
    /*!
     * \fn void setError(Interface::cellError_t value, const Interface::utf8String_t& formula)
     * \brief Assigner le type d'erreur de la cellule.
     * \param value Le type d'erreur.
     * \param formula La formule de calcul.
     */
    virtual void setNull(const Interface::utf8String_t& = "");
    virtual void setBoolean(bool, const Interface::utf8String_t& = "");
    virtual void setNumber(double, const Interface::utf8String_t& = "");
    virtual void setString(const Interface::utf8String_t&, const Interface::utf8String_t& = "");
    virtual void setError(Interface::cellError_t, const Interface::utf8String_t& = "");

	/*!
	 * \fn void setText(const Interface::Write::RichText* richtext, const Interface::utf8String_t& formula)
	 * \brief Assigner un texte riche à la cellule.
	 * \param richtext Le texte.
	 * \param formula La formule de calcul.
	 */
	virtual void setText(const Interface::Write::RichText*, const Interface::utf8String_t& = "");

public:
    /*!
     * \fn SimpleCellValue()
     * \brief Constructeur.
     */
    /*!
     * \fn SimpleCellValue(const SimpleCellValue& value)
     * \brief Constructeur de recopie.
     * \param value La valeur à recopier.
     */
    /*!
     * \fn SimpleCellValue& operator =(const SimpleCellValue& value)
     * \brief Opérateur de recopie.
     * \param value La valeur à recopier.
     * \return Cette valeur.
     */
    SimpleCellValue();
    SimpleCellValue(const SimpleCellValue&);
    SimpleCellValue& operator =(const SimpleCellValue&);

    /*!
     * \fn ~SimpleCellValue()
     * \brief Destructeur. 
     */
    ~SimpleCellValue();

    /*!
     * \fn SimpleCellValue(bool value, const Interface::utf8String_t& formula)
     * \brief Constructeur.
     * \param value Valeur booléenne.
     * \param formula La formule de calcul éventuelle attachée à cette cellule. La formule de calcul doit être au format "natif" d'Excel.
     */
    /*!
     * \fn SimpleCellValue(double value, const Interface::utf8String_t& formula)
     * \brief Constructeur.
     * \param value Valeur numérique.
     * \param formula La formule de calcul éventuelle attachée à cette cellule. La formule de calcul doit être au format "natif" d'Excel.
     */
    /*!
     * \fn SimpleCellValue(const Interface::utf8String_t& value, const Interface::utf8String_t& formula)
     * \brief Constructeur.
     * \param value Valeur chaîne.
     * \param formula La formule de calcul éventuelle attachée à cette cellule. La formule de calcul doit être au format "natif" d'Excel.
     */
    /*!
     * \fn SimpleCellValue(Interface::cellError_t value, const Interface::utf8String_t& formula)
     * \brief Constructeur.
     * \param value Le type d'erreur.
     * \param formula La formule de calcul éventuelle attachée à cette cellule. La formule de calcul doit être au format "natif" d'Excel.
     */
	/*!
	 * \fn SimpleCellValue(const SimpleRichText& value, const Interface::utf8String_t& formula)
	 * \brief Constructeur.
	 * \param value Valeur texte riche.
	 * \param formula La formule de calcul éventuelle attachée à cette cellule. La formule de calcul doit être au format "natif" d'Excel.
	 */
	SimpleCellValue(bool, const Interface::utf8String_t& ="");
    SimpleCellValue(double, const Interface::utf8String_t& ="");
    SimpleCellValue(const Interface::utf8String_t&, const Interface::utf8String_t& ="");
    SimpleCellValue(Interface::cellError_t, const Interface::utf8String_t& ="");
	SimpleCellValue(const SimpleRichText&, const Interface::utf8String_t& ="");

private:
    Interface::cellType_t m_type;
    union {
        SimpleRichText* text;
        Interface::utf8SharedString_t* string;
        bool boolean;
        double number;
        Interface::cellError_t error;
    } m_value;

    Interface::utf8SharedString_t* m_formula;


#if defined(INVOKE_XLSX_LOGS)
public:
    size_t log_size() const;
    void log_scan(Debug::Container*) const;
#endif
};

/*!
 * \class SimpleDefinedName
 * \brief Définit un nom de zone
 */
class SimpleDefinedName : public Interface::Read::DefinedName, public Interface::Write::DefinedName {
public:
    /*!
     * \fn Interface::utf8String_t name() const
     * \brief Obtenir le nom de la zone.
     * \return Le nom de la zone.
     */
    virtual Interface::utf8String_t name() const;

    /*!
     * \fn const Coordinates::MultiCellRange& zone() const
     * \brief Obtenir les coordonnées de la zone.
     * \return Les coordonnées de la zone.
     */
    virtual const Coordinates::MultiCellRange& zone() const;

public:
    /*!
     * \fn void setName(const Interface::utf8String_t& name)
     * \brief Assigned le nom de la zone.
     * \param name Le nom de la zone.
     */
    virtual void setName(const Interface::utf8String_t&);

    /*!
     * \fn void setZone(const Coordinates::MultiCellRange& coordinates)
     * \brief Assigner les coordonnées de la zone.
     * \param coordinates Les coordonnées de la zone.
     */
    virtual void setZone(const Coordinates::MultiCellRange&);

public:
    /*!
     * \fn SimpleDefinedName()
     * \brief Constructeur.
     */
    /*!
     * \fn SimpleDefinedName(const SimpleDefinedName& definedName)
     * \brief Constructeur de recopie.
     * \param definedName Nom de zone à recopier.
     */
    /*!
     * \fn SimpleDefinedName& operator =(const SimpleDefinedName& definedName)
     * \brief Opérateur de recopie.
     * \param definedName Nom de zone à recopier.
     * \return Cette zone.
     */
    SimpleDefinedName() = default;
    SimpleDefinedName(const SimpleDefinedName&) = default;
    SimpleDefinedName& operator =(const SimpleDefinedName&) = default;

    /*!
     * \fn SimpleDefinedName(const Interface::utf8String_t& name, const Coordinates::MultiCellRange& zone)
     * \brief Constructeur.
     * \param name Nom de la zone
     * \param zone Zone.
     *
     * Attention, les noms de plage ne sont pas tous valides (cf. Interface::isDefinedNameValid).
     */
    SimpleDefinedName(const Interface::utf8String_t&, const Coordinates::MultiCellRange&);

private:
    Interface::utf8SharedString_t m_name;
    Coordinates::MultiCellRange m_zone;


#if defined(INVOKE_XLSX_LOGS)
public:
    size_t log_size() const;
    void log_scan(Debug::Container*) const;
#endif
};

/*!
 * \class SimplePageHeaderFooter
 * \brief Description des entêtes et pieds de page.
 */
class SimplePageHeaderFooter : public Interface::Read::PageHeaderFooter, public Interface::Write::PageHeaderFooter {
public:
    /*!
     * \fn bool isDifferentFirst() const
     * \brief L'entête et pied de page de la première page sont ils différents des pages suivantes ?
     * \return Vrai si l'entête et le pied de page de la première page sont différents, faux sinon.
     */
    /*!
     * \fn bool isDifferentOddEven() const
     * \brief Les entêtes et pieds de page des pages paires et impaires sont ils différents ?
     * \return Vrai si les entêtes et les pieds de pages des pages paires sont différents des pages impaires, faux sinon.
     */
    virtual bool isDifferentFirst() const;
    virtual bool isDifferentOddEven() const;

    /*!
     * \fn const Interface::utf8String_t* leftFirstHeader() const
     * \brief Obtenir le texte à gauche dans l'entête de la première page.
     * \return Le texte à gauche dans l'entête de la première page, NULL si l'entête de la première page est identique aux autres.
     */
    /*!
     * \fn const Interface::utf8String_t* centerFirstHeader() const
     * \brief Obtenir le texte au centre dans l'entête de la première page.
     * \return Le texte au centre dans l'entête de la première page, NULL si l'entête de la première page est identique aux autres.
     */
    /*!
     * \fn const Interface::utf8String_t* rightFirstHeader() const
     * \brief Obtenir le texte à droite dans l'entête de la première page.
     * \return Le texte à droite dans l'entête de la première page, NULL si l'entête de la première page est identique aux autres.
     */
    /*!
     * \fn const Interface::utf8String_t* leftFirstFooter() const
     * \brief Obtenir le texte à gauche dans le pied de la première page.
     * \return Le texte à gauche dans le pied de la première page, NULL si le pied de la première page est identique aux autres.
     */
    /*!
     * \fn const Interface::utf8String_t* centerFirstFooter() const
     * \brief Obtenir le texte au centre dans l'entête de la première page.
     * \return Le texte au centre dans l'entête de la première page, NULL si l'entête de la première page est identique aux autres.
     */
    /*!
     * \fn const Interface::utf8String_t* rightFirstFooter() const
     * \brief Obtenir le texte à droite dans le pied de la première page.
     * \return Le texte à droite dans le pied de la première page, NULL si le pied de la première page est identique aux autres.
     */
    virtual const Interface::utf8String_t* leftFirstHeader() const;
    virtual const Interface::utf8String_t* centerFirstHeader() const;
    virtual const Interface::utf8String_t* rightFirstHeader() const;
    virtual const Interface::utf8String_t* leftFirstFooter() const;
    virtual const Interface::utf8String_t* centerFirstFooter() const;
    virtual const Interface::utf8String_t* rightFirstFooter() const;

    /*!
     * \fn const Interface::utf8String_t* leftEvenHeader() const
     * \brief Obtenir le texte à gauche dans l'entête des pages impaires.
     * \return Le texte à gauche dans l'entête des pages impaires, NULL si l'entête des pages impaires est identique aux autres.
     */
    /*!
     * \fn const Interface::utf8String_t* centerEvenHeader() const
     * \brief Obtenir le texte au centre dans l'entête des pages impaires.
     * \return Le texte au centre dans l'entête des pages impaires, NULL si l'entête des pages impaires est identique aux autres.
     */
    /*!
     * \fn const Interface::utf8String_t* rightEvenHeader() const
     * \brief Obtenir le texte à droite dans l'entête des pages impaires.
     * \return Le texte à droite dans l'entête des pages impaires, NULL si l'entête des pages impaires est identique aux autres.
     */
    /*!
     * \fn const Interface::utf8String_t* leftEvenFooter() const
     * \brief Obtenir le texte à gauche dans le pied des pages impaires.
     * \return Le texte à gauche dans le pied des pages impaires, NULL si le pied des pages impaires est identique aux autres.
     */
    /*!
     * \fn const Interface::utf8String_t* centerEvenFooter() const
     * \brief Obtenir le texte au centre dans le pied des pages impaires.
     * \return Le texte au centre dans le pied des pages impaires, NULL si le pied des pages impaires est identique aux autres.
     */
    /*!
     * \fn const Interface::utf8String_t* rightEvenFooter() const
     * \brief Obtenir le texte à droite dans le pied des pages impaires.
     * \return Le texte à droite dans le pied des pages impaires, NULL si le pied des pages impaires est identique aux autres.
     */
    virtual const Interface::utf8String_t* leftEvenHeader() const;
    virtual const Interface::utf8String_t* centerEvenHeader() const;
    virtual const Interface::utf8String_t* rightEvenHeader() const;
    virtual const Interface::utf8String_t* leftEvenFooter() const;
    virtual const Interface::utf8String_t* centerEvenFooter() const;
    virtual const Interface::utf8String_t* rightEvenFooter() const;

    /*!
     * \fn Interface::utf8String_t leftHeader() const
     * \brief Obtenir le texte à gauche dans l'entête des pages.
     * \return Le texte à gauche dans l'entête des pages.
     */
    /*!
     * \fn Interface::utf8String_t centerHeader() const
     * \brief Obtenir le texte au centre dans l'entête des pages.
     * \return Le texte au centre dans l'entête des pages.
     */
    /*!
     * \fn Interface::utf8String_t rightHeader() const
     * \brief Obtenir le texte à droite dans l'entête des pages.
     * \return Le texte à droite dans l'entête des pages.
     */
    /*!
     * \fn Interface::utf8String_t leftFooter() const
     * \brief Obtenir le texte à gauche dans le pied des pages.
     * \return Le texte à gauche dans le pied des pages.
     */
    /*!
     * \fn Interface::utf8String_t centerFooter() const
     * \brief Obtenir le texte au centre dans le pied des pages.
     * \return Le texte au centre dans le pied des pages.
     */
    /*!
     * \fn Interface::utf8String_t rightFooter() const
     * \brief Obtenir le texte à droite dans le pied des pages.
     * \return Le texte à droite dans le pied des pages.
     */
    virtual Interface::utf8String_t leftHeader() const;
    virtual Interface::utf8String_t centerHeader() const;
    virtual Interface::utf8String_t rightHeader() const;
    virtual Interface::utf8String_t leftFooter() const;
    virtual Interface::utf8String_t centerFooter() const;
    virtual Interface::utf8String_t rightFooter() const;

public:
    /*!
     * \fn virtual void setFirstHeader(const Interface::utf8String_t& left, const Interface::utf8String_t& center, const Interface::utf8String_t& right)
     * \brief Spécifier l'entête de la première page s'il est différent des autres entêtes.
     * \param left Le texte à gauche.
     * \param center Le texte au centre.
     * \param right Le texte à droite.
     */
    /*!
     * \fn virtual void setFirstFooter(const Interface::utf8String_t& left, const Interface::utf8String_t& center, const Interface::utf8String_t& right)
     * \brief Spécifier le pied de la première page s'il est différent des autres pieds de page.
     * \param left Le texte à gauche.
     * \param center Le texte au centre.
     * \param right Le texte à droite.
     */
    virtual void setFirstHeader(const Interface::utf8String_t&, const Interface::utf8String_t&, const Interface::utf8String_t&);
    virtual void setFirstFooter(const Interface::utf8String_t&, const Interface::utf8String_t&, const Interface::utf8String_t&);

    /*!
     * \fn virtual void setEvenHeader(const Interface::utf8String_t& left, const Interface::utf8String_t& center, const Interface::utf8String_t& right)
     * \brief Spécifier l'entête des pages impaires s'ils sont différents des autres entêtes.
     * \param left Le texte à gauche.
     * \param center Le texte au centre.
     * \param right Le texte à droite.
     */
    /*!
     * \fn virtual void setEvenFooter(const Interface::utf8String_t& left, const Interface::utf8String_t& center, const Interface::utf8String_t& right)
     * \brief Spécifier le pied des pages impaires s'ils sont différents des autres pieds de page.
     * \param left Le texte à gauche.
     * \param center Le texte au centre.
     * \param right Le texte à droite.
     */
    virtual void setEvenHeader(const Interface::utf8String_t&, const Interface::utf8String_t&, const Interface::utf8String_t&);
    virtual void setEvenFooter(const Interface::utf8String_t&, const Interface::utf8String_t&, const Interface::utf8String_t&);

    /*!
     * \fn virtual void setHeader(const Interface::utf8String_t& left, const Interface::utf8String_t& center, const Interface::utf8String_t& right)
     * \brief Spécifier les entêtes de page.
     * \param left Le texte à gauche.
     * \param center Le texte au centre.
     * \param right Le texte à droite.
     */
    /*!
     * \fn virtual void setFooter(const Interface::utf8String_t& left, const Interface::utf8String_t& center, const Interface::utf8String_t& right)
     * \brief Spécifier les pieds de page.
     * \param left Le texte à gauche.
     * \param center Le texte au centre.
     * \param right Le texte à droite.
     */
    virtual void setHeader(const Interface::utf8String_t&, const Interface::utf8String_t&, const Interface::utf8String_t&);
    virtual void setFooter(const Interface::utf8String_t&, const Interface::utf8String_t&, const Interface::utf8String_t&);

public:
    /*!
     * \fn SimplePageHeaderFooter()
     * \brief Constructeur.
     */
    /*!
     * \fn SimplePageHeaderFooter(const SimplePageHeaderFooter& pageHeaderFooter)
     * \brief Constructeur de recopie.
     * \param pageHeaderFooter Entêtes et pieds de page à recopier.
     */
    /*!
     * \fn SimplePageHeaderFooter& operator =(const SimplePageHeaderFooter& pageHeaderFooter)
     * \brief Opérateur de recopie.
     * \param pageHeaderFooter Entêtes et pieds de page à recopier.
     * \return Ces entêtes et pieds de page.
     */
    SimplePageHeaderFooter();
    SimplePageHeaderFooter(const SimplePageHeaderFooter&);
    SimplePageHeaderFooter& operator =(const SimplePageHeaderFooter&);

    /*!
     * \fn ~SimplePageHeaderFooter()
     * \brief Destructeur.
     */
    virtual ~SimplePageHeaderFooter();

private:
    Interface::utf8String_t* m_firstHeader;
    Interface::utf8String_t* m_firstFooter;

    Interface::utf8String_t* m_evenHeader;
    Interface::utf8String_t* m_evenFooter;

    Interface::utf8String_t m_header[3];
    Interface::utf8String_t m_footer[3];


#if defined(INVOKE_XLSX_LOGS)
public:
    size_t log_size() const;
    void log_scan(Debug::Container*) const;
#endif
};

/*!
 * \class SimplePageSetting
 * \brief Définit les paramètres d'impression d'une feuille de calcul.
 */
class SimplePageSetting : public Interface::Read::PageSetting, public Interface::Write::PageSetting {
public:
    /*!
     * \fn const Coordinates::MultiCellRange* printArea() const
     * \brief Obtenir les plages de cellules définissant les zones d'impression.
     * \return Une série de coordonnées de plage de cellules.
     */
    virtual const Coordinates::MultiCellRange* printArea() const;

    /*!
     * \fn const Coordinates::ColumnRowRange* headerColumns() const
     * \brief Obtenir les colonnes d'entête colonne.
     * \return Les coordonnées des colonnes d'entête.
     */
    /*!
     * \fn const Coordinates::ColumnRowRange* headerRows() const
     * \brief Obtenir les lignes d'entête.
     * \return Les coordonnées des lignes d'entête.
     */
    virtual const Coordinates::ColumnRowRange* headerColumns() const;
    virtual const Coordinates::ColumnRowRange* headerRows() const;

    /*!
     * \fn Interface::pageOrientation_t pageOrientation() const
     * \brief Obtenir l'orientation des pages.
     * \return L'orientation des pages.
     */
    virtual Interface::pageOrientation_t pageOrientation() const;

    /*!
     * \fn unsigned int fitToWidth() const
     * \brief Obtenir le nombre de pages sur lequel effectuer l'ajustement horizontal. 0 = pas d'ajustement.
     * \return Le nombre de page sur lequel est effectué le calcul de l'ajustement horizontal.
     */
    /*!
     * \fn unsigned int fitToHeight() const
     * \brief Obtenir le nombre de pages sur lequel effectuer l'ajustement vertical. 0 = pas d'ajustement.
     * \return Le nombre de page sur lequel est effectué le calcul de l'ajustement vertical.
     */
    virtual unsigned int fitToWidth() const;
    virtual unsigned int fitToHeight() const;

    /*!
     * \fn const unsigned short* scale() const
     * \brief Obtenir l'échelle d'impression en % de la taille normale [10, 400].
     * \return L'échelle d'impression qui est comprise entre 10% et 400% inclus ou NULL si l'échelle n'est pas assignée.
     */
    virtual const unsigned short* scale() const;

    /*!
     * \fn const Interface::Read::PageHeaderFooter* pageHeaderFooter() const
     * \brief Obtenir les entêtes et les pieds de page.
     * \return Les entêtes et les pieds de page, NULL s'il n'y en a pas.
     */
    virtual const Interface::Read::PageHeaderFooter* pageHeaderFooter() const;

public:
    /*!
     * \fn void setPrintArea(const Coordinates::MultiCellRange* printArea)
     * \brief Assigner la plage d'impression.
     * \param printArea La plage d'impression.
     */
    virtual void setPrintArea(const Coordinates::MultiCellRange*);

    /*!
     * \fn void setHeader(const Coordinates::ColumnRowRange* range)
     * \brief Assigner les colonnes/lignes d'entête.
     * \param range Les coordonnées des colonnes/lignes d'entête. NULL = pas d'entête.
     */
    virtual void setHeader(const Coordinates::ColumnRowRange*);

    /*!
     * \fn void setPageOrientation(Interface::pageOrientation_t orientation)
     * \brief Assigner l'orientation des pages d'impression.
     * \param orientation L'orientation des pages.
     */
    virtual void setPageOrientation(Interface::pageOrientation_t);

    /*!
     * \fn void setFitToWidth(unsigned int pages)
     * \brief Assigner le nombre de pages à utiliser pour l'alignement horizontal. 0 = pas d'alignement.
     * \param pages Le nombre de pages.
     */
    /*!
     * \fn void setFitToHeight(unsigned int pages)
     * \brief Assigner le nombre de pages à utiliser pour l'alignement vertical. 0 = pas d'alignement.
     * \param pages Le nombre de pages.
     */
    virtual void setFitToWidth(unsigned int);
    virtual void setFitToHeight(unsigned int);

    /*!
     * \fn void setScale(const unsigned short* scale)
     * \brief Assigner l'échelle en %. Assigner une échelle invalide les ajustements.
     * \param scale L'échelle exprimée en % de la taille normale [10, 400] ou NULL pour supprimer l'échelle.
     */
    virtual void setScale(const unsigned short*);

    /*!
     * \fn PageHeaderFooter* createPageHeaderFooter() const
     * \brief Créer des entêtes et des pieds de page.
     * \return Les entêtes et les pieds de page.
     */
    /*!
     * \fn void setPageHeaderFooter(const Interface::Write::PageHeaderFooter& pageHeaderFooter)
     * \brief Assigner les entêtes et les pieds de page.
     * \param pageHeaderFooter Les entêtes et les pieds de page.
     */
    virtual Interface::Write::PageHeaderFooter* createPageHeaderFooter() const;
    virtual void setPageHeaderFooter(const Interface::Write::PageHeaderFooter&);

public:
    /*!
     * \fn SimplePageSetting()
     * \brief Constructeur.
     */
    /*!
     * \fn SimplePageSetting(const SimplePageSetting& pageSetting)
     * \brief Constructeur de recopie.
     * \param pageSetting Configuration à recopier.
     */
    /*!
     * \fn SimplePageSetting& operator =(const SimplePageSetting& pageSetting)
     * \brief Opérateur de recopie.
     * \param pageSetting Configuration à recopier.
     * \return Cette configuration.
     */
    SimplePageSetting();
    SimplePageSetting(const SimplePageSetting&);
    SimplePageSetting& operator =(const SimplePageSetting&);

    /*!
     * \fn ~SimplePageSetting()
     * \brief Destructeur.
     */
    ~SimplePageSetting();

private:
    Coordinates::MultiCellRange* m_printArea;
    Coordinates::ColumnRowRange* m_headerColumns;
    Coordinates::ColumnRowRange* m_headerRows;
    Interface::pageOrientation_t m_pageOrientation;
    unsigned int m_fitToWidth;
    unsigned int m_fitToHeight;
    unsigned short* m_scale;
    SimplePageHeaderFooter* m_pageHeaderFooter;


#if defined(INVOKE_XLSX_LOGS)
public:
    size_t log_size() const;
    void log_scan(Debug::Container*) const;
#endif
};

/*!
 * \class SimpleCellFormat
 * \brief Définit un format de cellule.
 */
class SimpleCellFormat : public Interface::Read::CellFormat, public Interface::Write::CellFormat {
public:
    /*!
     * \fn Interface::utf8String_t fontName() const
     * \brief Obtenir le nom de la police de caractères.
     * \return Le nom de la police de caractères.
     */
    /*!
     * \fn unsigned short fontSize() const
     * \brief Obtenir la taille de la police (en point).
     * \return La taille de la police en point.
     */
    /*!
     * \fn Interface::color_t fontColor() const
     * \brief Obtenir la couleur de la police.
     * \return La couleur de la police au format RGB.
     */
    /*!
     * \fn bool isFontBolded() const
     * \brief La police est-elle grasse ?
     * \return Vrai si la police est grasse, faux sinon.
     */
    /*!
     * \fn bool isFontItalicized() const
     * \brief La police est-elle en italique ?
     * \return Vrai si la police est en italique, faux sinon.
     */
    /*!
     * \fn bool isFontUnderlined() const
     * \brief La police est-elle soulignée ?
     * \return Vrai si la police est soulignée, faux sinon.
     */
    virtual Interface::utf8String_t fontName() const;
    virtual unsigned short fontSize() const;
    virtual Interface::color_t fontColor() const;
    virtual bool isFontBolded() const;
    virtual bool isFontItalicized() const;
    virtual bool isFontUnderlined() const;

    /*!
     * \fn Interface::utf8String_t numberFormat() const
     * \brief Obtenir la chaîne de format de nombre (ex: #,##0.0;(#,##0.0);).
     * \return La chaîne de format de nombre.
     */
    /*!
     * \fn unsigned short builtInNumberFormatId() const
     * \brief Obtenir l'identifiant du format interne à Excel. Si la chaîne de format (fonction numberFormat) est assignée, cet identifiant n'est pas pris en compte.
     * \return Un identifiant compris entre [0, 164[.
     */
    virtual Interface::utf8String_t numberFormat() const;
    virtual unsigned short builtInNumberFormatId() const;

    /*!
     * \fn Interface::patternStyle_t patternStyle() const
     * \brief Obtenir le style du motif.
     * \return Le style du motif.
     */
    /*!
     * \fn Interface::color_t foregroundColor() const
     * \brief Obtenir la couleur du motif.
     * \return La couleur du motif au format RGB.
     */
    /*!
     * \fn Interface::color_t backgroundColor() const
     * \brief Obtenir la couleur d'arrière plan.
     * \return La couleur d'arrière plan au format RGB.
     */
    virtual Interface::patternStyle_t patternStyle() const;
    virtual Interface::color_t foregroundColor() const;
    virtual Interface::color_t backgroundColor() const;

    /*!
     * \fn bool isBorderVisible(Interface::border_t border) const
     * \brief La bordure est-elle visible ?
     * \param border La bordure concernée.
     * \return Vrai si la bordure est visible, faux sinon.
     */
    /*!
     * \fn Interface::borderStyle_t borderStyle(Interface::border_t border) const
     * \brief Obtenir le style de la bordure.
     * \param border La bordure concernée.
     * \return Le style de la bordure.
     */
    /*!
     * \fn Interface::color_t borderColor(Interface::border_t border) const
     * \brief Obtenir la couleur de la bordure.
     * \param border La bordure concernée.
     * \return La couleur RGB de la bordure.
     */
    virtual bool isBorderVisible(Interface::border_t) const;
    virtual Interface::borderStyle_t borderStyle(Interface::border_t) const;
    virtual Interface::color_t borderColor(Interface::border_t) const;

    /*!
     * \fn Interface::horizontalAlignment_t horizontalAlignment() const
     * \brief Obtenir l'alignement horizontal de la cellule.
     * \return L'alignement horizontal de la cellule.
     */
    virtual Interface::horizontalAlignment_t horizontalAlignment() const;

    /*!
     * \fn Interface::verticalAlignment_t verticalAlignment() const
     * \brief Obtenir l'alignement vertical de la cellule.
     * \return L'alignement vertical de la cellule.
     */
    virtual Interface::verticalAlignment_t verticalAlignment() const;

    /*!
     * \fn unsigned short textIndent() const
     * \brief Obtenir la valeur du retrait du texte.
     * \return La valeur du retrait du texte.
     */
    virtual unsigned short textIndent() const;

    /*!
     * \fn short textRotation() const
     * \brief Obtenir l'angle de rotation du texte.
     * \return L'angle de rotation du texte. Il est exprimé en degré et doit être compris entre [-90°, 90°].
     */
    virtual short textRotation() const;

    /*!
     * \fn bool wrapText() const
     * \brief Le texte doit-il être coupé en fonction de la taille de la cellule ?
     * \return Vrai si le format autorise les retours à la ligne automatique, faux sinon.
     */
    virtual bool wrapText() const;

public:
    /*!
     * \fn void setFontName(const Interface::utf8String_t& name)
     * \brief Assigner le nom d'une police de caractères au format.
     * \param name Le nom de la police de caractères.
     */
    /*!
     * \fn void setFontSize(unsigned short size)
     * \brief Assigner la taille (en point) de la police de caractères au format.
     * \param size La taille de la police de caractères.
     */
    /*!
     * \fn void setFontColor(Interface::color_t color)
     * \brief Assigner la couleur de la police de caractères au format.
     * \param color La couleur de la police de caractères.
     */
    /*!
     * \fn void setFontStyle(bool bold, bool italic, bool underline)
     * \brief Assigner le style de la police de caractères au format.
     * \param bold Vrai si la police de caractères doit être grasse, faux sinon.
     * \param italic Vrai si la police de caractères doit être italique, faux sinon.
     * \param underline Vrai si la police de caractères doit être soulignée, faux sinon.
     */
    /*!
     * \fn void setFont(const Interface::utf8String_t& name, unsigned short size, Interface::color_t color, bool bold, bool italic, bool underline)
     * \brief Assigner une police de caractères au format.
     * \param name Le nom de la police de caractères.
     * \param size La taille (en point) de la police de caractères.
     * \param color La couleur de la police de caractères.
     * \param bold Vrai si la police de caractères doit être grasse, faux sinon.
     * \param italic Vrai si la police de caractères doit être italique, faux sinon.
     * \param underline Vrai si la police de caractères doit être soulignée, faux sinon.
     */
    virtual void setFontName(const Interface::utf8String_t&);
    virtual void setFontSize(unsigned short);
    virtual void setFontColor(Interface::color_t);
    virtual void setFontStyle(bool, bool, bool);
    virtual void setFont(const Interface::utf8String_t&, unsigned short, Interface::color_t, bool, bool, bool);

    /*!
     * \fn void setNumberFormat(const Interface::utf8String_t& numberFormat)
     * \brief Assigner la chaîne de format des cellules.
     * \param numberFormat La chaîne de format des cellules (ex: #,##0.00).
     */
    /*!
     * \fn void setBuiltInNumberFormatId(unsigned short id)
     * \brief Assigner un format prédéfini à des cellules (cf. documentation de la fonction "Interface::Read::CellFormat::builtInNumberFormatId").
     * \param id Un identifiant compris entre [0, 164[.
     */
    virtual void setNumberFormat(const Interface::utf8String_t&);
    virtual void setBuiltInNumberFormatId(unsigned short);

    /*!
     * \fn void setPatternStyle(Interface::patternStyle_t style)
     * \brief Assigner le style du motif.
     * \param style Le style du motif.
     */
    /*!
     * \fn void setForegroundColor(Interface::color_t color)
     * \brief Assigner la couleur du motif.
     * \param color La couleur du motif au format 0xAARRGGBB (AA = alpha, RR = rouge, GG = vert et BB = bleu).
     */
    /*!
     * \fn void setBackgroundColor(Interface::color_t color)
     * \brief Assigner la couleur d'arrière plan.
     * \param color La couleur d'arrière plan au format 0xAARRGGBB (AA = alpha, RR = rouge, GG = vert et BB = bleu).
     */
    /*!
     * \fn void setSolidBackColor(Interface::color_t color)
     * \brief Assigner un motif solide de la couleur spécifié.
     * \param color La couleur du motif au format 0xAARRGGBB (AA = alpha, RR = rouge, GG = vert et BB = bleu).
     */
    virtual void setPatternStyle(Interface::patternStyle_t);
    virtual void setForegroundColor(Interface::color_t);
    virtual void setBackgroundColor(Interface::color_t);

    virtual void setSolidBackColor(Interface::color_t);

    /*!
     * \fn void setBorderVisible(Interface::border_t border, bool visible)
     * \brief Rendre une bordure visible ou invisible.
     * \param border La bordure à modifier.
     * \param visible Vrai pour afficher la bordure, faux sinon.
     */
    /*!
     * \fn void setBorderStyle(Interface::border_t border, Interface::borderStyle_t style)
     * \brief Assigner un style de bordure.
     * \param border La bordure à modifier.
     * \param style Le style de trait à assigner.
     */
    /*!
     * \fn void setBorderColor(Interface::border_t border, Interface::color_t color)
     * \brief Assigner une couleur de bordure.
     * \param border La bordure à modifier.
     * \param color La couleur de bordure à assigner.
     */
    virtual void setBorderVisible(Interface::border_t, bool);
    virtual void setBorderStyle(Interface::border_t, Interface::borderStyle_t);
    virtual void setBorderColor(Interface::border_t, Interface::color_t);

    /*!
     * \fn void setHorizontalAlignment(Interface::horizontalAlignment_t alignment)
     * \brief Assigner l'alignement horizontal
     * \param alignment L'alignement à assigner.
     */
    /*!
     * \fn void setVerticalAlignment(Interface::verticalAlignment_t alignment)
     * \brief Assigner l'alignement vertical
     * \param alignment L'alignement à assigner.
     */
    /*!
     * \fn void setTextIndent(unsigned short indent)
     * \brief Assigner le retrait du texte.
     * \param indent Le retrait du texte.
     */
    virtual void setHorizontalAlignment(Interface::horizontalAlignment_t);
    virtual void setVerticalAlignment(Interface::verticalAlignment_t);
    virtual void setTextIndent(unsigned short);

    /*!
     * \fn void setTextRotation(short angle)
     * \brief Assigner l'angle de rotation du contenu de la cellule. Il est exprimé en degré et doit être compris entre [-90°, 90°].
     * \param angle L'angle de rotation en degré.
     */
    virtual void setTextRotation(short);

    /*!
     * \fn void setWrapText(bool wrap)
     * \brief Assigner le renvoi à la ligne automatique.
     * \param wrap Vrai pour un renvoi automatique, faux sinon.
     */
    virtual void setWrapText(bool);

public:
    /*!
     * \fn SimpleCellFormat()
     * \brief Constructeur.
     */
    /*!
     * \fn SimpleCellFormat(const Interface::Read::CellFormat& format)
     * \brief Constructeur de recopie. DELETE.
     * \param format Format à recopier.
     */
    SimpleCellFormat();
    SimpleCellFormat(const Interface::Read::CellFormat&) = delete;

    /*!
     * \fn SimpleCellFormat(const Interface::Read::CellFormat* format)
     * \brief Constructeur de recopie.
     * \param format Format à recopier.
     */
    SimpleCellFormat(const Interface::Read::CellFormat*);

    /*!
     * \fn bool operator ==(const SimpleCellFormat& format) const
     * \brief Opérateur "égale à".
     * \param format Format à comparer.
     * \return Vrai si cette instance est égale à celle passée en paramètre, faux sinon.
     */
    bool operator ==(const SimpleCellFormat&) const;

    /*!
     * \fn std::string stringCode() const
     * \brief Calculer une chaîne représentative du format.
     * \return Une chaîne de caractères représentative du format.
     */
    std::string stringCode() const;

private:
    Interface::utf8SharedString_t m_fontName;
    unsigned short m_fontSize;
    Interface::color_t m_fontColor;
    bool m_fontBold, m_fontItalic, m_fontUnderline;
    Interface::utf8SharedString_t m_numberFormat;
    unsigned short m_builtInNumFmtId;
    Interface::patternStyle_t m_patternStyle;
    Interface::color_t m_foreColor;
    Interface::color_t m_backColor;
    bool m_borderVisible[6];
    Interface::borderStyle_t m_borderStyle[6];
    Interface::color_t m_borderColor[6];
    Interface::horizontalAlignment_t m_horizontalAlignment;
    Interface::verticalAlignment_t m_verticalAlignment;
    unsigned short m_indent;
    short m_rotation;
    bool m_wrap;


#if defined(INVOKE_XLSX_LOGS)
public:
    size_t log_size() const;
    void log_scan(Debug::Container*) const;
#endif
};

/*!
 * \class Hasher<SimpleCellFormat>
 * \brief Foncteur pour le hachage des formats.
 */
template<>
class Hasher<SimpleCellFormat> {
public:
    /*!
     * \fn unsigned long operator()(const SimpleCellFormat& format) const
     * \brief Fonction de hachage.
     * \param format Le format à hacher.
     * \return Le code de hachage.
     */
    unsigned long operator()(const SimpleCellFormat&) const;
};

/*!
 * \class SimpleDifferentialCellFormat
 * \brief Définit un format différentiel (utilisé pour les formats conditionnels).
 */
class SimpleDifferentialCellFormat : public Interface::Read::DifferentialCellFormat, public Interface::Write::DifferentialCellFormat {
public:
    /*!
     * \fn const Interface::color_t* fontColor() const
     * \brief Obtenir la couleur de la police.
     * \return La couleur de la police au format RGB ou NULL si cette propriété n'a pas été surchargée.
     */
    /*!
     * \fn const bool* isFontBolded() const
     * \brief La police est-elle grasse ?
     * \return Vrai si la police est grasse, faux sinon ou NULL si cette propriété n'a pas été surchargée.
     */
    /*!
     * \fn const bool* isFontItalicized() const
     * \brief La police est-elle en italic ?
     * \return Vrai si la police est en italic, faux sinon ou NULL si cette propriété n'a pas été surchargée.
     */
    /*!
     * \fn const bool* isFontUnderlined() const
     * \brief La police est-elle soulignée ?
     * \return Vrai si la police est soulignée, faux sinon ou NULL si cette propriété n'a pas été surchargée.
     */
    virtual const Interface::color_t* fontColor() const;
    virtual const bool* isFontBolded() const;
    virtual const bool* isFontItalicized() const;
    virtual const bool* isFontUnderlined() const;

    /*!
     * \fn const Interface::utf8String_t* numberFormat() const
     * \brief Obtenir la chaîne de format de nombre (ex: #,##0.0;(#,##0.0);).
     * \return La chaîne de format de nombre ou NULL si cette propriété n'a pas été surchargée.
     */
    /*!
     * \fn const unsigned short* builtInNumberFormatId() const
     * \brief Obtenir l'identifiant du format interne à Excel. Si la chaîne de format (fonction numberFormat) est assignée, cet identifiant n'est pas pris en compte.
     * \return Un identifiant compris entre [0, 164[ ou NULL si cette propriété n'a pas été surchargée.
     *
     * (cf. documentation de la fonction "Interface::Read::CellFormat::builtInNumberFormatId").
     */
    virtual const Interface::utf8String_t* numberFormat() const;
    virtual const unsigned short* builtInNumberFormatId() const;

    /*!
     * \fn const Interface::patternStyle_t* patternStyle() const
     * \brief Obtenir le style du motif.
     * \return Le style du motif ou NULL si cette propriété n'a pas été surchargée.
     */
    /*!
     * \fn const Interface::color_t* foregroundColor() const
     * \brief Obtenir la couleur du motif.
     * \return La couleur du motif au format RGB ou NULL si cette propriété n'a pas été surchargée.
     */
    /*!
     * \fn const Interface::color_t* backgroundColor() const
     * \brief Obtenir la couleur d'arrière plan.
     * \return La couleur d'arrière plan au format RGB ou NULL si cette propriété n'a pas été surchargée.
     */
    virtual const Interface::patternStyle_t* patternStyle() const;
    virtual const Interface::color_t* foregroundColor() const;
    virtual const Interface::color_t* backgroundColor() const;

    /*!
     * \fn const bool* isBorderVisible(Interface::border_t border) const
     * \brief La bordure est-elle visible ?
     * \param border La bordure concernée.
     * \return Vrai si la bordure est visible, faux sinon ou NULL si cette propriété n'a pas été surchargée.
     */
    /*!
     * \fn const Interface::borderStyle_t* borderStyle(Interface::border_t border) const
     * \brief Obtenir le style de la bordure.
     * \param border La bordure concernée.
     * \return Le style de la bordure ou NULL si cette propriété n'a pas été surchargée.
     */
    /*!
     * \fn const Interface::color_t* borderColor(Interface::border_t border) const
     * \brief Obtenir la couleur de la bordure.
     * \param border La bordure concernée.
     * \return La couleur RGB de la bordure ou NULL si cette propriété n'a pas été surchargée.
     */
    virtual const bool* isBorderVisible(Interface::border_t) const;
    virtual const Interface::borderStyle_t* borderStyle(Interface::border_t) const;
    virtual const Interface::color_t* borderColor(Interface::border_t) const;

public:
    /*!
     * \fn void setFontColor(Interface::color_t color)
     * \brief Surcharger la propriété "couleur de police".
     * \param color La nouvelle valeur de la propriété.
     */
    /*!
     * \fn void setFontBold(bool bold)
     * \brief Surcharger la propriété "police grasse".
     * \param bold La nouvelle valeur de la propriété.
     */
    /*!
     * \fn void setFontItalic(bool italic)
     * \brief Surcharger la propriété "police italique".
     * \param italic La nouvelle valeur de la propriété.
     */
    /*!
     * \fn void setFontUnderline(bool underline)
     * \brief Surcharger la propriété "police soulignée".
     * \param underline La nouvelle valeur de la propriété.
     */
    /*!
     * \fn void unsetFontColor()
     * \brief Annuler la surcharge.
     */
    /*!
     * \fn void unsetFontBold()
     * \brief Annuler la surcharge.
     */
    /*!
     * \fn void unsetFontItalic()
     * \brief Annuler la surcharge.
     */
    /*!
     * \fn void unsetFontUnderline()
     * \brief Annuler la surcharge.
     */
    virtual void setFontColor(Interface::color_t);
    virtual void setFontBold(bool);
    virtual void setFontItalic(bool);
    virtual void setFontUnderline(bool);
    virtual void unsetFontColor();
    virtual void unsetFontBold();
    virtual void unsetFontItalic();
    virtual void unsetFontUnderline();

    /*!
     * \fn void setNumberFormat(const Interface::utf8String_t& numberFormat)
     * \brief Surcharger la propriété "format de nombre".
     * \param numberFormat La nouvelle valeur de la propriété.
     */
    /*!
     * \fn void setBuildInNumberFormatId(unsigned short numberFormatId)
     * \brief Surcharger la propriété "identifiant du format de nombre interne à Excel". Si la chaîne de format (fonction numberFormat) est assignée, cet identifiant n'est pas pris en compte.
     * \param numberFormatId La nouvelle valeur de la propriété comprise entre [0, 164[.
     *
     * (cf. documentation de la fonction "Interface::Read::CellFormat::builtInNumberFormatId").
     */
    /*!
     * \fn void unsetNumberFormat()
     * \brief Annuler la surcharge.
     */
    /*!
     * \fn void unsetBuildInNumberFormatId()
     * \brief Annuler la surcharge.
     */
    virtual void setNumberFormat(const Interface::utf8String_t&);
    virtual void setBuildInNumberFormatId(unsigned short);
    virtual void unsetNumberFormat();
    virtual void unsetBuildInNumberFormatId();

    /*!
     * \fn void setPatternStyle(Interface::patternStyle_t style)
     * \brief Surcharger la propriété "style du motif".
     * \param style Le style du motif.
     */
    /*!
     * \fn void unsetPatternStyle()
     * \brief Annuler la surcharge.
     */
    /*!
     * \fn void setForegroundColor(Interface::color_t color)
     * \brief Surcharger la propriété "couleur du motif".
     * \param color La couleur du motif au format 0xAARRGGBB (AA = alpha, RR = rouge, GG = vert et BB = bleu).
     */
    /*!
     * \fn void unsetForegroundColor()
     * \brief Annuler la surcharge.
     */
    /*!
     * \fn void setBackgroundColor(Interface::color_t color)
     * \brief Surcharger la propriété "couleur d'arrière plan".
     * \param color La couleur d'arrière plan au format 0xAARRGGBB (AA = alpha, RR = rouge, GG = vert et BB = bleu).
     */
    /*!
     * \fn void unsetBackgroundColor()
     * \brief Annuler la surcharge.
     */
    /*!
     * \fn void setSolidBackColor(Interface::color_t color)
     * \brief Assigner un motif solide de la couleur spécifié.
     * \param color La couleur du motif au format 0xAARRGGBB (AA = alpha, RR = rouge, GG = vert et BB = bleu).
     */
    virtual void setPatternStyle(Interface::patternStyle_t);
    virtual void unsetPatternStyle();
    virtual void setForegroundColor(Interface::color_t);
    virtual void unsetForegroundColor();
    virtual void setBackgroundColor(Interface::color_t);
    virtual void unsetBackgroundColor();

    virtual void setSolidBackColor(Interface::color_t);

    /*!
     * \fn void setBorderVisible(Interface::border_t border, bool visible)
     * \brief Surcharger la propriété "bordure visible".
     * \param border La bordure concernée.
     * \param visible La nouvelle valeur de la propriété.
     */
    /*!
     * \fn void setBorderStyle(Interface::border_t border, Interface::borderStyle_t style)
     * \brief Surcharger la propriété "style de bordure".
     * \param border La bordure concernée.
     * \param style La nouvelle valeur de la propriété.
     */
    /*!
     * \fn void setBorderColor(Interface::border_t border, Interface::color_t color)
     * \brief Surcharger la propriété "couleur de bordure".
     * \param border La bordure concernée.
     * \param color La nouvelle valeur de la propriété.
     */
    /*!
     * \fn void unsetBorderVisible(Interface::border_t border)
     * \brief Annuler la surcharge.
     * \param border La bordure concernée.
     */
    /*!
     * \fn void unsetBorderStyle(Interface::border_t border)
     * \brief Annuler la surcharge.
     * \param border La bordure concernée.
     */
    /*!
     * \fn void unsetBorderColor(Interface::border_t border)
     * \brief Annuler la surcharge.
     * \param border La bordure concernée.
     */
    virtual void setBorderVisible(Interface::border_t, bool);
    virtual void setBorderStyle(Interface::border_t, Interface::borderStyle_t);
    virtual void setBorderColor(Interface::border_t, Interface::color_t);
    virtual void unsetBorderVisible(Interface::border_t);
    virtual void unsetBorderStyle(Interface::border_t);
    virtual void unsetBorderColor(Interface::border_t);

public:
    /*!
     * \fn SimpleDifferentialCellFormat()
     * \brief Constructeur.
     */
    /*!
     * \fn SimpleDifferentialCellFormat(const SimpleDifferentialCellFormat& diffFormat)
     * \brief Constructeur de recopie.
     * \param diffFormat Le format differentiel à recopier.
     */
    /*!
     * \fn SimpleDifferentialCellFormat& operator =(const SimpleDifferentialCellFormat& diffFormat)
     * \brief Opérateur d'assignation.
     * \param diffFormat Le format à assigner.
     * \return Ce format différentiel.
     */
    SimpleDifferentialCellFormat();
    SimpleDifferentialCellFormat(const SimpleDifferentialCellFormat&);
    SimpleDifferentialCellFormat& operator =(const SimpleDifferentialCellFormat&);

    /*!
     * \fn ~SimpleDifferentialCellFormat()
     * \brief Destructeur.
     */
    ~SimpleDifferentialCellFormat();

private:
    const Interface::color_t* m_fontColor;
    const bool* m_fontBold;
    const bool* m_fontItalic;
    const bool* m_fontUnderline;

    const Interface::utf8String_t* m_numberFormat;
    const unsigned short* m_buildInNumberFormatId;

    const Interface::patternStyle_t* m_patternStyle;
    const Interface::color_t* m_foregroundColor;
    const Interface::color_t* m_backgroundColor;

    const bool* m_borderVisible[6];
    const Interface::borderStyle_t* m_borderStyle[6];
    const Interface::color_t* m_borderColor[6];


#if defined(INVOKE_XLSX_LOGS)
public:
    size_t log_size() const;
    void log_scan(Debug::Container*) const;
#endif
};

/*!
 * \class SimpleConditionalFormatting
 * \brief Définit un format conditionnel.
 */
class SimpleConditionalFormatting : public Interface::Read::ConditionalFormatting, public Interface::Write::ConditionalFormatting {
public:
    /*!
     * \fn const Interface::Read::DifferentialCellFormat* format() const
     * \brief Obtenir le format.
     * \return Le format à appliquer si la condition est vraie.
     */
    virtual const Interface::Read::DifferentialCellFormat* format() const;

    /*!
     * \fn Interface::utf8String_t formula() const
     * \brief Obtenir la condition.
     * \return La condition au format "natif" Excel.
     */
    virtual Interface::utf8String_t formula() const;

    /*!
     * \fn const Coordinates::MultiCellRange& reference() const
     * \brief Les coordonnées des plages de cellules impactées.
     * \return Les coordonnées des plages de cellules impactées.
     */
    virtual const Coordinates::MultiCellRange& reference() const;

public:
    /*!
     * \fn void setFormat(const Interface::Write::DifferentialCellFormat& format)
     * \brief Assigner le format différentiel.
     * \param format Le format différentiel à appliquer si la condition est vraie.
     */
    virtual void setFormat(const Interface::Write::DifferentialCellFormat&);

    /*!
     * \fn void setFormula(const Interface::utf8String_t& formula)
     * \brief Assigner la condition.
     * \param formula La condition (Elle ne commence pas par "=" et est au format "natif" Excel).
     */
    virtual void setFormula(const Interface::utf8String_t&);

    /*!
     * \fn void setReference(const Coordinates::MultiCellRange& reference)
     * \brief Assigner la référence.
     * \param reference La référence sur laquelle s'applique le format si la condition est vraie. Les références aux worksheets sont ignorées (un format conditionnel n'agit que sur une feuille).
     */
    virtual void setReference(const Coordinates::MultiCellRange&);

public:
    /*!
     * \fn SimpleConditionalFormatting()
     * \brief Constructeur.
     */
    /*!
     * \fn SimpleConditionalFormatting(const SimpleConditionalFormatting& conditionalFormatting)
     * \brief Constructeur de recopie.
     * \param conditionalFormatting Le format conditionnel à recopier.
     */
    /*!
     * \fn SimpleConditionalFormatting& operator=(const SimpleConditionalFormatting& conditionalFormatting)
     * \brief Opérateur de recopie.
     * \param conditionalFormatting Le format conditionnel à recopier.
     * \return Ce format conditionnel.
     */
    SimpleConditionalFormatting() = default;
    SimpleConditionalFormatting(const SimpleConditionalFormatting&) = default;
    SimpleConditionalFormatting& operator=(const SimpleConditionalFormatting&) = default;

private:
    SimpleDifferentialCellFormat m_format;
    Interface::utf8SharedString_t m_formula;
    Coordinates::MultiCellRange m_reference;


#if defined(INVOKE_XLSX_LOGS)
public:
    size_t log_size() const;
    void log_scan(Debug::Container*) const;
#endif
};

/*!
 * \class SimpleValidation
 * \brief Définit une règle de validation de données.
 */

#if defined(_WIN32)
#pragma warning(disable: 4250)  // sur les conseils de MSDN...
#endif

class SimpleValidation : virtual public Interface::Read::Validation, virtual public Interface::Write::Validation {
public:
    /*!
     * \fn const Coordinates::MultiCellRange& reference() const
     * \brief Obtenir les coordonnées des plages de cellules impactées.
     * \return Les coordonnées des plages de cellules impactées.
     */
    virtual const Coordinates::MultiCellRange& reference() const;

    /*!
     * \fn bool isBlankAllowed() const
     * \brief Les valeurs vides sont-elles autorisées ?
     * \return Vrai si elles sont autorisées, faux sinon.
     */
    virtual bool isBlankAllowed() const;

    /*!
     * \fn bool isPromptShown() const
     * \brief Le texte de description est-il affiché ?
     * \return Vrai si il est affiché, faux sinon.
     */
    /*!
     * \fn Interface::utf8String_t promptTitle() const
     * \brief Obtenir le titre du texte de description.
     * \return Le titre du texte de description.
     */
    /*!
     * \fn Interface::utf8String_t promptMessage() const
     * \brief Obtenir le texte de description.
     * \return Le texte de description.
     */
    virtual bool isPromptShown() const;
    virtual Interface::utf8String_t promptTitle() const;
    virtual Interface::utf8String_t promptMessage() const;

    /*!
     * \fn bool isAlertShown() const
     * \brief Le message d'alerte est-il affiché ?
     * \return Vrai si il est affiché, faux sinon.
     */
    /*!
     * \fn Interface::alertType_t alertType() const
     * \brief Obtenir le type d'alerte.
     * \return Le type d'alerte.
     */
    /*!
     * \fn Interface::utf8String_t alertTitle() const
     * \brief Obtenir le titre du message d'alerte.
     * \return Le titre du message d'alerte.
     */
    /*!
     * \fn Interface::utf8String_t alertMessage() const
     * \brief Obtenir le texte du message d'alerte.
     * \return Le texte du message d'alerte.
     */
    virtual bool isAlertShown() const;
    virtual Interface::alertType_t alertType() const;
    virtual Interface::utf8String_t alertTitle() const;
    virtual Interface::utf8String_t alertMessage() const;

public:
    /*!
     * \fn void setReference(const Coordinates::MultiCellRange& reference)
     * \brief Assigner la référence.
     * \param reference La référence sur laquelle s'applique la validation. Les références aux worksheets sont ignorées (une validation n'agit que sur une feuille).
     */
    virtual void setReference(const Coordinates::MultiCellRange&);

    /*!
     * \fn void allowBlank(bool allow)
     * \brief Autoriser ou non les valeurs vides.
     * \param allow Autorisation des valeurs vides si vrai, sinon les valeurs vides déclenchent une erreur.
     */
    virtual void allowBlank(bool);

    /*!
     * \fn void showPrompt(bool show)
     * \brief Montrer ou non le texte de description.
     * \param show Montrer le texte de description si vrai.
     */
    virtual void showPrompt(bool);

    /*!
     * \fn void setPrompt(const Interface::utf8String_t& title, const Interface::utf8String_t& message)
     * \brief Assigner le texte de description.
     * \param title Le titre.
     * \param message Le message.
     */
    virtual void setPrompt(const Interface::utf8String_t&, const Interface::utf8String_t&);

    /*!
     * \fn void showAlert(bool show)
     * \brief Montrer ou non le message d'alerte.
     * \param show Montrer le message d'alerte si vrai.
     */
    virtual void showAlert(bool);

    /*!
     * \fn void setAlertType(Interface::alertType_t type)
     * \brief Assigner le type d'alerte.
     * \param type Le type d'alerte.
     */
    virtual void setAlertType(Interface::alertType_t);

    /*!
     * \fn void setAlert(const Interface::utf8String_t& title, const Interface::utf8String_t& message)
     * \brief Assigner le message d'alerte.
     * \param title Le titre.
     * \param message Le message.
     */
    virtual void setAlert(const Interface::utf8String_t&, const Interface::utf8String_t&);

public:
    /*!
     * \fn SimpleValidation()
     * \brief Constructeur.
     */
    /*!
     * \fn SimpleValidation(const SimpleValidation& validation)
     * \brief Constructeur de recopie.
     * \param validation La règle de validation à recopier.
     */
    /*!
     * \fn SimpleValidation& operator=(const SimpleValidation& validation)
     * \brief Opérateur de recopie.
     * \param validation La règle de validation à recopier.
     * \return Cette règle de validation.
     */
    SimpleValidation();
    SimpleValidation(const SimpleValidation&) = default;
    SimpleValidation& operator=(const SimpleValidation&) = default;

    /*!
     * \fn ~SimpleValidation()
     * \brief Destructeur.
     */
    virtual ~SimpleValidation() =0;

    /*!
     * \fn SimpleValidation* clone()
     * \brief Cloner la règle de validation.
     * \return La nouvelle règle de validation, copie de cette règle.
     */
    virtual SimpleValidation* clone() const =0;

private:
    Coordinates::MultiCellRange m_reference;
    bool m_allowBlank;
    bool m_showPrompt;
    Interface::utf8SharedString_t m_promptTitle;
    Interface::utf8SharedString_t m_promptMessage;
    bool m_showAlert;
    Interface::alertType_t m_alertType;
    Interface::utf8SharedString_t m_alertTitle;
    Interface::utf8SharedString_t m_alertMessage;


#if defined(INVOKE_XLSX_LOGS)
public:
    virtual size_t log_size() const;
    virtual void log_scan(Debug::Container*) const;
#endif
};

/*!
 * \class SimpleCustomValidation
 * \brief Définit une règle de validation de données à partir d'une formule.
 */
class SimpleCustomValidation : public SimpleValidation, public Interface::Read::CustomValidation, public Interface::Write::CustomValidation {
public:
    /*!
     * \fn Interface::utf8String_t formula() const
     * \brief Obtenir la condition de validation.
     * \return La condition de validation au format "natif" Excel.
     */
    virtual Interface::utf8String_t formula() const;

public:
    /*!
     * \fn void setFormula(const Interface::utf8String_t& formula)
     * \brief Assigner la condition de validation.
     * \param formula La condition de validation (Elle ne commence pas par "=" et est au format "natif" Excel).
     */
    virtual void setFormula(const Interface::utf8String_t&);

public:
    /*!
     * \fn SimpleCustomValidation()
     * \brief Constructeur.
     */
    /*!
     * \fn SimpleCustomValidation(const SimpleCustomValidation& validation)
     * \brief Constructeur de recopie.
     * \param validation La règle de validation à recopier.
     */
    /*!
     * \fn SimpleCustomValidation& operator =(const SimpleCustomValidation& validation)
     * \brief Opérateur de recopie.
     * \param validation La règle de validation à recopier.
     * \return Cette règle de validation.
     */
    SimpleCustomValidation() =default;
    SimpleCustomValidation(const SimpleCustomValidation&) = default;
    SimpleCustomValidation& operator =(const SimpleCustomValidation&) = default;

    /*!
     * \fn SimpleValidation* clone() const
     * \brief Cloner la règle de validation.
     * \return La nouvelle règle de validation, copie de cette règle.
     */
    virtual SimpleValidation* clone() const;

private:
    Interface::utf8SharedString_t m_formula;


#if defined(INVOKE_XLSX_LOGS)
public:
    virtual size_t log_size() const;
    virtual void log_scan(Debug::Container*) const;
#endif
};

/*!
 * \class SimpleListValidation
 * \brief Définit une règle de validation de données à partir d'une liste de valeur.
 */
class SimpleListValidation : public SimpleValidation, public Interface::Read::ListValidation, public Interface::Write::ListValidation {
public:
    /*!
     * \fn const Coordinates::CellRange* rangeReference() const
     * \brief Obtenir la plage de données de référence.
     * \return La plage de données de référence.
     */
    virtual const Coordinates::CellRange* rangeReference() const;

    /*!
     * \fn const Interface::valueList_t* list() const
     * \brief Obtenir la liste de choix.
     * \return La liste des valeurs possibles.
     */
    virtual const Interface::valueList_t* list() const;

public:
    /*!
     * \fn void setRangeReference(const Coordinates::CellRange& range);
     * \brief Assigner une plage de données de référence pour la liste de validation.
     * \param range La plage de données de référence.
     *
     * Assigner cette plage de cellules réinitialise la liste des valeurs possibles.
     */
    virtual void setRangeReference(const Coordinates::CellRange&);

    /*!
     * \fn void setList(const Interface::valueList_t& list)
     * \brief Assigner la liste des valeurs possibles.
     * \param list La liste des valeurs possibles.
     *
     * Assigner une liste de valeur invalide la plage de référence.
     */
    virtual void setList(const Interface::valueList_t&);

public:
    /*!
     * \fn SimpleListValidation()
     * \brief Constructeur.
     */
    /*!
     * \fn SimpleListValidation(const SimpleListValidation& validation)
     * \brief Constructeur de recopie.
     * \param validation La règle de validation à recopier.
     */
    SimpleListValidation();
    SimpleListValidation(const SimpleListValidation&);

    /*!
     * \fn ~SimpleListValidation()
     * \brief Destructeur.
     */
    virtual ~SimpleListValidation();

    /*!
     * \fn SimpleValidation* clone() const
     * \brief Cloner la règle de validation.
     * \return La nouvelle règle de validation, copie de cette règle.
     */
    virtual SimpleValidation* clone() const;

    /*!
     * \fn Interface::valueList_t values(const Interface::Read::Workbook* workbook, const Interface::Read::Worksheet* worksheet) const
     * \brief Obtenir la liste des valeurs possibles déduites de la plage de données ou de la liste.
     * \param workbook Le classeur.
     * \param worksheet La feuille de calcul par défaut.
     * \return La liste de valeurs.
     */
    Interface::valueList_t values(const Interface::Read::Workbook*, const Interface::Read::Worksheet* =nullptr) const;

private:
    Coordinates::CellRange* m_rangeReference;
    Interface::valueList_t* m_list;


#if defined(INVOKE_XLSX_LOGS)
public:
    virtual size_t log_size() const;
    virtual void log_scan(Debug::Container*) const;
#endif
};

/*! 
 * \class SimpleFilter
 * \brief Définit un filtre.
 */
class SimpleFilter : public Interface::Read::Filter, public Interface::Write::Filter {
public:
    /*!
     * \fn const Coordinates::CellRange* rangeReference() const
     * \brief Obtenir la plage de données de référence.
     * \return La plage de données de référence.
     */
    virtual const Coordinates::CellRange* rangeReference() const;

public:
    /*!
     * \fn void setRangeReference(const Coordinates::CellRange& range);
     * \brief Assigner une plage de données de référence pour le filtre.
     * \param range La plage de données de référence.
     */
    virtual void setRangeReference(const Coordinates::CellRange&);

public:
    /*!
     * \fn SimpleFilter()
     * \brief Construteur.
     */
    /*!
     * \fn SimpleFilter(const SimpleFilter& filter)
     * \brief Construteur de recopie.
     * \param filter Filtre à recopier.
     */
    /*!
     * \fn SimpleFilter& operator =(const SimpleFilter& filter)
     * \brief Opérateur de recopie.
     * \param filter Filtre à recopier.
     */
    SimpleFilter();
    SimpleFilter(const SimpleFilter&);
    SimpleFilter& operator =(const SimpleFilter&);

    /*!
     * \fn ~SimpleFilter()
     * \brief Destructeur.
     */
    ~SimpleFilter();

    /*!
     * \fn SimpleFilter* clone() const
     * \brief Cloner le filtre.
     * \return Le nouveau filtre, copie de ce filtre.
     */
    virtual SimpleFilter* clone() const;

private:
    Coordinates::CellRange* m_rangeReference;


#if defined(INVOKE_XLSX_LOGS)
public:
    size_t log_size() const;
    void log_scan(Debug::Container*) const;
#endif
};

/*!
 * \class SimpleImage
 * \brief Définit une image.
 */
class SimpleImage : public Interface::Read::Image, public Interface::Write::Image {
public:
    /*!
     * \fn void getImageBuffer(unsigned char*& buffer, unsigned int& length) const
     * \brief Obtenir le flux de l'image (c'est une référence sur le flux interne!! Ne pas le libérer !!).
     * \param buffer Le flux de l'image.
     * \param length La taille du flux.
     */
    virtual void getImageBuffer(unsigned char*&, unsigned int&) const;

    /*!
     * \fn Interface::imageType_t type() const
     * \brief Obtenir le type de l'image.
     * \return Le type de l'image (JPG, GIF, PNG ou BMP).
     */
    virtual Interface::imageType_t type() const;

    /*!
     * \fn unsigned int width() const
     * \brief Obtenir la largeur de l'image en pixel.
     * \return La largeur de l'image en pixel.
     */
    /*!
     * \fn unsigned int height() const
     * \brief Obtenir la hauteur de l'image en pixel.
     * \return La hauteur de l'image en pixel.
     */
    virtual unsigned int width() const;
    virtual unsigned int height() const;

    /*!
     * \fn const Coordinates::CellPoint& topLeft() const
     * \brief Obtenir la position haut-gauche de l'image par rapport à la grille.
     * \return La position haut-gauche de l'image.
     */
    /*!
     * \fn const Coordinates::CellPoint* rightBottom() const
     * \brief Obtenir la position bas-droite de l'image par rapport à la grille.
     * \return La position bas-droite de l'image. Si NULL alors la position sera calculée de façon à ce que l'image ne soit pas déformée.
     */
    virtual const Coordinates::CellPoint& topLeft() const;
    virtual const Coordinates::CellPoint* rightBottom() const;

    /*!
     * \fn const Interface::emuRectangle_t* cropRectangle() const
     * \brief Obtenir le rectangle de rognage de l'image.
     * \return Le rectangle de rognage. NULL si il n'y a pas de rognage.
     */
    virtual const Interface::pixelRectangle_t* cropRectangle() const;

    /*!
     * \fn Interface::imageProperty_t property() const
     * \brief Obtenir le comportement de l'image par rapport aux changements de la grille.
     * \return La propriété de l'image.
     */
    virtual Interface::imageProperty_t property() const;

    /*!
     * \fn bool isValid() const
     * \brief L'image est elle valide ?
     * \return Vrai si l'image peut être intégrée au fichier, faux sinon.
     */
    virtual bool isValid() const;

public:
    /*!
     * \fn void setImage(unsigned char* stream, unsigned int length, bool copy)
     * \brief Assigner le flux de l'image.
     * \param stream Le flux de l'image.
     * \param length La taille du flux.
     * \param copy Le flux doit il être recopié ?
     */
    virtual void setImage(unsigned char*, unsigned int, bool =true);

    /*!
     * \fn void setTopLeft(const Coordinates::CellPoint& point)
     * \brief Assigner la position haut-gauche de l'image par rapport à la grille.
     * \param point La position haut-gauche de l'image.
     */
    /*!
     * \fn void setRightBottom(const Coordinates::CellPoint* point)
     * \brief Assigner la position bas-droite de l'image par rapport à la grille.
     * \param point La position bas-droite de l'image. Si NULL, la position sera calculée de façon à ce que l'image ne soit pas déformée.
     */
    virtual void setTopLeft(const Coordinates::CellPoint&);
    virtual void setRightBottom(const Coordinates::CellPoint*);

    /*!
     * \fn void setCropRectangle(const Interface::pixelRectangle_t* cropRectangle)
     * \brief Assigner le rectangle de rognage de l'image.
     * \param cropRectangle Le rectangle de rognage. Si NULL alors il n'y a pas de rognage.
     */
    virtual void setCropRectangle(const Interface::pixelRectangle_t*);

    /*!
     * \fn void setProperty(Interface::imageProperty_t property)
     * \brief Assigner le comportement de l'image par rapport aux changements de la grille.
     * \param property La propriété de l'image.
     */
    virtual void setProperty(Interface::imageProperty_t);

public:
    /*!
     * \fn SimpleImage()
     * \brief Construteur.
     */
    /*!
     * \fn SimpleImage(const SimpleImage& image)
     * \brief Construteur de recopie.
     * \param image Image à recopier.
     */
    /*!
     * \fn SimpleImage& operator =(const SimpleImage& image)
     * \brief Opérateur de recopie.
     * \param image Image à recopier.
     */
    SimpleImage();
    SimpleImage(const SimpleImage&);
    SimpleImage& operator =(const SimpleImage&);

    /*!
     * \fn ~SimpleImage()
     * \brief Destructeur.
     */
    ~SimpleImage();

    /*!
     * \fn SimpleImage* clone() const
     * \brief Cloner l'image.
     * \return La nouvelle image, copie de cette image.
     */
    virtual SimpleImage* clone() const;

private:
    unsigned char* m_stream;
    unsigned int m_streamSize;

    Interface::imageType_t m_type;
    unsigned int m_width;
    unsigned int m_height;

    Coordinates::CellPoint m_topLeft;
    Coordinates::CellPoint* m_rightBottom;

    Interface::pixelRectangle_t* m_cropRectangle;
    Interface::imageProperty_t m_property;


#if defined(INVOKE_XLSX_LOGS)
public:
    size_t log_size() const;
    void log_scan(Debug::Container*) const;
#endif
};

/*!
 * \class SimpleHyperlink
 * \brief Définit un lien d'une cellule à une plage de cellules.
 */
class SimpleHyperlink : public Interface::Read::Hyperlink, public Interface::Write::Hyperlink {
public:
    /*!
     * \fn const Coordinates::CellRange& reference() const
     * \brief Obtenir les coordonnées de la plage de cellules sur lesquelles le lien est positionné.
     * \return Les coordonnées de la plage de cellules.
     */
    virtual const Coordinates::CellRange& reference() const;

    /*!
     * \fn const Interface::utf8String_t& display() const
     * \brief Obtenir le texte à afficher par défaut.
     * \return Le texte à afficher par défaut.
     */
    virtual const Interface::utf8String_t& display() const;

    /*!
     * \fn const Coordinates::CellRange* location() const
     * \brief Obtenir les coordonnées de la plage de cellules vers lesquelles pointe le lien.
     * \return Les coordonnées de la plage de cellules vers lesquelles pointe le lien. NULL si il n'y a pas de coordonnées spécifiées.
     */
    /*!
     * \fn const Interface::Read::DefinedName* definedName() const
     * \brief Obtenir la plage de cellules nommée vers laquelle le lien pointe.
     * \return La plage de cellules. NULL si le lien ne pointe pas vers une plage nommée.
     */
    /*!
     * \fn const Interface::utf8String_t* fileLocation() const
     * \brief Obtenir le nom du fichier à ouvrir.
     * \return Le nom du fichier à ouvrir. NULL si le lien ne pointe pas vers un fichier.
     */
    /*!
     * \fn bool getMailLocation(Interface::utf8String_t& mail, Interface::utf8String_t& subject) const
     * \brief Obtenir les paramètres du mail à préparer.
     * \param mail L'adresse mail du destinataire.
     * \param subject L'objet du mail.
     * \return Vrai si le lien est un lien de préparation de mail, faux sinon.
     */
    virtual const Coordinates::CellRange* location() const;
    virtual const Interface::Read::DefinedName* definedName() const;
    virtual const Interface::utf8String_t* fileLocation() const;
    virtual bool getMailLocation(Interface::utf8String_t&, Interface::utf8String_t&) const;

    /*!
     * \fn const Interface::utf8String_t& tooltip()
     * \brief Obtenir le texte de l'info bulle.
     * \return Le texte de l'info bulle.
     */
    virtual const Interface::utf8String_t& tooltip() const;

    /*!
     * \fn bool isValid() const
     * \brief Le lien est-il valide ?
     * \return Vrai si le lien est valide (si le lien est assigné), faux sinon.
     */
    virtual bool isValid() const;

public:
    /*!
     * \fn void setReference(const Coordinates::Cell& cell)
     * \brief Spécifier le lien à la cellule passée en paramètre. Annule et remplace les autres références spécifiées précédement.
     * \param cell La cellule sur laquelle repose le lien.
     */
    /*!
     * \fn void setReference(const Coordinates::CellRange& range)
     * \brief Spécifier le lien à la plage de cellules passée en paramètre. Annule et remplace les autres références spécifiées précédement.
     * \param range La plage de cellule sur laquelle repose le lien.
     */
    virtual void setReference(const Coordinates::Cell&);
    virtual void setReference(const Coordinates::CellRange&);

    /*!
     * \fn void setDisplay(const Interface::utf8String_t& text)
     * \brief Spécifier un texte à afficher par défaut.
     * \param text Le texte à afficher par défaut.
     */
    virtual void setDisplay(const Interface::utf8String_t&);

    /*!
     * \fn void setLocation(const Coordinates::Cell& cell)
     * \brief Spécifier la destination du lien. Annule et remplace les autres actions spécifiées précédement.
     * \param cell La cellule destination du lien.
     */
    /*!
     * \fn void setLocation(const Coordinates::CellRange& range)
     * \brief Spécifier la destination du lien. Annule et remplace les autres actions spécifiées précédement.
     * \param range La plage de cellules destination du lien.
     */
    /*!
     * \fn void setLocation(const Interface::Write::DefinedName& name)
     * \brief Spécifier la destination du lien. Annule et remplace les autres actions spécifiées précédement.
     * \param name La plage de cellules destination du lien.
     */
    virtual void setLocation(const Coordinates::Cell&);
    virtual void setLocation(const Coordinates::CellRange&);
    virtual void setLocation(const Interface::Write::DefinedName&);

    /*!
     * \fn void setFileLocation(const Interface::utf8String_t& filename)
     * \brief Spécifier le fichier à ouvrir. Annule et remplace les autres actions spécifiées précédement.
     * \param filename Le nom du fichier à ouvrir.
     */
    /*!
     * \fn void setMailLocation(const Interface::utf8String_t& mail, const Interface::utf8String_t& subject)
     * \brief Spécifier les paramètres du mail à préparer. Annule et remplace les autres actions spécifiée précédement.
     * \param mail L'adresse mail du destinataire.
     * \param subject L'objet du mail.
     */
    virtual void setFileLocation(const Interface::utf8String_t&);
    virtual void setMailLocation(const Interface::utf8String_t&, const Interface::utf8String_t&);

    /*!
     * \fn void setTooltip(const Interface::utf8String_t& text)
     * \brief Spécifier le texte de l'info bulle.
     * \param text Le texte de l'info bulle.
     */
    virtual void setTooltip(const Interface::utf8String_t&);

public:
    /*!
     * \fn SimpleHyperlink()
     * \brief Constructeur.
     */
    /*!
     * \fn SimpleHyperlink(const SimpleHyperlink& hyperlink)
     * \brief Constructeur.
     * \param hyperlink Le lien à recopier.
     */
    /*!
     * \fn SimpleHyperlink& operator =(const SimpleHyperlink& hyperlink)
     * \brief Opérateur de recopie.
     * \param hyperlink Le lien à recopier.
     * \return Ce lien.
     */
    SimpleHyperlink();
    SimpleHyperlink(const SimpleHyperlink&);
    SimpleHyperlink& operator =(const SimpleHyperlink&);

    /*!
     * \fn ~SimpleHyperlink
     * \brief destructeur.
     */
    ~SimpleHyperlink();

    /*!
     * \fn SimpleHyperlink* clone() const
     * \brief Cloner le lien.
     * \return Le nouveau lien, copie de ce lien.
     */
    virtual SimpleHyperlink* clone() const;

private:
    typedef enum {
        lCellRange,
        lDefinedName,
        lFile,
        lMail
    } locationType_t;

    typedef struct {
        Interface::utf8SharedString_t address;
        Interface::utf8SharedString_t subject;
    } mail_t;

    void newLocation(locationType_t, const void*);
    void deleteLocation();

    Coordinates::CellRange m_reference;
    Interface::utf8SharedString_t m_display;
    locationType_t m_locationType;
    void* m_location;
    Interface::utf8SharedString_t m_tooltip;


#if defined(INVOKE_XLSX_LOGS)
public:
    size_t log_size() const;
    void log_scan(Debug::Container*) const;
#endif
};

/*!
 * \class SimpleComment
 * \brief Définit un commentaire.
 */
class SimpleComment : public Interface::Read::Comment, public Interface::Write::Comment {
public:
    /*!
     * \fn const Coordinates::Cell& reference() const
     * \brief Obtenir les coordonées de la cellule sur laquelle est accroché le commentaire.
     * \return Les coordonnées de la cellule.
     */
    virtual const Coordinates::Cell& reference() const;

    /*!
     * \fn const Interface::utf8String_t& author() const
     * \brief Obtenir le nom de l'auteur.
     * \return Le nom de l'auteur.
     */
    virtual const Interface::utf8String_t& author() const;

    /*!
     * \fn size_t runCount() const
     * \brief Obtenir le nombre de portion de texte.
     * \return Le nombre de portion de texte.
     */
    /*!
     * \fn const Interface::font_t* runFont(size_t index) const
     * \brief Obtenir la police de caractères de la portion de texte.
     * \param index L'index de la portion de texte ciblée (index doit être compris entre 0 et runCount() - 1).
     * \return La police de caractères de la portion de texte à l'index "index".
     */
    /*!
     * \fn const Interface::utf8String_t* runText(size_t index) const
     * \brief Obtenir le texte de la portion.
     * \param index L'index de la portion de texte ciblée (index doit être compris entre 0 et runCount() - 1).
     * \return Le texte de la portion à l'index "index".
     */
    virtual size_t runCount() const;
    virtual const Interface::font_t* runFont(size_t) const;
    virtual const Interface::utf8String_t* runText(size_t) const;

    /*!
     * \fn const std::string& hyperlink() const
     * \brief Obtenir le lien hyper texte.
     * \return le lien hyper texte de la boite de commentaire ou chaîne vide.
     */
    virtual const std::string& hyperlink() const;

    /*!
     * \fn Interface::horizontalAlignment_t alignment() const
     * \brief Obtenir l'alignement horizontal de la boite de commentaire.
     * \return L'alignement du texte dans la boite de commentaire.
     */
    virtual Interface::horizontalAlignment_t alignment() const;

    /*!
     * \fn const Coordinates::CellPoint& topLeft() const
     * \brief Obtenir la position haut-gauche de la boite de commentaire par rapport à la grille.
     * \return La position haut-gauche de la boite de commentaire.
     */
    /*!
     * \fn const Coordinates::CellPoint& rightBottom() const
     * \brief Obtenir la position bas-droite de la boite de commentaire par rapport à la grille.
     * \return La position bas-droite de la boite de commentaire.
     */
    /*!
     * \fn bool autoSize() const
     * \brief La taille automatique est-elle activée ?
     * \return Vrai si la taille de la boite de commentaire sera ajustée au texte.
     */
    virtual const Coordinates::CellPoint& topLeft() const;
    virtual const Coordinates::CellPoint& rightBottom() const;
    virtual bool autoSize() const;

    /*!
     * \fn Interface::color_t fillColor() const
     * \brief Obtenir la couleur de fond de la boite de commentaire.
     * \return La couleur de fond de la boite de commentaire.
     */
    virtual Interface::color_t fillColor() const;

    /*!
     * \fn Interface::visibility_t visibility() const
     * \brief Obtenir la visibilité de la boite de commentaire (cachée ou visible).
     * \return La visibilité de la boite de commentaire (cachée ou visible).
     */
    virtual Interface::visibility_t visibility() const;

    /*!
     * \fn Interface::commentProperty_t property() const
     * \brief Obtenir le comportement de la boite de commentaire.
     * \return Le comportement de la boite de commentaire.
     */
    virtual Interface::commentProperty_t property() const;

public:
    /*!
     * \fn void setReference(const Coordinates::Cell& cell)
     * \brief Spécifier la cellule à laquelle est raccroché le commentaire.
     * \param cell La cellule à laquelle est raccroché le commentaire.
     */
    virtual void setReference(const Coordinates::Cell&);

    /*!
     * \fn void setAuthor(const Interface::utf8String_t& author)
     * \brief Spécifier l'auteur du commentaire.
     * \param author L'auteur du commentaire.
     */
    virtual void setAuthor(const Interface::utf8String_t&);

    /*!
     * \fn void addRun(const Interface::font_t& font, const Interface::utf8String_t& text)
     * \brief Ajouter une portion de texte.
     * \param font La police de caractères de la portion de texte.
     * \param text Le texte de la portion.
     */
    virtual void addRun(const Interface::font_t&, const Interface::utf8String_t&);

    /*!
     * \fn void setHyperlink(const std::string& hyperlink)
     * \brief Assigner le lien hyper texte de la boite de commentaire.
     * \param hyperlink Le lien hyper texte.
     */
    virtual void setHyperlink(const std::string&);

    /*!
     * \fn void setAlignment(Interface::horizontalAlignment_t alignment)
     * \brief Specifier l'alignement du texte dans la boite de commentaire.
     * \param alignment L'alignement horizontal du texte.
     */
    virtual void setAlignment(Interface::horizontalAlignment_t);

    /*!
     * \fn void setTopLeft(const Coordinates::CellPoint& point)
     * \brief Assigner la position haut-gauche de la boite de commentaire par rapport à la grille.
     * \param point La position haut-gauche de la boite de commentaire.
     */
    /*!
     * \fn void setRightBottom(const Coordinates::CellPoint& point)
     * \brief Assigner la position bas-droite de la boite de commentaire par rapport à la grille.
     * \param point La position bas-droite de la boite de commentaire.
     */
    /*!
     * \fn void setAutoSize(bool autoSize)
     * \brief Ajuster la taille de la boite de commentaire au texte.
     * \param autoSize Si Vrai, la taille de la boite de commentaire s'ajustera au texte.
     */
    virtual void setTopLeft(const Coordinates::CellPoint&);
    virtual void setRightBottom(const Coordinates::CellPoint&);
    virtual void setAutoSize(bool);

    /*!
     * \fn void setFillColor(Interface::color_t color)
     * \brief Spécifier la couleur de fond de la boite de commentaire.
     * \param color La couleur de fond.
     */
    virtual void setFillColor(Interface::color_t);

    /*!
     * \fn void setVisibility(Interface::visibility_t visibility)
     * \brief Spécifier la visibilité de la boite de commentaire (cachée ou toujours visible).
     * \param visibility La visibilité de la boite de commentaire.
     */
    virtual void setVisibility(Interface::visibility_t);

    /*!
     * \fn void setProperty(Interface::commentProperty_t property)
     * \brief Spécifier le comportement de la boite de commentaire par rapport à la grille.
     * \param property Le comportement de la boite de commentaire par rapport à la grille.
     */
    virtual void setProperty(Interface::commentProperty_t);

public:
    /*!
     * \fn SimpleComment()
     * \brief Constructeur.
     */
    /*!
     * \fn SimpleComment(const SimpleComment& comment)
     * \brief Constructeur.
     * \param comment Le commentaire à recopier.
     */
    /*!
     * \fn SimpleComment& operator =(const SimpleComment& comment)
     * \brief Opérateur de recopie.
     * \param comment Le commentaire à recopier.
     * \return Ce commentaire.
     */
    SimpleComment();
    SimpleComment(const SimpleComment&);
    SimpleComment& operator =(const SimpleComment&);

    /*!
     * \fn SimpleComment* clone() const
     * \brief Cloner le commentaire.
     * \return Le nouveau commentaire, copie de ce commentaire.
     */
    virtual SimpleComment* clone() const;

    /*!
     * \fn void resetCoordinates()
     * \brief Réinitialiser les coordonnées de la boite de commentaire.
     */
    void resetCoordinates();

    /*!
     * \fn void reset()
     * \brief Réinitialiser le commentaire.
     */
    void reset();

private:
    Coordinates::Cell m_reference;
    Interface::utf8SharedString_t m_author;
    SimpleRichText m_text;
    SharedString m_hyperlink;
    Interface::horizontalAlignment_t m_alignment;
    Coordinates::CellPoint m_topLeft;
    Coordinates::CellPoint m_rightBottom;
    bool m_autoCoordinates;
    bool m_autoSize;
    Interface::color_t m_color;
    Interface::visibility_t m_visibility;
    Interface::commentProperty_t m_property;


#if defined(INVOKE_XLSX_LOGS)
public:
    size_t log_size() const;
    void log_scan(Debug::Container*) const;
#endif
};

/*!
 * \class SimpleWorkbook
 * \brief Définit un classeur de feuilles de calcul.
 */
class SimpleWorksheet;

class SimpleWorkbook : public Interface::Read::Workbook, public Interface::Write::Workbook {
public:
    /*!
     * \fn const Coordinates::WorksheetProxy* selectedWorksheet() const
     * \brief Obtenir une procuration sur la feuille de calcul active.
     * \return Une procuration sur la feuille de calcul.
     */
    virtual const Coordinates::WorksheetProxy* selectedWorksheet() const;

    /*!
     * \fn Interface::utf8String_t checkWorksheetName(const Interface::utf8String_t& name) const
     * \brief Verifier l'unicité d'un nom de feuille de calcul dans ce classeur.
     * \param name Le nom de la feuille de calcul.
     * \return Le nom de la feuille de calcul corrigé.
     */
    /*!
     * \fn size_t worksheetCount() const
     * \brief Obtenir le nombre de feuilles de calcul.
     * \return Le nombre de feuilles de calcul présentes dans le classeur.
     */
    /*!
     * \fn const Interface::Read::Worksheet* worksheet(size_t index) const
     * \brief Obtenir une feuille de calcul.
     * \param index L'index de la feuille demandée (entre 0 et worksheetCount()).
     * \return La feuille demandée, NULL si l'index est erroné.
     */
    /*!
     * \fn const Coordinates::WorksheetProxy* worksheet(const Interface::utf8String_t& sheetName) const
     * \brief Obtenir une procuration sur une feuille de calcul précisée en paramètre.
     * \param sheetName Le nom de la feuille.
     * \return Une procuration sur la feuille de calcul, NULL si la feuille n'existe pas.
     */
    virtual Interface::utf8String_t checkWorksheetName(const Interface::utf8String_t&) const;
    virtual size_t worksheetCount() const;
    virtual const Interface::Read::Worksheet* worksheet(size_t) const;
    virtual const Coordinates::WorksheetProxy* worksheet(const Interface::utf8String_t&) const;

    /*!
     * \fn void getDefaultFont(Interface::utf8String_t& name, unsigned short& size, Interface::color_t& color, bool& bold, bool& italic, bool& underline) const
     * \brief Obtenir la police de caractères par défaut.
     * \param name Le nom de la police.
     * \param size La taille de la police (en pt).
     * \param color La couleur de la police.
     * \param bold La police est-elle grasse ?
     * \param italic La police est-elle en italique ?
     * \param underline La police est-elle soulignée ?
     */
    virtual void getDefaultFont(Interface::utf8String_t&, unsigned short&, Interface::color_t&, bool&, bool&, bool&) const;

    /*!
     * \fn Interface::Read::Workbook::cellFormatList_t formats() const
     * \brief Obtenir la liste des formats de cellule.
     * \return La liste des formats de cellule.
     */
    virtual Interface::Read::Workbook::cellFormatList_t formats() const;

    /*!
     * \fn size_t definedNameCount() const
     * \brief Obtenir le nombre de plages de cellules nommées.
     * \return Le nombre de plages de cellules nommées.
     */
    /*!
     * \fn const Interface::Read::DefinedName* definedName(size_t index) const
     * \brief Obtenir une plage de cellules nommée.
     * \param index L'index de la plage de cellules nommée demandée (entre 0 et definedNameCount()).
     * \return La plage de cellules nommée demandée, NULL si l'index est erroné.
     */
    /*!
     * \fn const Interface::Read::DefinedName* definedName(const Interface::utf8String_t& name) const
     * \brief Obtenir une plage de cellules nommée.
     * \param name Le nom de la plage de cellules nommée demandée.
     * \return La plage de cellules nommée demandée, NULL si le nom n'existe pas.
     */
    virtual size_t definedNameCount() const;
    virtual const Interface::Read::DefinedName* definedName(size_t) const;
    virtual const Interface::Read::DefinedName* definedName(const Interface::utf8String_t&) const;

public:
    /*!
     * \fn const Coordinates::WorkbookProxy* proxy() const
     * \brief Obtenir le proxy du classeur.
     * \return Le proxy du classeur.
     */
    virtual const Coordinates::WorkbookProxy* proxy() const;

    /*!
     * \fn Interface::Write::Worksheet* newWorksheet(const Interface::utf8String_t& name)
     * \brief Ajouter une feuille de calcul au classeur.
     * \param name Le nom de la feuille de calcul à ajouter.
     * \return La feuille de calcul ajoutée. Le nom de la feuille a pu être modifié pour éviter les doublons.
     */
    virtual Interface::Write::Worksheet* newWorksheet(const Interface::utf8String_t&);

    /*!
     * \fn bool selectWorksheet(const Interface::Write::Worksheet* worksheet)
     * \brief Selectionner la feuille active.
     * \param worksheet La feuille de calcul à selectionner.
     * \return Vrai si la feuille appartient au classeur, faux sinon.
     */
    /*!
     * \fn void selectWorksheetIndex(unsigned int index)
     * \brief Selectionner la feuille active.
     * \param index L'index de la feuille de calcul à selectionner.
     */
    virtual bool selectWorksheet(const Interface::Write::Worksheet*);
    virtual void selectWorksheetIndex(unsigned int);

    /*!
     * \fn void setDefaultFont(const Interface::utf8String_t& name, unsigned short size, Interface::color_t color, bool bold, bool italic, bool underline)
     * \brief Assigner la police de caractères par défault.
     * \param name Le nom de la police.
     * \param size La taille de la police (en pt).
     * \param color La couleur de la police.
     * \param bold La police est-elle grasse ?
     * \param italic La police est-elle en italique ?
     * \param underline La police est-elle soulignée ?
     */
    virtual void setDefaultFont(const Interface::utf8String_t&, unsigned short, Interface::color_t, bool, bool, bool);

    /*!
     * \fn Interface::Write::CellFormat* createFormat() const
     * \brief Créer un format de cellule.
     * \return Un nouveau format de cellule.
     */
    /*!
     * \fn Interface::formatIdentifier_t addFormat(const Interface::Write::CellFormat& format)
     * \brief Ajouter le format de cellule à la liste générale des formats de cellule.
     * \param format Le format de cellule à ajouter.
     * \return L'identifiant du format ajouté.
     */
    virtual Interface::Write::CellFormat* createFormat() const;
    virtual Interface::formatIdentifier_t addFormat(const Interface::Write::CellFormat&);

    /*!
     * \fn void setFormat(const Coordinates::Cell& coordinate, const Interface::Write::CellFormat& format)
     * \brief Assigner un format à une cellule.
     * \param coordinate La coordonnée de la cellule.
     * \param format Le format à assigner. Il sera ajouté au classeur.
     */
    /*!
     * \fn void setFormat(const Coordinates::CellRange& coordinates, const Interface::Write::CellFormat& format)
     * \brief Assigner un format à une plage de cellules.
     * \param coordinates Les coordonnées de la plage de cellules.
     * \param format Le format à assigner. Il sera ajouté au classeur.
     */
    /*!
     * \fn void setFormat(const Coordinates::MultiCellRange& coordinates, const Interface::Write::CellFormat& format)
     * \brief Assigner un format à plusieurs plages de cellules.
     * \param coordinates Les coordonnées des plages de cellules.
     * \param format Le format à assigner. Il sera ajouté au classeur.
     */
    virtual void setFormat(const Invoke::XLSX::Coordinates::Cell&, const Invoke::XLSX::Interface::Write::CellFormat&);
    virtual void setFormat(const Coordinates::CellRange&, const Interface::Write::CellFormat&);
    virtual void setFormat(const Coordinates::MultiCellRange&, const Interface::Write::CellFormat&);

    /*!
     * \fn Interface::Write::DefinedName* createDefinedName() const
     * \brief Créer un nom de plage de cellules.
     * \return Un nouveau nom de plage de cellules.
     */
    /*!
     * \fn size_t addDefinedName(const Interface::Write::DefinedName& definedName)
     * \brief Ajouter une plage de cellules nommée. Si elle existe déjà, rien n'est modifié.
     * \param definedName La plage de cellules nommée.
     * \return L'index de la plage nommée.
     *
     * Attention, les noms de plage ne sont pas tous valides (cf. méthode Interface::isDefinedNameValid).
     * Attention, les plages nommées sur plusieurs feuilles ne sont pas valides.
     * Attention, les plages nommées non bloquées (attribut locked) ont des comportements bizares dans Excel.
     */
    virtual Interface::Write::DefinedName* createDefinedName() const;
    virtual size_t addDefinedName(const Interface::Write::DefinedName&);

public:
    /*!
     * \fn SimpleWorkbook()
     * \brief Constructeur.
     */
    /*!
     * \fn SimpleWorkbook(const SimpleWorkbook& workbook)
     * \brief Constructeur de recopie. DELETE.
     * \param workbook Classeur à recopier.
     */
    /*!
     * \fn SimpleWorkbook& operator =(const SimpleWorkbook& workbook)
     * \brief Opérateur de recopie. DELETE.
     * \param workbook Classeur à recopier.
     * \return Ce classeur.
     */
    SimpleWorkbook();
    SimpleWorkbook(const SimpleWorkbook&) = delete;
    SimpleWorkbook(SimpleWorkbook&&) = default;
    SimpleWorkbook& operator =(const SimpleWorkbook&) = delete;
    SimpleWorkbook& operator =(SimpleWorkbook&&) = default;

    /*!
     * \fn ~SimpleWorkbook()
     * \brief Destructeur.
     */
    ~SimpleWorkbook();

private:
    void splitWorksheetName(const Interface::utf8String_t&, Interface::utf8String_t&, unsigned int&, size_t&) const;

    typedef std::vector<SimpleWorksheet*> worksheets_t;
    worksheets_t m_worksheets;
    size_t m_selectedWorksheetIndex;

    typedef struct {
        Interface::utf8SharedString_t name;
        unsigned short size;
        Interface::color_t color;
        bool bold;
        bool italic;
        bool underline;
    } font_t;
    font_t* m_defaultFont;

    typedef std::unordered_set<SimpleCellFormat, Hasher<SimpleCellFormat>> formats_t;
    formats_t m_formats;

    typedef std::vector<const SimpleDefinedName*> definedNames_t;
    definedNames_t m_definedNames;


#if defined(INVOKE_XLSX_LOGS)
public:
    size_t log_size() const;
    void log_scan(Debug::Container*) const;
#endif
};

/*!
 * \class CellPosition
 * \brief Definit une position de cellule.
 * Cette classe est utilisée en interne par la Worksheet pour organiser les cellules.
 */
class CellPosition {
public:
    /*!
     * \fn CellPosition()
     * \brief Constructeur.
     */
    /*!
     * \fn CellPosition(const CellPosition& position)
     * \brief Constructeur de recopie.
     * \param position La position à recopier.
     */
    /*!
     * \fn CellPosition& operator =(const CellPosition& position)
     * \brief Opérateur de recopie.
     * \param position La position à recopier.
     * \return Cette position.
     */
    CellPosition() = default;
    CellPosition(const CellPosition&) = default;
    CellPosition& operator =(const CellPosition&) = default;

    /*!
     * \fn CellPosition(unsigned int column, unsigned int row)
     * \brief Constructeur.
     * \param column Définition de la colonne.
     * \param row Définition de la ligne.
     */
    CellPosition(unsigned int p_column, unsigned int p_row) : m_column(p_column), m_row(p_row) {}

    /*!
     * \fn unsigned int column() const
     * \brief Obtenir l'index de la colonne.
     * \return L'index de la colonne.
     */
    /*!
     * \fn unsigned int row() const
     * \brief Obtenir l'index de la ligne.
     * \return L'index de la ligne.
     */
    unsigned int column() const { return m_column; }
    unsigned int row() const { return m_row; }

    /*!
     * \fn bool operator ==(const CellPosition& position) const
     * \brief Opérateur d'égalité.
     * \param position La position à tester.
     * \return Vrai si cette position est égale à celle passée en paramètre, faux sinon.
     */
    bool operator ==(const CellPosition& p_position) const { return ((p_position.column() == m_column) && (p_position.row() == m_row)); }

private:
    unsigned int m_column;
    unsigned int m_row;
};

/*!
 * \class Hasher<CellPosition>
 * \brief Foncteur pour le hachage des positions de cellule.
 */
template<>
class Hasher<CellPosition> {
public:
    /*!
     * \fn unsigned long operator()(const CellPosition& position) const
     * \brief Fonction de hachage.
     * \param position La position de cellule à hacher.
     * \return Le code de hachage.
     */
    unsigned long operator()(const CellPosition&) const;
};

/*!
 * \class CellDescription
 * \brief Définit le contenu d'une cellule.
 * Cette classe est utilisée en interne par la Worksheet pour organiser les cellules.
 */
class CellDescription {
public:
    /*!
     * \fn CellDescription()
     * \brief Constructeur.
     */
    /*!
     * \fn CellDescription(const CellDescription& description)
     * \brief Constructeur de recopie.
     * \param description Contenu à copier.
     */
    /*!
     * \fn CellDescription& operator =(const CellDescription& description)
     * \brief Opérateur de recopie.
     * \param description Contenu à copier.
     * \return Ce contenu.
     */
    CellDescription() = default;
    CellDescription(const CellDescription&) = default;
    CellDescription& operator =(const CellDescription&) = default;

    /*!
     * \fn CellDescription(const SimpleCellValue& value)
     * \brief Constructeur.
     * \param value Valeur de la cellule.
     */
    /*!
     * \fn CellDescription(Interface::formatIdentifier_t format)
     * \brief Constructeur.
     * \param format Format de la cellule
     */
    /*!
     * \fn CellDescription(const SimpleCellValue& value, Interface::formatIdentifier_t format)
     * \brief Constructeur.
     * \param value Valeur de la cellule.
     * \param format Format de la cellule
     */
    CellDescription(const SimpleCellValue& p_value) : m_value(p_value), m_format(nullptr) {}
    CellDescription(Interface::formatIdentifier_t p_format) : m_value(), m_format(p_format) {}
    CellDescription(const SimpleCellValue& p_value, Interface::formatIdentifier_t p_format) : m_value(p_value), m_format(p_format) {}

    /*!
     * \fn void setValue(const SimpleCellValue& value)
     * \brief Assigner une valeur.
     * \param value La valeur à assigner.
     */
    /*!
     * \fn void setFormatIdentifier(Interface::formatIdentifier_t format)
     * \brief Assigner un format.
     * \param format Le format à assigner.
     */
    void setValue(const SimpleCellValue& p_value) { m_value = p_value; }
    void setFormatIdentifier(Interface::formatIdentifier_t p_format) { m_format = p_format; }

    /*!
     * \fn const SimpleCellValue& value() const
     * \brief Obtenir la valeur de la cellule.
     * \return La valeur de la cellule.
     */
    /*!
     * \fn Interface::formatIdentifier_t formatIdentifier() const
     * \brief Obtenir le format de la cellule.
     * \return Le format de la cellule.
     */
    const SimpleCellValue& value() const { return m_value; }
    Interface::formatIdentifier_t formatIdentifier() const { return m_format; }

private:
    SimpleCellValue m_value;
    Interface::formatIdentifier_t m_format;
};

/*!
 * \class SimpleWorksheet
 * \brief Définit une feuille de calcul.
 */
class SimpleWorksheet : public Interface::Read::Worksheet, public Interface::Write::Worksheet {
public:
    /*!
     * \fn Interface::utf8String_t name() const
     * \brief Obtenir le nom de la feuille de calcul.
     * \return Le nom de la feuille de calcul.
     */
    virtual Interface::utf8String_t name() const;

    /*!
     * \fn bool isHidden() const
     * \brief La feuille de calcul est-elle cachée ?
     * \return Vrai si la feuille est cachée, faux sinon.
     */
    virtual bool isHidden() const;

    /*!
     * \fn bool formulasShown() const
     * \brief Les formules de calcul sont-elles visibles dans la feuille ?
     * \return Vrai si les formules sont visibles, faux sinon.
     */
    virtual bool formulasShown() const;

    /*!
     * \fn bool gridLinesShown() const
     * \brief Le quadrillage est-il visible dans la feuille ?
     * \return Vrai si le quadrillage est visible, faux sinon.
     */
    virtual bool gridLinesShown() const;

    /*!
     * \fn bool rowColHeadersShown() const
     * \brief Les entêtes de lignes et de colonnes sont-ils visibles dans la feuille ?
     * \return Vrai si les entêtes de lignes et de colonnes sont visibles, faux sinon.
     */
    virtual bool rowColHeadersShown() const;

    /*!
     * \fn bool zerosShown() const
     * \brief Les zéros dans les cellules qui ont une valeur nulle sont-ils affichés ?
     * \return Vrai si les zéros sont affichés, faux sinon.
     */
    virtual bool zerosShown() const;

    /*!
     * \fn const Coordinates::Cell* activeCell() const
     * \brief Obtenir la cellule active selectionnée.
     * \return Les coordonnées de la cellule active selectionnée.
     */
    /*!
     * \fn const Coordinates::MultiCellRange* selection() const
     * \brief Obtenir la plage de cellules sélectionnée.
     * \return Les coordonnées de la plage de cellules sélectionnée.
     */
    virtual const Coordinates::Cell* activeCell() const;
    virtual const Coordinates::MultiCellRange* selection() const;

    /*!
     * \fn const Interface::Read::PageSetting* pageSetting() const
     * \brief Obtenir les paramètres d'impression de la feuille de calcul.
     * \return Les paramètres d'impression de la feuille de calcul.
     */
    virtual const Interface::Read::PageSetting* pageSetting() const;

    /*!
     * \fn const Coordinates::CellRange& minBounds() const
     * \brief Obtenir la plage de données non vide minimale.
     * \return La plage de données non vide minimale.
     */
    virtual const Coordinates::CellRange& minBounds() const;

    /*!
     * \fn bool isColumnVisible(unsigned int index) const
     * \brief La colonne est-elle visible ?
     * \param index L'index de la colonne demandée ([0, ∞[).
     * \return Vrai si la colonne est visible, faux sinon.
     */
    /*!
     * \fn double columnWidth(unsigned int index) const
     * \brief Obtenir la taille de la colonne.
     * \param index L'index de la colonne demandée ([0, ∞[).
     * \return La largeur de la colonne.
     *
     * La taille de la colonne correspond au nombre de chiffre maximum visibles dans la police de style normal.
     * Pour le calcul, Excel utilise la taille du chiffre le plus large, ajoute 2 pixel de marge de chaque côté et 1 pixel pour la grille.\n
     * Le calcul est : taille en pixel = trunc({size} * 7)
     */
    /*!
     * \fn unsigned short columnOutlineLevel(unsigned int index) const
     * \brief Obtenir le niveau de regroupement.
     * \param index L'index de la colonne demandée ([0, ∞[).
     * \return Le niveau de regroupement de la colonne.
     */
    /*!
     * \fn bool isColumnCollapsed(unsigned int index) const
     * \brief Le regroupement est-il masqué ?
     * \param index L'index de la colonne demandée ([0, ∞[).
     * \return Vrai si le regroupement est masqué, faux sinon.
     */
    /*!
     * \fn const Interface::Read::CellFormat* columnCellFormat(unsigned int index) const
     * \brief Obtenir le format de cellule assigné à la colonne.
     * \param index L'index de la colonne demandée ([0, ∞[).
     * \return Le format de cellule assigné à la colonne, NULL si aucun format n'est assigné.
     */
    /*!
     * \fn bool isColumnDefault(unsigned int index) const
     * \brief Savoir si la colonne a les paramètres par défaut.
     * \param index L'index de la colonne demandée ([0, ∞[).
     * \return Vrai si la colonne a les paramètres par défaut, faux sinon.
     */
    /*!
     * \fn bool getColumnParentIndex(unsigned int index, unsigned int& parentIndex) const
     * \brief Obtenir l'index de la colonne parente d'une colonne.
     * \param index L'index de la colonne demandée ([0, ∞[).
     * \param parentIndex L'index de la colonne parente (si la colonne a une colonne parente).
     * \return Vrai si la colonne a une colonne parente, faux sinon.
     *
     * Cette fonction tient compte de la valeur retournée par la fonction outlineSummaryRight.
     */
    /*!
     * \fn bool hasColumnChildren(unsigned int index) const
     * \brief Savoir si la colonne a des colonnes enfants.
     * \param index L'index de la colonne demandée ([0, ∞[).
     * \return Vrai si la colonne a des colonnes enfants, faux sinon.
     *
     * Cette fonction tient compte de la valeur retournée par la fonction outlineSummaryRight.
     */
    /*!
     * \fn bool areColumnChildrenCollapsed(unsigned int index) const
     * \brief Savoir si les colonnes enfants sont repliées.
     * \param index L'index de la colonne demandée ([0, ∞[).
     * \return Vrai la colonne a des colonnes enfants et qu'elles sont repliées, faux sinon.
     *
     * Cette fonction tient compte de la valeur retournée par la fonction outlineSummaryRight.
     */
    virtual bool isColumnVisible(unsigned int) const;
    virtual double columnWidth(unsigned int) const;
    virtual unsigned short columnOutlineLevel(unsigned int) const;
    virtual bool isColumnCollapsed(unsigned int) const;
    virtual const Interface::Read::CellFormat* columnCellFormat(unsigned int) const;

    virtual bool isColumnDefault(unsigned int) const;

    virtual bool getColumnParentIndex(unsigned int, unsigned int&) const;
    virtual bool hasColumnChildren(unsigned int) const;
    virtual bool areColumnChildrenCollapsed(unsigned int) const;

    /*!
     * \fn bool isRowVisible(unsigned int index) const
     * \brief La ligne est-elle visible ?
     * \param index L'index de la ligne demandée ([0, ∞[).
     * \return Vrai si la ligne est visible, faux sinon.
     */
    /*!
     * \fn double rowHeight(unsigned int index) const
     * \brief Obtenir la taille de la ligne.
     * \param index L'index de la ligne demandée ([0, ∞[).
     * \return La hauteur de la ligne.
     *
     * La taille des lignes est exprimée en point.
     */
    /*!
     * \fn unsigned short rowOutlineLevel(unsigned int index) const
     * \brief Obtenir le niveau de regroupement.
     * \param index L'index de la ligne demandée ([0, ∞[).
     * \return Le niveau de regroupement de la ligne.
     */
    /*!
     * \fn bool isRowCollapsed(unsigned int index) const
     * \brief Le regroupement est-il masqué ?
     * \param index L'index de la ligne demandée ([0, ∞[).
     * \return Vrai si le regroupement est masqué, faux sinon.
     */
    /*!
     * \fn const Interface::Read::CellFormat* rowCellFormat(unsigned int index) const
     * \brief Obtenir le format de cellule assigné à la ligne.
     * \param index L'index de la ligne demandée ([0, ∞[).
     * \return Le format de cellule assigné à la ligne, NULL si aucun format n'est assigné.
     */
    /*!
     * \fn bool isRowDefault(unsigned int index) const
     * \brief Savoir si la ligne a les paramètres par défaut.
     * \param index L'index de la ligne demandée ([0, ∞[).
     * \return Vrai si la ligne a les paramètres par défaut, faux sinon.
     */
    /*!
     * \fn bool getRowParentIndex(unsigned int index, unsigned int& parentIndex) const
     * \brief Obtenir l'index de la ligne parente d'une ligne.
     * \param index L'index de la ligne demandée ([0, ∞[).
     * \param parentIndex L'index de la ligne parente (si la ligne a une ligne parente).
     * \return Vrai si la ligne a une ligne parente, faux sinon.
     *
     * Cette fonction tient compte de la valeur retournée par la fonction outlineSummaryBelow.
     */
    /*!
     * \fn bool hasRowChildren(unsigned int index) const
     * \brief Savoir si la ligne a des lignes enfants.
     * \param index L'index de la ligne demandée ([0, ∞[).
     * \return Vrai si la ligne a des lignes enfants, faux sinon.
     *
     * Cette fonction tient compte de la valeur retournée par la fonction outlineSummaryBelow.
     */
    /*!
     * \fn bool areRowChildrenCollapsed(unsigned int index) const
     * \brief Savoir si les lignes enfants sont repliées.
     * \param index L'index de la ligne demandée ([0, ∞[).
     * \return Vrai la ligne a des lignes enfants et qu'elles sont repliées, faux sinon.
     *
     * Cette fonction tient compte de la valeur retournée par la fonction outlineSummaryBelow.
     */
    virtual bool isRowVisible(unsigned int) const;
    virtual double rowHeight(unsigned int) const;
    virtual unsigned short rowOutlineLevel(unsigned int) const;
    virtual bool isRowCollapsed(unsigned int) const;
    virtual const Interface::Read::CellFormat* rowCellFormat(unsigned int) const;

    virtual bool isRowDefault(unsigned int) const;

    virtual bool getRowParentIndex(unsigned int, unsigned int&) const;
    virtual bool hasRowChildren(unsigned int) const;
    virtual bool areRowChildrenCollapsed(unsigned int) const;

    /*!
     * \fn double defaultColumnWidth() const
     * \brief Obtenir la taille par défaut des colonnes.
     * \return La taille par défaut des colonnes.
     *
     * La taille de la colonne correspond au nombre de chiffres maximum visibles dans la police de style normal.
     * Pour le calcul, Excel utilise la taille du chiffre le plus large, ajoute 2 pixels de marge de chaque côté et 1 pixel pour la grille.\n
     * Le calcul est : taille en pixel = trunc({size} * 7)
     */
    /*!
     * \fn double defaultRowHeight() const
     * \brief Obtenir la taille par défaut des lignes.
     * \return La taille par défaut des lignes (exprimée en point).
     */
    virtual double defaultColumnWidth() const;
    virtual double defaultRowHeight() const;

    /*!
     * \fn bool outlineSummaryRight() const
     * \brief La colonne de récapitulation est elle à droite des colonnes plan ?
     * \return Vrai si cette colonne est à droite, faux sinon.
     */
    /*!
     * \fn bool outlineSummaryBelow() const
     * \brief La ligne de récapitulation est elle en dessous des lignes plan ?
     * \return Vrai si cette ligne est en dessous, faux sinon.
     */
    virtual bool outlineSummaryRight() const;
    virtual bool outlineSummaryBelow() const;

    /*!
     * \fn bool getXSplit(unsigned int& xSplitIndex) const
     * \brief Obtenir l'index de la dernière colonne fixe si il y en a.
     * \param xSplitIndex L'index de la dernière colonne fixe si il y en a ([0, ∞[).
     * \return Vrai si il y a des colonnes fixes et que le paramètre a été affecté, faux sinon.
     */
    /*!
     * \fn bool getYSplit(unsigned int& ySplitIndex) const
     * \brief Obtenir l'index de la dernière ligne fixe si il y en a.
     * \param ySplitIndex L'index de la dernière ligne fixe si il y en a ([0, ∞[).
     * \return Vrai si il y a des lignes fixes et que le paramètre a été affecté, faux sinon.
     */
    virtual bool getXSplit(unsigned int&) const;
    virtual bool getYSplit(unsigned int&) const;

    /*!
     * \fn size_t mergeCount() const
     * \brief Obtenir le nombre de fusions de cellules.
     * \return Le nombre de fusions de cellules.
     */
    /*!
     * \fn const Coordinates::CellRange* merge(size_t index) const
     * \brief Obtenir les coordonnées d'une fusion de cellules.
     * \param index Un index compris entre 0 et mergeCount().
     * \return Les coordonnées d'une fusion de cellules, NULL si l'index est erroné.
     */
    virtual size_t mergeCount() const;
    virtual const Coordinates::CellRange* merge(size_t) const;

    /*!
     * \fn const Interface::Read::CellFormat* cellFormat(unsigned int col, unsigned int row) const
     * \brief Obtenir le format d'une cellule.
     * \param col L'index de la colonne de la cellule concernée ([0, ∞[).
     * \param row L'index de la ligne de la cellule concernée ([0, ∞[).
     * \return Le format de la cellule concernée.
     */
    /*!
     * \fn const Interface::Read::CellValue* cellValue(unsigned int col, unsigned int row) const
     * \brief Obtenir la valeur d'une cellule.
     * \param col L'index de la colonne de la cellule concernée ([0, ∞[).
     * \param row L'index de la ligne de la cellule concernée ([0, ∞[).
     * \return La valeur de la cellule concernée.
     */
    virtual const Interface::Read::CellFormat* cellFormat(unsigned int, unsigned int) const;
    virtual const Interface::Read::CellValue* cellValue(unsigned int, unsigned int) const;

    /*!
     * \fn size_t conditionalFormattingCount() const
     * \brief Obtenir le nombre de formats conditionnels.
     * \return Le nombre de formats conditionnels.
     */
    /*!
     * \fn const Interface::Read::ConditionalFormatting* conditionalFormatting(size_t index) const
     * \brief Obtenir un format conditionnel.
     * \param index Un index compris entre 0 et conditionalFormattingCount().
     * \return Un format conditionnel, NULL si l'index est erroné.
     */
    virtual size_t conditionalFormattingCount() const;
    virtual const Interface::Read::ConditionalFormatting* conditionalFormatting(size_t) const;

    /*!
     * \fn size_t validationCount() const
     * \brief Obtenir le nombre de règles de validation.
     * \return Le nombre de règles de validation.
     */
    /*!
     * \fn const Interface::Read::Validation* validation(size_t index) const
     * \brief Obtenir une règle de validation.
     * \param index Un index compris entre 0 et validationCount().
     * \return Une règle de validation, NULL si l'index est erroné.
     */
    virtual size_t validationCount() const;
    virtual const Interface::Read::Validation* validation(size_t) const;

    /*!
     * \fn const Interface::Read::Filter* filter() const
     * \brief Obtenir le filtre.
     * \return Le filtre ou NULL.
     */
    virtual const Interface::Read::Filter* filter() const;

    /*!
     * \fn bool containsValidImages() const
     * \brief La feuille contient elle des images valides ?
     * \return Vrai si la feuille contient des images valides, faux sinon.
     */
    /*!
     * \fn size_t imageCount() const
     * \brief Obtenir le nombre d'images.
     * \return Le nombre d'images.
     */
    /*!
     * \fn const Image* image(size_t index) const
     * \brief Obtenir une image.
     * \param index Un index compris entre 0 et imageCount().
     * \return Une image, NULL si l'index est erroné.
     */
    virtual bool containsValidImages() const;
    virtual size_t imageCount() const;
    virtual const Interface::Read::Image* image(size_t) const;

    /*!
     * \fn size_t hyperlinkCount() const
     * \brief Obtenir le nombre de liens.
     * \return Le nombre de liens.
     */
    /*!
     * \fn const Interface::Read::Hyperlink* hyperlink(size_t index) const
     * \brief Obtenir les paramètres d'un lien.
     * \param index Un index compris entre 0 et hyperlinkCount().
     * \return Les paramètres du lien, NULL si l'index est erroné.
     */
    virtual size_t hyperlinkCount() const;
    virtual const Interface::Read::Hyperlink* hyperlink(size_t) const;

    /*!
     * \fn size_t commentCount() const
     * \brief Obtenir le nombre de commentaires.
     * \return Le nombre de commentaires.
     */
    /*!
     * \fn const Interface::Read::Comment* comment(size_t index) const
     * \brief Obtenir les paramètres d'un commentaire.
     * \return Les paramètres du commentaire, NULL si l'index est erroné.
     */
    /*!
     * \fn const Interface::Read::Comment* comment(unsigned int col, unsigned int row) const
     * \brief Obtenir les paramètres d'un commentaire.
     * \param col L'index de la colonne de la cellule concernée ([0, ∞[).
     * \param row L'index de la ligne de la cellule concernée ([0, ∞[).
     * \return Les paramètres du commentaire, NULL si il n'y a pas de commentaire sur la cellule concernée.
     */
    virtual size_t commentCount() const;
    virtual const Interface::Read::Comment* comment(size_t) const;
    virtual const Interface::Read::Comment* comment(unsigned int, unsigned int) const;

public:
    /*!
     * \fn const Coordinates::WorksheetProxy* proxy() const
     * \brief Obtenir le proxy de la feuille.
     * \return Le proxy de la feuille.
     */
    virtual const Coordinates::WorksheetProxy* proxy() const;

    /*!
     * \fn void setHidden(bool hidden)
     * \brief Cacher ou rendre visible la feuille.
     * \param hidden Si vrai, la feuille est cachée.
     */
    virtual void setHidden(bool);

    /*!
     * \fn void showFormulas(bool show)
     * \brief Rendre les formules visibles dans la feuille.
     * \param show Si vrai, les formules seront affichées.
     */
    virtual void showFormulas(bool);

    /*!
     * \fn void showGridLines(bool show) 
     * \brief Rendre le quadrillage visible dans la feuille ?
     * \param show Si vrai, le quadrillage sera affiché.
     */
    virtual void showGridLines(bool);

    /*!
     * \fn void showRowColHeaders(bool show)
     * \brief Rendre les entêtes de lignes et de colonnes visibles dans la feuille ?
     * \param show Si vrai, les entêtes de lignes et de colonnes seront affichés.
     */
    virtual void showRowColHeaders(bool);

    /*!
     * \fn void showZeros(bool show)
     * \brief Afficher un zéro dans les cellules qui ont une valeur nulle.
     * \param show Si vrai, les zéros seront affichés.
     */
    virtual void showZeros(bool);

    /*!
     * \fn void setActiveCell(const Coordinates::Cell& cell)
     * \brief Spécifier la cellule active.
     * \param cell Les coordonnées de la cellule active.
     * Si la cellule n'appartient pas à la selection, la selection est changée en la cellule active.
     */
    /*!
     * \fn void setSelection(const Coordinates::MultiCellRange& cell)
     * \brief Spécifier les cellules sélectionnées.
     * \param cell Les coordonnées des cellules sélectionnées.
     * Si la cellule active n'appartient pas à la selection, la cellule est changée en la coordonnée de la cellule en haut à droite de la première plage de sélection.
     */
    virtual void setActiveCell(const Coordinates::Cell&);
    virtual void setSelection(const Coordinates::MultiCellRange&);

    /*!
     * \fn Interface::Write::PageSetting* createPageSetting() const
     * \brief Créer des paramètres d'impression de la feuille.
     * \return Les paramètres d'impression.
     */
    /*!
     * \fn void setPageSetting(const Interface::Write::PageSetting& pageSetting)
     * \brief Assigner les paramètres d'impression de la feuille.
     * \param pageSetting Les paramètres d'impression de la feuille.
     */
    virtual Interface::Write::PageSetting* createPageSetting() const;
    virtual void setPageSetting(const Interface::Write::PageSetting&);

    /*!
     * \fn void setColumnVisible(unsigned int index, bool visible)
     * \brief Rendre la colonne visible ou invisible.
     * \param index L'index de la colonne concernée ([0, ∞[).
     * \param visible Vrai si la colonne est visible, faux sinon.
     */
    /*!
     * \fn void setColumnWidth(unsigned int index, const double* size)
     * \brief Assigner la taille.
     * \param index L'index de la colonne concernée ([0, ∞[).
     * \param size La largeur de la colonne. Si NULL, la colonne aura la taille définie par défaut.
     *
     * La taille de la colonne correspond au nombre de chiffres maximum visibles dans la police de style normal.
     * Pour le calcul, Excel utilise la taille du chiffre le plus large.
     * Excel ajoute 2 pixels de marge de chaque côté et 1 pixel pour la grille.
     * Le calcul est : taille en pixel = trunc({size} * 7)
     */
    /*!
     * \fn void setColumnOutlineLevel(unsigned int index, unsigned short outlineLevel)
     * \brief Assigner le niveau de groupement.
     * \param index L'index de la colonne concernée ([0, ∞[).
     * \param outlineLevel Le niveau. Doit être compris entre [0-7].
     */
    /*!
     * \fn void setColumnCollapsed(unsigned int index, bool collapsed)
     * \brief Rendre le groupement masqué.
     * \param index L'index de la colonne concernée ([0, ∞[).
     * \param collapsed Vrai si le groupement doit être masqué, faux sinon.
     */
    /*!
     * \fn void setColumnFormat(unsigned int index, const Interface::Write::CellFormat* format)
     * \brief Assigner un format de cellule à la colonne.
     * \param index L'index de la colonne concernée ([0, ∞[).
     * \param format Le format de cellule.
     */
    /*!
     * \fn bool setColumnChildrenCollapsed(unsigned int index, bool collapsed)
     * \brief Rendre les colonnes enfants de la colonne masquées.
     * \param index L'index de la colonne concernée ([0, ∞[).
     * \param collapsed Vrai si le groupement doit être masqué, faux sinon.
     * \return Vrai si la colonne a des enfants, faux sinon.
     *
     * Cette fonction tient compte de la valeur assignée par la fonction setOutlineSummaryRight.
     */
    virtual void setColumnVisible(unsigned int, bool);
    virtual void setColumnWidth(unsigned int, const double*);
    virtual void setColumnOutlineLevel(unsigned int, unsigned short);
    virtual void setColumnCollapsed(unsigned int, bool);
    virtual void setColumnFormat(unsigned int, const Interface::Write::CellFormat*);

    virtual bool setColumnChildrenCollapsed(unsigned int, bool);

    /*!
     * \fn void setRowVisible(unsigned int index, bool visible)
     * \brief Rendre la ligne visible ou invisible.
     * \param index L'index de la ligne concernée ([0, ∞[).
     * \param visible Vrai si la ligne est visible, faux sinon.
     */
    /*!
     * \fn void setRowHeight(unsigned int index, const double* size)
     * \brief Assigner la taille.
     * \param index L'index de la ligne concernée ([0, ∞[).
     * \param size La hauteur de la ligne. Si NULL, la colonne aura la taille définie par défaut.
     *
     * La taille des lignes est exprimée en point.
     */
    /*!
     * \fn void setRowOutlineLevel(unsigned int index, unsigned short outlineLevel)
     * \brief Assigner le niveau de groupement.
     * \param index L'index de la ligne concernée ([0, ∞[).
     * \param outlineLevel Le niveau. Doit être compris entre [0-7].
     */
    /*!
     * \fn void setRowCollapsed(unsigned int index, bool collapsed)
     * \brief Rendre le groupement masqué.
     * \param index L'index de la ligne concernée ([0, ∞[).
     * \param collapsed Vrai si le groupement doit être masqué, faux sinon.
     */
    /*!
     * \fn void setRowFormat(unsigned int index, const Interface::Write::CellFormat* format)
     * \brief Assigner un format de cellule à la ligne.
     * \param index L'index de la ligne concernée ([0, ∞[).
     * \param format Le format de cellule.
     */
    /*!
     * \fn bool setRowChildrenCollapsed(unsigned int index, bool collapsed)
     * \brief Rendre les lignes enfants de la ligne masquées.
     * \param index L'index de la ligne concernée ([0, ∞[).
     * \param collapsed Vrai si le groupement doit être masqué, faux sinon.
     * \return Vrai si la ligne a des enfants, faux sinon.
     *
     * Cette fonction tient compte de la valeur assignée par la fonction setOutlineSummaryBelow.
     */
    virtual void setRowVisible(unsigned int, bool);
    virtual void setRowHeight(unsigned int, const double*);
    virtual void setRowOutlineLevel(unsigned int, unsigned short);
    virtual void setRowCollapsed(unsigned int, bool);
    virtual void setRowFormat(unsigned int, const Interface::Write::CellFormat*);

    virtual bool setRowChildrenCollapsed(unsigned int, bool);

    /*!
     * \fn void setDefaultColumnWidth(double width)
     * \brief Spécifier la taille par défaut des colonnes.
     * \param width La largeur par défaut des colonnes.
     *
     * La taille de la colonne correspond au nombre de chiffres maximum visibles dans la police de style normal.
     * Pour le calcul, Excel utilise la taille du chiffre le plus large.
     * Excel ajoute 2 pixels de marge de chaque côté et 1 pixel pour la grille.
     * Le calcul est : taille en pixel = trunc({size} * 7)
     */
    /*!
     * \fn void setDefaultRowHeight(double height)
     * \brief Spécifier la taille par défaut des lignes.
     * \param height La hauteur par défault des lignes (exprimée en point).
     */
    virtual void setDefaultColumnWidth(double);
    virtual void setDefaultRowHeight(double);

    /*!
     * \fn void setOutlineSummaryRight(bool summaryRight)
     * \brief Assigner la position de la colonne de récapitulation.
     * \param summaryRight Vrai si la colone de récapitulation doit être à droite, faux sinon.
     */
    /*!
     * \fn void setOutlineSummaryBelow(bool summaryBelow)
     * \brief Assigner la position de la ligne de récapitulation.
     * \param summaryBelow Vrai si la ligne de récapitulation doit être en bas, faux sinon.
     */
    virtual void setOutlineSummaryRight(bool);
    virtual void setOutlineSummaryBelow(bool);

    /*!
     * \fn void setXSplit(unsigned int column)
     * \brief Assigner la dernière colonne fixe.
     * \param column L'index de la dernière colone fixe ([0, ∞[).
     */
    /*!
     * \fn void unsetXSplit()
     * \brief Supprimer les colonnes fixes.
     */
    virtual void setXSplit(unsigned int);
    virtual void unsetXSplit();

    /*!
     * \fn void setYSplit(unsigned int row)
     * \brief Assigner la dernière ligne fixe.
     * \param row L'index de la dernière ligne fixe ([0, ∞[).
     */
    /*!
     * \fn void unsetYSplit()
     * \brief Supprimer les lignes fixes.
     */
    virtual void setYSplit(unsigned int);
    virtual void unsetYSplit();

    /*!
     * \fn Interface::Write::CellFormat* createFormat() const
     * \brief Créer un format de cellule.
     * \return Un nouveau format de cellule.
     */
    /*!
     * \fn void setFormat(unsigned int column, unsigned int row, const Interface::Write::CellFormat& format)
     * \brief Assigner un format à une cellule.
     * \param column L'index de la colonne.
     * \param row L'index de la ligne.
     * \param format Le format à assigner. Il sera ajouté au classeur.
     */
    virtual Interface::Write::CellFormat* createFormat() const;
    virtual void setFormat(unsigned int, unsigned int, const Interface::Write::CellFormat&);

    /*!
     * \fn void setSimpleCellValue(unsigned int column, unsigned int row, const Interface::Write::CellValue& value)
     * \brief Assigner une valeur à une cellule.
     * \param column L'index de la colonne.
     * \param row L'index de la ligne.
     * \param value La valeur à assigner.
     */
    /*!
     * \fn void setNullValue(unsigned int column, unsigned int row, const Interface::utf8String_t& formula)
     * \brief Assigner une valeur nulle à une cellule.
     * \param column L'index de la colonne ([0, ∞[).
     * \param row L'index de la ligne ([0, ∞[).
     * \param formula La formule de calcul au format "natif" Excel.
     */
    /*!
     * \fn void setBooleanValue(unsigned int column, unsigned int row, bool value, const Interface::utf8String_t& formula)
     * \brief Assigner une valeur à une cellule.
     * \param column L'index de la colonne ([0, ∞[).
     * \param row L'index de la ligne ([0, ∞[).
     * \param value La valeur booléenne.
     * \param formula La formule de calcul au format "natif" Excel.
     */
    /*!
     * \fn void setNumberValue(unsigned int column, unsigned int row, double value, const Interface::utf8String_t& formula)
     * \brief Assigner une valeur à une cellule.
     * \param column L'index de la colonne ([0, ∞[).
     * \param row L'index de la ligne ([0, ∞[).
     * \param value La valeur numérique.
     * \param formula La formule de calcul au format "natif" Excel.
     */
    /*!
     * \fn void setStringValue(unsigned int column, unsigned int row, const Interface::utf8String_t& value, const Interface::utf8String_t& formula)
     * \brief Assigner une valeur à une cellule.
     * \param column L'index de la colonne ([0, ∞[).
     * \param row L'index de la ligne ([0, ∞[).
     * \param value La valeur chaîne.
     * \param formula La formule de calcul au format "natif" Excel.
     */
    /*!
     * \fn void setErrorValue(unsigned int column, unsigned int row, Interface::cellError_t value, const Interface::utf8String_t& formula)
     * \brief Assigner une valeur à une cellule.
     * \param column L'index de la colonne ([0, ∞[).
     * \param row L'index de la ligne ([0, ∞[).
     * \param value Le type d'erreur.
     * \param formula La formule de calcul au format "natif" Excel.
     */
    /*!
     * \fn void forceDateValue(unsigned int column, unsigned int row, double value, const Interface::utf8String_t& formula)
     * \brief Assigner une valeur date à une cellule. Le format de la cellule sera édité pour pointer sur une chaîne de format "en dur dans Excel" qui représente le format date (format qui répond aux changements dans les paramètres régionnaux).
     * \param column L'index de la colonne ([0, ∞[).
     * \param row L'index de la ligne ([0, ∞[).
     * \param value La date.
     * \param formula La formule de calcul au format "natif" Excel.
     */
	/*!
	 * \fn Interface::Write::RichText* createRichText() const
	 * \brief Créer un texte riche.
	 * \return Un nouveau texte riche.
	 */
	/*!
	 * \fn void setRichTextValue(unsigned int column, unsigned int row, const Interface::Write::RichText* value, const Interface::utf8String_t& formula)
	 * \brief Assigner une valeur à une cellule.
	 * \param column L'index de la colonne ([0, ∞[).
	 * \param row L'index de la ligne ([0, ∞[).
	 * \param value La valeur texte riche.
	 * \param formula La formule de calcul au format "natif" Excel.
	 */
	virtual void setSimpleCellValue(unsigned int, unsigned int, const Interface::Write::CellValue&);
    virtual void setNullValue(unsigned int, unsigned int, const Interface::utf8String_t& ="");
    virtual void setBooleanValue(unsigned int, unsigned int, bool, const Interface::utf8String_t& ="");
    virtual void setNumberValue(unsigned int, unsigned int, double, const Interface::utf8String_t& ="");
    virtual void setStringValue(unsigned int, unsigned int, const Interface::utf8String_t&, const Interface::utf8String_t& ="");
    virtual void setErrorValue(unsigned int, unsigned int, Interface::cellError_t, const Interface::utf8String_t& ="");

    virtual void forceDateValue(unsigned int, unsigned int, double, const Interface::utf8String_t& ="");

	virtual Interface::Write::RichText* createRichText() const;
	virtual void setRichTextValue(unsigned int, unsigned int, const Interface::Write::RichText*, const Interface::utf8String_t& = "");

    /*!
     * \fn void setMerge(const Coordinates::CellRange& merge)
     * \brief Ajouter une fusion de cellule.
     * \param merge La plage de cellules fusionnées.
     */
    virtual void setMerge(const Coordinates::CellRange&);

    /*!
     * \fn Interface::Write::DifferentialCellFormat* createDifferentialCellFormat() const
     * \brief Créer un format différentiel.
     * \return Un nouveau format différentiel.
     */
    /*!
     * \fn Interface::Write::ConditionalFormatting* createConditionalFormatting() const
     * \brief Créer un format conditionnel.
     * \return Un nouveau format conditionnel.
     */
    /*!
     * \fn void addConditionalFormatting(const Interface::Write::ConditionalFormatting& conditionalFormatting)
     * \brief Ajouter un format conditionnel.
     * \param conditionalFormatting Le format conditionnel à ajouter.
     */
    virtual Interface::Write::DifferentialCellFormat* createDifferentialCellFormat() const;
    virtual Interface::Write::ConditionalFormatting* createConditionalFormatting() const;
    virtual void addConditionalFormatting(const Interface::Write::ConditionalFormatting&);

    /*!
     * \fn Interface::Write::CustomValidation* createCustomValidation() const
     * \brief Créer une règle de validation de données à partir d'une formule.
     * \return Une nouvelle règle de validation de données à partir d'une formule.
     */
    /*!
     * \fn Interface::Write::ListValidation* createListValidation() const
     * \brief Créer une règle de validation de données à partir d'une liste.
     * \return Une nouvelle règle de validation de données à partir d'une liste.
     */
    /*!
     * \fn void addValidation(const Interface::Write::Validation* validation)
     * \brief Ajouter une règle de validation.
     * \param validation La règle de validation.
     */
    virtual Interface::Write::CustomValidation* createCustomValidation() const;
    virtual Interface::Write::ListValidation* createListValidation() const;
    virtual void addValidation(const Interface::Write::Validation*);

    /*!
     * \fn Interface::Write::Filter* createFilter() const
     * \brief Créer un filtre.
     * \return Un nouveau filtre.
     */
    /*!
     * \fn void setFilter(const Interface::Write::Filter& filter)
     * \brief Assigne un filtre.
     * \param filter Le filtre.
     */
    virtual Interface::Write::Filter* createFilter() const;
    virtual void setFilter(const Interface::Write::Filter&);

    /*!
     * \fn Interface::Write::Image* createImage() const
     * \brief Créer une image.
     * \return Une nouvelle image.
     */
    /*!
     * \fn void addImage(const Interface::Write::Image* image)
     * \brief Ajouter une image (JPG, GIF, PNG ou BMP).
     * \param image L'image.
     */
    virtual Interface::Write::Image* createImage() const;
    virtual void addImage(const Interface::Write::Image*);

    /*!
     * \fn Interface::Write::Hyperlink* createHyperlink() const
     * \brief Créer un lien.
     * \return Un nouveau lien.
     */
    /*!
     * \fn void addHyperlink(const Interface::Write::Hyperlink* hyperlink)
     * \brief Ajouter un lien.
     * \param hyperlink Les paramètres du lien.
     */
    virtual Interface::Write::Hyperlink* createHyperlink() const;
    virtual void addHyperlink(const Interface::Write::Hyperlink*);

    /*!
     * \fn Interface::Write::Comment* createComment() const
     * \brief Créer un commentaire.
     * \return Un nouveau commentaire.
     */
    /*!
     * \fn bool addComment(const Interface::Write::Comment* comment)
     * \brief Ajouter un commentaire.
     * \param comment Les paramètres du commentaire.
     * \return Vrai si le commentaire a été ajouté, faux sinon (un commentaire existe déjà sur cette cellule).
     */
    virtual Interface::Write::Comment* createComment() const;
    virtual bool addComment(const Interface::Write::Comment*);

public:
    /*!
     * \fn SimpleWorksheet()
     * \brief Constructeur. DELETE.
     */
    /*!
     * \fn SimpleWorksheet(const SimpleWorksheet& worksheet)
     * \brief Constructeur de recopie. DELETE.
     * \param worksheet La feuille à recopier.
     */
    /*!
     * \fn SimpleWorksheet& operator =(const SimpleWorksheet& worksheet)
     * \brief Opérateur de recopie. DELETE.
     * \param worksheet La feuille à recopier.
     * \return Cette feuille.
     */
    SimpleWorksheet() = delete;
    SimpleWorksheet(const SimpleWorksheet&) = delete;
    SimpleWorksheet& operator =(const SimpleWorksheet&) = delete;

    /*!
     * \fn SimpleWorksheet(SimpleWorkbook* workbook, const Interface::utf8String_t& name);
     * \brief Constructeur.
     * \param workbook Classeur contenant cette feuille de calcul.
     * \param name Nom de la feuille de calcul.
     */
    SimpleWorksheet(SimpleWorkbook*, const Interface::utf8String_t&);

    /*!
     * \fn ~SimpleWorksheet()
     * \brief Destructeur.
     */
    ~SimpleWorksheet();

private:
    // Les fonctions setFormat du Workbook accèdent directement à la fonction privée setFormat de la Worksheet pour optimisation.
    friend void SimpleWorkbook::setFormat(const Coordinates::CellRange&, const Interface::Write::CellFormat&);
    friend void SimpleWorkbook::setFormat(const Coordinates::MultiCellRange&, const Interface::Write::CellFormat&);
    void setFormat(unsigned int, unsigned int, Interface::formatIdentifier_t);

    void updateMinBounds(const Coordinates::Cell&);

    SimpleWorkbook* m_workbook;
    Interface::utf8SharedString_t m_name;

    bool m_hidden;
    bool m_showFormulas;
    bool m_showGridLines;
    bool m_showRowColHeaders;
    bool m_showZeros;

    Coordinates::MultiCellRange m_selection;
    Coordinates::Cell m_activeCell;

    // paramètres d'impression
    SimplePageSetting* m_pageSetting;

    // la taille de grille minimale
    Coordinates::CellRange m_minBounds;

    // les colonnes et les lignes
    class ColumnRow {
    public:
        ColumnRow();
        ColumnRow(const ColumnRow&);
        ColumnRow& operator =(const ColumnRow&);
        ~ColumnRow();

        void setVisible(bool);
        void setSize(const double*);
        void setOutlineLevel(unsigned short);
        void setCollapsed(bool);
        void setFormatIdentifier(const Interface::formatIdentifier_t*);

        bool isVisible() const;
        const double* size() const;
        unsigned short outlineLevel() const;
        bool isCollapsed() const;
        const Interface::formatIdentifier_t* formatIdentifier() const;

        bool isDefault() const;
    private:
        bool m_isVisible;
        double* m_size;
        unsigned short m_outlineLevel;
        bool m_isCollapsed;
        Interface::formatIdentifier_t* m_formatIdentifier;
    };

    typedef std::unordered_map<unsigned int, ColumnRow> columnsRows_t;
    columnsRows_t m_columns;
    columnsRows_t m_rows;

    double m_defaultColumnWidth;
    double m_defaultRowHeight;

    bool m_summaryRight;
    bool m_summaryBelow;

    unsigned int* m_xSplit;
    unsigned int* m_ySplit;

    // cellules (valeur & format)
    typedef std::unordered_map<CellPosition, CellDescription, Hasher<CellPosition>> cells_t;
    cells_t m_cells;

    // les fusions
    typedef std::vector<Coordinates::CellRange> ranges_t;
    ranges_t m_merges;

    // les formats conditionnels
    typedef std::vector<SimpleConditionalFormatting> conditionalFormattingRules_t;
    conditionalFormattingRules_t m_conditionalFormattingRules;

    // les validations
    typedef std::vector<const SimpleValidation*> validations_t;
    validations_t m_validations;

    // les filtres
    SimpleFilter* m_filter;

    // les images
    typedef std::vector<const SimpleImage*> images_t;
    images_t m_images;

    // les liens
    typedef std::vector<const SimpleHyperlink*> hyperlinks_t;
    hyperlinks_t m_hyperlinks;

    // les commentaires
    typedef std::vector<const SimpleComment*> comments_t;
    typedef std::unordered_map<CellPosition, const SimpleComment*, Hasher<CellPosition>> mappedComments_t;
    comments_t m_comments;
    mappedComments_t m_mappedComments;


#if defined(INVOKE_XLSX_LOGS)
public:
    size_t log_size() const;
    void log_scan(Debug::Container*) const;
#endif
};

} // namespace SimpleWorkbook
} // namespace XLSX
} // namespace Invoke

#endif  /* invoke_xlsx_simpleWorkbook_hpp */
