/*!
 * \file        SimpleWorkbook.cpp
 * \author      Invoke - Jean-Christophe PHILIPPE (jcphilippe\@invoke.fr)
 * \date        Novembre 2014
 * \copyright   SA Invoke
 */

#include "xlsx/SimpleWorkbook.hpp"
#include "string/UtfString.hpp"
#include "string/Unicode.hpp"

#include "unicode/unistr.h"
#include <concept_check.hpp>
#include <vector>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <string.h>


#if defined(INVOKE_XLSX_LOGS)
#define LOG_SCAN_ADD_OBJECT(__container__, __name__, __size__) \
    if (__container__) { \
        Debug::Object* w_log_object = __container__->addObject(__name__); \
        w_log_object->add(__size__); \
    }
#endif


namespace Invoke {
namespace XLSX {
namespace SimpleWorkbook {

size_t SimpleRichText::runCount() const
{
	if (m_runs)
		return m_runs->size();
	return 0;
}

const Interface::font_t* SimpleRichText::runFont(size_t p_index) const
{
	if ((m_runs) && (p_index < m_runs->size()))
		return &(m_runs->at(p_index).font);
	return nullptr;
}

const Interface::utf8String_t* SimpleRichText::runText(size_t p_index) const
{
	if ((m_runs) && (p_index < m_runs->size()))
		return &(m_runs->at(p_index).text.string());
	return nullptr;
}

Interface::utf8String_t SimpleRichText::text() const
{
	if (m_runs) {
		Interface::utf8String_t w_result = "";
		for (const run_t& w_run : *m_runs)
			w_result += w_run.text;
		return w_result;
	}
	
	if (m_text)
		return *m_text;
	
	return "";
}

void SimpleRichText::clear() 
{
	delete m_runs;
	delete m_text;

	m_runs = nullptr;
	m_text = nullptr;
}

void SimpleRichText::addRun(const Interface::font_t& p_font, const Interface::utf8String_t& p_text)
{
	delete m_text;
	m_text = nullptr;

	if (!m_runs) 
		m_runs = new runs_t();

	if ((m_runs->size() > 0) && (m_runs->back().font == p_font))
		m_runs->back().text = m_runs->back().text + p_text;
	else
		m_runs->push_back({ p_font, p_text });
}

void SimpleRichText::setText(const Interface::utf8String_t& p_text)
{
	delete m_runs;
	m_runs = nullptr;

	if (!m_text) 
		m_text = new Interface::utf8SharedString_t();
        
	*m_text = p_text;
}

SimpleRichText::SimpleRichText()
:   m_runs(nullptr),
    m_text(nullptr)
{
}

SimpleRichText::SimpleRichText(const SimpleRichText& p_richtext)
:   m_runs(nullptr),
    m_text(nullptr)
{
	*this = p_richtext;
}

SimpleRichText& SimpleRichText::operator =(const SimpleRichText& p_richtext)
{
	clear();

	if (p_richtext.m_runs) {
		m_runs = new runs_t();
		*m_runs = *(p_richtext.m_runs);
	}

	if (p_richtext.m_text) {
		m_text = new Interface::utf8SharedString_t();
        *m_text = *(p_richtext.m_text);
	}

	return *this;
}

SimpleRichText::~SimpleRichText()
{
	delete m_runs;
	delete m_text;
}

#if defined(INVOKE_XLSX_LOGS)
size_t SimpleRichText::log_size() const
{
    size_t w_size = sizeof(*this);
    if (m_runs)
        w_size += sizeof(*m_runs);
    if (m_text)
        w_size += sizeof(*m_text);
    
    return w_size;
}

void SimpleRichText::log_scan(Debug::Container* p_container) const
{
    LOG_SCAN_ADD_OBJECT(p_container, "SimpleRichText", log_size());
}
#endif

Interface::cellType_t SimpleCellValue::type() const
{
    return m_type;
}

bool SimpleCellValue::boolean() const
{
    if (m_type == Interface::ctBoolean)
        return m_value.boolean;
    return false;
}

double SimpleCellValue::number() const
{
    if (m_type == Interface::ctNumber)
        return m_value.number;
    return 0;
}

Interface::utf8String_t SimpleCellValue::string() const
{
    if ((m_type == Interface::ctString) && (m_value.string))
        return m_value.string->string();
    if ((m_type == Interface::ctRichText) && (m_value.text))
        return m_value.text->text();
    return "";
}

Interface::cellError_t SimpleCellValue::error() const
{
    if (m_type == Interface::ctError)
        return m_value.error;
    return Interface::ceNONE;
}

Interface::utf8String_t SimpleCellValue::formula() const
{
    if (m_formula)
        return *m_formula;
    return "";
}

const Interface::Read::RichText* SimpleCellValue::text() const
{
    if (m_type == Interface::ctRichText)
	    return m_value.text;
    return nullptr;
}

void SimpleCellValue::setNull(const Interface::utf8String_t& p_formula)
{
    if (m_type == Interface::ctString)
        delete m_value.string;
    if (m_type == Interface::ctRichText)
        delete m_value.text;
    
    m_type = Interface::ctNull;
    m_value.text = nullptr;
    
    delete m_formula;
    m_formula = nullptr;

    if (p_formula != "") {
        m_formula = new Interface::utf8SharedString_t();
        *m_formula = p_formula;
    }
}

void SimpleCellValue::setBoolean(bool p_value, const Interface::utf8String_t& p_formula)
{
    setNull(p_formula);

    m_type = Interface::ctBoolean;
    m_value.boolean = p_value;
}

void SimpleCellValue::setNumber(double p_value, const Interface::utf8String_t& p_formula)
{
    setNull(p_formula);

    m_type = Interface::ctNumber;
    m_value.number = p_value;
}

void SimpleCellValue::setString(const Interface::utf8String_t& p_value, const Interface::utf8String_t& p_formula)
{
    setNull(p_formula);

    m_type = Interface::ctString;
    m_value.string = new Interface::utf8SharedString_t();
    *m_value.string = p_value;
}

void SimpleCellValue::setError(Interface::cellError_t p_value, const Interface::utf8String_t& p_formula)
{
    setNull(p_formula);

    m_type = Interface::ctError;
    m_value.error = p_value;
}

void SimpleCellValue::setText(const Interface::Write::RichText* p_text, const Interface::utf8String_t& p_formula)
{
    setNull(p_formula);

    SimpleRichText const * const k_richText = dynamic_cast<const SimpleRichText*>(p_text);
    if (k_richText) {
        if (k_richText->runCount() < 2) {
            m_type = Interface::ctString;
            m_value.string = new Interface::utf8SharedString_t(k_richText->text());
        } else {
            m_type = Interface::ctRichText;
            m_value.text = new SimpleRichText(*k_richText);
        }
    }
}

SimpleCellValue::SimpleCellValue()
:   m_type(Interface::ctNull),
    m_value({nullptr}),
    m_formula(nullptr)
{
}

SimpleCellValue::SimpleCellValue(const SimpleCellValue& p_cellValue)
:   m_type(Interface::ctNull),
    m_value({nullptr}),
    m_formula(nullptr)
{
    *this = p_cellValue;
}

SimpleCellValue& SimpleCellValue::operator =(const SimpleCellValue& p_cellValue)
{
    switch (p_cellValue.type()) {
    case Interface::ctBoolean:
        setBoolean(p_cellValue.boolean(), p_cellValue.formula());
        break;

    case Interface::ctNumber:
        setNumber(p_cellValue.number(), p_cellValue.formula());
        break;

    case Interface::ctString:
        setString(p_cellValue.string(), p_cellValue.formula());
        break;

    case Interface::ctRichText: {
            SimpleRichText const * const k_richText = dynamic_cast<const SimpleRichText*>(p_cellValue.text());
            if (k_richText)
                setText(k_richText, p_cellValue.formula());
            else
                setString(p_cellValue.string(), p_cellValue.formula());
        }
        break;

    case Interface::ctError:
        setError(p_cellValue.error(), p_cellValue.formula());
        break;

    default:
        setNull(p_cellValue.formula());
        break;
    }

    return *this;
}

SimpleCellValue::SimpleCellValue(bool p_value, const Interface::utf8String_t& p_formula)
:   m_type(Interface::ctNull),
    m_value({nullptr}),
    m_formula(nullptr)
{
    setBoolean(p_value, p_formula);
}

SimpleCellValue::SimpleCellValue(double p_value, const Interface::utf8String_t& p_formula)
:   m_type(Interface::ctNull),
    m_value({nullptr}),
    m_formula(nullptr)
{
    setNumber(p_value, p_formula);
}

SimpleCellValue::SimpleCellValue(const Interface::utf8String_t& p_value, const Interface::utf8String_t& p_formula)
:   m_type(Interface::ctNull),
    m_value({nullptr}),
    m_formula(nullptr)
{
    setString(p_value, p_formula);
}

SimpleCellValue::SimpleCellValue(Interface::cellError_t p_value, const Interface::utf8String_t& p_formula)
:   m_type(Interface::ctNull),
    m_value({nullptr}),
    m_formula(nullptr)
{
    setError(p_value, p_formula);
}

SimpleCellValue::SimpleCellValue(const SimpleRichText& p_value, const Interface::utf8String_t& p_formula)
:   m_type(Interface::ctNull),
    m_value({nullptr}),
    m_formula(nullptr)
{
    setText(&p_value, p_formula);
}

SimpleCellValue::~SimpleCellValue()
{
    setNull();
}

#if defined(INVOKE_XLSX_LOGS)
size_t SimpleCellValue::log_size() const
{
    size_t w_size = sizeof(*this);
    if ((m_type == Interface::ctString) && (m_value.string))
        w_size += sizeof(*m_value.string);
    if ((m_type == Interface::ctRichText) && (m_value.text))
        w_size += m_value.text->log_size();
    if (m_formula)
        w_size += sizeof(*m_formula);

    return w_size;
}

void SimpleCellValue::log_scan(Debug::Container* p_container) const
{
    LOG_SCAN_ADD_OBJECT(p_container, "SimpleCellValue", log_size());
}
#endif

Interface::utf8String_t SimpleDefinedName::name() const
{
    return m_name;
}

const Coordinates::MultiCellRange& SimpleDefinedName::zone() const
{
    return m_zone;
}

void SimpleDefinedName::setName(const Interface::utf8String_t& p_name)
{
    m_name = Interface::correctDefinedName(p_name);
}

void SimpleDefinedName::setZone(const Coordinates::MultiCellRange& p_zone)
{
    m_zone = p_zone;
}

SimpleDefinedName::SimpleDefinedName(const Interface::utf8String_t& p_name, const Coordinates::MultiCellRange& p_zone)
:   m_name( Interface::correctDefinedName(p_name) ),
    m_zone(p_zone)
{
}

#if defined(INVOKE_XLSX_LOGS)
size_t SimpleDefinedName::log_size() const
{
    return sizeof(*this);
}

void SimpleDefinedName::log_scan(Debug::Container* p_container) const
{
    LOG_SCAN_ADD_OBJECT(p_container, "SimpleDefinedName", log_size());
}
#endif

bool SimplePageHeaderFooter::isDifferentFirst() const
{
    return ((m_firstHeader) || (m_firstFooter));
}

bool SimplePageHeaderFooter::isDifferentOddEven() const
{
    return ((m_evenHeader) || (m_evenFooter));
}

const Interface::utf8String_t* SimplePageHeaderFooter::leftFirstHeader() const
{
    if (m_firstHeader)
        return &m_firstHeader[0];
    return nullptr;
}

const Interface::utf8String_t* SimplePageHeaderFooter::centerFirstHeader() const
{
    if (m_firstHeader)
        return &m_firstHeader[1];
    return nullptr;
}

const Interface::utf8String_t* SimplePageHeaderFooter::rightFirstHeader() const
{
    if (m_firstHeader)
        return &m_firstHeader[2];
    return nullptr;
}

const Interface::utf8String_t* SimplePageHeaderFooter::leftFirstFooter() const
{
    if (m_firstFooter)
        return &m_firstFooter[0];
    return nullptr;
}

const Interface::utf8String_t* SimplePageHeaderFooter::centerFirstFooter() const
{
    if (m_firstFooter)
        return &m_firstFooter[1];
    return nullptr;
}

const Interface::utf8String_t* SimplePageHeaderFooter::rightFirstFooter() const
{
    if (m_firstFooter)
        return &m_firstFooter[2];
    return nullptr;
}

const Interface::utf8String_t* SimplePageHeaderFooter::leftEvenHeader() const
{
    if (m_evenHeader)
        return &m_evenHeader[0];
    return nullptr;
}

const Interface::utf8String_t* SimplePageHeaderFooter::centerEvenHeader() const
{
    if (m_evenHeader)
        return &m_evenHeader[1];
    return nullptr;
}

const Interface::utf8String_t* SimplePageHeaderFooter::rightEvenHeader() const
{
    if (m_evenHeader)
        return &m_evenHeader[2];
    return nullptr;
}

const Interface::utf8String_t* SimplePageHeaderFooter::leftEvenFooter() const
{
    if (m_evenFooter)
        return &m_evenFooter[0];
    return nullptr;
}

const Interface::utf8String_t* SimplePageHeaderFooter::centerEvenFooter() const
{
    if (m_evenFooter)
        return &m_evenFooter[1];
    return nullptr;
}

const Interface::utf8String_t* SimplePageHeaderFooter::rightEvenFooter() const
{
    if (m_evenFooter)
        return &m_evenFooter[2];
    return nullptr;
}

Interface::utf8String_t SimplePageHeaderFooter::leftHeader() const
{
    return m_header[0];
}

Interface::utf8String_t SimplePageHeaderFooter::centerHeader() const
{
    return m_header[1];
}

Interface::utf8String_t SimplePageHeaderFooter::rightHeader() const
{
    return m_header[2];
}

Interface::utf8String_t SimplePageHeaderFooter::leftFooter() const
{
    return m_footer[0];
}

Interface::utf8String_t SimplePageHeaderFooter::centerFooter() const
{
    return m_footer[1];
}

Interface::utf8String_t SimplePageHeaderFooter::rightFooter() const
{
    return m_footer[2];
}

void SimplePageHeaderFooter::setFirstHeader(const Interface::utf8String_t& p_left, const Interface::utf8String_t& p_center, const Interface::utf8String_t& p_right)
{
    if (!m_firstHeader)
        m_firstHeader = new Interface::utf8String_t[3];
    m_firstHeader[0] = p_left;
    m_firstHeader[1] = p_center;
    m_firstHeader[2] = p_right;
}

void SimplePageHeaderFooter::setFirstFooter(const Interface::utf8String_t& p_left, const Interface::utf8String_t& p_center, const Interface::utf8String_t& p_right)
{
    if (!m_firstFooter)
        m_firstFooter = new Interface::utf8String_t[3];
    m_firstFooter[0] = p_left;
    m_firstFooter[1] = p_center;
    m_firstFooter[2] = p_right;
}

void SimplePageHeaderFooter::setEvenHeader(const Interface::utf8String_t& p_left, const Interface::utf8String_t& p_center, const Interface::utf8String_t& p_right)
{
    if (!m_evenHeader)
        m_evenHeader = new Interface::utf8String_t[3];
    m_evenHeader[0] = p_left;
    m_evenHeader[1] = p_center;
    m_evenHeader[2] = p_right;
}

void SimplePageHeaderFooter::setEvenFooter(const Interface::utf8String_t& p_left, const Interface::utf8String_t& p_center, const Interface::utf8String_t& p_right)
{
    if (!m_evenFooter)
        m_evenFooter = new Interface::utf8String_t[3];
    m_evenFooter[0] = p_left;
    m_evenFooter[1] = p_center;
    m_evenFooter[2] = p_right;
}

void SimplePageHeaderFooter::setHeader(const Interface::utf8String_t& p_left, const Interface::utf8String_t& p_center, const Interface::utf8String_t& p_right)
{
    m_header[0] = p_left;
    m_header[1] = p_center;
    m_header[2] = p_right;
}

void SimplePageHeaderFooter::setFooter(const Interface::utf8String_t& p_left, const Interface::utf8String_t& p_center, const Interface::utf8String_t& p_right)
{
    m_footer[0] = p_left;
    m_footer[1] = p_center;
    m_footer[2] = p_right;
}

SimplePageHeaderFooter::SimplePageHeaderFooter()
:   m_firstHeader(nullptr),
    m_firstFooter(nullptr),
    m_evenHeader(nullptr),
    m_evenFooter(nullptr),
    m_header(),
    m_footer()
{
    m_header[0] = "";
    m_header[1] = "";
    m_header[2] = "";
    m_footer[0] = "";
    m_footer[1] = "";
    m_footer[2] = "";
}

SimplePageHeaderFooter::SimplePageHeaderFooter(const SimplePageHeaderFooter& p_pageHeaderFooter)
:   m_firstHeader(nullptr),
    m_firstFooter(nullptr),
    m_evenHeader(nullptr),
    m_evenFooter(nullptr),
    m_header(),
    m_footer()
{
    if (p_pageHeaderFooter.m_firstHeader)
        setFirstHeader( p_pageHeaderFooter.m_firstHeader[0], p_pageHeaderFooter.m_firstHeader[1], p_pageHeaderFooter.m_firstHeader[2] );
    if (p_pageHeaderFooter.m_firstFooter)
        setFirstFooter( p_pageHeaderFooter.m_firstFooter[0], p_pageHeaderFooter.m_firstFooter[1], p_pageHeaderFooter.m_firstFooter[2] );

    if (p_pageHeaderFooter.m_evenHeader)
        setEvenHeader( p_pageHeaderFooter.m_evenHeader[0], p_pageHeaderFooter.m_evenHeader[1], p_pageHeaderFooter.m_evenHeader[2] );
    if (p_pageHeaderFooter.m_evenFooter)
        setEvenFooter( p_pageHeaderFooter.m_evenFooter[0], p_pageHeaderFooter.m_evenFooter[1], p_pageHeaderFooter.m_evenFooter[2] );

    setHeader(p_pageHeaderFooter.m_header[0], p_pageHeaderFooter.m_header[1], p_pageHeaderFooter.m_header[2]);
    setFooter(p_pageHeaderFooter.m_footer[0], p_pageHeaderFooter.m_footer[1], p_pageHeaderFooter.m_footer[2]);
}

SimplePageHeaderFooter& SimplePageHeaderFooter::operator =(const SimplePageHeaderFooter& p_pageHeaderFooter)
{
    delete[] m_firstHeader;
    delete[] m_firstFooter;
    m_firstHeader = nullptr;
    m_firstFooter = nullptr;

    delete[] m_evenHeader;
    delete[] m_evenFooter;
    m_evenHeader = nullptr;
    m_evenFooter = nullptr;

    if (p_pageHeaderFooter.m_firstHeader)
        setFirstHeader( p_pageHeaderFooter.m_firstHeader[0], p_pageHeaderFooter.m_firstHeader[1], p_pageHeaderFooter.m_firstHeader[2] );
    if (p_pageHeaderFooter.m_firstFooter)
        setFirstFooter( p_pageHeaderFooter.m_firstFooter[0], p_pageHeaderFooter.m_firstFooter[1], p_pageHeaderFooter.m_firstFooter[2] );

    if (p_pageHeaderFooter.m_evenHeader)
        setEvenHeader( p_pageHeaderFooter.m_evenHeader[0], p_pageHeaderFooter.m_evenHeader[1], p_pageHeaderFooter.m_evenHeader[2] );
    if (p_pageHeaderFooter.m_evenFooter)
        setEvenFooter( p_pageHeaderFooter.m_evenFooter[0], p_pageHeaderFooter.m_evenFooter[1], p_pageHeaderFooter.m_evenFooter[2] );

    setHeader(p_pageHeaderFooter.m_header[0], p_pageHeaderFooter.m_header[1], p_pageHeaderFooter.m_header[2]);
    setFooter(p_pageHeaderFooter.m_footer[0], p_pageHeaderFooter.m_footer[1], p_pageHeaderFooter.m_footer[2]);

    return *this;
}

SimplePageHeaderFooter::~SimplePageHeaderFooter()
{
    delete[] m_firstHeader;
    delete[] m_firstFooter;

    delete[] m_evenHeader;
    delete[] m_evenFooter;
}

#if defined(INVOKE_XLSX_LOGS)
size_t SimplePageHeaderFooter::log_size() const
{
    size_t w_size = sizeof(*this);
    if (m_firstHeader)
        w_size += sizeof(*m_firstHeader);
    if (m_firstFooter)
        w_size += sizeof(*m_firstFooter);
    if (m_evenHeader)
        w_size += sizeof(*m_evenHeader);
    if (m_evenFooter)
        w_size += sizeof(*m_evenFooter);

    return w_size;
}

void SimplePageHeaderFooter::log_scan(Debug::Container* p_container) const
{
    LOG_SCAN_ADD_OBJECT(p_container, "SimplePageHeaderFooter", log_size());
}
#endif

const Coordinates::MultiCellRange* SimplePageSetting::printArea() const
{
    return m_printArea;
}

const Coordinates::ColumnRowRange* SimplePageSetting::headerColumns() const
{
    return m_headerColumns;
}

const Coordinates::ColumnRowRange* SimplePageSetting::headerRows() const
{
    return m_headerRows;
}

Interface::pageOrientation_t SimplePageSetting::pageOrientation() const
{
    return m_pageOrientation;
}

unsigned int SimplePageSetting::fitToWidth() const
{
    return m_fitToWidth;
}

unsigned int SimplePageSetting::fitToHeight() const
{
    return m_fitToHeight;
}

const unsigned short* SimplePageSetting::scale() const
{
    return m_scale;
}

const Interface::Read::PageHeaderFooter* SimplePageSetting::pageHeaderFooter() const
{
    return m_pageHeaderFooter;
}

void SimplePageSetting::setPrintArea(const Coordinates::MultiCellRange* p_printArea)
{
    if (p_printArea) {
        if (m_printArea)
            *m_printArea = *p_printArea;
        else
            m_printArea = new Coordinates::MultiCellRange(*p_printArea);
    } else {
        delete m_printArea;
        m_printArea = nullptr;
    }
}

void SimplePageSetting::setHeader(const Coordinates::ColumnRowRange* p_range)
{
    if (p_range->type() == Interface::crtColumn) {
        delete m_headerColumns;
        m_headerColumns = nullptr;
        if (p_range)
            m_headerColumns = new Coordinates::ColumnRowRange(*p_range);
    }

    if (p_range->type() == Interface::crtRow) {
        delete m_headerRows;
        m_headerRows = nullptr;
        if (p_range)
            m_headerRows = new Coordinates::ColumnRowRange(*p_range);
    }
}

void SimplePageSetting::setPageOrientation(Interface::pageOrientation_t p_orientation)
{
    m_pageOrientation = p_orientation;
}

void SimplePageSetting::setFitToWidth(unsigned int p_pages)
{
    m_fitToWidth = p_pages;
}

void SimplePageSetting::setFitToHeight(unsigned int p_pages)
{
    m_fitToHeight = p_pages;
}

void SimplePageSetting::setScale(const unsigned short* p_scale)
{
    delete m_scale;
    m_scale = nullptr;

    if ((p_scale) && (*p_scale >= 10) && (*p_scale <= 400))
        m_scale = new unsigned short(*p_scale);
}

Interface::Write::PageHeaderFooter* SimplePageSetting::createPageHeaderFooter() const
{
    return new SimplePageHeaderFooter();
}

void SimplePageSetting::setPageHeaderFooter(const Interface::Write::PageHeaderFooter& p_pageHeaderFooter)
{
    delete m_pageHeaderFooter;
    m_pageHeaderFooter = nullptr;

    SimplePageHeaderFooter const * const k_pageHeaderFooter = dynamic_cast<SimplePageHeaderFooter const * const>(&p_pageHeaderFooter);
    if (k_pageHeaderFooter)
        m_pageHeaderFooter = new SimplePageHeaderFooter(*k_pageHeaderFooter);
}

SimplePageSetting::SimplePageSetting()
:   m_printArea(nullptr),
    m_headerColumns(nullptr),
    m_headerRows(nullptr),
    m_pageOrientation(Interface::poDefault),
    m_fitToWidth(0),
    m_fitToHeight(0),
    m_scale(nullptr),
    m_pageHeaderFooter(nullptr)
{
}

SimplePageSetting::SimplePageSetting(const SimplePageSetting& p_pageSetting)
:   m_printArea(nullptr),
    m_headerColumns(nullptr),
    m_headerRows(nullptr),
    m_pageOrientation(p_pageSetting.m_pageOrientation),
    m_fitToWidth(p_pageSetting.m_fitToWidth),
    m_fitToHeight(p_pageSetting.m_fitToHeight),
    m_scale(nullptr),
    m_pageHeaderFooter(nullptr)
{
    if (p_pageSetting.m_printArea)
        m_printArea = new Coordinates::MultiCellRange( *p_pageSetting.m_printArea );
    if (p_pageSetting.m_headerColumns)
        m_headerColumns = new Coordinates::ColumnRowRange( *p_pageSetting.m_headerColumns );
    if (p_pageSetting.m_headerRows)
        m_headerRows = new Coordinates::ColumnRowRange( *p_pageSetting.m_headerRows );
    if (p_pageSetting.m_scale)
        m_scale = new unsigned short( *p_pageSetting.m_scale );
    if (p_pageSetting.m_pageHeaderFooter)
        m_pageHeaderFooter = new SimplePageHeaderFooter( *p_pageSetting.m_pageHeaderFooter );
}

SimplePageSetting& SimplePageSetting::operator =(const SimplePageSetting& p_pageSetting)
{
    delete m_printArea;
    m_printArea = nullptr;

    delete m_headerColumns;
    m_headerColumns = nullptr;

    delete m_headerRows;
    m_headerRows = nullptr;

    delete m_scale;
    m_scale = nullptr;

    delete m_pageHeaderFooter;
    m_pageHeaderFooter = nullptr;

    if (p_pageSetting.m_printArea)
        m_printArea = new Coordinates::MultiCellRange( *p_pageSetting.m_printArea );

    if (p_pageSetting.m_headerColumns)
        m_headerColumns = new Coordinates::ColumnRowRange( *p_pageSetting.m_headerColumns );

    if (p_pageSetting.m_headerRows)
        m_headerRows = new Coordinates::ColumnRowRange( *p_pageSetting.m_headerRows );

    if (p_pageSetting.m_scale)
        m_scale = new unsigned short( *p_pageSetting.m_scale );

    if (p_pageSetting.m_pageHeaderFooter)
        m_pageHeaderFooter = new SimplePageHeaderFooter( *p_pageSetting.m_pageHeaderFooter );

    return *this;
}

SimplePageSetting::~SimplePageSetting()
{
    delete m_printArea;
    delete m_headerColumns;
    delete m_headerRows;
    delete m_scale;
    delete m_pageHeaderFooter;
}

#if defined(INVOKE_XLSX_LOGS)
size_t SimplePageSetting::log_size() const
{
    size_t w_size = sizeof(*this);
    if (m_printArea)
        w_size += sizeof(*m_printArea);
    if (m_headerColumns)
        w_size += sizeof(*m_headerColumns);
    if (m_headerRows)
        w_size += sizeof(*m_headerRows);
    if (m_scale)
        w_size += sizeof(*m_scale);
    if (m_pageHeaderFooter)
        w_size += m_pageHeaderFooter->log_size();

    return w_size;
}

void SimplePageSetting::log_scan(Debug::Container* p_container) const
{
    if (p_container) {
        Debug::Container* w_container = p_container->addContainer("SimplePageSetting", log_size());
        if (m_pageHeaderFooter)
            m_pageHeaderFooter->log_scan(w_container);
    }
}
#endif

Interface::utf8String_t SimpleCellFormat::fontName() const
{
    return m_fontName;
}

unsigned short SimpleCellFormat::fontSize() const
{
    return m_fontSize;
}

Interface::color_t SimpleCellFormat::fontColor() const
{
    return m_fontColor;
}

bool SimpleCellFormat::isFontBolded() const
{
    return m_fontBold;
}

bool SimpleCellFormat::isFontItalicized() const
{
    return m_fontItalic;
}

bool SimpleCellFormat::isFontUnderlined() const
{
    return m_fontUnderline;
}

Interface::utf8String_t SimpleCellFormat::numberFormat() const
{
    return m_numberFormat;
}

unsigned short SimpleCellFormat::builtInNumberFormatId() const
{
    return m_builtInNumFmtId;
}

Interface::patternStyle_t SimpleCellFormat::patternStyle() const
{
    return m_patternStyle;
}

Interface::color_t SimpleCellFormat::foregroundColor() const
{
    return m_foreColor;
}

Interface::color_t SimpleCellFormat::backgroundColor() const
{
    return m_backColor;
}

bool SimpleCellFormat::isBorderVisible(Interface::border_t p_border) const
{
    return m_borderVisible[p_border];
}

Interface::borderStyle_t SimpleCellFormat::borderStyle(Interface::border_t p_border) const
{
    return m_borderStyle[p_border];
}

Interface::color_t SimpleCellFormat::borderColor(Interface::border_t p_border) const
{
    return m_borderColor[p_border];
}

Interface::horizontalAlignment_t SimpleCellFormat::horizontalAlignment() const
{
    return m_horizontalAlignment;
}

Interface::verticalAlignment_t SimpleCellFormat::verticalAlignment() const
{
    return m_verticalAlignment;
}

unsigned short SimpleCellFormat::textIndent() const
{
    return m_indent;
}

short SimpleCellFormat::textRotation() const
{
    return m_rotation;
}

bool SimpleCellFormat::wrapText() const
{
    return m_wrap;
}

void SimpleCellFormat::setFontName(const Interface::utf8String_t& p_name)
{
    m_fontName = p_name;
}

void SimpleCellFormat::setFontSize(unsigned short p_size)
{
    m_fontSize = p_size;
}

void SimpleCellFormat::setFontColor(Interface::color_t p_color)
{
    m_fontColor = p_color;
}

void SimpleCellFormat::setFontStyle(bool p_bold, bool p_italic, bool p_underline)
{
    m_fontBold = p_bold;
    m_fontItalic = p_italic;
    m_fontUnderline = p_underline;
}

void SimpleCellFormat::setFont(const Interface::utf8String_t& p_name, unsigned short p_size, Interface::color_t p_color, bool p_bold, bool p_italic, bool p_underline)
{
    m_fontName = p_name;
    m_fontSize = p_size;
    m_fontColor = p_color;
    m_fontBold = p_bold;
    m_fontItalic = p_italic;
    m_fontUnderline = p_underline;
}

void SimpleCellFormat::setNumberFormat(const Interface::utf8String_t& p_numberFormat)
{
    m_numberFormat = p_numberFormat;
}

void SimpleCellFormat::setBuiltInNumberFormatId(unsigned short p_id)
{
    m_builtInNumFmtId = p_id;
}

void SimpleCellFormat::setPatternStyle(Interface::patternStyle_t p_style)
{
    m_patternStyle = p_style;
}

void SimpleCellFormat::setForegroundColor(Interface::color_t p_color)
{
    m_foreColor = p_color;
}

void SimpleCellFormat::setBackgroundColor(Interface::color_t p_color)
{
    m_backColor = p_color;
}

void SimpleCellFormat::setSolidBackColor(Interface::color_t p_color)
{
    m_patternStyle = Interface::psSolid;
    m_foreColor = p_color;
    m_backColor = 0x00000000;
}

void SimpleCellFormat::setBorderVisible(Interface::border_t p_border, bool p_isVisible)
{
    m_borderVisible[p_border] = p_isVisible;
}

void SimpleCellFormat::setBorderStyle(Interface::border_t p_border, Interface::borderStyle_t p_style)
{
    m_borderStyle[p_border] = p_style;
}

void SimpleCellFormat::setBorderColor(Interface::border_t p_border, Interface::color_t p_color)
{
    m_borderColor[p_border] = p_color;
}

void SimpleCellFormat::setHorizontalAlignment(Interface::horizontalAlignment_t p_alignment)
{
    m_horizontalAlignment = p_alignment;
}

void SimpleCellFormat::setVerticalAlignment(Interface::verticalAlignment_t p_alignment)
{
    m_verticalAlignment = p_alignment;
}

void SimpleCellFormat::setTextIndent(unsigned short p_indent)
{
    m_indent = p_indent;
}

void SimpleCellFormat::setTextRotation(short p_angle)
{
    m_rotation = p_angle;
}

void SimpleCellFormat::setWrapText(bool p_wrap)
{
    m_wrap = p_wrap;
}

SimpleCellFormat::SimpleCellFormat()
:   m_fontName("Arial"), m_fontSize(10), m_fontColor(0), m_fontBold(false), m_fontItalic(false), m_fontUnderline(false),
    m_numberFormat(""),
    m_builtInNumFmtId(0),
    m_patternStyle(Interface::psNone),
    m_foreColor(0),
    m_backColor(0),
    //m_borderVisible(), m_borderStyle(), m_borderColor(),	=> MSVC++ warning C4351
    m_horizontalAlignment(Interface::haAuto),
    m_verticalAlignment(Interface::vaBottom),
    m_indent(0),
    m_rotation(0),
    m_wrap(false)
{
    for (unsigned short i = 0; i < 6; ++i) {
        m_borderVisible[i] = false;
        m_borderStyle[i] = Interface::bsThin;
        m_borderColor[i] = 0;
    }
}

SimpleCellFormat::SimpleCellFormat(const Interface::Read::CellFormat* p_format)
:   m_fontName( (p_format) ? p_format->fontName() : "Arial" ), m_fontSize( (p_format) ? p_format->fontSize() : 10 ), m_fontColor( (p_format) ? p_format->fontColor() : 0), m_fontBold( (p_format) ? p_format->isFontBolded() : false ), m_fontItalic( (p_format) ? p_format->isFontItalicized() : false ), m_fontUnderline( (p_format) ? p_format->isFontUnderlined() : false ),
    m_numberFormat( (p_format) ? p_format->numberFormat() : "" ),
    m_builtInNumFmtId( (p_format) ? p_format->builtInNumberFormatId() : 0 ),
    m_patternStyle( (p_format) ? p_format->patternStyle() : Interface::psNone ),
    m_foreColor( (p_format) ? p_format->foregroundColor() : 0 ),
    m_backColor( (p_format) ? p_format->backgroundColor() : 0 ),
    //m_borderVisible(), m_borderStyle(), m_borderColor(),	=> MSVC++ warning C4351
    m_horizontalAlignment( (p_format) ? p_format->horizontalAlignment() : Interface::haAuto ),
    m_verticalAlignment( (p_format) ? p_format->verticalAlignment() : Interface::vaBottom ),
    m_indent( (p_format) ? p_format->textIndent() : 0 ),
    m_rotation( (p_format) ? p_format->textRotation() : 0 ),
    m_wrap( (p_format) ? p_format->wrapText() : false )
{
    for (unsigned short i = 0; i < 6; ++i) {
        m_borderVisible[i] = ((p_format) ? p_format->isBorderVisible(static_cast<Interface::border_t>(i)) : false);
        m_borderStyle[i] = ((p_format) ? p_format->borderStyle(static_cast<Interface::border_t>(i)) : Interface::bsThin);
        m_borderColor[i] = ((p_format) ? p_format->borderColor(static_cast<Interface::border_t>(i)) : 0);
    }
}

bool SimpleCellFormat::operator ==(const SimpleCellFormat& p_format) const
{
    return  (  (m_fontName == p_format.m_fontName)
            && (m_fontSize == p_format.m_fontSize)
            && (m_fontColor == p_format.m_fontColor)
            && (m_fontBold == p_format.m_fontBold)
            && (m_fontItalic == p_format.m_fontItalic)
            && (m_fontUnderline == p_format.m_fontUnderline)
            && (m_numberFormat == p_format.m_numberFormat)
            && (m_builtInNumFmtId == p_format.m_builtInNumFmtId)
            && (m_patternStyle == p_format.m_patternStyle)
            && (m_foreColor == p_format.m_foreColor)
            && (m_backColor == p_format.m_backColor)
            && (m_borderVisible[Interface::bLeft] == p_format.m_borderVisible[Interface::bLeft])
            && (m_borderStyle[Interface::bLeft] == p_format.m_borderStyle[Interface::bLeft])
            && (m_borderColor[Interface::bLeft] == p_format.m_borderColor[Interface::bLeft])
            && (m_borderVisible[Interface::bTop] == p_format.m_borderVisible[Interface::bTop])
            && (m_borderStyle[Interface::bTop] == p_format.m_borderStyle[Interface::bTop])
            && (m_borderColor[Interface::bTop] == p_format.m_borderColor[Interface::bTop])
            && (m_borderVisible[Interface::bRight] == p_format.m_borderVisible[Interface::bRight])
            && (m_borderStyle[Interface::bRight] == p_format.m_borderStyle[Interface::bRight])
            && (m_borderColor[Interface::bRight] == p_format.m_borderColor[Interface::bRight])
            && (m_borderVisible[Interface::bBottom] == p_format.m_borderVisible[Interface::bBottom])
            && (m_borderStyle[Interface::bBottom] == p_format.m_borderStyle[Interface::bBottom])
            && (m_borderColor[Interface::bBottom] == p_format.m_borderColor[Interface::bBottom])
            && (m_borderVisible[Interface::bDiagonalUp] == p_format.m_borderVisible[Interface::bDiagonalUp])
            && (m_borderStyle[Interface::bDiagonalUp] == p_format.m_borderStyle[Interface::bDiagonalUp])
            && (m_borderColor[Interface::bDiagonalUp] == p_format.m_borderColor[Interface::bDiagonalUp])
            && (m_borderVisible[Interface::bDiagonalDown] == p_format.m_borderVisible[Interface::bDiagonalDown])
            && (m_borderStyle[Interface::bDiagonalDown] == p_format.m_borderStyle[Interface::bDiagonalDown])
            && (m_borderColor[Interface::bDiagonalDown] == p_format.m_borderColor[Interface::bDiagonalDown])
            && (m_horizontalAlignment == p_format.m_horizontalAlignment)
            && (m_verticalAlignment == p_format.m_verticalAlignment)
            && (m_indent == p_format.m_indent)
            && (m_rotation == p_format.m_rotation)
            && (m_wrap == p_format.m_wrap)
            );
}

std::string SimpleCellFormat::stringCode() const
{
    std::stringstream w_result;

    w_result    << "F{"
                << fontName() << ","
                << fontSize() << ","
                << fontColor()
                << (isFontBolded() ? "B" : "")
                << (isFontItalicized() ? "I" : "")
                << (isFontUnderlined() ? "U" : "")
                << "}";

    w_result    << "FS{" << numberFormat() << "}";

    w_result    << "P{"
                << patternStyle() << ","
                << foregroundColor() << ","
                << backgroundColor()
                << "}";

    w_result    << "B{";
    w_result    << "l(" << (!isBorderVisible(Interface::bLeft) ? "X" : "") << "," << borderStyle(Interface::bLeft) << "," << borderColor(Interface::bLeft) << ")";
    w_result    << "t(" << (!isBorderVisible(Interface::bTop) ? "X" : "") << "," << borderStyle(Interface::bTop) << "," << borderColor(Interface::bTop) << ")";
    w_result    << "r(" << (!isBorderVisible(Interface::bRight) ? "X" : "") << "," << borderStyle(Interface::bRight) << "," << borderColor(Interface::bRight) << ")";
    w_result    << "b(" << (!isBorderVisible(Interface::bBottom) ? "X" : "") << "," << borderStyle(Interface::bBottom) << "," << borderColor(Interface::bBottom) << ")";
    w_result    << "du(" << (!isBorderVisible(Interface::bDiagonalUp) ? "X" : "") << "," << borderStyle(Interface::bDiagonalUp) << "," << borderColor(Interface::bDiagonalUp) << ")";
    w_result    << "dd(" << (!isBorderVisible(Interface::bDiagonalDown) ? "X" : "") << "," << borderStyle(Interface::bDiagonalDown) << "," << borderColor(Interface::bDiagonalDown) << ")";
    w_result    << "}";

    w_result    << "A{"
                << horizontalAlignment() << ","
                << verticalAlignment() << ","
                << textIndent() << ","
                << textRotation()
                << "}";

    if (wrapText())
        w_result << "WT";

    return w_result.str();
}

#if defined(INVOKE_XLSX_LOGS)
size_t SimpleCellFormat::log_size() const
{
    return sizeof(*this);
}

void SimpleCellFormat::log_scan(Debug::Container* p_container) const
{
    LOG_SCAN_ADD_OBJECT(p_container, "SimpleCellFormat", log_size());
}
#endif

unsigned long Hasher<SimpleCellFormat>::operator()(const SimpleCellFormat& p_key) const
{
    // djb2
    const std::string k_stringCode = p_key.stringCode();

    unsigned long w_hash = 5381;
    for (std::string::const_iterator w_it = k_stringCode.begin(); w_it != k_stringCode.end(); ++w_it)
        w_hash = (w_hash << 5) + w_hash + *w_it;
    return w_hash;
}

const Interface::color_t* SimpleDifferentialCellFormat::fontColor() const
{
    return m_fontColor;
}

const bool* SimpleDifferentialCellFormat::isFontBolded() const
{
    return m_fontBold;
}

const bool* SimpleDifferentialCellFormat::isFontItalicized() const
{
    return m_fontItalic;
}

const bool* SimpleDifferentialCellFormat::isFontUnderlined() const
{
    return m_fontUnderline;
}

const Interface::utf8String_t* SimpleDifferentialCellFormat::numberFormat() const
{
    return m_numberFormat;
}

const unsigned short* SimpleDifferentialCellFormat::builtInNumberFormatId() const
{
    return m_buildInNumberFormatId;
}

const Interface::patternStyle_t* SimpleDifferentialCellFormat::patternStyle() const
{
    return m_patternStyle;
}

const Interface::color_t* SimpleDifferentialCellFormat::foregroundColor() const
{
    return m_foregroundColor;
}

const Interface::color_t* SimpleDifferentialCellFormat::backgroundColor() const
{
    return m_backgroundColor;
}

const bool* SimpleDifferentialCellFormat::isBorderVisible(Interface::border_t p_border) const
{
    return m_borderVisible[p_border];
}

const Interface::borderStyle_t* SimpleDifferentialCellFormat::borderStyle(Interface::border_t p_border) const
{
    return m_borderStyle[p_border];
}

const Interface::color_t* SimpleDifferentialCellFormat::borderColor(Interface::border_t p_border) const
{
    return m_borderColor[p_border];
}

void SimpleDifferentialCellFormat::setFontColor(Interface::color_t p_color)
{
    if ((!m_fontColor) || (*m_fontColor != p_color)) {
        unsetFontColor();
        m_fontColor = new Interface::color_t(p_color);
    }
}

void SimpleDifferentialCellFormat::setFontBold(bool p_bold)
{
    if ((!m_fontBold) || (*m_fontBold != p_bold)) {
        unsetFontBold();
        m_fontBold = new bool(p_bold);
    }
}

void SimpleDifferentialCellFormat::setFontItalic(bool p_italic)
{
    if ((!m_fontItalic) || (*m_fontItalic != p_italic)) {
        unsetFontItalic();
        m_fontItalic = new bool(p_italic);
    }
}

void SimpleDifferentialCellFormat::setFontUnderline(bool p_underline)
{
    if ((!m_fontUnderline) || (*m_fontUnderline != p_underline)) {
        unsetFontUnderline();
        m_fontUnderline = new bool(p_underline);
    }
}

void SimpleDifferentialCellFormat::unsetFontColor()
{
    delete m_fontColor;
    m_fontColor = nullptr;
}

void SimpleDifferentialCellFormat::unsetFontBold()
{
    delete m_fontBold;
    m_fontBold = nullptr;
}

void SimpleDifferentialCellFormat::unsetFontItalic()
{
    delete m_fontItalic;
    m_fontItalic = nullptr;
}

void SimpleDifferentialCellFormat::unsetFontUnderline()
{
    delete m_fontUnderline;
    m_fontUnderline = nullptr;
}

void SimpleDifferentialCellFormat::setNumberFormat(const Interface::utf8String_t& p_numberFormat)
{
    if ((!m_numberFormat) || (*m_numberFormat != p_numberFormat)) {
        unsetNumberFormat();
        m_numberFormat = new Interface::utf8String_t(p_numberFormat);
    }
}

void SimpleDifferentialCellFormat::setBuildInNumberFormatId(unsigned short p_formatId)
{
    if ((!m_buildInNumberFormatId) || (*m_buildInNumberFormatId != p_formatId)) {
        unsetBuildInNumberFormatId();
        m_buildInNumberFormatId = new unsigned short(p_formatId);
    }
}

void SimpleDifferentialCellFormat::unsetNumberFormat()
{
    delete m_numberFormat;
    m_numberFormat = nullptr;
}

void SimpleDifferentialCellFormat::unsetBuildInNumberFormatId()
{
    delete m_buildInNumberFormatId;
    m_buildInNumberFormatId = nullptr;
}

void SimpleDifferentialCellFormat::setPatternStyle(Interface::patternStyle_t p_pattern)
{
    if ((!m_patternStyle) || (*m_patternStyle != p_pattern)) {
        unsetPatternStyle();
        m_patternStyle = new Interface::patternStyle_t(p_pattern);
    }
}

void SimpleDifferentialCellFormat::unsetPatternStyle()
{
    delete m_patternStyle;
    m_patternStyle = nullptr;
}

void SimpleDifferentialCellFormat::setForegroundColor(Interface::color_t p_color)
{
    if ((!m_foregroundColor) || (*m_foregroundColor != p_color)) {
        unsetForegroundColor();
        m_foregroundColor = new Interface::color_t(p_color);
    }
}

void SimpleDifferentialCellFormat::unsetForegroundColor()
{
    delete m_foregroundColor;
    m_foregroundColor = nullptr;
}

void SimpleDifferentialCellFormat::setBackgroundColor(Interface::color_t p_color)
{
    if ((!m_backgroundColor) || (*m_backgroundColor != p_color)) {
        unsetBackgroundColor();
        m_backgroundColor = new Interface::color_t(p_color);
    }
}

void SimpleDifferentialCellFormat::unsetBackgroundColor()
{
    delete m_backgroundColor;
    m_backgroundColor = nullptr;
}

void SimpleDifferentialCellFormat::setSolidBackColor(Interface::color_t p_color)
{
    setPatternStyle(Interface::psSolid);
    setBackgroundColor(p_color);
}

void SimpleDifferentialCellFormat::setBorderVisible(Interface::border_t p_border, bool p_visible)
{
    if ((!m_borderVisible[p_border]) || (*m_borderVisible[p_border] != p_visible)) {
        unsetBorderVisible(p_border);
        m_borderVisible[p_border] = new bool(p_visible);
    }
}

void SimpleDifferentialCellFormat::setBorderStyle(Interface::border_t p_border, Interface::borderStyle_t p_style)
{
    if ((!m_borderStyle[p_border]) || (*m_borderStyle[p_border] != p_style)) {
        unsetBorderStyle(p_border);
        m_borderStyle[p_border] = new Interface::borderStyle_t(p_style);
    }
}

void SimpleDifferentialCellFormat::setBorderColor(Interface::border_t pBorder, Interface::color_t p_color)
{
    if ((!m_borderColor[pBorder]) || (*m_borderColor[pBorder] != p_color)) {
        unsetBorderColor(pBorder);
        m_borderColor[pBorder] = new Interface::color_t(p_color);
    }
}

void SimpleDifferentialCellFormat::unsetBorderVisible(Interface::border_t p_border)
{
    delete m_borderVisible[p_border];
    m_borderVisible[p_border] = nullptr;
}

void SimpleDifferentialCellFormat::unsetBorderStyle(Interface::border_t p_border)
{
    delete m_borderStyle[p_border];
    m_borderStyle[p_border] = nullptr;
}

void SimpleDifferentialCellFormat::unsetBorderColor(Interface::border_t p_border)
{
    delete m_borderColor[p_border];
    m_borderColor[p_border] = nullptr;
}

SimpleDifferentialCellFormat::SimpleDifferentialCellFormat()
:   m_fontColor(nullptr),
    m_fontBold(nullptr),
    m_fontItalic(nullptr),
    m_fontUnderline(nullptr),
    m_numberFormat(nullptr),
    m_buildInNumberFormatId(nullptr),
    m_patternStyle(nullptr),
    m_foregroundColor(nullptr),
    m_backgroundColor(nullptr)
{
    for (unsigned short i = 0; i < 6; ++i) {
        m_borderVisible[i] = nullptr;
        m_borderStyle[i] = nullptr;
        m_borderColor[i] = nullptr;
    }
}

SimpleDifferentialCellFormat::SimpleDifferentialCellFormat(const SimpleDifferentialCellFormat& p_differentialCellFormat)
:   m_fontColor(nullptr),
    m_fontBold(nullptr),
    m_fontItalic(nullptr),
    m_fontUnderline(nullptr),
    m_numberFormat(nullptr),
    m_buildInNumberFormatId(nullptr),
    m_patternStyle(nullptr),
    m_foregroundColor(nullptr),
    m_backgroundColor(nullptr)
{
    if (p_differentialCellFormat.fontColor())
        setFontColor(*p_differentialCellFormat.fontColor());
    if (p_differentialCellFormat.isFontBolded())
        setFontBold(*p_differentialCellFormat.isFontBolded());
    if (p_differentialCellFormat.isFontItalicized())
        setFontItalic(*p_differentialCellFormat.isFontItalicized());
    if (p_differentialCellFormat.isFontUnderlined())
        setFontUnderline(*p_differentialCellFormat.isFontUnderlined());

    if (p_differentialCellFormat.numberFormat())
        setNumberFormat(*p_differentialCellFormat.numberFormat());
    if (p_differentialCellFormat.builtInNumberFormatId())
        setBuildInNumberFormatId(*p_differentialCellFormat.builtInNumberFormatId());

    if (p_differentialCellFormat.patternStyle())
        setPatternStyle(*p_differentialCellFormat.patternStyle());
    if (p_differentialCellFormat.foregroundColor())
        setForegroundColor(*p_differentialCellFormat.foregroundColor());
    if (p_differentialCellFormat.backgroundColor())
        setBackgroundColor(*p_differentialCellFormat.backgroundColor());

    for (unsigned short i = 0; i < 6; ++i) {
        m_borderVisible[i] = nullptr;
        if (p_differentialCellFormat.isBorderVisible(static_cast<Interface::border_t>(i)))
            setBorderVisible(static_cast<Interface::border_t>(i), *p_differentialCellFormat.isBorderVisible(static_cast<Interface::border_t>(i)));

        m_borderStyle[i] = nullptr;
        if (p_differentialCellFormat.borderStyle(static_cast<Interface::border_t>(i)))
            setBorderStyle(static_cast<Interface::border_t>(i), *p_differentialCellFormat.borderStyle(static_cast<Interface::border_t>(i)));

        m_borderColor[i] = nullptr;
        if (p_differentialCellFormat.borderColor(static_cast<Interface::border_t>(i)))
            setBorderColor(static_cast<Interface::border_t>(i), *p_differentialCellFormat.borderColor(static_cast<Interface::border_t>(i)));
    }
}

SimpleDifferentialCellFormat& SimpleDifferentialCellFormat::operator =(const SimpleDifferentialCellFormat& p_differentialCellFormat)
{
    unsetFontColor();
    unsetFontBold();
    unsetFontItalic();
    unsetFontUnderline();

    if (p_differentialCellFormat.fontColor())
        setFontColor(*p_differentialCellFormat.fontColor());
    if (p_differentialCellFormat.isFontBolded())
        setFontBold(*p_differentialCellFormat.isFontBolded());
    if (p_differentialCellFormat.isFontItalicized())
        setFontItalic(*p_differentialCellFormat.isFontItalicized());
    if (p_differentialCellFormat.isFontUnderlined())
        setFontUnderline(*p_differentialCellFormat.isFontUnderlined());

    unsetNumberFormat();
    unsetBuildInNumberFormatId();

    if (p_differentialCellFormat.numberFormat())
        setNumberFormat(*p_differentialCellFormat.numberFormat());
    if (p_differentialCellFormat.builtInNumberFormatId())
        setBuildInNumberFormatId(*p_differentialCellFormat.builtInNumberFormatId());

    unsetPatternStyle();
    unsetForegroundColor();
    unsetBackgroundColor();

    if (p_differentialCellFormat.patternStyle())
        setPatternStyle(*p_differentialCellFormat.patternStyle());
    if (p_differentialCellFormat.foregroundColor())
        setForegroundColor(*p_differentialCellFormat.foregroundColor());
    if (p_differentialCellFormat.backgroundColor())
        setBackgroundColor(*p_differentialCellFormat.backgroundColor());

    for (unsigned short i = 0; i < 6; ++i) {
        unsetBorderVisible(static_cast<Interface::border_t>(i));
        if (p_differentialCellFormat.isBorderVisible(static_cast<Interface::border_t>(i)))
            setBorderVisible(static_cast<Interface::border_t>(i), *p_differentialCellFormat.isBorderVisible(static_cast<Interface::border_t>(i)));

        unsetBorderStyle(static_cast<Interface::border_t>(i));
        if (p_differentialCellFormat.borderStyle(static_cast<Interface::border_t>(i)))
            setBorderStyle(static_cast<Interface::border_t>(i), *p_differentialCellFormat.borderStyle(static_cast<Interface::border_t>(i)));

        unsetBorderColor(static_cast<Interface::border_t>(i));
        if (p_differentialCellFormat.borderColor(static_cast<Interface::border_t>(i)))
            setBorderColor(static_cast<Interface::border_t>(i), *p_differentialCellFormat.borderColor(static_cast<Interface::border_t>(i)));
    }

    return *this;
}

SimpleDifferentialCellFormat::~SimpleDifferentialCellFormat()
{
    unsetFontColor();
    unsetFontBold();
    unsetFontItalic();
    unsetFontUnderline();

    unsetNumberFormat();
    unsetBuildInNumberFormatId();

    unsetPatternStyle();
    unsetForegroundColor();
    unsetBackgroundColor();

    for (unsigned short i = 0; i < 6; ++i) {
        unsetBorderVisible(static_cast<Interface::border_t>(i));
        unsetBorderStyle(static_cast<Interface::border_t>(i));
        unsetBorderColor(static_cast<Interface::border_t>(i));
    }
}

#if defined(INVOKE_XLSX_LOGS)
size_t SimpleDifferentialCellFormat::log_size() const
{
    size_t w_size = sizeof(*this);
    if (m_fontColor)
        w_size += sizeof(*m_fontColor);
    if (m_fontBold)
        w_size += sizeof(*m_fontBold);
    if (m_fontItalic)
        w_size += sizeof(*m_fontItalic);
    if (m_fontUnderline)
        w_size += sizeof(*m_fontUnderline);
    if (m_numberFormat)
        w_size += sizeof(*m_numberFormat);
    if (m_buildInNumberFormatId)
        w_size += sizeof(*m_buildInNumberFormatId);
    if (m_patternStyle)
        w_size += sizeof(*m_patternStyle);
    if (m_foregroundColor)
        w_size += sizeof(*m_foregroundColor);
    if (m_backgroundColor)
        w_size += sizeof(*m_backgroundColor);
    if (m_borderVisible)
        w_size += sizeof(*m_borderVisible);
    if (m_borderStyle)
        w_size += sizeof(*m_borderStyle);
    if (m_borderColor)
        w_size += sizeof(*m_borderColor);

    return w_size;
}

void SimpleDifferentialCellFormat::log_scan(Debug::Container* p_container) const
{
    LOG_SCAN_ADD_OBJECT(p_container, "SimpleDifferentialCellFormat", log_size());
}
#endif

const Interface::Read::DifferentialCellFormat* SimpleConditionalFormatting::format() const
{
    return &m_format;
}

Interface::utf8String_t SimpleConditionalFormatting::formula() const
{
    return m_formula;
}

const Coordinates::MultiCellRange& SimpleConditionalFormatting::reference() const
{
    return m_reference;
}

void SimpleConditionalFormatting::setFormat(const Interface::Write::DifferentialCellFormat& p_format)
{
    SimpleDifferentialCellFormat const * const k_differentialCellFormat = dynamic_cast<const SimpleDifferentialCellFormat*>(&p_format);
    if (k_differentialCellFormat)
        m_format = *k_differentialCellFormat;
}

void SimpleConditionalFormatting::setFormula(const Interface::utf8String_t& p_formula)
{
    m_formula = p_formula;
}

void SimpleConditionalFormatting::setReference(const Coordinates::MultiCellRange& p_multiRange)
{
    m_reference = Coordinates::MultiCellRange();
    for (unsigned int i = 0; i < p_multiRange.rangeCount(); ++i) {
        Coordinates::CellRange const * const k_range = p_multiRange.range(i);
        m_reference.addRange( Coordinates::CellRange(nullptr, k_range->leftIndex(), k_range->topIndex(), k_range->rightIndex(), k_range->bottomIndex()) );
    }
}

#if defined(INVOKE_XLSX_LOGS)
size_t SimpleConditionalFormatting::log_size() const
{
    return sizeof(*this);
}

void SimpleConditionalFormatting::log_scan(Debug::Container* p_container) const
{
    LOG_SCAN_ADD_OBJECT(p_container, "SimpleConditionalFormatting", log_size());
}
#endif

const Coordinates::MultiCellRange& SimpleValidation::reference() const
{
    return m_reference;
}

bool SimpleValidation::isBlankAllowed() const
{
    return m_allowBlank;
}

bool SimpleValidation::isPromptShown() const
{
    return m_showPrompt;
}

Interface::utf8String_t SimpleValidation::promptTitle() const
{
    return m_promptTitle;
}

Interface::utf8String_t SimpleValidation::promptMessage() const
{
    return m_promptMessage;
}

bool SimpleValidation::isAlertShown() const
{
    return m_showAlert;
}

Interface::alertType_t SimpleValidation::alertType() const
{
    return m_alertType;
}

Interface::utf8String_t SimpleValidation::alertTitle() const
{
    return m_alertTitle;
}

Interface::utf8String_t SimpleValidation::alertMessage() const
{
    return m_alertMessage;
}

void SimpleValidation::setReference(const Coordinates::MultiCellRange& p_reference)
{
    m_reference = p_reference;
}

void SimpleValidation::allowBlank(bool p_allowBlank)
{
    m_allowBlank = p_allowBlank;
}

void SimpleValidation::showPrompt(bool p_showPrompt)
{
    m_showPrompt = p_showPrompt;
}

void SimpleValidation::setPrompt(const Interface::utf8String_t& p_title, const Interface::utf8String_t& p_message)
{
    m_promptTitle = p_title;
    m_promptMessage = p_message;
}

void SimpleValidation::showAlert(bool p_showAlert)
{
    m_showAlert = p_showAlert;
}

void SimpleValidation::setAlertType(Interface::alertType_t p_type)
{
    m_alertType = p_type;
}

void SimpleValidation::setAlert(const Interface::utf8String_t& p_title, const Interface::utf8String_t& p_message)
{
    m_alertTitle = p_title;
    m_alertMessage = p_message;
}

SimpleValidation::SimpleValidation()
:   m_reference(),
    m_allowBlank(true),
    m_showPrompt(true),
    m_promptTitle(),
    m_promptMessage(),
    m_showAlert(true),
    m_alertType(Interface::atError),
    m_alertTitle(),
    m_alertMessage()
{
}

SimpleValidation::~SimpleValidation()
{
}

#if defined(INVOKE_XLSX_LOGS)
size_t SimpleValidation::log_size() const
{
    return sizeof(*this);
}

void SimpleValidation::log_scan(Debug::Container* p_container) const
{
    LOG_SCAN_ADD_OBJECT(p_container, "SimpleValidation", log_size());
}
#endif

Interface::utf8String_t SimpleCustomValidation::formula() const
{
    return m_formula;
}

void SimpleCustomValidation::setFormula(const Interface::utf8String_t& p_formula)
{
    m_formula = p_formula;
}

SimpleValidation* SimpleCustomValidation::clone() const
{
    return new SimpleCustomValidation(*this);
}

#if defined(INVOKE_XLSX_LOGS)
size_t SimpleCustomValidation::log_size() const
{
    return sizeof(*this);
}

void SimpleCustomValidation::log_scan(Debug::Container* p_container) const
{
    LOG_SCAN_ADD_OBJECT(p_container, "SimpleCustomValidation", log_size());
}
#endif

const Coordinates::CellRange* SimpleListValidation::rangeReference() const
{
    return m_rangeReference;
}

const Interface::valueList_t* SimpleListValidation::list() const
{
    return m_list;
}

void SimpleListValidation::setRangeReference(const Coordinates::CellRange& p_range)
{
    delete m_rangeReference;
    delete m_list;

    m_rangeReference = new Coordinates::CellRange(p_range);
    m_list = nullptr;
}

void SimpleListValidation::setList(const Interface::valueList_t& p_list)
{
    delete m_rangeReference;
    delete m_list;

    m_rangeReference = nullptr;
    m_list = new Interface::valueList_t( p_list );
}

SimpleListValidation::SimpleListValidation()
:   SimpleValidation(),
    m_rangeReference(nullptr),
    m_list(nullptr)
{
}

SimpleListValidation::SimpleListValidation(const SimpleListValidation& p_validation)
:   SimpleValidation(p_validation),
    m_rangeReference(nullptr),
    m_list(nullptr)
{
    if (p_validation.m_rangeReference)
        m_rangeReference = new Coordinates::CellRange(*p_validation.m_rangeReference);
    if (p_validation.m_list)
        m_list = new Interface::valueList_t(*p_validation.m_list);
}

SimpleListValidation::~SimpleListValidation()
{
    delete m_rangeReference;
    delete m_list;
}

SimpleValidation* SimpleListValidation::clone() const
{
    return new SimpleListValidation(*this);
}

Interface::valueList_t SimpleListValidation::values(const Interface::Read::Workbook* p_workbook, const Interface::Read::Worksheet* p_worksheet) const
{
    if (!isValid())
        return Interface::valueList_t();

    if (m_list)
        return Interface::valueList_t(*m_list);

    if ((m_rangeReference) && (p_workbook)) {
        const Coordinates::CellRange k_range = *m_rangeReference;

        const Interface::Read::Worksheet * w_worksheet = nullptr;
        if (k_range.worksheet()) {
            unsigned int w_index = 0;
            while ((w_index < p_workbook->worksheetCount()) && (p_workbook->worksheet(w_index)->name() != k_range.worksheet()->name()))
                ++w_index;
            if (w_index < p_workbook->worksheetCount())
                w_worksheet = p_workbook->worksheet(w_index);
        } else
            w_worksheet = p_worksheet;

        if (w_worksheet) {
            const std::vector<std::string> k_boolean = {"FALSE", "TRUE"};
            const std::vector<std::string> k_error = {"", "#DIV/0!", "#NULL!", "#REF!", "#NAME?", "#NUM!", "#N/A"};

            Interface::valueList_t w_result;
            for (unsigned int w_iCol = k_range.left(); w_iCol <= k_range.right(); ++w_iCol)
                for (unsigned int w_iRow = k_range.top(); w_iRow <= k_range.bottom(); ++w_iRow) {
                    Interface::Read::CellValue const * const k_value = w_worksheet->cellValue(w_iCol, w_iRow);
                    switch (k_value->type()) {
                    case Interface::ctNull:
                        w_result.push_back( "" );
                        break;
                    case Interface::ctBoolean:
                        if (k_value->boolean())
                            w_result.push_back( k_boolean[1] );
                        else
                            w_result.push_back( k_boolean[0] );
                        break;
                    case Interface::ctNumber:
                        w_result.push_back( std::to_string(k_value->number()) );
                        break;
                    case Interface::ctString:
                    case Interface::ctRichText:
                        w_result.push_back( k_value->string() );
                        break;
                    case Interface::ctError:
                        w_result.push_back( k_error[k_value->error()] );
                        break;
                    }
                }

            return w_result;
        }
    }

    return Interface::valueList_t();
}

#if defined(INVOKE_XLSX_LOGS)
size_t SimpleListValidation::log_size() const
{
    size_t w_size = sizeof(*this);
    if (m_rangeReference)
        w_size += sizeof(*m_rangeReference);
    if (m_list)
        w_size += sizeof(*m_list);

    return w_size;
}

void SimpleListValidation::log_scan(Debug::Container* p_container) const
{
    // size
    LOG_SCAN_ADD_OBJECT(p_container, "SimpleListValidation", log_size());
}
#endif

const Coordinates::CellRange* SimpleFilter::rangeReference() const
{
    return m_rangeReference;
}

void SimpleFilter::setRangeReference(const Coordinates::CellRange& p_range)
{
    delete m_rangeReference;
    m_rangeReference = new Coordinates::CellRange(p_range);
}

SimpleFilter::SimpleFilter()
:   m_rangeReference(nullptr)
{
}

SimpleFilter::SimpleFilter(const SimpleFilter& p_filter)
:   m_rangeReference(nullptr)
{
    m_rangeReference = new Coordinates::CellRange(*p_filter.m_rangeReference);
}

SimpleFilter& SimpleFilter::operator =(const SimpleFilter& p_filter)
{
    delete m_rangeReference;
    m_rangeReference = new Coordinates::CellRange(*p_filter.m_rangeReference);

    return *this;
}

SimpleFilter::~SimpleFilter()
{
    delete m_rangeReference;
}

SimpleFilter* SimpleFilter::clone() const
{
    return new SimpleFilter(*this);
}

#if defined(INVOKE_XLSX_LOGS)
size_t SimpleFilter::log_size() const
{
    size_t w_size = sizeof(*this);
    if (m_rangeReference)
        w_size += sizeof(*m_rangeReference);

    return w_size;
}

void SimpleFilter::log_scan(Debug::Container* p_container) const
{
    LOG_SCAN_ADD_OBJECT(p_container, "SimpleFilter", log_size());
}
#endif

void SimpleImage::getImageBuffer(unsigned char*& o_buffer, unsigned int& o_size) const
{
    o_buffer = m_stream;
    o_size = m_streamSize;
}

Interface::imageType_t SimpleImage::type() const
{
    return m_type;
}

unsigned int SimpleImage::width() const
{
    return m_width;
}

unsigned int SimpleImage::height() const
{
    return m_height;
}

const Coordinates::CellPoint& SimpleImage::topLeft() const
{
    return m_topLeft;
}

const Coordinates::CellPoint* SimpleImage::rightBottom() const
{
    return m_rightBottom;
}

const Interface::pixelRectangle_t* SimpleImage::cropRectangle() const
{
    return m_cropRectangle;
}

Interface::imageProperty_t SimpleImage::property() const
{
    return m_property;
}

bool SimpleImage::isValid() const
{
    return  (   (m_stream)
            &&  (m_streamSize > 0)
            &&  (m_topLeft.worksheet())
            &&  (   (!m_rightBottom)
                ||  (m_topLeft.worksheet() == m_rightBottom->worksheet())
                )
            &&  (m_type != Interface::itUnknown)
            &&  (m_width > 0)
            &&  (m_height > 0)
            );
}

void SimpleImage::setImage(unsigned char* p_stream, unsigned int p_length, bool p_copy)
{
    if (m_stream) {
        free(m_stream);
        m_stream = nullptr;
        m_streamSize = 0;
    }

    if (p_copy) {
        m_stream = (unsigned char*)malloc(p_length * sizeof(unsigned char));
        memcpy(m_stream, p_stream, p_length);
    } else
        m_stream = p_stream;

    m_streamSize = p_length;

    Interface::getImageProperties(m_stream, m_streamSize, m_type, m_width, m_height);
}

void SimpleImage::setTopLeft(const Coordinates::CellPoint& p_point)
{
    m_topLeft = p_point;
}

void SimpleImage::setRightBottom(const Coordinates::CellPoint* p_point)
{
    if ((!m_rightBottom) && (!p_point))
        return;

    if (!p_point) {
        delete m_rightBottom;
        m_rightBottom = nullptr;
        return;
    }

    if (!m_rightBottom)
        m_rightBottom = new Coordinates::CellPoint(*p_point);
    else
        *m_rightBottom = *p_point;
}

void SimpleImage::setCropRectangle(const Interface::pixelRectangle_t* p_rectangle)
{
    if ((!m_cropRectangle) && (!p_rectangle))
        return;

    if (!p_rectangle) {
        delete m_cropRectangle;
        m_cropRectangle = nullptr;
        return;
    }

    if (!m_cropRectangle)
        m_cropRectangle = new Interface::pixelRectangle_t();

    *m_cropRectangle = *p_rectangle;
}

void SimpleImage::setProperty(Interface::imageProperty_t p_property)
{
    m_property = p_property;
}

SimpleImage::SimpleImage()
:   m_stream(nullptr),
    m_streamSize(0),
    m_type(Interface::itUnknown),
    m_width(0),
    m_height(0),
    m_topLeft(nullptr, 0, 0, 0, 0),
    m_rightBottom(nullptr),
    m_cropRectangle(nullptr),
    m_property(Interface::ipStatic)
{
}

SimpleImage::SimpleImage(const SimpleImage& p_image)
:   m_stream(nullptr),
    m_streamSize(0),
    m_type(Interface::itUnknown),
    m_width(0),
    m_height(0),
    m_topLeft(p_image.topLeft()),
    m_rightBottom(nullptr),
    m_cropRectangle(nullptr),
    m_property(p_image.m_property)
{
    unsigned char* w_buffer;
    unsigned int w_bufferLength;
    p_image.getImageBuffer(w_buffer, w_bufferLength);
    setImage(w_buffer, w_bufferLength, true);

    setRightBottom(p_image.rightBottom());
    setCropRectangle(p_image.cropRectangle());
}

SimpleImage& SimpleImage::operator =(const SimpleImage& p_image)
{
    unsigned char* w_buffer;
    unsigned int w_bufferLength;
    p_image.getImageBuffer(w_buffer, w_bufferLength);
    setImage(w_buffer, w_bufferLength, true);

    m_topLeft = p_image.topLeft();
    setRightBottom(p_image.rightBottom());

    setCropRectangle(p_image.cropRectangle());

    m_property = p_image.property();

    return *this;
}

SimpleImage::~SimpleImage()
{
    free(m_stream);
    delete m_rightBottom;
    delete m_cropRectangle;
}

SimpleImage* SimpleImage::clone() const
{
    return new SimpleImage(*this);
}

#if defined(INVOKE_XLSX_LOGS)
size_t SimpleImage::log_size() const
{
    size_t w_size = sizeof(*this);
    if (m_stream)
        w_size += sizeof(*m_stream);
    if (m_rightBottom)
        w_size += sizeof(*m_rightBottom);
    if (m_cropRectangle)
        w_size += sizeof(*m_cropRectangle);

    return w_size;
}

void SimpleImage::log_scan(Debug::Container* p_container) const
{
    LOG_SCAN_ADD_OBJECT(p_container, "SimpleImage", log_size());
}
#endif

const Coordinates::CellRange& SimpleHyperlink::reference() const
{
    return m_reference;
}

const Interface::utf8String_t& SimpleHyperlink::display() const
{
    return m_display.string();
}

const Coordinates::CellRange* SimpleHyperlink::location() const
{
    if (m_locationType == lCellRange)
        return static_cast<Coordinates::CellRange*>(m_location);
    return nullptr;
}

const Interface::Read::DefinedName* SimpleHyperlink::definedName() const
{
    if (m_locationType == lDefinedName)
        return static_cast<Interface::Read::DefinedName*>(m_location);
    return nullptr;
}

const Interface::utf8String_t* SimpleHyperlink::fileLocation() const
{
    if (m_locationType == lFile)
        return static_cast<Interface::utf8String_t*>(m_location);
    return nullptr;
}

bool SimpleHyperlink::getMailLocation(Interface::utf8String_t& o_mail, Interface::utf8String_t& o_subject) const
{
    if (m_locationType != lMail)
        return false;

    mail_t const * const k_mail = static_cast<mail_t const * const>(m_location);
    if (!k_mail)
        return false;

    o_mail = k_mail->address;
    o_subject = k_mail->subject;
    return true;
}

const Interface::utf8String_t& SimpleHyperlink::tooltip() const
{
    return m_tooltip.string();
}

bool SimpleHyperlink::isValid() const
{
    return (m_location != nullptr);
}

void SimpleHyperlink::setReference(const Coordinates::Cell& p_cell)
{
    m_reference = Coordinates::CellRange( p_cell.worksheet(), p_cell.columnIndex(), p_cell.rowIndex(), p_cell.columnIndex(), p_cell.rowIndex());
}

void SimpleHyperlink::setReference(const Coordinates::CellRange& p_cellRange)
{
    m_reference = p_cellRange;
}

void SimpleHyperlink::setDisplay(const Interface::utf8String_t& p_display)
{
    m_display = p_display;
}

void SimpleHyperlink::setLocation(const Coordinates::Cell& p_cell)
{
    const Coordinates::CellRange k_cellRange(p_cell.worksheet(), p_cell.columnIndex(), p_cell.rowIndex(), p_cell.columnIndex(), p_cell.rowIndex());
    newLocation(lCellRange, &k_cellRange);
}

void SimpleHyperlink::setLocation(const Coordinates::CellRange& p_cellRange)
{
    newLocation(lCellRange, &p_cellRange);
}

void SimpleHyperlink::setLocation(const Interface::Write::DefinedName& p_definedName)
{
    SimpleDefinedName const * const k_definedName = dynamic_cast<const SimpleDefinedName*>(&p_definedName);
    if (k_definedName)
        newLocation(lDefinedName, k_definedName);
}

void SimpleHyperlink::setFileLocation(const Interface::utf8String_t& p_file)
{
    newLocation(lFile, &p_file);
}

void SimpleHyperlink::setMailLocation(const Interface::utf8String_t& p_address, const Interface::utf8String_t& p_object)
{
    const mail_t k_mail = {p_address, p_object};
    newLocation(lMail, &k_mail);
}

void SimpleHyperlink::setTooltip(const Interface::utf8String_t& p_tooltip)
{
    m_tooltip = p_tooltip;
}

SimpleHyperlink::SimpleHyperlink()
:   m_reference(nullptr, 0, 0, 0, 0),
    m_display(),
    m_locationType(lCellRange),
    m_location(nullptr),
    m_tooltip()
{
}

SimpleHyperlink::SimpleHyperlink(const SimpleHyperlink& p_hyperlink)
:   m_reference(p_hyperlink.m_reference),
    m_display(p_hyperlink.m_display),
    m_locationType(p_hyperlink.m_locationType),
    m_location(nullptr),
    m_tooltip(p_hyperlink.m_tooltip)
{
    newLocation(p_hyperlink.m_locationType, p_hyperlink.m_location);
}

SimpleHyperlink& SimpleHyperlink::operator =(const SimpleHyperlink& p_hyperlink)
{
    m_reference = p_hyperlink.m_reference;
    m_display = p_hyperlink.m_display;
    newLocation(p_hyperlink.m_locationType, p_hyperlink.m_location);
    m_tooltip = p_hyperlink.m_tooltip;

    return *this;
}

SimpleHyperlink::~SimpleHyperlink()
{
    deleteLocation();
}

SimpleHyperlink* SimpleHyperlink::clone() const
{
    return new SimpleHyperlink(*this);
}

void SimpleHyperlink::newLocation(SimpleHyperlink::locationType_t p_type, const void* p_location)
{
    deleteLocation();

    m_locationType = p_type;

    if (p_location) {
        switch (p_type) {
        case lCellRange:
            m_location = new Coordinates::CellRange( *(static_cast<const Coordinates::CellRange*>(p_location)) );
            break;
        case lDefinedName:
            m_location = new SimpleDefinedName( *(static_cast<const SimpleDefinedName*>(p_location)) );
            break;
        case lFile:
            m_location = new Interface::utf8String_t( *(static_cast<const Interface::utf8String_t*>(p_location)) );
            break;
        case lMail:
            m_location = new mail_t( *(static_cast<const mail_t*>(p_location)) );
            break;
        }
    }
}

void SimpleHyperlink::deleteLocation()
{
    if (m_location) {
        switch (m_locationType) {
        case lCellRange:
            delete static_cast<Coordinates::CellRange*>(m_location);
            break;
        case lDefinedName:
            delete static_cast<SimpleDefinedName*>(m_location);
            break;
        case lFile:
            delete static_cast<Interface::utf8String_t*>(m_location);
            break;
        case lMail:
            delete static_cast<mail_t*>(m_location);
            break;
        }

        m_location = nullptr;
    }
}

#if defined(INVOKE_XLSX_LOGS)
size_t SimpleHyperlink::log_size() const
{
    size_t w_size = sizeof(*this);
    // void*

    return w_size;
}

void SimpleHyperlink::log_scan(Debug::Container* p_container) const
{
    LOG_SCAN_ADD_OBJECT(p_container, "SimpleHyperlink", log_size());
}
#endif

const Coordinates::Cell& SimpleComment::reference() const
{
    return m_reference;
}

const Interface::utf8String_t& SimpleComment::author() const
{
    return m_author.string();
}

size_t SimpleComment::runCount() const
{
    return m_text.runCount();
}

const Interface::font_t* SimpleComment::runFont(size_t p_index) const
{
	return m_text.runFont(p_index);
}

const Interface::utf8String_t* SimpleComment::runText(size_t p_index) const
{
	return m_text.runText(p_index);
}

const std::string& SimpleComment::hyperlink() const
{
    return m_hyperlink.string();
}

Interface::horizontalAlignment_t SimpleComment::alignment() const
{
    return m_alignment;
}

const Coordinates::CellPoint& SimpleComment::topLeft() const
{
    return m_topLeft;
}

const Coordinates::CellPoint& SimpleComment::rightBottom() const
{
    return m_rightBottom;
}

bool SimpleComment::autoSize() const
{
    return m_autoSize;
}

Interface::color_t SimpleComment::fillColor() const
{
    return m_color;
}

Interface::visibility_t SimpleComment::visibility() const
{
    return m_visibility;
}

Interface::commentProperty_t SimpleComment::property() const
{
    return m_property;
}

void SimpleComment::setReference(const Coordinates::Cell& p_reference)
{
    m_reference = p_reference;
    if (m_autoCoordinates) {
        const unsigned int w_topRow = ((m_reference.row() > 0) ? m_reference.row() - 1 : 0);
        const unsigned int w_topOffset = ((m_reference.row() > 0) ? 100000 : 200000);

        m_topLeft = Coordinates::CellPoint(m_reference.worksheet(), m_reference.column() + 1, w_topRow, 150000, w_topOffset);
        m_rightBottom = Coordinates::CellPoint(m_reference.worksheet(), m_reference.column() + 2, w_topRow + 4, 790000, w_topOffset - 10000);
    }
}

void SimpleComment::setAuthor(const Interface::utf8String_t& p_author)
{
    m_author = p_author;
}

void SimpleComment::addRun(const Interface::font_t& p_font, const Interface::utf8String_t& p_text)
{
	m_text.addRun(p_font, p_text);
}

void SimpleComment::setHyperlink(const std::string& p_hyperlink)
{
    m_hyperlink = p_hyperlink;
}

void SimpleComment::setAlignment(Interface::horizontalAlignment_t p_alignment)
{
    m_alignment = p_alignment;
}

void SimpleComment::setTopLeft(const Coordinates::CellPoint& p_topLeft)
{
    m_topLeft = p_topLeft;
    m_autoCoordinates = false;
}

void SimpleComment::setRightBottom(const Coordinates::CellPoint& p_rightBottom)
{
    m_rightBottom = p_rightBottom;
    m_autoCoordinates = false;
}

void SimpleComment::setAutoSize(bool p_autoSize)
{
    m_autoSize = p_autoSize;
}

void SimpleComment::setFillColor(Interface::color_t p_color)
{
    m_color = p_color;
}

void SimpleComment::setVisibility(Interface::visibility_t p_visibility)
{
    m_visibility = p_visibility;
}

void SimpleComment::setProperty(Interface::commentProperty_t p_property)
{
    m_property = p_property;
}

SimpleComment::SimpleComment()
:   m_reference(nullptr, 0, 0),
    m_author(""),
    m_text(),
    m_hyperlink(),
    m_alignment(Interface::haLeft),
    m_topLeft(nullptr, 0, 0, 0, 0),
    m_rightBottom(nullptr, 0, 0, 0, 0),
    m_autoCoordinates(true),
    m_autoSize(false),
    m_color(0xFFFFE1),
    m_visibility(Interface::vHidden),
    m_property(Interface::cpStatic)
{
    setReference(m_reference);
}

SimpleComment::SimpleComment(const SimpleComment& p_comment)
:   m_reference(p_comment.m_reference),
    m_author(p_comment.m_author),
    m_text(p_comment.m_text),
    m_hyperlink(p_comment.m_hyperlink),
    m_alignment(p_comment.m_alignment),
    m_topLeft(p_comment.m_topLeft),
    m_rightBottom(p_comment.m_rightBottom),
    m_autoCoordinates(p_comment.m_autoCoordinates),
    m_autoSize(p_comment.m_autoSize),
    m_color(p_comment.m_color),
    m_visibility(p_comment.m_visibility),
    m_property(p_comment.m_property)
{
}

SimpleComment& SimpleComment::operator =(const SimpleComment& p_comment)
{
    m_reference = p_comment.m_reference;
    m_author = p_comment.m_author;
    m_text = p_comment.m_text;
    m_hyperlink = p_comment.m_hyperlink;
    m_alignment = p_comment.m_alignment;
    m_topLeft = p_comment.m_topLeft;
    m_rightBottom = p_comment.m_rightBottom;
    m_autoCoordinates = p_comment.m_autoCoordinates;
    m_autoSize = p_comment.m_autoSize;
    m_color = p_comment.m_color;
    m_visibility = p_comment.m_visibility;
    m_property = p_comment.m_property;

    return *this;
}

SimpleComment* SimpleComment::clone() const
{
    return new SimpleComment(*this);
}

void SimpleComment::resetCoordinates()
{
    m_autoCoordinates = true;
    setReference(m_reference);
}

void SimpleComment::reset()
{
    *this = SimpleComment();
}

#if defined(INVOKE_XLSX_LOGS)
size_t SimpleComment::log_size() const
{
    return sizeof(*this);
}

void SimpleComment::log_scan(Debug::Container* p_container) const
{
    LOG_SCAN_ADD_OBJECT(p_container, "SimpleComment", log_size());
}
#endif

const Coordinates::WorksheetProxy* SimpleWorkbook::selectedWorksheet() const
{
    if (m_selectedWorksheetIndex < m_worksheets.size())
        return m_worksheets[m_selectedWorksheetIndex];
    return nullptr;
}

Interface::utf8String_t SimpleWorkbook::checkWorksheetName(const Interface::utf8String_t& p_name) const
{
    // caractères spéciaux
    Interface::utf8String_t w_name = "";
    Interface::utf8String_t::const_iterator w_it = p_name.begin();
    while (w_it < p_name.end()) {
        const char32_t k_char = UtfString::UTF8::read(w_it);
        if  (   (Unicode::isChar(k_char))
            &&  (k_char != 0x00000009)
            &&  (k_char != 0x0000000A)
            &&  (k_char != 0x0000000D)
            )
            UtfString::UTF8::write(k_char, std::back_inserter(w_name));
    }

    // découpage
    Interface::utf8String_t w_prefix = "";
    unsigned int w_index = 0;
    size_t w_indexLength = 0;
    splitWorksheetName(w_name, w_prefix, w_index, w_indexLength);

    bool w_checkName;
    do {
        // longueur
        const size_t k_nameLength = static_cast<size_t>(UtfString::length(w_name));
        if (k_nameLength > 31) {
            Interface::utf8String_t w_tmpPrefix = "";
            const size_t k_prefixLength = static_cast<size_t>(UtfString::length(w_prefix));
            w_it = w_prefix.begin();
            for (size_t i = 0; i < k_prefixLength - (k_nameLength - 31) - 1; ++i) {
                const char32_t k_char = UtfString::UTF8::read(w_it);
                UtfString::UTF8::write(k_char, std::back_inserter(w_tmpPrefix));
            }

            std::stringstream w_builder;
            w_builder << w_tmpPrefix << "\xE2\x80\xA6";
            if (w_indexLength > 0)
                w_builder << std::setfill('0') << std::setw(w_indexLength) << w_index;
            w_name = w_builder.str();
        }

        // doublon
        worksheets_t::const_iterator w_it = m_worksheets.begin();
        while   (   (w_it != m_worksheets.end())
                &&  (icu::UnicodeString(w_name.c_str()).caseCompare(icu::UnicodeString((*w_it)->name().c_str()), 0) != 0)
                )
            ++w_it;

        // incrémentation
        w_checkName = false;
        if (w_it != m_worksheets.end()) {
            ++w_index;
            if (w_indexLength == 0)
                w_indexLength = 1;

            std::stringstream w_builder;
            w_builder << w_prefix << std::setfill('0') << std::setw(w_indexLength) << w_index;
            w_name = w_builder.str();

            w_checkName = true;
        }
    } while (w_checkName);

    return w_name;
}

size_t SimpleWorkbook::worksheetCount() const
{
    return m_worksheets.size();
}

const Interface::Read::Worksheet* SimpleWorkbook::worksheet(size_t p_index) const
{
    if (p_index < m_worksheets.size())
        return m_worksheets[p_index];
    return nullptr;
}

const Coordinates::WorksheetProxy* SimpleWorkbook::worksheet(const Interface::utf8String_t& p_name) const
{
    for (unsigned int i = 0; i < worksheetCount(); ++i)
        if (worksheet(i)->name() == p_name)
            return worksheet(i);
    return nullptr;
}

void SimpleWorkbook::getDefaultFont(Interface::utf8String_t& o_name, unsigned short& o_size, Interface::color_t& o_color, bool& o_bold, bool& o_italic, bool& o_underline) const
{
    if (m_defaultFont) {
        o_name = m_defaultFont->name;
        o_size = m_defaultFont->size;
        o_color = m_defaultFont->color;
        o_bold = m_defaultFont->bold;
        o_italic = m_defaultFont->italic;
        o_underline = m_defaultFont->underline;
    } else {
        o_name = "Arial";
        o_size = 10;
        o_color = 0xFF000000;
        o_bold = false;
        o_italic = false;
        o_underline = false;
    }
}

Interface::Read::Workbook::cellFormatList_t SimpleWorkbook::formats() const
{
    Interface::Read::Workbook::cellFormatList_t w_result;
    for (formats_t::const_iterator w_it = m_formats.begin(); w_it != m_formats.end(); ++w_it)
        w_result.push_back( &*w_it );
    return w_result;
}

size_t SimpleWorkbook::definedNameCount() const
{
    return m_definedNames.size();
}

const Interface::Read::DefinedName* SimpleWorkbook::definedName(size_t p_index) const
{
    if (p_index < m_definedNames.size())
        return m_definedNames[p_index];
    return nullptr;
}

const Interface::Read::DefinedName* SimpleWorkbook::definedName(const Interface::utf8String_t& p_name) const
{
    definedNames_t::const_iterator w_index = std::lower_bound(  m_definedNames.begin(),
                                                                m_definedNames.end(),
                                                                p_name,
                                                                [](const SimpleDefinedName* p_definedName, const Interface::utf8String_t& p_name){ return p_definedName->name() < p_name; }
                                                                );

    if (w_index != m_definedNames.end())
        return (*w_index);
    return nullptr;
}

const Coordinates::WorkbookProxy* SimpleWorkbook::proxy() const
{
    return this;
}

Interface::Write::Worksheet* SimpleWorkbook::newWorksheet(const Interface::utf8String_t& p_name)
{
    m_worksheets.push_back( new SimpleWorksheet(this, checkWorksheetName(p_name)) );
    return m_worksheets.back();
}

bool SimpleWorkbook::selectWorksheet(const Interface::Write::Worksheet* p_worksheet)
{
    size_t w_index = m_worksheets.size() - 1;
    while ((w_index) && (m_worksheets[w_index] != p_worksheet))
        --w_index;
    if (m_worksheets[w_index] == p_worksheet) {
        m_selectedWorksheetIndex = w_index;
        return true;
    }
    return false;
}

void SimpleWorkbook::selectWorksheetIndex(unsigned int p_index)
{
    m_selectedWorksheetIndex = p_index;
}

Interface::Write::CellFormat* SimpleWorkbook::createFormat() const
{
    return new SimpleCellFormat();
}

void SimpleWorkbook::setDefaultFont(const Interface::utf8String_t& p_name, unsigned short p_size, Interface::color_t p_color, bool p_bold, bool p_italic, bool p_underline)
{
    if  (   (p_name == "Arial")
        &&  (p_size == 10)
        &&  (p_color == 0xFF000000)
        &&  (!p_bold)
        &&  (!p_italic)
        &&  (!p_underline)
        ) {

        delete m_defaultFont;
        m_defaultFont = nullptr;

    } else {

        if (m_defaultFont == nullptr)
            m_defaultFont = new font_t();

        m_defaultFont->name = p_name;
        m_defaultFont->size = p_size;
        m_defaultFont->color = p_color;
        m_defaultFont->bold = p_bold;
        m_defaultFont->italic = p_italic;
        m_defaultFont->underline = p_underline;

    }
}

Interface::formatIdentifier_t SimpleWorkbook::addFormat(const Interface::Write::CellFormat& p_format)
{
    SimpleCellFormat const * const k_format = dynamic_cast<const SimpleCellFormat*>(&p_format);
    if (k_format) {
        const formats_t::const_iterator k_index = m_formats.find( *k_format );
        if (k_index != m_formats.end())
            return &*k_index;

        return &*(m_formats.insert(*k_format).first);
    }

    return nullptr;
}

void SimpleWorkbook::setFormat(const Coordinates::Cell& p_coordinates, const Interface::Write::CellFormat& p_format)
{
    SimpleCellFormat const * const k_format = dynamic_cast<const SimpleCellFormat*>(&p_format);
    if ((k_format) && (p_coordinates.worksheet())) {
        const worksheets_t::iterator w_index = std::find(m_worksheets.begin(), m_worksheets.end(), p_coordinates.worksheet());
        if (w_index != m_worksheets.end())
            (*w_index)->setFormat(p_coordinates.column(), p_coordinates.row(), *k_format);
    }
}

void SimpleWorkbook::setFormat(const Coordinates::CellRange& p_range, const Interface::Write::CellFormat& p_format)
{
    SimpleCellFormat const * const k_format = dynamic_cast<const SimpleCellFormat*>(&p_format);
    if ((k_format) && (p_range.worksheet())) {
        const worksheets_t::iterator w_index = std::find(m_worksheets.begin(), m_worksheets.end(), p_range.worksheet());
        if (w_index != m_worksheets.end()) {
            const Interface::formatIdentifier_t k_formatIdentifier = addFormat(*k_format);
            if (k_formatIdentifier) {
                for (unsigned int w_column = p_range.left(); w_column <= p_range.right(); ++w_column) {
                    for (unsigned int w_row = p_range.top(); w_row <= p_range.bottom(); ++w_row)
                        (*w_index)->setFormat(w_column, w_row, k_formatIdentifier);
                }
            }
        }
    }
}

void SimpleWorkbook::setFormat(const Coordinates::MultiCellRange& p_multiRange, const Interface::Write::CellFormat& p_format)
{
    SimpleCellFormat const * const k_format = dynamic_cast<const SimpleCellFormat*>(&p_format);
    if ((k_format) && (p_multiRange.rangeCount())) {
        const Interface::formatIdentifier_t k_formatIdentifier = addFormat(p_format);
        if (k_formatIdentifier) {
            for (unsigned int i = 0; i < p_multiRange.rangeCount(); ++i) {
                const Coordinates::CellRange k_range = *p_multiRange.range(i);
                if (k_range.worksheet()) {
                    const worksheets_t::iterator w_index = std::find(m_worksheets.begin(), m_worksheets.end(), k_range.worksheet());
                    if (w_index != m_worksheets.end()) {
                        for (unsigned int w_column = k_range.left(); w_column <= k_range.right(); ++w_column) {
                            for (unsigned int w_row = k_range.top(); w_row <= k_range.bottom(); ++w_row)
                                (*w_index)->setFormat(w_column, w_row, k_formatIdentifier);
                        }
                    }
                }
            }
        }
    }
}

Interface::Write::DefinedName* SimpleWorkbook::createDefinedName() const
{
    return new SimpleDefinedName();
}

size_t SimpleWorkbook::addDefinedName(const Interface::Write::DefinedName& p_definedName)
{
    SimpleDefinedName const * const k_definedName = dynamic_cast<const SimpleDefinedName*>(&p_definedName);
    if (k_definedName) {
        definedNames_t::iterator w_index = std::lower_bound(    m_definedNames.begin(),
                                                                m_definedNames.end(),
                                                                k_definedName,
                                                                [](const SimpleDefinedName* p_a, const SimpleDefinedName* p_b) {
                                                                        return (icu::UnicodeString(p_a->name().c_str()).caseCompare(icu::UnicodeString(p_b->name().c_str()), 0) < 0);
                                                                    }
                                                                );

        if (w_index == m_definedNames.end()) {
            m_definedNames.push_back(new SimpleDefinedName(*k_definedName));
            return m_definedNames.size() - 1;
        }

        if (icu::UnicodeString((*w_index)->name().c_str()).caseCompare(k_definedName->name().c_str(), 0) != 0)
            w_index = m_definedNames.insert(w_index, new SimpleDefinedName(*k_definedName));

        return (w_index - m_definedNames.begin());
    }
    return std::numeric_limits<size_t>::max();
}

SimpleWorkbook::SimpleWorkbook()
:   m_worksheets(),
    m_selectedWorksheetIndex(0),
    m_defaultFont(nullptr),
    m_formats(),
    m_definedNames()
{
#if defined(INVOKE_XLSX_LOGS)
    Invoke::XLSX::Debug::Logs::get().message("**** new SimpleWorkbook ****");
    Invoke::XLSX::Debug::Logs::get().checkMemory();
#endif
}

SimpleWorkbook::~SimpleWorkbook()
{
    for (worksheets_t::iterator w_it = m_worksheets.begin(); w_it != m_worksheets.end(); ++w_it)
        delete (*w_it);
    delete m_defaultFont;
    for (definedNames_t::iterator w_it = m_definedNames.begin(); w_it != m_definedNames.end(); ++w_it)
        delete (*w_it);
}

void SimpleWorkbook::splitWorksheetName(const Interface::utf8String_t& p_name, Interface::utf8String_t& o_prefix, unsigned int& o_index, size_t& o_indexLength) const
{
    o_prefix = p_name;
    o_index = 0;
    o_indexLength = 0;

    Interface::utf8String_t::const_reverse_iterator w_it = p_name.rbegin();
    while ( (w_it != p_name.rend()) && (*w_it >= '0') && (*w_it <= '9') )
        ++w_it;

    if (w_it == p_name.rend()) {
        o_prefix = "";
        o_index = atoi(p_name.c_str());
        o_indexLength = p_name.length();
    } else if (w_it != p_name.rbegin()) {
        o_prefix = p_name.substr(0, p_name.rend()-w_it);
        o_index = atoi(p_name.substr(p_name.rend()-w_it).c_str());
        o_indexLength = w_it - p_name.rbegin();
    }
}

#if defined(INVOKE_XLSX_LOGS)
size_t SimpleWorkbook::log_size() const
{
    size_t w_size = sizeof(*this);
    for (worksheets_t::const_iterator w_it = m_worksheets.begin(); w_it != m_worksheets.end(); ++w_it)
        w_size += (*w_it)->log_size();
    if (m_defaultFont)
        w_size += sizeof(m_defaultFont);
    for (formats_t::const_iterator w_it = m_formats.begin(); w_it != m_formats.end(); ++w_it)
        w_size += (w_it->log_size() - sizeof(SimpleCellFormat));
    for (definedNames_t::const_iterator w_it = m_definedNames.begin(); w_it != m_definedNames.end(); ++w_it)
        w_size += (*w_it)->log_size();

    return w_size;
}

void SimpleWorkbook::log_scan(Debug::Container* p_container) const
{
    if (p_container) {
        Debug::Container* w_container = p_container->addContainer("SimpleWorkbook", log_size());
        
        for (worksheets_t::const_iterator w_it = m_worksheets.begin(); w_it != m_worksheets.end(); ++w_it)
            (*w_it)->log_scan(w_container);

        for (formats_t::const_iterator w_it = m_formats.begin(); w_it != m_formats.end(); ++w_it)
            w_it->log_scan(w_container);

        for (definedNames_t::const_iterator w_it = m_definedNames.begin(); w_it != m_definedNames.end(); ++w_it)
            (*w_it)->log_scan(w_container);
    }
}
#endif

Interface::utf8String_t SimpleWorksheet::name() const
{
    return m_name;
}

bool SimpleWorksheet::isHidden() const
{
    return m_hidden;
}

bool SimpleWorksheet::formulasShown() const
{
    return m_showFormulas;
}

bool SimpleWorksheet::gridLinesShown() const
{
    return m_showGridLines;
}

bool SimpleWorksheet::rowColHeadersShown() const
{
    return m_showRowColHeaders;
}

bool SimpleWorksheet::zerosShown() const
{
    return m_showZeros;
}

const Coordinates::Cell* SimpleWorksheet::activeCell() const
{
    return &m_activeCell;
}

const Coordinates::MultiCellRange* SimpleWorksheet::selection() const
{
    return &m_selection;
}

const Interface::Read::PageSetting* SimpleWorksheet::pageSetting() const
{
    return m_pageSetting;
}

const Coordinates::CellRange& SimpleWorksheet::minBounds() const
{
    return m_minBounds;
}

bool SimpleWorksheet::getXSplit(unsigned int& o_xSplit) const
{
    o_xSplit = 0;
    if (m_xSplit)
        o_xSplit = *m_xSplit;
    return (m_xSplit != 0); // return (m_xSplit); => MSVC++ warning C4800
}

bool SimpleWorksheet::getYSplit(unsigned int& o_ySplit) const
{
    o_ySplit = 0;
    if (m_ySplit)
        o_ySplit = *m_ySplit;
    return (m_ySplit != 0); // return (m_ySplit); => MSVC++ warning C4800
}

bool SimpleWorksheet::isColumnVisible(unsigned int p_index) const
{
    const columnsRows_t::const_iterator k_index = m_columns.find(p_index);
    if (k_index != m_columns.end())
        return k_index->second.isVisible();
    return true;
}

double SimpleWorksheet::columnWidth(unsigned int p_index) const
{
    const columnsRows_t::const_iterator k_index = m_columns.find(p_index);
    if (k_index != m_columns.end())
        if (k_index->second.size())
            return *k_index->second.size();
    return defaultColumnWidth();
}

unsigned short SimpleWorksheet::columnOutlineLevel(unsigned int p_index) const
{
    const columnsRows_t::const_iterator k_index = m_columns.find(p_index);
    if (k_index != m_columns.end())
        return k_index->second.outlineLevel();
    return 0;
}

bool SimpleWorksheet::isColumnCollapsed(unsigned int p_index) const
{
    const columnsRows_t::const_iterator k_index = m_columns.find(p_index);
    if (k_index != m_columns.end())
        return k_index->second.isCollapsed();
    return false;
}

const Interface::Read::CellFormat* SimpleWorksheet::columnCellFormat(unsigned int p_index) const
{
    const columnsRows_t::const_iterator k_index = m_columns.find(p_index);
    if (k_index != m_columns.end())
        if (k_index->second.formatIdentifier())
            return static_cast<const Interface::Read::CellFormat*>(*k_index->second.formatIdentifier());
    return nullptr;
}

bool SimpleWorksheet::isColumnDefault(unsigned int p_index) const
{
    const columnsRows_t::const_iterator k_index = m_columns.find(p_index);
    if (k_index != m_columns.end())
        return k_index->second.isDefault();
    return true;
}

bool SimpleWorksheet::getColumnParentIndex(unsigned int p_index, unsigned int& o_parentIndex) const
{
    o_parentIndex = p_index;

    const unsigned short k_outlineLevel = columnOutlineLevel(p_index);
    if (!k_outlineLevel)
        return false;

    o_parentIndex += (m_summaryRight ? 1 : -1);
    unsigned short w_parentOutlineLevel = columnOutlineLevel(o_parentIndex);
    while (o_parentIndex && (w_parentOutlineLevel >= k_outlineLevel)) {
        o_parentIndex += (m_summaryRight ? 1 : -1);
        w_parentOutlineLevel = columnOutlineLevel(o_parentIndex);
    }
    return true;
}

bool SimpleWorksheet::hasColumnChildren(unsigned int p_index) const
{
    const unsigned short k_outlineLevel = columnOutlineLevel(p_index);
    const unsigned short k_nextOutlineLevel = columnOutlineLevel( p_index + (m_summaryRight ? -1 : 1) );

    return (k_outlineLevel < k_nextOutlineLevel);
}

bool SimpleWorksheet::areColumnChildrenCollapsed(unsigned int p_index) const
{
    if (m_summaryRight && !p_index)
        return false;

    const unsigned short k_outlineLevel = columnOutlineLevel(p_index);

    int w_index = p_index + (m_summaryRight ? -1 : 1);
    unsigned short w_nextOutlineLevel = columnOutlineLevel(w_index);

    while (w_nextOutlineLevel > k_outlineLevel) {
        if ((k_outlineLevel + 1 == w_nextOutlineLevel) && (isColumnCollapsed(w_index)))
            return true;
        w_index += (m_summaryRight ? -1 : 1);
        w_nextOutlineLevel = ((w_index >= 0) ? columnOutlineLevel(w_index) : k_outlineLevel);
    }

    return false;
}

bool SimpleWorksheet::isRowVisible(unsigned int p_index) const
{
    const columnsRows_t::const_iterator k_index = m_rows.find(p_index);
    if (k_index != m_rows.end())
        return k_index->second.isVisible();
    return true;
}

double SimpleWorksheet::rowHeight(unsigned int p_index) const
{
    const columnsRows_t::const_iterator k_index = m_rows.find(p_index);
    if (k_index != m_rows.end())
        if (k_index->second.size())
            return *k_index->second.size();
    return defaultRowHeight();
}

unsigned short SimpleWorksheet::rowOutlineLevel(unsigned int p_index) const
{
    const columnsRows_t::const_iterator k_index = m_rows.find(p_index);
    if (k_index != m_rows.end())
        return k_index->second.outlineLevel();
    return 0;
}

bool SimpleWorksheet::isRowCollapsed(unsigned int p_index) const
{
    const columnsRows_t::const_iterator k_index = m_rows.find(p_index);
    if (k_index != m_rows.end())
        return k_index->second.isCollapsed();
    return false;
}

const Interface::Read::CellFormat* SimpleWorksheet::rowCellFormat(unsigned int p_index) const
{
    const columnsRows_t::const_iterator k_index = m_rows.find(p_index);
    if (k_index != m_rows.end())
        if (k_index->second.formatIdentifier())
            return static_cast<const Interface::Read::CellFormat*>(*k_index->second.formatIdentifier());
    return nullptr;
}

bool SimpleWorksheet::isRowDefault(unsigned int p_index) const
{
    const columnsRows_t::const_iterator k_index = m_rows.find(p_index);
    if (k_index != m_rows.end())
        return k_index->second.isDefault();
    return true;
}

bool SimpleWorksheet::getRowParentIndex(unsigned int p_index, unsigned int& o_parentIndex) const
{
    o_parentIndex = p_index;

    const unsigned short k_outlineLevel = rowOutlineLevel(p_index);
    if (!k_outlineLevel)
        return false;

    o_parentIndex += (m_summaryBelow ? 1 : -1);
    unsigned short w_parentOutlineLevel = rowOutlineLevel(o_parentIndex);
    while (o_parentIndex && (w_parentOutlineLevel >= k_outlineLevel)) {
        o_parentIndex += (m_summaryBelow ? 1 : -1);
        w_parentOutlineLevel = rowOutlineLevel(o_parentIndex);
    }
    return true;
}

bool SimpleWorksheet::hasRowChildren(unsigned int p_index) const
{
    const unsigned short k_outlineLevel = rowOutlineLevel(p_index);
    const unsigned short k_nextOutlineLevel = rowOutlineLevel( p_index + (m_summaryBelow ? -1 : 1) );

    return (k_outlineLevel < k_nextOutlineLevel);
}

bool SimpleWorksheet::areRowChildrenCollapsed(unsigned int p_index) const
{
    if (m_summaryBelow && !p_index)
        return false;

    const unsigned short k_outlineLevel = rowOutlineLevel(p_index);

    int w_index = p_index + (m_summaryBelow ? -1 : 1);
    unsigned short w_nextOutlineLevel = rowOutlineLevel(w_index);

    while (w_nextOutlineLevel > k_outlineLevel) {
        if ((k_outlineLevel + 1 == w_nextOutlineLevel) && (isRowCollapsed(w_index)))
            return true;
        w_index += (m_summaryBelow ? -1 : 1);
        w_nextOutlineLevel = ((w_index >= 0) ? rowOutlineLevel(w_index) : k_outlineLevel);
    };

    return false;
}

double SimpleWorksheet::defaultColumnWidth() const
{
    return m_defaultColumnWidth;
}

double SimpleWorksheet::defaultRowHeight() const
{
    return m_defaultRowHeight;
}

bool SimpleWorksheet::outlineSummaryRight() const
{
    return m_summaryRight;
}

bool SimpleWorksheet::outlineSummaryBelow() const
{
    return m_summaryBelow;
}

unsigned long Hasher<CellPosition>::operator()(const CellPosition& p_key) const
{
    unsigned long w_hash = 7;
    w_hash = 71 * w_hash + p_key.column();
    w_hash = 71 * w_hash + p_key.row();
    return w_hash;
}

size_t SimpleWorksheet::mergeCount() const
{
    return m_merges.size();
}

const Coordinates::CellRange* SimpleWorksheet::merge(size_t p_index) const
{
    if (p_index < m_merges.size())
        return &(m_merges[p_index]);
    return nullptr;
}

const Interface::Read::CellFormat* SimpleWorksheet::cellFormat(unsigned int p_column, unsigned int p_row) const
{
    if (m_cells.empty())
        return nullptr;

    const cells_t::const_iterator k_index = m_cells.find(CellPosition(p_column, p_row));
    if (k_index == m_cells.end())
        return nullptr;
    return static_cast<const Interface::Read::CellFormat*>(k_index->second.formatIdentifier());
}

const Interface::Read::CellValue* SimpleWorksheet::cellValue(unsigned int p_column, unsigned int p_row) const
{
    if (m_cells.empty())
        return nullptr;

    const cells_t::const_iterator k_index = m_cells.find(CellPosition(p_column, p_row));
    if (k_index == m_cells.end())
        return nullptr;
    return &(k_index->second.value());
}

size_t SimpleWorksheet::conditionalFormattingCount() const
{
    return m_conditionalFormattingRules.size();
}

const Interface::Read::ConditionalFormatting* SimpleWorksheet::conditionalFormatting(size_t p_index) const
{
    if (p_index < m_conditionalFormattingRules.size())
        return &m_conditionalFormattingRules[p_index];
    return nullptr;
}

const Coordinates::WorksheetProxy* SimpleWorksheet::proxy() const
{
    return this;
}

void SimpleWorksheet::setHidden(bool p_hidden)
{
    m_hidden = p_hidden;
}

void SimpleWorksheet::showFormulas(bool p_show)
{
    m_showFormulas = p_show;
}

void SimpleWorksheet::showGridLines(bool p_show)
{
    m_showGridLines = p_show;
}

void SimpleWorksheet::showRowColHeaders(bool p_show)
{
    m_showRowColHeaders = p_show;
}

void SimpleWorksheet::showZeros(bool p_show)
{
    m_showZeros = p_show;
}

void SimpleWorksheet::setActiveCell(const Coordinates::Cell& p_cell)
{
    m_activeCell = Coordinates::Cell(this, p_cell.columnIndex(), p_cell.rowIndex());
    if (!m_selection.isContaining(m_activeCell)) {
        m_selection = Coordinates::MultiCellRange();
        m_selection.addRange(m_activeCell);
    }
}

void SimpleWorksheet::setSelection(const Coordinates::MultiCellRange& p_multiCellRange)
{
    m_selection = Coordinates::MultiCellRange();
    for (unsigned int w_iRange = 0; w_iRange < p_multiCellRange.rangeCount(); ++w_iRange) {
        Coordinates::CellRange const * const k_range = p_multiCellRange.range(w_iRange);
        m_selection.addRange( Coordinates::CellRange(this, k_range->leftIndex(), k_range->topIndex(), k_range->rightIndex(), k_range->bottomIndex()) );
    }

    if (!m_selection.rangeCount())
        m_selection.addRange(m_activeCell);

    if (!m_selection.isContaining(m_activeCell))
        m_activeCell = m_selection.range(0)->topLeft();
}

size_t SimpleWorksheet::validationCount() const
{
    return m_validations.size();
}

const Interface::Read::Validation* SimpleWorksheet::validation(size_t p_index) const
{
    if (p_index < m_validations.size())
        return m_validations[p_index];
    return nullptr;
}

const Interface::Read::Filter* SimpleWorksheet::filter() const
{
    return m_filter;
}

bool SimpleWorksheet::containsValidImages() const
{
    images_t::const_iterator w_it = m_images.begin();
    while   (   (w_it != m_images.end())
            &&  (!(*w_it)->isValid())
            )
        ++w_it;

    return (w_it != m_images.end());
}

size_t SimpleWorksheet::imageCount() const
{
    return m_images.size();
}

const Interface::Read::Image* SimpleWorksheet::image(size_t p_index) const
{
    if (p_index < m_images.size())
        return m_images[p_index];
    return nullptr;
}

size_t SimpleWorksheet::hyperlinkCount() const
{
    return m_hyperlinks.size();
}

const Interface::Read::Hyperlink* SimpleWorksheet::hyperlink(size_t p_index) const
{
    if (p_index < m_hyperlinks.size())
        return m_hyperlinks[p_index];
    return nullptr;
}

size_t SimpleWorksheet::commentCount() const
{
    return m_comments.size();
}

const Interface::Read::Comment* SimpleWorksheet::comment(size_t p_index) const
{
    if (p_index < m_comments.size())
        return m_comments.at(p_index);
    return nullptr;
}

const Interface::Read::Comment* SimpleWorksheet::comment(unsigned int p_column, unsigned int p_row) const
{
    const CellPosition k_cell = CellPosition(p_column, p_row);
    const mappedComments_t::const_iterator k_index = m_mappedComments.find(k_cell);
    if (k_index != m_mappedComments.end())
        return k_index->second;
    return nullptr;
}

Interface::Write::PageSetting* SimpleWorksheet::createPageSetting() const
{
    return new SimplePageSetting();
}

void SimpleWorksheet::setPageSetting(const Interface::Write::PageSetting& p_pageSetting)
{
    SimplePageSetting const * const k_pageSetting = dynamic_cast<const SimplePageSetting*>(&p_pageSetting);
    if (k_pageSetting) {
        if (m_pageSetting)
            delete m_pageSetting;
        m_pageSetting = new SimplePageSetting(*k_pageSetting);

        Coordinates::MultiCellRange const * const k_printAreas = m_pageSetting->printArea();
        if (k_printAreas) {
            Coordinates::MultiCellRange w_printAreaUpdated;
            for (unsigned int w_iRange = 0; w_iRange < k_printAreas->rangeCount(); ++w_iRange) {
                const Coordinates::CellRange k_range = *k_printAreas->range(w_iRange);
                w_printAreaUpdated.addRange( Coordinates::CellRange(this, k_range.leftIndex(), k_range.topIndex(), k_range.rightIndex(), k_range.bottomIndex()) );
            }
            m_pageSetting->setPrintArea(&w_printAreaUpdated);
        }

        Coordinates::ColumnRowRange const * const k_headerColumns = m_pageSetting->headerColumns();
        if (k_headerColumns) {
            const Coordinates::ColumnRowRange k_columnRangeUpdated(Coordinates::Index::itColumn, this, k_headerColumns->firstIndex(), k_headerColumns->lastIndex());
            m_pageSetting->setHeader( &k_columnRangeUpdated );
        }

        Coordinates::ColumnRowRange const * const k_headerRows = m_pageSetting->headerRows();
        if (k_headerRows) {
            const Coordinates::ColumnRowRange k_rowRangeUpdated(Coordinates::Index::itRow, this, k_headerRows->firstIndex(), k_headerRows->lastIndex());
            m_pageSetting->setHeader( &k_rowRangeUpdated );
        }
    }
}

void SimpleWorksheet::setColumnVisible(unsigned int p_index, bool p_visible)
{
    columnsRows_t::iterator w_index = m_columns.find(p_index);
    if (w_index != m_columns.end()) {
        w_index->second.setVisible(p_visible);
        if (w_index->second.isDefault())
            m_columns.erase(w_index);
    } else {
        ColumnRow w_column;
        w_column.setVisible(p_visible);
        if (!w_column.isDefault())
            m_columns.emplace(p_index, w_column);
    }

    updateMinBounds( Coordinates::Cell(this, p_index, 0) );
}

void SimpleWorksheet::setColumnWidth(unsigned int p_index, const double* p_size)
{
    columnsRows_t::iterator w_index = m_columns.find(p_index);
    if (w_index != m_columns.end()) {
        w_index->second.setSize(p_size);
        if (w_index->second.isDefault())
            m_columns.erase(w_index);
    } else {
        ColumnRow w_column;
        w_column.setSize(p_size);
        if (!w_column.isDefault())
            m_columns.emplace(p_index, w_column);
    }

    updateMinBounds( Coordinates::Cell(this, p_index, 0) );
}

void SimpleWorksheet::setColumnOutlineLevel(unsigned int p_index, unsigned short p_outlineLevel)
{
    columnsRows_t::iterator w_index = m_columns.find(p_index);
    if (w_index != m_columns.end()) {
        w_index->second.setOutlineLevel(p_outlineLevel);
        if (w_index->second.isDefault())
            m_columns.erase(w_index);
    } else {
        ColumnRow w_column;
        w_column.setOutlineLevel(p_outlineLevel);
        if (!w_column.isDefault())
            m_columns.emplace(p_index, w_column);
    }

    updateMinBounds( Coordinates::Cell(this, p_index, 0) );
}

void SimpleWorksheet::setColumnCollapsed(unsigned int p_index, bool p_collapsed)
{
    columnsRows_t::iterator w_index = m_columns.find(p_index);
    if (w_index != m_columns.end()) {
        w_index->second.setCollapsed(p_collapsed);
        if (w_index->second.isDefault())
            m_columns.erase(w_index);
    } else {
        ColumnRow w_column;
        w_column.setCollapsed(p_collapsed);
        if (!w_column.isDefault())
            m_columns.emplace(p_index, w_column);
    }

    updateMinBounds( Coordinates::Cell(this, p_index, 0) );
}

void SimpleWorksheet::setColumnFormat(unsigned int p_index, const Interface::Write::CellFormat* p_format)
{
    Interface::formatIdentifier_t* w_formatIdentifier = nullptr;
    try {
        if (p_format)
            w_formatIdentifier = new Interface::formatIdentifier_t(m_workbook->addFormat(*p_format));

        columnsRows_t::iterator w_index = m_columns.find(p_index);
        if (w_index != m_columns.end()) {
            w_index->second.setFormatIdentifier(w_formatIdentifier);
            if (w_index->second.isDefault())
                m_columns.erase(w_index);
        } else {
            ColumnRow w_column;
            w_column.setFormatIdentifier(w_formatIdentifier);
            if (!w_column.isDefault())
                m_columns.emplace(p_index, w_column);
        }

        delete w_formatIdentifier;
    } catch (...) {
        delete w_formatIdentifier;
        throw;
    }

    updateMinBounds( Coordinates::Cell(this, p_index, 0) );
}

bool SimpleWorksheet::setColumnChildrenCollapsed(unsigned int p_index, bool p_collapsed)
{
    if ((m_summaryRight) && (!p_index))
        return false;

    const unsigned short k_outlineLevel = columnOutlineLevel(p_index);

    int w_index = p_index + (m_summaryRight ? -1 : 1);
    unsigned short w_nextOutlineLevel = columnOutlineLevel(w_index);

    if (w_nextOutlineLevel > k_outlineLevel) {
        do {
            if (k_outlineLevel + 1 == w_nextOutlineLevel)
                setColumnCollapsed(w_index, p_collapsed);
            w_index += (m_summaryRight ? -1 : 1);
            w_nextOutlineLevel = ((w_index >= 0) ? columnOutlineLevel(w_index) : k_outlineLevel);
        } while (w_nextOutlineLevel > k_outlineLevel);

        return true;
    }
    return false;
}

void SimpleWorksheet::setRowVisible(unsigned int p_index, bool p_visible)
{
    columnsRows_t::iterator w_index = m_rows.find(p_index);
    if (w_index != m_rows.end()) {
        w_index->second.setVisible(p_visible);
        if (w_index->second.isDefault())
            m_rows.erase(w_index);
    } else {
        ColumnRow w_row;
        w_row.setVisible(p_visible);
        if (!w_row.isDefault())
            m_rows.emplace(p_index, w_row);
    }

    updateMinBounds( Coordinates::Cell(this, 0, p_index) );
}

void SimpleWorksheet::setRowHeight(unsigned int p_index, const double* p_size)
{
    columnsRows_t::iterator w_index = m_rows.find(p_index);
    if (w_index != m_rows.end()) {
        w_index->second.setSize(p_size);
        if (w_index->second.isDefault())
            m_rows.erase(w_index);
    } else {
        ColumnRow w_row;
        w_row.setSize(p_size);
        if (!w_row.isDefault())
            m_rows.emplace(p_index, w_row);
    }

    updateMinBounds( Coordinates::Cell(this, 0, p_index) );
}

void SimpleWorksheet::setRowOutlineLevel(unsigned int p_index, unsigned short p_outlineLevel)
{
    columnsRows_t::iterator w_index = m_rows.find(p_index);
    if (w_index != m_rows.end()) {
        w_index->second.setOutlineLevel(p_outlineLevel);
        if (w_index->second.isDefault())
            m_rows.erase(w_index);
    } else {
        ColumnRow w_row;
        w_row.setOutlineLevel(p_outlineLevel);
        if (!w_row.isDefault())
            m_rows.emplace(p_index, w_row);
    }

    updateMinBounds( Coordinates::Cell(this, 0, p_index) );
}

void SimpleWorksheet::setRowCollapsed(unsigned int p_index, bool p_collapsed)
{
    columnsRows_t::iterator w_index = m_rows.find(p_index);
    if (w_index != m_rows.end()) {
        w_index->second.setCollapsed(p_collapsed);
        if (w_index->second.isDefault())
            m_rows.erase(w_index);
    } else {
        ColumnRow w_row;
        w_row.setCollapsed(p_collapsed);
        if (!w_row.isDefault())
            m_rows.emplace(p_index, w_row);
    }

    updateMinBounds( Coordinates::Cell(this, 0, p_index) );
}

void SimpleWorksheet::setRowFormat(unsigned int p_index, const Interface::Write::CellFormat* p_format)
{
    Interface::formatIdentifier_t* w_formatIdentifier = nullptr;
    try {
        if (p_format)
            w_formatIdentifier = new Interface::formatIdentifier_t(m_workbook->addFormat(*p_format));

        columnsRows_t::iterator w_index = m_rows.find(p_index);
        if (w_index != m_rows.end()) {
            w_index->second.setFormatIdentifier(w_formatIdentifier);
            if (w_index->second.isDefault())
                m_rows.erase(w_index);
        } else {
            ColumnRow w_row;
            w_row.setFormatIdentifier(w_formatIdentifier);
            if (!w_row.isDefault())
                m_rows.emplace(p_index, w_row);
        }

        delete w_formatIdentifier;
    } catch (...) {
        delete w_formatIdentifier;
        throw;
    }

    updateMinBounds( Coordinates::Cell(this, 0, p_index) );
}

bool SimpleWorksheet::setRowChildrenCollapsed(unsigned int p_index, bool p_collapsed)
{
    if ((m_summaryBelow) && (!p_index))
        return false;

    const unsigned short k_outlineLevel = rowOutlineLevel(p_index);

    int w_index = p_index + (m_summaryBelow ? -1 : 1);
    unsigned short w_nextOutlineLevel = rowOutlineLevel(w_index);

    if (w_nextOutlineLevel > k_outlineLevel) {
        do {
            if (k_outlineLevel + 1 == w_nextOutlineLevel)
                setRowCollapsed(w_index, p_collapsed);
            w_index += (m_summaryBelow ? -1 : 1);
            w_nextOutlineLevel = ((w_index >= 0) ? rowOutlineLevel(w_index) : k_outlineLevel);
        } while (w_nextOutlineLevel > k_outlineLevel);

        return true;
    }
    return false;
}

void SimpleWorksheet::setDefaultColumnWidth(double p_width)
{
    m_defaultColumnWidth = p_width;
}

void SimpleWorksheet::setDefaultRowHeight(double p_height)
{
    m_defaultRowHeight = p_height;
}

void SimpleWorksheet::setOutlineSummaryRight(bool p_summaryRight)
{
    m_summaryRight = p_summaryRight;
}

void SimpleWorksheet::setOutlineSummaryBelow(bool p_summaryBelow)
{
    m_summaryBelow = p_summaryBelow;
}

void SimpleWorksheet::setXSplit(unsigned int p_column)
{
    if (m_xSplit)
        *m_xSplit = p_column;
    else
        m_xSplit = new unsigned int(p_column);
}

void SimpleWorksheet::unsetXSplit()
{
    delete m_xSplit;
    m_xSplit = nullptr;
}

void SimpleWorksheet::setYSplit(unsigned int p_row)
{
    if (m_ySplit)
        *m_ySplit = p_row;
    else
        m_ySplit = new unsigned int(p_row);
}

void SimpleWorksheet::unsetYSplit()
{
    delete m_ySplit;
    m_ySplit = nullptr;
}

Interface::Write::CellFormat* SimpleWorksheet::createFormat() const
{
    return m_workbook->createFormat();
}

void SimpleWorksheet::setFormat(unsigned int p_column, unsigned int p_row, const Interface::Write::CellFormat& p_format)
{
    setFormat(p_column, p_row, m_workbook->addFormat(p_format));
}

void SimpleWorksheet::setSimpleCellValue(unsigned int p_column, unsigned int p_row, const Interface::Write::CellValue& p_value)
{
    SimpleCellValue const * const k_value = dynamic_cast<const SimpleCellValue*>(&p_value);
    if (k_value) {
        updateMinBounds(Coordinates::Cell(this, p_column, p_row));

        const cells_t::iterator w_index = m_cells.find(CellPosition(p_column, p_row));
        if (w_index == m_cells.end())
            m_cells[CellPosition(p_column, p_row)] = CellDescription(*k_value);
        else
            w_index->second.setValue(*k_value);
    }
}

void SimpleWorksheet::setNullValue(unsigned int p_column, unsigned int p_row, const Interface::utf8String_t& p_formula)
{
    SimpleCellValue w_value;
    w_value.setNull(p_formula);
    setSimpleCellValue(p_column, p_row, w_value);
}

void SimpleWorksheet::setBooleanValue(unsigned int p_column, unsigned int p_row, bool p_value, const Interface::utf8String_t& p_formula)
{
    setSimpleCellValue(p_column, p_row, SimpleCellValue(p_value, p_formula));
}

void SimpleWorksheet::setStringValue(unsigned int p_column, unsigned int p_row, const Interface::utf8String_t& p_value, const Interface::utf8String_t& p_formula)
{
    setSimpleCellValue(p_column, p_row, SimpleCellValue(p_value, p_formula));
}

void SimpleWorksheet::setNumberValue(unsigned int p_column, unsigned int p_row, double p_value, const Interface::utf8String_t& p_formula)
{
    setSimpleCellValue(p_column, p_row, SimpleCellValue(p_value, p_formula));
}

void SimpleWorksheet::setErrorValue(unsigned int p_column, unsigned int p_row, Interface::cellError_t p_value, const Interface::utf8String_t& p_formula)
{
    setSimpleCellValue(p_column, p_row, SimpleCellValue(p_value, p_formula));
}

void SimpleWorksheet::forceDateValue(unsigned int p_column, unsigned int p_row, double p_value, const Interface::utf8String_t& p_formula)
{
    setSimpleCellValue(p_column, p_row, SimpleCellValue(p_value, p_formula));

    SimpleCellFormat w_newFormat(cellFormat(p_column, p_row));
    w_newFormat.setNumberFormat("");
    w_newFormat.setBuiltInNumberFormatId(14);
    setFormat(p_column, p_row, w_newFormat);
}

Interface::Write::RichText* SimpleWorksheet::createRichText() const
{
	return new SimpleRichText();
}

void SimpleWorksheet::setRichTextValue(unsigned int p_column, unsigned int p_row, const Interface::Write::RichText* p_value, const Interface::utf8String_t& p_formula)
{
	SimpleRichText const * const k_richtext = dynamic_cast<SimpleRichText const * const>(p_value);
	if (k_richtext)
		setSimpleCellValue(p_column, p_row, SimpleCellValue(*k_richtext, p_formula));
}

void SimpleWorksheet::setMerge(const Coordinates::CellRange& p_merge)
{
    if  (   (p_merge.worksheet() != this)
        &&  (p_merge.worksheet() != nullptr)
        )
        throw std::exception();

    if  (   (p_merge.left() == p_merge.right())
        &&  (p_merge.top() == p_merge.bottom())
        )
        return;

    const Coordinates::Index k_leftIndex( p_merge.left() < p_merge.right() ? p_merge.leftIndex() : p_merge.rightIndex() );
    const Coordinates::Index k_topIndex( p_merge.top() < p_merge.bottom() ? p_merge.topIndex() : p_merge.bottomIndex() );
    const Coordinates::Index k_rightIndex( p_merge.left() >= p_merge.right() ? p_merge.leftIndex() : p_merge.rightIndex() );
    const Coordinates::Index k_bottomIndex( p_merge.top() >= p_merge.bottom() ? p_merge.topIndex() : p_merge.bottomIndex() );
    Coordinates::CellRange w_merge = Coordinates::CellRange(this, k_leftIndex, k_topIndex, k_rightIndex, k_bottomIndex);

    ranges_t::iterator w_it = m_merges.begin();
    while (w_it != m_merges.end()) {
        if (w_it->intersectWith(w_merge)) {
            Coordinates::CellRange* w_union = nullptr;
            w_merge.getUnion(*w_it, w_union);
            if (w_union)
                w_merge = *w_union;
            delete w_union;
            m_merges.erase(w_it);
            w_it = m_merges.begin();
        } else
            ++w_it;
    }

    updateMinBounds( w_merge.rightBottom() );
    m_merges.push_back(w_merge);
}

Interface::Write::DifferentialCellFormat* SimpleWorksheet::createDifferentialCellFormat() const
{
    return new SimpleDifferentialCellFormat();
}

Interface::Write::ConditionalFormatting* SimpleWorksheet::createConditionalFormatting() const
{
    return new SimpleConditionalFormatting();
}

void SimpleWorksheet::addConditionalFormatting(const Interface::Write::ConditionalFormatting& p_conditionalFormatting)
{
    SimpleConditionalFormatting const * const k_conditionalFormatting = dynamic_cast<const SimpleConditionalFormatting*>(&p_conditionalFormatting);
    if (k_conditionalFormatting)
        m_conditionalFormattingRules.push_back(*k_conditionalFormatting);
}

Interface::Write::CustomValidation* SimpleWorksheet::createCustomValidation() const
{
    return new SimpleCustomValidation();
}

Interface::Write::ListValidation* SimpleWorksheet::createListValidation() const
{
    return new SimpleListValidation();
}

void SimpleWorksheet::addValidation(const Interface::Write::Validation* p_validation)
{
    SimpleValidation const * const k_validation = dynamic_cast<const SimpleValidation*>(p_validation);
    if (k_validation)
        m_validations.push_back(k_validation->clone());
}

Interface::Write::Filter* SimpleWorksheet::createFilter() const
{
    return new SimpleFilter();
}

void SimpleWorksheet::setFilter(const Interface::Write::Filter& p_filter)
{
    SimpleFilter const * const k_filter = dynamic_cast<SimpleFilter const * const>(&p_filter);
    if ((k_filter) && (k_filter->rangeReference())) {
        if (  (k_filter->rangeReference()->worksheet() == this)
           || (k_filter->rangeReference()->worksheet() == nullptr)
           ) {
            const Coordinates::CellRange* k_range = k_filter->rangeReference();

            m_filter = new SimpleFilter();
            m_filter->setRangeReference( Coordinates::CellRange(this, k_range->left(), k_range->top(), k_range->right(), k_range->bottom()) );
        }
    }
}

Interface::Write::Image* SimpleWorksheet::createImage() const
{
    return new SimpleImage();
}

void SimpleWorksheet::addImage(const Interface::Write::Image* p_image)
{
    SimpleImage const * const k_image = dynamic_cast<const SimpleImage*>(p_image);
    if (k_image)
        m_images.push_back(k_image->clone());
}

Interface::Write::Hyperlink* SimpleWorksheet::createHyperlink() const
{
    return new SimpleHyperlink();
}

void SimpleWorksheet::addHyperlink(const Interface::Write::Hyperlink* p_hyperlink)
{
    SimpleHyperlink const * const k_hyperlink = dynamic_cast<const SimpleHyperlink*>(p_hyperlink);
    if (k_hyperlink) {
        m_hyperlinks.push_back(k_hyperlink->clone());
        updateMinBounds(k_hyperlink->reference().rightBottom());
    }
}

Interface::Write::Comment* SimpleWorksheet::createComment() const
{
    return new SimpleComment();
}

bool SimpleWorksheet::addComment(const Interface::Write::Comment* p_comment)
{
    bool w_result = false;

    SimpleComment const * const k_comment = dynamic_cast<const SimpleComment*>(p_comment);
    if (k_comment) {
        const CellPosition k_cell = CellPosition(k_comment->reference().column(), k_comment->reference().row());
        if (m_mappedComments.find(k_cell) == m_mappedComments.end()) {
            SimpleComment const * const k_clonedComment = k_comment->clone();
            m_comments.push_back(k_clonedComment);
            m_mappedComments.emplace(k_cell, k_clonedComment);
            updateMinBounds(k_comment->reference());
            w_result = true;
        }
    }

    return w_result;
}

SimpleWorksheet::SimpleWorksheet(SimpleWorkbook* p_workbook, const Interface::utf8String_t& p_name)
:   m_workbook(p_workbook),
    m_name(p_name),
    m_hidden(false),
    m_showFormulas(false),
    m_showGridLines(true),
    m_showRowColHeaders(true),
    m_showZeros(true),
    m_selection(),
    m_activeCell(this, 0, 0),
    m_pageSetting(nullptr),
    m_minBounds(this, 0, 0, 0, 0),
    m_columns(),
    m_rows(),
    m_defaultColumnWidth(10),
    m_defaultRowHeight(15),
    m_summaryRight(true),
    m_summaryBelow(true),
    m_xSplit(nullptr),
    m_ySplit(nullptr),
    m_cells(),
    m_merges(),
    m_conditionalFormattingRules(),
    m_validations(),
    m_filter(nullptr),
    m_images(),
    m_hyperlinks(),
    m_comments(),
    m_mappedComments()
{
    m_selection.addRange(m_activeCell);
}

SimpleWorksheet::~SimpleWorksheet()
{
    delete m_pageSetting;
    delete m_xSplit;
    delete m_ySplit;
    delete m_filter;

    for (size_t w_iValidation = 0; w_iValidation < m_validations.size(); ++w_iValidation)
        delete m_validations[w_iValidation];

    for (size_t w_iImage = 0; w_iImage < m_images.size(); ++w_iImage)
        delete m_images[w_iImage];

     for (size_t w_iHyperlink = 0; w_iHyperlink < m_hyperlinks.size(); ++w_iHyperlink)
         delete m_hyperlinks[w_iHyperlink];

     for (size_t w_iComment = 0; w_iComment < m_comments.size(); ++w_iComment)
         delete m_comments[w_iComment];
}

void SimpleWorksheet::setFormat(unsigned int p_column, unsigned int p_row, Interface::formatIdentifier_t p_format)
{
    updateMinBounds(Coordinates::Cell(this, p_column, p_row));

    const cells_t::iterator w_index = m_cells.find(CellPosition(p_column, p_row));
    if (w_index == m_cells.end())
        m_cells[CellPosition(p_column, p_row)] = CellDescription(p_format);
    else
        w_index->second.setFormatIdentifier(p_format);
}

void SimpleWorksheet::updateMinBounds(const Coordinates::Cell& p_rightBottom)
{
    if (m_minBounds.worksheet() == p_rightBottom.worksheet()) {

        if  (   (m_minBounds.right() < p_rightBottom.column())
            ||  (m_minBounds.bottom() < p_rightBottom.row())
            ) {

            m_minBounds = Coordinates::CellRange(   this,
                                                    0,
                                                    0,
                                                    ((m_minBounds.right() < p_rightBottom.column()) ? p_rightBottom.column() : m_minBounds.right()),
                                                    ((m_minBounds.bottom() < p_rightBottom.row()) ? p_rightBottom.row() : m_minBounds.bottom())
                                                    );

        }

    }
}

SimpleWorksheet::ColumnRow::ColumnRow()
:   m_isVisible(true),
    m_size(nullptr),
    m_outlineLevel(0),
    m_isCollapsed(false),
    m_formatIdentifier(nullptr)
{
}

SimpleWorksheet::ColumnRow::ColumnRow(const SimpleWorksheet::ColumnRow& p_columnRow)
:   m_isVisible(p_columnRow.isVisible()),
    m_size( p_columnRow.size() ? new double(*p_columnRow.size()) : nullptr ),
    m_outlineLevel( p_columnRow.outlineLevel() ),
    m_isCollapsed( p_columnRow.isCollapsed() ),
    m_formatIdentifier( p_columnRow.m_formatIdentifier ? new Interface::formatIdentifier_t(*p_columnRow.formatIdentifier()) : nullptr )
{
}

SimpleWorksheet::ColumnRow& SimpleWorksheet::ColumnRow::operator =(const SimpleWorksheet::ColumnRow& p_columnRow)
{
    setVisible(p_columnRow.isVisible());
    setSize(p_columnRow.size());
    setOutlineLevel(p_columnRow.outlineLevel());
    setCollapsed(p_columnRow.isCollapsed());
    setFormatIdentifier(p_columnRow.formatIdentifier());

    return *this;
}

SimpleWorksheet::ColumnRow::~ColumnRow()
{
    delete m_size;
    delete m_formatIdentifier;
}

void SimpleWorksheet::ColumnRow::setVisible(bool p_visible)
{
    m_isVisible = p_visible;
}

void SimpleWorksheet::ColumnRow::setSize(const double* p_size)
{
    delete m_size;
    m_size = nullptr;

    if (p_size)
        m_size = new double(*p_size);
}

void SimpleWorksheet::ColumnRow::setOutlineLevel(unsigned short p_outlineLevel)
{
    m_outlineLevel = p_outlineLevel;
}

void SimpleWorksheet::ColumnRow::setCollapsed(bool p_collapsed)
{
    m_isCollapsed = p_collapsed;
}

void SimpleWorksheet::ColumnRow::setFormatIdentifier(const Interface::formatIdentifier_t* p_formatIdentifier)
{
    delete m_formatIdentifier;
    m_formatIdentifier = nullptr;

    if (p_formatIdentifier)
        m_formatIdentifier = new Interface::formatIdentifier_t(*p_formatIdentifier);
}

bool SimpleWorksheet::ColumnRow::isVisible() const
{
    return m_isVisible;
}

const double* SimpleWorksheet::ColumnRow::size() const
{
    return m_size;
}

short unsigned int SimpleWorksheet::ColumnRow::outlineLevel() const
{
    return m_outlineLevel;
}

bool SimpleWorksheet::ColumnRow::isCollapsed() const
{
    return m_isCollapsed;
}

const Interface::formatIdentifier_t* SimpleWorksheet::ColumnRow::formatIdentifier() const
{
    return m_formatIdentifier;
}

bool SimpleWorksheet::ColumnRow::isDefault() const
{
    return  (   (m_isVisible)
            &&  (!m_size)
            &&  (!m_outlineLevel)
            &&  (!m_isCollapsed)
            &&  (!m_formatIdentifier)
            );
}

#if defined(INVOKE_XLSX_LOGS)
size_t SimpleWorksheet::log_size() const
{
    size_t w_size = sizeof(*this);
    
    if (m_pageSetting)
        w_size += m_pageSetting->log_size();
    
    for (columnsRows_t::const_iterator w_it = m_columns.begin(); w_it != m_columns.end(); w_it++)
        w_size += ((w_it->second.size()) ? sizeof(double) : 0);
    for (columnsRows_t::const_iterator w_it = m_rows.begin(); w_it != m_rows.end(); w_it++)
        w_size += ((w_it->second.size()) ? sizeof(double) : 0);

    if (m_xSplit)
        w_size += sizeof(*m_xSplit);
    if (m_ySplit)
        w_size += sizeof(*m_ySplit);
    
    for (cells_t::const_iterator w_it = m_cells.begin(); w_it != m_cells.end(); ++w_it)
        w_size += (w_it->second.value().log_size() - sizeof(SimpleCellValue));

    for (validations_t::const_iterator w_it = m_validations.begin(); w_it != m_validations.end(); ++w_it)
        (*w_it)->log_size();

    for (conditionalFormattingRules_t::const_iterator w_it = m_conditionalFormattingRules.begin(); w_it != m_conditionalFormattingRules.end(); ++w_it)
        w_size += (w_it->log_size() - sizeof(SimpleConditionalFormatting));

    for (validations_t::const_iterator w_it = m_validations.begin(); w_it != m_validations.end(); ++w_it)
        w_size += (*w_it)->log_size();

    if (m_filter)
        w_size += m_filter->log_size();

    for (images_t::const_iterator w_it = m_images.begin(); w_it != m_images.end(); ++w_it)
        w_size += (*w_it)->log_size();

    for (hyperlinks_t::const_iterator w_it = m_hyperlinks.begin(); w_it != m_hyperlinks.end(); ++w_it)
        w_size += (*w_it)->log_size();

    for (comments_t::const_iterator w_it = m_comments.begin(); w_it != m_comments.end(); ++w_it)
        w_size += (*w_it)->log_size();

    return w_size;
}

void SimpleWorksheet::log_scan(Debug::Container* p_container) const
{
    if (p_container) {
        Debug::Container* w_container = p_container->addContainer("SimpleWorksheet", log_size());
        
        if (m_pageSetting)
            m_pageSetting->log_scan(w_container);
        
        for (cells_t::const_iterator w_it = m_cells.begin(); w_it != m_cells.end(); ++w_it)
            w_it->second.value().log_scan(w_container);

        for (conditionalFormattingRules_t::const_iterator w_it = m_conditionalFormattingRules.begin(); w_it != m_conditionalFormattingRules.end(); ++w_it)
            w_it->log_scan(w_container);

        for (validations_t::const_iterator w_it = m_validations.begin(); w_it != m_validations.end(); ++w_it)
            (*w_it)->log_scan(w_container);

        if (m_filter)
            m_filter->log_scan(w_container);

        for (images_t::const_iterator w_it = m_images.begin(); w_it != m_images.end(); ++w_it)
            (*w_it)->log_scan(w_container);

        for (hyperlinks_t::const_iterator w_it = m_hyperlinks.begin(); w_it != m_hyperlinks.end(); ++w_it)
            (*w_it)->log_scan(w_container);

        for (comments_t::const_iterator w_it = m_comments.begin(); w_it != m_comments.end(); ++w_it)
            (*w_it)->log_scan(w_container);
    }
}
#endif

} // namespace SimpleWorkbook
} // namespace XLSX
} // namespace Invoke
