/*!
 * \file        WorkbookReadInterface.cpp
 * \author      Invoke - Jean-Christophe PHILIPPE (jcphilippe\@invoke.fr)
 * \date        Juin 2015
 * \copyright   SA Invoke
 */

#include "xlsx/WorkbookReadInterface.hpp"

#include <sstream>

namespace Invoke {
namespace XLSX {
namespace Interface {
namespace Read {

// -----------------------------------------------------------------------------
// RichText
// -----------------------------------------------------------------------------
RichText::~RichText()
{
}

bool RichText::operator ==(const RichText* p_richtext) const
{
    if (runCount() && p_richtext->runCount()) {
        bool w_return = (runCount() == p_richtext->runCount());
            
        size_t w_it = 0;
        while ((w_return) && (w_it < runCount())) {
            w_return = ((*runFont(w_it) == *p_richtext->runFont(w_it)) && (*runText(w_it) == *p_richtext->runText(w_it)));
            ++w_it;
        }

        return w_return;
    }

    if (!runCount() && !p_richtext->runCount()) 
        return (text() == p_richtext->text());

    return false;
}

bool RichText::operator <(const RichText* p_richtext) const
{
    return (text() < p_richtext->text());
}

// -----------------------------------------------------------------------------
// CellValue
// -----------------------------------------------------------------------------
CellValue::~CellValue()
{
}

bool CellValue::operator ==(const CellValue* p_value) const
{
    switch (type()) {
    
    case Interface::ctNull:
        return (p_value->type() == Interface::ctNull);
    case Interface::ctBoolean:
        return ((p_value->type() == Interface::ctBoolean) && (boolean() == p_value->boolean()));
    case Interface::ctNumber:
        return ((p_value->type() == Interface::ctNumber) && (number() == p_value->number()));
    case Interface::ctString:
    case Interface::ctRichText:
        if ((type() == Interface::ctString) && (p_value->type() == Interface::ctString))
            return (string() == p_value->string());
        if ((type() == Interface::ctRichText) && (p_value->type() == Interface::ctRichText))
            return (*text() == p_value->text());
        if ((type() == Interface::ctString) && (p_value->type() == Interface::ctRichText) && (!p_value->text()->runCount()))
            return (string() == p_value->text()->text());
        if ((type() == Interface::ctRichText) && (!text()->runCount()) && (p_value->type() == Interface::ctString))
            return (text()->text() == p_value->string());
        return false;
    case Interface::ctError:
        return ((p_value->type() == Interface::ctError) && (error() == p_value->error()));
    
    default:
        return false;
    }
}

bool CellValue::operator <(const CellValue* p_value) const
{
    switch (type()) {

    case Interface::ctNull:
        return false;
    case Interface::ctBoolean:
        return ((p_value->type() == Interface::ctBoolean) && (boolean() < p_value->boolean()));
    case Interface::ctNumber:
        return ((p_value->type() == Interface::ctNumber) && (number() < p_value->number()));
    case Interface::ctString:
    case Interface::ctRichText:
        if ((type() == Interface::ctString) && (p_value->type() == Interface::ctString))
            return (string() < p_value->string());
        if ((type() == Interface::ctRichText) && (p_value->type() == Interface::ctRichText))
            return (*text() < p_value->text());
        if ((type() == Interface::ctString) && (p_value->type() == Interface::ctRichText) && (!p_value->text()->runCount()))
            return (string() < p_value->text()->text());
        if ((type() == Interface::ctRichText) && (!text()->runCount()) && (p_value->type() == Interface::ctString))
            return (text()->text() < p_value->string());
        return false;
    case Interface::ctError:
        return ((p_value->type() == Interface::ctError) && (error() < p_value->error()));

    default:
        return false;
    }
}

// -----------------------------------------------------------------------------
// DefinedName
// -----------------------------------------------------------------------------
DefinedName::~DefinedName()
{
}

// -----------------------------------------------------------------------------
// PageHeaderFooter
// -----------------------------------------------------------------------------
PageHeaderFooter::~PageHeaderFooter()
{
}

// -----------------------------------------------------------------------------
// PageSetting
// -----------------------------------------------------------------------------
PageSetting::~PageSetting()
{
}

// -----------------------------------------------------------------------------
// CellFormat
// -----------------------------------------------------------------------------
CellFormat::~CellFormat()
{
}

// -----------------------------------------------------------------------------
// DifferentialCellFormat
// -----------------------------------------------------------------------------
DifferentialCellFormat::~DifferentialCellFormat()
{
}

// -----------------------------------------------------------------------------
// ConditionalFormatting
// -----------------------------------------------------------------------------
ConditionalFormatting::~ConditionalFormatting()
{
}

bool ConditionalFormatting::isValid() const
{
    return  (   (formula() != "")
            &&  (reference().rangeCount())
            );
}

// -----------------------------------------------------------------------------
// Validation
// -----------------------------------------------------------------------------
Validation::~Validation()
{
}

bool Validation::isValid() const
{
    return (reference().rangeCount() != 0); // "!= 0" pour Visual Studio : warning C4800.
}

CustomValidation::~CustomValidation()
{
}

bool CustomValidation::isValid() const
{
    return  (   (formula() != "")
            &&  (reference().rangeCount())
            );
}

ListValidation::~ListValidation()
{
}

bool ListValidation::isValid() const
{
    return  (   (   (   (rangeReference())
                    &&  (   (rangeReference()->left() == rangeReference()->right())
                        ||  (rangeReference()->top() == rangeReference()->bottom())
                        )
                    )
                ||  (   (list())
                    &&  (list()->size() > 0)
                    )
                )
            &&  (reference().rangeCount())
            );
}

// -----------------------------------------------------------------------------
// Filter
// -----------------------------------------------------------------------------
Filter::~Filter()
{
}

// -----------------------------------------------------------------------------
// Image
// -----------------------------------------------------------------------------
Image::~Image()
{
}

// -----------------------------------------------------------------------------
// Hyperlink
// -----------------------------------------------------------------------------
Hyperlink::~Hyperlink()
{
}

// -----------------------------------------------------------------------------
// Comment
// -----------------------------------------------------------------------------
Comment::~Comment()
{
}

// -----------------------------------------------------------------------------
// Worksheet
// -----------------------------------------------------------------------------
Worksheet::~Worksheet()
{
}

// -----------------------------------------------------------------------------
// Workbook
// -----------------------------------------------------------------------------
Workbook::~Workbook()
{
}

} // namespace Read
} // namespace Interface
} // namespace XLSX
} // namespace Invoke
