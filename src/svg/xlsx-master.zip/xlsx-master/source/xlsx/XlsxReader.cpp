/*!
 * \file        XlsxReader.cpp
 * \author      Invoke - Jean-Christophe PHILIPPE (jcphilippe\@invoke.fr)
 * \date        Juillet 2015
 * \copyright   SA Invoke
 */

#include "xlsx/XlsxReader.hpp"
#include "xlsx/SimpleWorkbook.hpp"

#include <iostream>
#include <algorithm>

namespace Invoke {
namespace XLSX {

Reader::coordinatesCell_t Reader::parseCellCoordinates(const std::string& p_sqref, const Coordinates::WorkbookProxy* p_workbook)
{
	if (p_sqref != "") {
		const Coordinates::Parser k_parser(p_sqref, p_workbook);
		if	(	(k_parser.parseResult())
			&&	(!(k_parser.warnings() & 6))
			&&	(k_parser.type() == Coordinates::Parser::ctCell)
			)
			return coordinatesCell_t(new Coordinates::Cell(*k_parser.cell()));
	}

    return coordinatesCell_t(nullptr);
}

Reader::coordinatesCellRange_t Reader::parseCellRangeCoordinates(const std::string& p_sqref, const Coordinates::WorkbookProxy* p_workbook)
{
	if (p_sqref != "") {
		const Coordinates::Parser k_parser(p_sqref, p_workbook);
		if	(	(k_parser.parseResult())
			&&	(!(k_parser.warnings() & 6))
			) {
			switch (k_parser.type()) {
			case Coordinates::Parser::ctCell:
				return coordinatesCellRange_t(new Coordinates::CellRange(k_parser.cell()->worksheet(), k_parser.cell()->columnIndex(), k_parser.cell()->rowIndex(), k_parser.cell()->columnIndex(), k_parser.cell()->rowIndex()));
			case Coordinates::Parser::ctCellRange:
				return coordinatesCellRange_t(new Coordinates::CellRange(*k_parser.cellRange()));
			default:
				return coordinatesCellRange_t(nullptr);
			}
		}
	}

    return coordinatesCellRange_t(nullptr);
}

Reader::coordinatesMultiCellRange_t Reader::parseMultiCellRangeCoordinates(const std::string& p_sqref, const Coordinates::WorkbookProxy* p_workbook, char32_t p_separator)
{
	if (p_sqref != "") {
		const Coordinates::Parser k_parser(p_sqref, p_workbook, p_separator);
		if	(	(k_parser.parseResult())
			&&	(!(k_parser.warnings() & 6))
			) {
			Coordinates::MultiCellRange* w_result = nullptr;

			switch (k_parser.type()) {
			case Coordinates::Parser::ctCell:
				w_result = new Coordinates::MultiCellRange();
				w_result->addRange(*k_parser.cell());
				break;
			case Coordinates::Parser::ctCellRange:
				w_result = new Coordinates::MultiCellRange();
				w_result->addRange(*k_parser.cellRange());
				break;
			case Coordinates::Parser::ctMultiCellRange:
				w_result = new Coordinates::MultiCellRange(*k_parser.multiCellRange());
				break;
			default:
				;
			}

			return coordinatesMultiCellRange_t(w_result);
		}
	}

    return coordinatesMultiCellRange_t(nullptr);
}

Reader::relations_t Reader::rels(Zip::ZipArchiveReader& p_zipReader, const std::string& p_filename)
{
    XML::DOM::Document w_xml;
    loadXMLDocument(p_zipReader, p_filename, w_xml);

    relations_t w_relations = relations_t(new relationsMap_t);

    xPathElement_t w_elements = xpath(&w_xml, "pr:Relationships/pr:Relationship");
    for (int i = 1; i <= w_elements->size(); ++i) {     // w_elements->size() devrait être de type size_t
        XML::DOM::Node const * const k_node = w_elements->at(i)->node();

        relation_t w_rel;
        w_rel.id = k_node->getAttribute("Id");
        w_rel.type = k_node->getAttribute("Type");
        w_rel.target = k_node->getAttribute("Target");

        if ((w_rel.id != "") && (w_rel.type != ""))
            (*w_relations)[w_rel.id] = w_rel;
    }

    return w_relations;
}

std::string Reader::targetFromRels(const relations_t& p_relations, relsType_t p_type)
{
    std::string w_type = "";

    switch (p_type) {
    case rtExtendedProperties:
        w_type = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties";
        break;
    case rtCoreProperties:
        w_type = "http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties";
        break;
    case rtOfficeDocument:
        w_type = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument";
        break;
    case rtStyles:
        w_type = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles";
        break;
    case rtTheme:
        w_type = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme";
        break;
    case rtSharedStrings:
        w_type = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings";
        break;
    case rtWorksheet:
        w_type = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet";
        break;
    case rtDrawing:
        w_type = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing";
        break;
    case rtComments:
        w_type = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments";
        break;
    case rtVmlDrawing:
        w_type = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/vmlDrawing";
        break;
    }

    relationsMap_t::const_iterator w_it = p_relations->begin();
    while ((w_it != p_relations->end()) && (w_it->second.type != w_type))
        ++w_it;

    if (w_it != p_relations->end())
        return w_it->second.target;
    return "";
}

Reader::colorScheme_t Reader::colorScheme(Zip::ZipArchiveReader& p_zipReader, const std::string& p_filename)
{
    colorScheme_t w_colorScheme = colorScheme_t(new colorSchemeStruct_t);
    for (unsigned int i = 0; i < 12; ++i)
        w_colorScheme->colors[i] = 0;

    if (p_filename != "") {
        XML::DOM::Document w_xml;
        loadXMLDocument(p_zipReader, p_filename, w_xml);

        const std::unordered_map<std::string, unsigned int> k_colorIndex = {
            {"lt1",         0},
            {"dk1",         1},
            {"lt2",         2},
            {"dk2",         3},
            {"accent1",     4},
            {"accent2",     5},
            {"accent3",     6},
            {"accent4",     7},
            {"accent5",     8},
            {"accent6",     9},
            {"hlink",       10},
            {"folHlink",    11}
            };

        xPathElement_t w_elements = xpath(&w_xml, "dml:theme/dml:themeElements/dml:clrScheme/*");
        for (int i = 1; i <= w_elements->size(); i++) {     // w_elements->size() devrait être de type size_t
            XML::DOM::Node const * const k_node = w_elements->at(i)->node();

            if (k_node) {
                auto w_index = k_colorIndex.find( k_node->localName() );
                if (w_index != k_colorIndex.end()) {
                    std::vector<XML::DOM::Node*> w_subNodes;

                    k_node->getElementsByTagNameNS("http://schemas.openxmlformats.org/drawingml/2006/main", "sysClr", w_subNodes);
                    if ((w_subNodes.size()) && (w_subNodes.at(0)))
                        w_colorScheme->colors[w_index->second] = std::stoul("FF"+ w_subNodes.at(0)->getAttribute("lastClr"), nullptr, 16);
                    else {
                        k_node->getElementsByTagNameNS("http://schemas.openxmlformats.org/drawingml/2006/main", "srgbClr", w_subNodes);
                        if ((w_subNodes.size()) && (w_subNodes.at(0)))
                            w_colorScheme->colors[w_index->second] = std::stoul("FF"+ w_subNodes.at(0)->getAttribute("val"), nullptr, 16);
                    }
                }
            }
        }
    }

    return w_colorScheme;
}

Reader::runs_t Reader::richText(const XML::DOM::Node* p_node, const colorScheme_t& p_colorScheme)
{
	runs_t w_result = runs_t(new runsVector_t);

	if (p_node) {
		xPathElement_t w_runs = xpath(p_node, "ssml:r");
		if ((w_runs) && (w_runs->size() > 0)) {
			for (int i = 1; i <= w_runs->size(); ++i) {     // w_runs->size() devrait être de type size_t
				XML::DOM::Node const * const k_rNode = w_runs->at(i)->node();

				Reader::run_t w_run;

				w_run.font.name = toString(xpath(k_rNode, "fn:data(ssml:rPr/ssml:rFont/@val)"));
				w_run.font.size = toInteger(xpath(k_rNode, "fn:data(ssml:rPr/ssml:sz/@val)"), 8);
				w_run.font.color = color(node(xpath(k_rNode, "ssml:rPr/ssml:color")), p_colorScheme, 0xFF000000);
				w_run.font.bold = !(xpath(k_rNode, "ssml:rPr/ssml:b")->isEmpty());
				w_run.font.italic = !(xpath(k_rNode, "ssml:rPr/ssml:i")->isEmpty());
				w_run.font.underline = !(xpath(k_rNode, "ssml:rPr/ssml:u")->isEmpty());

				w_run.text = toString(xpath(k_rNode, "fn:data(ssml:t)"));

				w_result->push_back(w_run);
			}

			return w_result;
		} else {
			xPathElement_t w_text = xpath(p_node, "fn:data(ssml:t)");
			if (w_text) {
				Reader::run_t w_run;

				w_run.font.name = "";
				w_run.font.size = 0;
				w_run.font.color = 0;
				w_run.font.bold = false;
				w_run.font.italic = false;
				w_run.font.underline = false;

				w_run.text = toString(w_text);

				w_result->push_back(w_run);
			}
		}
	}

	return w_result;
}

void Reader::assignRichText(Interface::Write::RichText* o_richtext, const runsVector_t& p_runs)
{
	if ((p_runs.size() == 1) && (p_runs.at(0).font.name == "")) 
		o_richtext->setText(p_runs.at(0).text);
	else {
		for (run_t w_run : p_runs) 
			o_richtext->addRun(w_run.font, w_run.text);
	}
}

Reader::sharedStrings_t Reader::sharedStrings(Zip::ZipArchiveReader& p_zipReader, const std::string& p_filename, const colorScheme_t& p_colorScheme)
{
    sharedStrings_t w_sharedStrings = sharedStrings_t(new sharedStringsVector_t);

    if (p_filename != "") {
        XML::DOM::Document w_xml;
        loadXMLDocument(p_zipReader, p_filename, w_xml);

        xPathElement_t w_elements = xpath(&w_xml, "ssml:sst/ssml:si");
		for (int i = 1; i <= w_elements->size(); ++i)       // w_elements->size() devrait être de type size_t
			w_sharedStrings->push_back( *richText(w_elements->at(i)->node(), p_colorScheme).get() );
    }

    return w_sharedStrings;
}

Interface::color_t Reader::color(const XML::DOM::Node* p_node, const colorScheme_t& p_colorScheme, Interface::color_t p_default)
{
    if (!p_node)
        return p_default;

    if (p_node->hasAttribute("rgb"))
        return std::stoul(p_node->getAttribute("rgb"), nullptr, 16);

    if (p_node->hasAttribute("indexed")) {
        const unsigned int k_index = std::stoi(p_node->getAttribute("indexed"));

        switch (k_index) {
        case  8:    return 0xFF000000;
        case  9:    return 0xFFFFFFFF;
        case 10:    return 0xFFFF0000;
        case 11:    return 0xFF00FF00;
        case 12:    return 0xFF0000FF;
        case 13:    return 0xFFFFFF00;
        case 14:    return 0xFFFF00FF;
        case 15:    return 0xFF00FFFF;
        case 16:    return 0xFF800000;
        case 17:    return 0xFF008000;
        case 18:    return 0xFF000080;
        case 19:    return 0xFF808000;
        case 20:    return 0xFF800080;
        case 21:    return 0xFF008080;
        case 22:    return 0xFFC0C0C0;
        case 23:    return 0xFF808080;
        case 24:    return 0xFF9999FF;
        case 25:    return 0xFF993366;
        case 26:    return 0xFFFFFFCC;
        case 27:    return 0xFFCCFFFF;
        case 28:    return 0xFF660066;
        case 29:    return 0xFFFF8080;
        case 30:    return 0xFF0066CC;
        case 31:    return 0xFFCCCCFF;
        case 32:    return 0xFF000080;
        case 33:    return 0xFFFF00FF;
        case 34:    return 0xFFFFFF00;
        case 35:    return 0xFF00FFFF;
        case 36:    return 0xFF800080;
        case 37:    return 0xFF800000;
        case 38:    return 0xFF008080;
        case 39:    return 0xFF0000FF;
        case 40:    return 0xFF00CCFF;
        case 41:    return 0xFFCCFFFF;
        case 42:    return 0xFFCCFFCC;
        case 43:    return 0xFFFFFF99;
        case 44:    return 0xFF99CCFF;
        case 45:    return 0xFFFF99CC;
        case 46:    return 0xFFCC99FF;
        case 47:    return 0xFFFFCC99;
        case 48:    return 0xFF3366FF;
        case 49:    return 0xFF33CCCC;
        case 50:    return 0xFF99CC00;
        case 51:    return 0xFFFFCC00;
        case 52:    return 0xFFFF9900;
        case 53:    return 0xFFFF6600;
        case 54:    return 0xFF666699;
        case 55:    return 0xFF969696;
        case 56:    return 0xFF003366;
        case 57:    return 0xFF339966;
        case 58:    return 0xFF003300;
        case 59:    return 0xFF333300;
        case 60:    return 0xFF993300;
        case 61:    return 0xFF993366;
        case 62:    return 0xFF333399;
        case 63:    return 0xFF333333;

        default:    return p_default;
        }
    }

    if (p_node->hasAttribute("theme")) {
        Interface::color_t w_color = p_default;

        const unsigned int k_index = std::stoi(p_node->getAttribute("theme"));
        if (k_index < COLOR_COUNT)
            w_color = p_colorScheme->colors[k_index];

        if (p_node->hasAttribute("tint")) {
            const double k_intensity = std::stod(p_node->getAttribute("tint"));

            const unsigned char k_alpha  = static_cast<unsigned char>((w_color & 0xFF000000) >> 24);
            unsigned char w_red          = static_cast<unsigned char>((w_color & 0x00FF0000) >> 16);
            unsigned char w_green        = static_cast<unsigned char>((w_color & 0x0000FF00) >> 8);
            unsigned char w_blue         = static_cast<unsigned char>((w_color & 0x000000FF));

            if (k_intensity > 0) {
                const unsigned char k_percent = static_cast<unsigned char>(100 - (k_intensity * 100));

                w_red = std::max(std::min((w_red * k_percent / 100) + (255 - (255 * k_percent / 100)), 255), 0);
                w_green = std::max(std::min((w_green * k_percent / 100) + (255 - (255 * k_percent / 100)), 255), 0);
                w_blue = std::max(std::min((w_blue * k_percent / 100) + (255 - (255 * k_percent / 100)), 255), 0);
            } else {
                const unsigned char k_percent = static_cast<unsigned char>(100 + (k_intensity * 100));

                w_red = std::max(std::min(w_red * k_percent / 100, 255), 0);
                w_green = std::max(std::min(w_green * k_percent / 100, 255), 0);
                w_blue = std::max(std::min(w_blue * k_percent / 100, 255), 0);
            }

            w_color = (k_alpha << 24) | (w_red << 16) | (w_green << 8) | w_blue;
        }

        return w_color;
    }

    return p_default;
}

Reader::numFmts_t Reader::numFmts(XML::DOM::Document& p_xml)
{
    numFmts_t w_numFmts = numFmts_t(new numFmtsMap_t);

    (*w_numFmts)[ 1] = "0";
    (*w_numFmts)[ 2] = "0.00";
    (*w_numFmts)[ 3] = "#,##0";
    (*w_numFmts)[ 4] = "#,##0.00";

    (*w_numFmts)[ 5] = "#,##0 €;-#,##0 €";
    (*w_numFmts)[ 6] = "#,##0 €;[red]-#,##0 €";
    (*w_numFmts)[ 7] = "#,##0.00 €;-#,##0.00 €";
    (*w_numFmts)[ 8] = "#,##0.00 €;[red]-#,##0.00 €";

    (*w_numFmts)[ 9] = "0%";
    (*w_numFmts)[10] = "0.00%";

    (*w_numFmts)[11] = "0.00E+00";

    (*w_numFmts)[12] = "# ?/?";
    (*w_numFmts)[13] = "# \?\?/??";

    (*w_numFmts)[14] = "dd/mm/yyyy";
    (*w_numFmts)[15] = "d-mm-yy";
    (*w_numFmts)[16] = "d-mmm";
    (*w_numFmts)[17] = "mmm-yy";
    (*w_numFmts)[18] = "h:mm AM/PM";
    (*w_numFmts)[19] = "h:mm:ss AM/PM";
    (*w_numFmts)[20] = "h:mm";
    (*w_numFmts)[21] = "h:mm:ss";
    (*w_numFmts)[22] = "dd/mm/yyyy h:mm";

    (*w_numFmts)[37] = "#,##0 _€;-#,##0 _€";
    (*w_numFmts)[38] = "#,##0 _€;[red]-#,##0 _€";
    (*w_numFmts)[39] = "#,##0.00 _€;-#,##0.00 _€";
    (*w_numFmts)[40] = "#,##0.00 _€;[red]-#,##0.00 _€";

    (*w_numFmts)[41] = "_-* #,##0 _€_-;-* #,##0 _€_-;_-* - _€_-;_-@_-";
    (*w_numFmts)[42] = "_-* #,##0 €_-;-* #,##0 €_-;_-* - _€_-;_-@_-";
    (*w_numFmts)[43] = "_-* #,##0.00 _€_-;-* #,##0.00 _€_-;_-* -?? _€_-;_-@_-";
    (*w_numFmts)[44] = "_-* #,##0.00 €_-;-* #,##0.00 €_-;_-* -?? €_-;_-@_-";

    (*w_numFmts)[45] = "mm:ss";
    (*w_numFmts)[46] = "[h]:mm:ss";
    (*w_numFmts)[47] = "mm:ss.0";
    (*w_numFmts)[48] = "##0.0E+0";
    (*w_numFmts)[49] = "@";

    xPathElement_t w_elements = xpath(&p_xml, "ssml:styleSheet/ssml:numFmts/ssml:numFmt");
    for (int i = 1; i <= w_elements->size(); ++i) {     // w_elements->size() devrait être de type size_t
        XML::DOM::Node const * const k_node = w_elements->at(i)->node();

        const std::string k_numFmtId = k_node->getAttribute("numFmtId");
        const std::string k_formatCode = k_node->getAttribute("formatCode");

        if ((k_numFmtId != "") && (k_formatCode != "")) {
            const unsigned int k_id = std::stoi(k_numFmtId, nullptr, 10);
            (*w_numFmts)[k_id] = k_formatCode;
        }
    }

    return w_numFmts;
}

Reader::fonts_t Reader::fonts(XML::DOM::Document& p_xml, const colorScheme_t& p_colorScheme)
{
    fonts_t w_fonts = fonts_t(new fontsVector_t);

    xPathElement_t w_elements = xpath(&p_xml, "ssml:styleSheet/ssml:fonts/ssml:font");
    for (int i = 1; i <= w_elements->size(); ++i) {     // w_elements->size() devrait être de type size_t
        XML::DOM::Node const * const k_node = w_elements->at(i)->node();

        font_t w_font;

        w_font.name = toString(xpath(k_node, "fn:data(ssml:name/@val)"), "Arial");
        w_font.size = toInteger(xpath(k_node, "fn:data(ssml:sz/@val)"), 10);
        w_font.color = color(node(xpath(k_node, "ssml:color")), p_colorScheme, 0xFF000000);

        w_font.bold = false;
        w_font.italic = false;
        w_font.underline = false;

        typedef std::vector<XML::DOM::Node*> nodes_t;
        nodes_t w_nodes;
        k_node->getElementsByTagNameNS("http://schemas.openxmlformats.org/spreadsheetml/2006/main", "b", w_nodes);
        if ((w_nodes.size() == 1) && (w_nodes.at(0))) {
            XML::DOM::Node const * const k_subNode = w_nodes.at(0);
            w_font.bold = (/*!k_subNode->hasAttribute("val") || */ (k_subNode->getAttribute("val") != "0"));
        }

        w_nodes.clear();
        k_node->getElementsByTagNameNS("http://schemas.openxmlformats.org/spreadsheetml/2006/main", "i", w_nodes);
        if ((w_nodes.size() == 1) && (w_nodes.at(0))) {
            XML::DOM::Node const * const k_subNode = w_nodes.at(0);
            w_font.italic = (/*!k_subNode->hasAttribute("val") || */ (k_subNode->getAttribute("val") != "0"));
        }

        w_nodes.clear();
        k_node->getElementsByTagNameNS("http://schemas.openxmlformats.org/spreadsheetml/2006/main", "u", w_nodes);
        if ((w_nodes.size() == 1) && (w_nodes.at(0))) {
            XML::DOM::Node const * const k_subNode = w_nodes.at(0);
            w_font.underline = (/*!k_subNode->hasAttribute("val") || */ (k_subNode->getAttribute("val") != "none"));
        }

        w_fonts->push_back(w_font);
    }

    return w_fonts;
}

const Reader::patternStyleMap_t Reader::patternStyleMap()
{
    const patternStyleMap_t k_patternStyles = {
        {"none",            Interface::psNone},
        {"solid",           Interface::psSolid},
        {"darkGray",        Interface::psDarkGray},
        {"mediumGray",      Interface::psMediumGray},
        {"lightGray",       Interface::psLightGray},
        {"gray125",         Interface::psGray125},
        {"gray0625",        Interface::psGray0625},
        {"darkHorizontal",  Interface::psDarkHorizontal},
        {"darkVertical",    Interface::psDarkVertical},
        {"darkDown",        Interface::psDarkDown},
        {"darkUp",          Interface::psDarkUp},
        {"darkGrid",        Interface::psDarkGrid},
        {"darkTrellis",     Interface::psDarkTrellis},
        {"lightHorizontal", Interface::psLightHorizontal},
        {"lightVertical",   Interface::psLightVertical},
        {"lightDown",       Interface::psLightDown},
        {"lightUp",         Interface::psLightUp},
        {"lightGrid",       Interface::psLightGrid},
        {"lightTrellis",    Interface::psLightTrellis}
        };

    return k_patternStyles;
}

Reader::patterns_t Reader::patterns(XML::DOM::Document& p_xml, const colorScheme_t& p_colorScheme)
{
    patterns_t w_patterns = patterns_t(new patternsVector_t);

    const patternStyleMap_t k_patternStyles = patternStyleMap();

    xPathElement_t w_elements = xpath(&p_xml, "ssml:styleSheet/ssml:fills/ssml:fill");
    for (int i = 1; i <= w_elements->size(); ++i) {     // w_elements->size() devrait être de type size_t
        XML::DOM::Node const * const k_node = w_elements->at(i)->node();

        pattern_t w_pattern;

        const std::string k_type = toString(xpath(k_node, "fn:data(ssml:patternFill/@patternType)"), "none");

        w_pattern.style = Interface::psNone;
        auto w_index = k_patternStyles.find(k_type);
        if (w_index != k_patternStyles.end())
            w_pattern.style = w_index->second;

        w_pattern.fgColor = color(node(xpath(k_node, "ssml:patternFill/ssml:fgColor")), p_colorScheme, 0xFF000000);
        w_pattern.bgColor = color(node(xpath(k_node, "ssml:patternFill/ssml:bgColor")), p_colorScheme, 0xFFFFFFFF);

        w_patterns->push_back(w_pattern);
    }

    return w_patterns;
}

const Reader::borderStyleMap_t Reader::borderStyleMap()
{
    const borderStyleMap_t k_borderStyles = {
        {"hair",                Interface::bsHair},
        {"dotted",              Interface::bsDotted},
        {"dashDotDot",          Interface::bsDashDotDot},
        {"dashDot",             Interface::bsDashDot},
        {"dashed",              Interface::bsDashed},
        {"thin",                Interface::bsThin},
        {"mediumDashDotDot",    Interface::bsMediumDashDotDot},
        {"slantDashDot",        Interface::bsSlantDashDot},
        {"mediumDashDot",       Interface::bsMediumDashDot},
        {"mediumDashed",        Interface::bsMediumDashed},
        {"medium",              Interface::bsMedium},
        {"thick",               Interface::bsThick},
        {"double",              Interface::bsDouble}
        };

    return k_borderStyles;
}

Reader::border_t Reader::border(const XML::DOM::Node* p_node, const strBorderStyles_t& p_strStyles, const colorScheme_t& p_colorScheme)
{
    border_t w_border;
    w_border.style = Interface::bsThin;
    w_border.color = 0x00000000;

    if (p_node) {
        const std::string k_style = toString(xpath(p_node, "fn:data(@style)"), "none");
        if (k_style != "none") {
            const strBorderStyles_t::const_iterator k_index = p_strStyles.find(k_style);
            if (k_index != p_strStyles.end())
                w_border.style = k_index->second;
            w_border.color = color(node(xpath(p_node, "color")), p_colorScheme, 0xFF000000);
        }
    }

    return w_border;
}

Reader::borders_t Reader::borders(XML::DOM::Document& p_xml, const colorScheme_t& p_colorScheme)
{
    borders_t w_borders = borders_t(new bordersVector_t);

    const borderStyleMap_t k_borderStyles = borderStyleMap();

    xPathElement_t w_elements = xpath(&p_xml, "ssml:styleSheet/ssml:borders/ssml:border");
    for (int i = 1; i <= w_elements->size(); ++i) {     // w_elements->size() devrait être de type size_t
        XML::DOM::Node const * const k_node = w_elements->at(i)->node();

        cellBorders_t w_cellBorders;
        w_cellBorders.left = border(xpath(k_node, "ssml:left")->node(), k_borderStyles, p_colorScheme);
        w_cellBorders.right = border(xpath(k_node, "ssml:right")->node(), k_borderStyles, p_colorScheme);
        w_cellBorders.top = border(xpath(k_node, "ssml:top")->node(), k_borderStyles, p_colorScheme);
        w_cellBorders.bottom = border(xpath(k_node, "ssml:bottom")->node(), k_borderStyles, p_colorScheme);

        w_cellBorders.diagonalUp.style = Interface::bsThin;
        w_cellBorders.diagonalUp.color = 0x00000000;

        w_cellBorders.diagonalDown.style = Interface::bsThin;
        w_cellBorders.diagonalDown.color = 0x00000000;

        if (toString(xpath(k_node, "fn:data(@diagonalUp)")) == "1")
            w_cellBorders.diagonalUp = border(node(xpath(k_node, "ssml:diagonal")), k_borderStyles, p_colorScheme);

        if (toString(xpath(k_node, "fn:data(@diagonalDown)")) == "1")
            w_cellBorders.diagonalDown = border(node(xpath(k_node, "ssml:diagonal")), k_borderStyles, p_colorScheme);

        w_borders->push_back(w_cellBorders);
    }

    return w_borders;
}

void Reader::freeCellStyles(const cellStyles_t& p_cellStyles)
{
    for (cellStyles_t::const_iterator w_it = p_cellStyles.begin(); w_it != p_cellStyles.end(); ++w_it) {
        delete w_it->numFmtId;
        delete w_it->fontId;
        delete w_it->fillId;
        delete w_it->borderId;
        delete w_it->horizontalAlignment;
        delete w_it->verticalAlignment;
        delete w_it->indent;
        delete w_it->rotation;
        delete w_it->wrap;
    }
}

void Reader::getDiffBorder(const XML::DOM::Node* p_node, const borderStyleMap_t& p_borderStyles, const colorScheme_t& p_colorScheme, bool*& o_visible, Interface::borderStyle_t*& o_style, Interface::color_t*& o_color)
{
    o_visible = nullptr;
    o_style = nullptr;
    o_color = nullptr;

    if (p_node) {
        xPathElement_t w_element = xpath(p_node, "fn:data(@style)");
        if (value(w_element)) {
            o_style = new Interface::borderStyle_t();
            *o_style = p_borderStyles.at( toString(w_element) );
        }

        w_element = xpath(p_node, "ssml:color");
        if (node(w_element)) {
            o_color = new Interface::color_t();
            *o_color = color(node(w_element), p_colorScheme, 0xFF000000);
        }

        o_visible = new bool( o_style || o_color );
    }
}

Reader::styles_t Reader::styles(Zip::ZipArchiveReader& p_zipReader, const std::string& p_filename, const colorScheme_t& p_colorScheme)
{
    styles_t w_styles = styles_t(new stylesStruct_t);

    if (p_filename != "") {
        XML::DOM::Document w_xml;
        loadXMLDocument(p_zipReader, p_filename, w_xml);

        // formats
        const numFmts_t k_numFmts = numFmts(w_xml);
        const fonts_t k_fonts = fonts(w_xml, p_colorScheme);
        const patterns_t k_fills = patterns(w_xml, p_colorScheme);
        const borders_t k_borders = borders(w_xml, p_colorScheme);

        // Police par défaut
        w_styles->defaultFont = { "Arial", 10, 0xFF000000, false, false, false };
        if (k_fonts->size() > 0)
            w_styles->defaultFont = k_fonts->at(0);

        std::unordered_map<std::string, Interface::horizontalAlignment_t> w_horizontalAlignment = {
            {"left",    Interface::haLeft},
            {"center",  Interface::haCenter},
            {"right",   Interface::haRight}
            };

        std::unordered_map<std::string, Interface::verticalAlignment_t> w_verticalAlignment = {
            {"top",     Interface::vaTop},
            {"center",  Interface::vaCenter},
            {"bottom",  Interface::vaBottom}
            };

        cellStyles_t w_cellStyles;
        try {
            // Style de cellules
            xPathElement_t w_elements = xpath(&w_xml, "ssml:styleSheet/ssml:cellStyleXfs/ssml:xf");
            for (int i = 1; i <= w_elements->size(); ++i) {     // w_elements->size() devrait être de type size_t
                XML::DOM::Node const * const k_node = w_elements->at(i)->node();

                w_cellStyles.push_back( { nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr, nullptr } );

                xPathElement_t w_apply = xpath(k_node, "fn:data(@applyNumberFormat)");
                if (!value(w_apply) || (toString(w_apply) != "0"))
                    w_cellStyles.back().numFmtId = new unsigned int(toInteger(xpath(k_node, "fn:data(@numFmtId)"), 0));

                w_apply = xpath(k_node, "fn:data(@applyFont)");
                if (!value(w_apply) || (toString(w_apply) != "0"))
                    w_cellStyles.back().fontId = new unsigned int(toInteger(xpath(k_node, "fn:data(@fontId)"), 0));

                w_apply = xpath(k_node, "fn:data(@applyFill)");
                if (!value(w_apply) || (toString(w_apply) != "0"))
                    w_cellStyles.back().fillId = new unsigned int(toInteger(xpath(k_node, "fn:data(@fillId)"), 0));

                w_apply = xpath(k_node, "fn:data(@applyBorder)");
                if (!value(w_apply) || (toString(w_apply) != "0"))
                    w_cellStyles.back().borderId = new unsigned int(toInteger(xpath(k_node, "fn:data(@borderId)"), 0));

                w_apply = xpath(k_node, "fn:data(@applyAlignment)");
                if (!value(w_apply) || (toString(w_apply) != "0")) {
                    xPathElement_t w_subElement = xpath(k_node, "fn:data(ssml:alignment/@horizontal)");
                    if (value(w_subElement))
                        w_cellStyles.back().horizontalAlignment = new Interface::horizontalAlignment_t( w_horizontalAlignment[toString(w_subElement)] );

                    w_subElement = xpath(k_node, "fn:data(ssml:alignment/@horizontal)");
                    if (value(w_subElement))
                        w_cellStyles.back().verticalAlignment = new Interface::verticalAlignment_t( w_verticalAlignment[toString(w_subElement)] );

                    w_subElement = xpath(k_node, "fn:data(ssml:alignment/@indent)");
                    if (value(w_subElement))
                        w_cellStyles.back().indent = new unsigned short( toInteger(w_subElement) );

                    w_subElement = xpath(k_node, "fn:data(ssml:alignment/@textRotation)");
                    if (value(w_subElement)) {
                        w_cellStyles.back().rotation = new short( toInteger(w_subElement) );
                        if (*w_cellStyles.back().rotation > 90)
                            *w_cellStyles.back().rotation = -(*w_cellStyles.back().rotation - 90);
                    }

                    w_subElement = xpath(k_node, "fn:data(ssml:alignment/@wrapText)");
                    if (value(w_subElement))
                        w_cellStyles.back().wrap = new bool( toInteger(w_subElement) == 1 );
                }
            }

            // Formats de cellules
            w_elements = xpath(&w_xml, "ssml:styleSheet/ssml:cellXfs/ssml:xf");
            for (int i = 1; i <= w_elements->size(); ++i) {     // w_elements->size() devrait être de type size_t
                XML::DOM::Node const * const k_node = w_elements->at(i)->node();

                cellStyle_t* w_cellStyle = nullptr;
                xPathElement_t w_xfId = xpath(k_node, "fn:data(@xfId)");
                if (value(w_xfId) && (static_cast<size_t>(toInteger(w_xfId)) < w_cellStyles.size()))
                    w_cellStyle = &(w_cellStyles[toInteger(w_xfId)]);

                cellFormat_t w_format;

                unsigned int w_id = ((w_cellStyle && w_cellStyle->numFmtId) ? *w_cellStyle->numFmtId : 0);
                xPathElement_t w_apply = xpath(k_node, "fn:data(@applyNumberFormat)");
                if (value(w_apply) && (toString(w_apply) == "1"))
                    w_id = toInteger(xpath(k_node, "fn:data(@numFmtId)"), 0);
                w_format.numFmt = (*k_numFmts)[w_id];

                w_id = ((w_cellStyle && w_cellStyle->fontId) ? *w_cellStyle->fontId : 0);
                w_apply = xpath(k_node, "fn:data(@applyFont)");
                if (value(w_apply) && (toString(w_apply) == "1"))
                    w_id = toInteger(xpath(k_node, "fn:data(@fontId)"), 0);
                w_format.font = (*k_fonts)[ (w_id < k_fonts->size() ? w_id : 0) ];

                w_id = ((w_cellStyle && w_cellStyle->fillId) ? *w_cellStyle->fillId : 0);
                w_apply = xpath(k_node, "fn:data(@applyFill)");
                if (value(w_apply) && (toString(w_apply) == "1"))
                    w_id = toInteger(xpath(k_node, "fn:data(@fillId)"), 0);
                w_format.pattern = (*k_fills)[ (w_id < k_fills->size() ? w_id : 0) ];

                w_id = ((w_cellStyle && w_cellStyle->borderId) ? *w_cellStyle->borderId : 0);
                w_apply = xpath(k_node, "fn:data(@applyBorder)");
                if (value(w_apply) && (toString(w_apply) == "1"))
                    w_id = toInteger(xpath(k_node, "fn:data(@borderId)"), 0);
                const cellBorders_t k_cellBorders = (*k_borders)[ (w_id < k_borders->size() ? w_id : 0) ];
                w_format.borders[Interface::bLeft] = k_cellBorders.left;
                w_format.borders[Interface::bTop] = k_cellBorders.top;
                w_format.borders[Interface::bRight] = k_cellBorders.right;
                w_format.borders[Interface::bBottom] = k_cellBorders.bottom;
                w_format.borders[Interface::bDiagonalUp] = k_cellBorders.diagonalUp;
                w_format.borders[Interface::bDiagonalDown] = k_cellBorders.diagonalDown;

                w_format.horizontalAlignment = ((w_cellStyle && w_cellStyle->horizontalAlignment) ? *(w_cellStyle->horizontalAlignment) : Interface::haAuto);
                w_format.verticalAlignment =  ((w_cellStyle && w_cellStyle->verticalAlignment) ? *(w_cellStyle->verticalAlignment) : Interface::vaBottom);
                w_format.indent = ((w_cellStyle && w_cellStyle->indent) ? *(w_cellStyle->indent) : 0);
                w_format.rotation = ((w_cellStyle && w_cellStyle->rotation) ? *(w_cellStyle->rotation) : 0);
                w_format.wrap = ((w_cellStyle && w_cellStyle->wrap) ? *(w_cellStyle->wrap) : false);

                w_apply = xpath(k_node, "fn:data(@applyAlignment)");
                if (value(w_apply) && (toString(w_apply) == "1")) {
                    xPathElement_t w_subElement = xpath(k_node, "fn:data(ssml:alignment/@horizontal)");
                    if (value(w_subElement))
                        w_format.horizontalAlignment = w_horizontalAlignment[ toString(w_subElement) ];

                    w_subElement = xpath(k_node, "fn:data(ssml:alignment/@vertical)");
                    if (value(w_subElement))
                        w_format.verticalAlignment = w_verticalAlignment[ toString(w_subElement) ];

                    w_format.indent = toInteger(xpath(k_node, "fn:data(ssml:alignment/@indent)"), 0);

                    w_format.rotation = toInteger(xpath(k_node, "fn:data(ssml:alignment/@textRotation)"), 0);
                    if (w_format.rotation > 90)
                        w_format.rotation = -(w_format.rotation - 90);

                    w_format.wrap = (node(xpath(k_node, "ssml:alignment[@wrapText eq '1']")) != nullptr);
                }

                w_styles->formats.push_back(w_format);
            }

        } catch (...) {
            freeCellStyles(w_cellStyles);
            throw;
        }
        freeCellStyles(w_cellStyles);

        // Formats de cellule différentiels
        const patternStyleMap_t k_patternStyles = patternStyleMap();
        const borderStyleMap_t k_borderStyles = borderStyleMap();

        xPathElement_t w_elements = xpath(&w_xml, "ssml:styleSheet/ssml:dxfs/ssml:dxf");
            for (int i = 1; i <= w_elements->size(); ++i) {     // w_elements->size() devrait être de type size_t
            XML::DOM::Node const * const k_node = w_elements->at(i)->node();

            diffCellFormat_t w_diffFormat;


            w_diffFormat.numFmt = nullptr;
            xPathElement_t w_subElement = xpath(k_node, "fn:data(@numFmtId)");
            if (value(w_subElement)) {
                w_diffFormat.numFmt = new std::string;
                const unsigned int k_numFmtId = toInteger(w_subElement);
                *w_diffFormat.numFmt = (*k_numFmts)[k_numFmtId];
            }


            w_diffFormat.fontColor = nullptr;
            w_diffFormat.fontBold = nullptr;
            w_diffFormat.fontItalic = nullptr;
            w_diffFormat.fontUnderline = nullptr;
            w_subElement = xpath(k_node, "ssml:font/ssml:color");
            if (node(w_subElement)) {
                w_diffFormat.fontColor = new Interface::color_t;
                *w_diffFormat.fontColor = color(node(w_subElement), p_colorScheme, 0xFF000000);
            }
            w_subElement = xpath(k_node, "if (ssml:font/ssml:b) then if (ssml:font/ssml:b/@val) then fn:data(ssml:font/ssml:b/@val) ne '0' else fn:true() else ()");
            if (value(w_subElement)) {
                w_diffFormat.fontBold = new bool;
                *w_diffFormat.fontBold = value(w_subElement)->asBool();
            }
            w_subElement = xpath(k_node, "if (ssml:font/ssml:i) then if (ssml:font/ssml:i/@val) then fn:data(ssml:font/ssml:i/@val) ne '0' else fn:true() else ()");
            if (value(w_subElement)) {
                w_diffFormat.fontItalic = new bool;
                *w_diffFormat.fontItalic = value(w_subElement)->asBool();
            }
            w_subElement = xpath(k_node, "if (ssml:font/ssml:u) then if (ssml:font/ssml:u/@val) then fn:data(ssml:font/ssml:u/@val) ne 'none' else fn:true() else ()");
            if (value(w_subElement)) {
                w_diffFormat.fontUnderline = new bool;
                *w_diffFormat.fontUnderline = value(w_subElement)->asBool();
            }


            w_diffFormat.patternStyle = nullptr;
            w_diffFormat.patternForegroundColor = nullptr;
            w_diffFormat.patternBackgroundColor = nullptr;
            w_subElement = xpath(k_node, "ssml:fill/ssml:patternFill");
            if (node(w_subElement)) {
                w_diffFormat.patternStyle = new Interface::patternStyle_t;

                w_subElement = xpath(node(w_subElement), "fn:data(@patternType)");
                if (value(w_subElement))
                    *w_diffFormat.patternStyle = k_patternStyles.at(toString(w_subElement));
                else
                    *w_diffFormat.patternStyle = Interface::psSolid;
            }
            w_subElement = xpath(k_node, "ssml:fill/ssml:patternFill/ssml:fgColor");
            if (node(w_subElement)) {
                w_diffFormat.patternForegroundColor = new Interface::color_t;
                *w_diffFormat.patternForegroundColor = color(w_subElement->node(), p_colorScheme, 0xFF000000);
            }
            w_subElement = xpath(k_node, "ssml:fill/ssml:patternFill/ssml:bgColor");
            if (node(w_subElement)) {
                w_diffFormat.patternBackgroundColor = new Interface::color_t;
                *w_diffFormat.patternBackgroundColor = color(w_subElement->node(), p_colorScheme, 0xFFFFFFFF);
            }


            for (unsigned char i = 0; i < 6; ++i) {
                w_diffFormat.borderVisible[i] = nullptr;
                w_diffFormat.borderStyle[i] = nullptr;
                w_diffFormat.borderColor[i] = nullptr;

                w_subElement = nullptr;
                switch ( static_cast<Interface::border_t>(i) ) {
                case Interface::bLeft:
                    w_subElement = xpath(k_node, "ssml:border/ssml:left");
                    break;
                case Interface::bRight:
                    w_subElement = xpath(k_node, "ssml:border/ssml:right");
                    break;
                case Interface::bTop:
                    w_subElement = xpath(k_node, "ssml:border/ssml:top");
                    break;
                case Interface::bBottom:
                    w_subElement = xpath(k_node, "ssml:border/ssml:bottom");
                    break;
                case Interface::bDiagonalDown:
                case Interface::bDiagonalUp:
                    break;
                }

                if (node(w_subElement))
                    getDiffBorder(node(w_subElement), k_borderStyles, p_colorScheme, w_diffFormat.borderVisible[i], w_diffFormat.borderStyle[i], w_diffFormat.borderColor[i]);
            }

            w_styles->diffFormats.push_back(w_diffFormat);
        }
    }

    return w_styles;
}

void Reader::freeStyles(const Reader::styles_t& p_styles)
{
    for (diffCellFormats_t::const_iterator w_it = p_styles->diffFormats.begin(); w_it != p_styles->diffFormats.end(); ++w_it) {
        delete w_it->numFmt;
        delete w_it->fontColor;
        delete w_it->fontBold;
        delete w_it->fontItalic;
        delete w_it->fontUnderline;
        delete w_it->patternStyle;
        delete w_it->patternForegroundColor;
        delete w_it->patternBackgroundColor;
        for (unsigned int i = 0; i < 6; ++i) {
            delete w_it->borderVisible[i];
            delete w_it->borderStyle[i];
            delete w_it->borderColor[i];
        }
    }
}

Reader::images_t Reader::images(Zip::ZipArchiveReader& p_zipReader, const Interface::Write::Worksheet* p_worksheet, const std::string& p_filename)
{
    Reader::images_t w_result;

    const std::string k_path = path(p_filename);
    const std::string k_file = name(p_filename);
    const std::string k_rels = k_path +"_rels/"+ k_file +".rels";

    Zip::ZipArchiveReader::fileList_t w_list = p_zipReader.fileList();
    const Zip::ZipArchiveReader::fileList_t::const_iterator k_index = std::find(w_list.begin(), w_list.end(), k_rels);

    if (k_index != w_list.end()) {
        const relations_t k_sheetRelations = rels(p_zipReader, k_rels);

        relationsMap_t::const_iterator w_it = k_sheetRelations->begin();
        while ((w_it != k_sheetRelations->end()) && (w_it->second.type != "http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing"))
            ++w_it;

        if (w_it != k_sheetRelations->end()) {
            w_result.id = w_it->second.id;

            const std::string k_drawingPath = path(w_it->second.target);
            const std::string k_drawingFile = name(w_it->second.target);

            const std::string k_drawingAbsName = absoluteName(k_path + k_drawingPath, k_drawingFile);

            XML::DOM::Document w_xml;
            loadXMLDocument(p_zipReader, k_drawingAbsName, w_xml);

            xPathElement_t w_elements = xpath(&w_xml, "dmls:wsDr/dmls:twoCellAnchor");
            for (int i = 1; i <= w_elements->size(); ++i) {     // w_elements->size() devrait être de type size_t
                XML::DOM::Node const * const k_node = w_elements->at(i)->node();

                Coordinates::CellPoint w_topLeft(
                    p_worksheet->proxy(),
                    toInteger( xpath(k_node, "fn:data(dmls:from/dmls:col/text())") ),
                    toInteger( xpath(k_node, "fn:data(dmls:from/dmls:row/text())") ),
                    toInteger( xpath(k_node, "fn:data(dmls:from/dmls:colOff/text())") ),
                    toInteger( xpath(k_node, "fn:data(dmls:from/dmls:rowOff/text())") )
                    );

                // bidouille ........................................................
                Coordinates::CellPoint w_rightBottom(nullptr, 0, 0, 0, 0 );
                {
                    std::vector<XML::DOM::Node*> w_to;
                    w_elements->at(i)->node()->getElementsByTagNameNS("http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing", "to", w_to);
                    if (w_to.size() > 0) {
                        w_rightBottom = Coordinates::CellPoint(
                            p_worksheet->proxy(),
                            toInteger( xpath(w_to[0], "fn:data(dmls:col/text())") ),
                            toInteger( xpath(w_to[0], "fn:data(dmls:row/text())") ),
                            toInteger( xpath(w_to[0], "fn:data(dmls:colOff/text())") ),
                            toInteger( xpath(w_to[0], "fn:data(dmls:rowOff/text())") )
                            );
                    }
                }
//                 Coordinates::CellPoint w_rightBottom(
//                     p_worksheet->proxy(),
//                     toInteger( xpath(k_node, "fn:data(dmls:to/dmls:col/text())") ),
//                     toInteger( xpath(k_node, "fn:data(dmls:to/dmls:row/text())") ),
//                     toInteger( xpath(k_node, "fn:data(dmls:to/dmls:colOff/text())") ),
//                     toInteger( xpath(k_node, "fn:data(dmls:to/dmls:rowOff/text())") )
//                     );
                // ..................................................................

                Reader::imageStruct_t w_imageStruct = { w_topLeft, w_rightBottom, nullptr, Interface::ipMoveAndResizeWithCells, "" };

                xPathElement_t w_cropElement = xpath(k_node, "dmls:pic/dmls:blipFill/dml:srcRect");
                if (node(w_cropElement)) {
                    rectangle_t w_rectangle;
                    w_rectangle.left = toInteger( xpath(k_node, "fn:data(dmls:pic/dmls:blipFill/dml:srcRect/@l)") );
                    w_rectangle.top = toInteger( xpath(k_node, "fn:data(dmls:pic/dmls:blipFill/dml:srcRect/@t)") );
                    w_rectangle.right = toInteger( xpath(k_node, "fn:data(dmls:pic/dmls:blipFill/dml:srcRect/@r)") );
                    w_rectangle.bottom = toInteger( xpath(k_node, "fn:data(dmls:pic/dmls:blipFill/dml:srcRect/@b)") );

                    w_imageStruct.blipFillSrcRect = std::shared_ptr<rectangle_t>(new rectangle_t(w_rectangle));
                }

                xPathElement_t w_editAs = xpath(k_node, "fn:data(@editAs)");
                if (toString(w_editAs) == "oneCell")
                    w_imageStruct.property = Interface::ipMoveWithCells;
                else if (toString(w_editAs) == "absolute")
                    w_imageStruct.property = Interface::ipStatic;

                const std::string k_imageId = toString( xpath(k_node, "fn:data(dmls:pic/dmls:blipFill/dml:blip/@odr:embed)") );

                const std::string k_drawingRelsAbsName = absoluteName(k_path + k_drawingPath, "_rels/"+ k_drawingFile +".rels");
                const Reader::relations_t k_drawingRelations = rels(p_zipReader, k_drawingRelsAbsName);
                relationsMap_t::const_iterator w_it = k_drawingRelations->begin();
                while ((w_it != k_drawingRelations->end()) && (w_it->second.id != k_imageId))
                    ++w_it;
                if (w_it != k_drawingRelations->end())
                    w_imageStruct.filename = absoluteName(k_path + k_drawingPath, w_it->second.target);

                w_result.images.push_back(w_imageStruct);
            }
        }
    }

    return w_result;
}

void Reader::addImages(Zip::ZipArchiveReader& p_zipReader, Interface::Write::Worksheet* o_worksheet, const images_t& p_images)
{
    for (std::vector<imageStruct_t>::const_iterator w_it = p_images.images.begin(); w_it != p_images.images.end(); ++w_it) {
        Interface::Write::Image* w_image = o_worksheet->createImage();
        try {

            w_image->setTopLeft( w_it->topLeft );
            w_image->setRightBottom( &w_it->rightBottom );

            w_image->setProperty( w_it->property );

            Zip::byte_t* w_buffer = nullptr;
            unsigned int w_size = 0;
            p_zipReader.extractToStream(w_it->filename, w_buffer, w_size);
            w_image->setImage(reinterpret_cast<unsigned char*>(w_buffer), w_size, false);

            if ((w_buffer) && (w_size) && (w_it->blipFillSrcRect)) {
                Interface::imageType_t w_type;
                unsigned int w_width;
                unsigned int w_height;
                if (Interface::getImageProperties(reinterpret_cast<const unsigned char*>(w_buffer), w_size, w_type, w_width, w_height)) {
                    Interface::pixelRectangle_t w_pxRect;
                    w_pxRect.left = w_it->blipFillSrcRect->left * w_width / 100000;
                    w_pxRect.top = w_it->blipFillSrcRect->top * w_height / 100000;
                    w_pxRect.width = w_width - (w_it->blipFillSrcRect->right * w_width / 100000) - w_pxRect.left;
                    w_pxRect.height = w_height - (w_it->blipFillSrcRect->bottom * w_height / 100000) - w_pxRect.top;

                    w_image->setCropRectangle(&w_pxRect);
                }
            }

            o_worksheet->addImage(w_image);

        } catch (...) {
            delete w_image;
            throw;
        }
        delete w_image;
    }
}

void Reader::hyperlinks(Zip::ZipArchiveReader& p_zipReader, const XML::DOM::Node* p_node, Interface::Write::Worksheet* p_worksheet, const std::string& p_filename, Reader::hyperlinks_t& o_hyperlinks)
{
    if (p_node == nullptr)
        return;

    relations_t w_sheetRelations = nullptr;

    const std::string k_path = path(p_filename);
    const std::string k_file = name(p_filename);
    const std::string k_rels = k_path +"_rels/"+ k_file +".rels";

    Zip::ZipArchiveReader::fileList_t w_list = p_zipReader.fileList();
    const Zip::ZipArchiveReader::fileList_t::const_iterator k_index = std::find(w_list.begin(), w_list.end(), k_rels);

    if (k_index != w_list.end())
        w_sheetRelations = rels(p_zipReader, k_rels);

    xPathElement_t w_elements = xpath(p_node, "ssml:hyperlink");
    for (int i = 1; i <= w_elements->size(); ++i) {     // w_elements->size() devrait être de type size_t
        XML::DOM::Node const * const k_node = w_elements->at(i)->node();

        coordinatesCellRange_t w_ref = parseCellRangeCoordinates(toString(xpath(k_node, "fn:data(@ref)")), nullptr);
        if (w_ref) {
            hyperlinkStruct_t w_link = {
                p_worksheet,
                *w_ref,
                toString(xpath(k_node, "fn:data(@display)")),
                toString(xpath(k_node, "fn:data(@tooltip)")),
                toString(xpath(k_node, "fn:data(@location)")),
                ""
            };

            const std::string k_id = toString(xpath(k_node, "fn:data(@odr:id)"));
            if ((w_sheetRelations.get()) && (k_id != ""))
                w_link.target = w_sheetRelations->at(k_id).target;

            o_hyperlinks.push_back(w_link);
        }
    }
}

Reader::comments_t Reader::comments(Zip::ZipArchiveReader& p_zipReader, const Interface::Write::Worksheet* p_worksheet, const std::string& p_filename, const colorScheme_t& p_colorScheme)
{
    Reader::comments_t w_result;
    
    const std::string k_path = path(p_filename);
    const std::string k_file = name(p_filename);
    const std::string k_rels = k_path +"_rels/"+ k_file +".rels";

    Zip::ZipArchiveReader::fileList_t w_list = p_zipReader.fileList();
    const Zip::ZipArchiveReader::fileList_t::const_iterator k_index = std::find(w_list.begin(), w_list.end(), k_rels);

    if (k_index != w_list.end()) {
        const relations_t k_sheetRelations = rels(p_zipReader, k_rels);

        // commentsX.xml
        relationsMap_t::const_iterator w_it = k_sheetRelations->begin();
        while ((w_it != k_sheetRelations->end()) && (w_it->second.type != "http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments"))
            ++w_it;

        if (w_it != k_sheetRelations->end()) {
            const std::string k_commentsPath = path(w_it->second.target);
            const std::string k_commentsFile = name(w_it->second.target);
            const std::string k_commentsAbsName = absoluteName(k_path + k_commentsPath, k_commentsFile);

            XML::DOM::Document w_xml;
            loadXMLDocument(p_zipReader, k_commentsAbsName, w_xml);
            
            // authors
            std::vector<Interface::utf8String_t> w_authors;

            xPathElement_t w_elements = xpath(&w_xml, "fn:data(ssml:comments/ssml:authors/ssml:author)");
            for (int i = 1; i <= w_elements->size(); ++i)       // w_elements->size() devrait être de type size_t
                w_authors.push_back( toString(w_elements->at(i)) );

            // comments
            w_elements = xpath(&w_xml, "ssml:comments/ssml:commentList/ssml:comment");
            for (int i = 1; i <= w_elements->size(); ++i) {     // w_elements->size() devrait être de type size_t
                XML::DOM::Node const * const k_node = w_elements->at(i)->node();

                Reader::comment_t w_comment = { 
                    "", 
                    "", 
                    {}, 
                    "",
                    Interface::haLeft,
                    Coordinates::CellPoint(nullptr, 0, 0, 0, 0), 
                    Coordinates::CellPoint(nullptr, 0, 0, 0, 0), 
                    false,
                    0xFFFFFFE1,
                    Interface::vHidden,
                    Interface::cpStatic
                };

                w_comment.reference = toString( xpath(k_node, "fn:data(@ref)") );
                w_comment.author = w_authors.at(toInteger(xpath(k_node, "fn:data(@authorId)"), 0));
				w_comment.runs = richText(xpath(k_node, "ssml:text")->node(), p_colorScheme);

                w_result.emplace(w_comment.reference, w_comment);
            }
        }

        // vmlDrawingX.vml
        w_it = k_sheetRelations->begin();
        while ((w_it != k_sheetRelations->end()) && (w_it->second.type != "http://schemas.openxmlformats.org/officeDocument/2006/relationships/vmlDrawing"))
            ++w_it;

        if (w_it != k_sheetRelations->end()) {
            const std::string k_commentsPath = path(w_it->second.target);
            const std::string k_commentsFile = name(w_it->second.target);
            const std::string k_commentsAbsName = absoluteName(k_path + k_commentsPath, k_commentsFile);

            XML::DOM::Document w_xml;
            loadXMLDocument(p_zipReader, k_commentsAbsName, w_xml);

            xPathElement_t w_elements = xpath(&w_xml, "xml/vml:shape");
            for (int i = 1; i <= w_elements->size(); ++i) {     // w_elements->size() devrait être de type size_t
                XML::DOM::Node const * const k_node = w_elements->at(i)->node();

                const unsigned int k_row = toInteger(xpath(k_node, "fn:data(excel:ClientData/excel:Row)"), 0);
                const unsigned int k_column = toInteger(xpath(k_node, "fn:data(excel:ClientData/excel:Column)"), 0);
                const std::string k_ref = Coordinates::Cell(nullptr, k_column, k_row).name(nullptr);

                Reader::comments_t::iterator w_index = w_result.find(k_ref);
                if (w_index != w_result.end()) {
                    (*w_index).second.href = toString(xpath(k_node, "fn:data(@href)"));
                    if (k_node->attributeFromLocalName("fillcolor")) {
                        try {
                            (*w_index).second.color = 0xFF000000 + std::stoul(std::string(k_node->getAttribute("fillcolor")).substr(1), nullptr, 16);
                        } catch (...) {
                            (*w_index).second.color = 0xFFFFFFE1;
                        }
                    }

                    const std::string k_textboxStyle = toString(xpath(k_node, "fn:data(vml:textbox/@style)"));
                    (*w_index).second.autoSize = (k_textboxStyle.find("mso-fit-shape-to-text:t") != std::string::npos);

// PB AVEC LA REQUETE XPATH -------------------------------------------------------------------------------------------
//                    const std::string k_textboxDivStyle = toString(xpath(k_node, "fn:data(vml:textbox/div/@style)"));
                    const XML::DOM::Node* k_textbox = k_node->elementFromBoth("urn:schemas-microsoft-com:vml", "textbox");
                    const XML::DOM::Node* k_div = (k_textbox ? k_textbox->elementFromBoth("", "div") : nullptr);
                    const std::string k_textboxDivStyle = (k_div ? k_div->getAttribute("style") : "");
// --------------------------------------------------------------------------------------------------------------------                    
                    if (k_textboxDivStyle.find("text-align:center") != std::string::npos)
                        (*w_index).second.alignment = Interface::haCenter;
                    if (k_textboxDivStyle.find("text-align:right") != std::string::npos)
                        (*w_index).second.alignment = Interface::haRight;

                    const bool k_moveWithCells = xpath(k_node, "excel:ClientData/excel:MoveWithCells")->isEmpty();  // fonctionne à l'envers
                    const bool k_sizeWithCells = xpath(k_node, "excel:ClientData/excel:SizeWithCells")->isEmpty();  // fonctionne à l'envers
                    (*w_index).second.property = ((k_moveWithCells && k_sizeWithCells) ? Interface::cpMoveAndResizeWithCells : ((k_moveWithCells) ? Interface::cpMoveWithCells : Interface::cpStatic));

                    std::vector<unsigned int> w_coordinates;
                    std::string w_anchor = toString(xpath(k_node, "fn:data(excel:ClientData/excel:Anchor)")) + ",";
                    size_t w_pos = 0;
                    while ((w_pos = w_anchor.find(",")) != std::string::npos) {
                        std::string w_token = w_anchor.substr(0, w_pos);
                        w_coordinates.push_back( std::atoi(w_token.c_str()) );
                        w_anchor.erase(0, w_pos + 1);
                    }
                    if (w_coordinates.size() >= 4)
                        (*w_index).second.topLeft = Coordinates::CellPoint(nullptr, w_coordinates.at(0), w_coordinates.at(2), w_coordinates.at(1) * 10000, w_coordinates.at(3) * 10000);
                    if (w_coordinates.size() >= 8)
                        (*w_index).second.rightBottom = Coordinates::CellPoint(nullptr, w_coordinates.at(4), w_coordinates.at(6), w_coordinates.at(5) * 10000, w_coordinates.at(7) * 10000);

                    (*w_index).second.visibility = ((xpath(k_node, "excel:ClientData/excel:Visible")->isEmpty()) ? Interface::vHidden : Interface::vVisible);
                }
            }
        }
    }

    return w_result;
}

void Reader::addComments(Interface::Write::Worksheet* o_worksheet, const Reader::comments_t& p_comments)
{
    for (comments_t::const_iterator w_it = p_comments.begin(); w_it != p_comments.end(); ++w_it) {
        const comment_t k_comment = (*w_it).second;
        
        Interface::Write::Comment* w_writeComment = o_worksheet->createComment();
        try {
            coordinatesCell_t w_cell = parseCellCoordinates(k_comment.reference, nullptr);
            if (w_cell) {
                w_writeComment->setReference(*(w_cell.get()));
                w_writeComment->setAuthor(k_comment.author);
                
				for (unsigned int i = 0; i != k_comment.runs->size(); ++i) {
					const run_t k_run = k_comment.runs->at(i);
					                    
					Interface::font_t w_font = {
						k_run.font.name,
					    k_run.font.size,
					    k_run.font.color,
					    k_run.font.bold,
					    k_run.font.italic,
					    k_run.font.underline
					};
					w_writeComment->addRun(w_font, k_run.text);
				}

                w_writeComment->setHyperlink(k_comment.href);
                w_writeComment->setAlignment(k_comment.alignment);
                w_writeComment->setTopLeft(k_comment.topLeft);
                w_writeComment->setRightBottom(k_comment.rightBottom);
                w_writeComment->setAutoSize(k_comment.autoSize);
                w_writeComment->setFillColor(k_comment.color);
                w_writeComment->setVisibility(k_comment.visibility);
                w_writeComment->setProperty(k_comment.property);

                o_worksheet->addComment(w_writeComment);
            }
        } catch (...) {
            delete w_writeComment;
            throw;
        }
        delete w_writeComment;
    }
}

Reader::workbook_t Reader::workbook(Zip::ZipArchiveReader& p_zipReader, const std::string& p_filename)
{
    workbook_t w_workbook = workbook_t(new workbookStruct_t);

    if (p_filename != "") {
        XML::DOM::Document w_xml;
        loadXMLDocument(p_zipReader, p_filename, w_xml);

        xPathElement_t w_elements = xpath(&w_xml, "ssml:workbook/ssml:sheets/ssml:sheet");
        for (int i = 1; i <= w_elements->size(); ++i) {     // w_elements->size() devrait être de type size_t
            XML::DOM::Node const * const k_node = w_elements->at(i)->node();

            sheet_t w_sheet;
            w_sheet.name = k_node->getAttribute("name");
            w_sheet.id = k_node->getAttributeNS("http://schemas.openxmlformats.org/officeDocument/2006/relationships", "id");
            w_sheet.hidden = (k_node->getAttribute("state") == "hidden");

            if (w_sheet.name != "")
                w_workbook->sheets.push_back(w_sheet);
        }

        w_elements = xpath(&w_xml, "ssml:workbook/ssml:definedNames/ssml:definedName");
        for (int i = 1; i <= w_elements->size(); ++i) {     // w_elements->size() devrait être de type size_t
            XML::DOM::Node const * const k_node = w_elements->at(i)->node();

            if (k_node->hasAttribute("name")) {
                bool w_processed = false;

                const std::string k_name = k_node->getAttribute("name");
                if (k_node->hasAttribute("localSheetId")) {
                    const unsigned int k_localSheetId = std::stoi(k_node->getAttribute("localSheetId"), nullptr, 10);
                    if  (   (k_localSheetId < w_workbook->sheets.size())
                        &&  (   (k_name == "_xlnm.Print_Area")
                            ||  (k_name == "_xlnm.Print_Titles")
                            )
                        ) {
                        w_processed = true;
                        if (k_localSheetId < w_workbook->sheets.size()) {
                            const std::string k_sheetName = w_workbook->sheets[k_localSheetId].name;
                            if (k_name == "_xlnm.Print_Area")
                                w_workbook->printAreas[k_sheetName] = k_node->textContent();
                            else
                                w_workbook->printTitles[k_sheetName] = k_node->textContent();
                        }
                    }
                }

                if (!w_processed)
                    w_workbook->definedNames[k_name] = k_node->textContent();
            }
        }
    }

    return w_workbook;
}

Interface::Write::CellFormat* Reader::createCellFormat(const Interface::Write::Worksheet* p_worksheet, const cellFormat_t& p_format)
{
    Interface::Write::CellFormat* w_cellFormat = p_worksheet->createFormat();
    try {
        w_cellFormat->setNumberFormat(p_format.numFmt);

        w_cellFormat->setFontName(p_format.font.name);
        w_cellFormat->setFontSize(p_format.font.size);
        w_cellFormat->setFontColor(p_format.font.color);
        w_cellFormat->setFontStyle(p_format.font.bold, p_format.font.italic, p_format.font.underline);

        w_cellFormat->setPatternStyle( p_format.pattern.style );
        w_cellFormat->setForegroundColor( p_format.pattern.fgColor );
        w_cellFormat->setBackgroundColor( p_format.pattern.bgColor );

        for (unsigned char i = 0; i < 6; ++i) {
            w_cellFormat->setBorderVisible( static_cast<Interface::border_t>(i), p_format.borders[i].color != 0x00000000 );
            w_cellFormat->setBorderStyle( static_cast<Interface::border_t>(i), p_format.borders[i].style );
            w_cellFormat->setBorderColor( static_cast<Interface::border_t>(i), p_format.borders[i].color );
        }

        w_cellFormat->setHorizontalAlignment( p_format.horizontalAlignment );
        w_cellFormat->setVerticalAlignment( p_format.verticalAlignment );
        w_cellFormat->setTextIndent( p_format.indent );

        w_cellFormat->setTextRotation( p_format.rotation );

        w_cellFormat->setWrapText( p_format.wrap );

    } catch (...) {
        delete w_cellFormat;
        throw;
    }

    return w_cellFormat;
}

Interface::Write::DifferentialCellFormat* Reader::createDifferentialFormat(const Interface::Write::Worksheet* p_worksheet, const diffCellFormat_t& p_diffFormat)
{
    Interface::Write::DifferentialCellFormat* w_diffCellFormat = p_worksheet->createDifferentialCellFormat();
    try {
        if (p_diffFormat.numFmt)
            w_diffCellFormat->setNumberFormat(*p_diffFormat.numFmt);

        if (p_diffFormat.fontColor)
            w_diffCellFormat->setFontColor(*p_diffFormat.fontColor);
        if (p_diffFormat.fontBold)
            w_diffCellFormat->setFontBold(*p_diffFormat.fontBold);
        if (p_diffFormat.fontItalic)
            w_diffCellFormat->setFontItalic(*p_diffFormat.fontItalic);
        if (p_diffFormat.fontUnderline)
            w_diffCellFormat->setFontUnderline(*p_diffFormat.fontUnderline);

        if (p_diffFormat.patternStyle)
            w_diffCellFormat->setPatternStyle(*p_diffFormat.patternStyle);
        if (p_diffFormat.patternForegroundColor)
            w_diffCellFormat->setForegroundColor(*p_diffFormat.patternForegroundColor);
        if (p_diffFormat.patternBackgroundColor)
            w_diffCellFormat->setBackgroundColor(*p_diffFormat.patternBackgroundColor);

        for (unsigned char i = 0; i < 6; ++i) {
            if (p_diffFormat.borderVisible[i])
                w_diffCellFormat->setBorderVisible(static_cast<Interface::border_t>(i), *p_diffFormat.borderVisible[i]);
            if (p_diffFormat.borderStyle[i])
                w_diffCellFormat->setBorderStyle(static_cast<Interface::border_t>(i), *p_diffFormat.borderStyle[i]);
            if (p_diffFormat.borderColor[i])
                w_diffCellFormat->setBorderColor(static_cast<Interface::border_t>(i), *p_diffFormat.borderColor[i]);
        }

    } catch (...) {
        delete w_diffCellFormat;
        throw;
    }

    return w_diffCellFormat;
}

void Reader::columns(XML::DOM::Document& p_xml, const styles_t& p_styles, Interface::Write::Worksheet* o_worksheet)
{
    xPathElement_t w_elements = xpath(&p_xml, "fn:data(ssml:worksheet/ssml:sheetPr/ssml:outlinePr/@summaryRight)");
    const bool k_summaryRight = ((!w_elements->value()) || (toString(w_elements) != "0"));
    o_worksheet->setOutlineSummaryRight(k_summaryRight);

    std::vector<unsigned int> w_collapsedColumns;

    w_elements = xpath(&p_xml, "ssml:worksheet/ssml:cols/ssml:col");
    for (int i = 1; i <= w_elements->size(); ++i) {     // w_elements->size() devrait être de type size_t
        XML::DOM::Node const * const k_node = w_elements->at(i)->node();

        const Interface::Write::CellFormat* w_format = nullptr;
        const double* w_width = nullptr;
        try {
            const bool k_visible = (k_node->hasAttribute("hidden") ? k_node->getAttribute("hidden") != "1" : true);

            const bool k_customWidth = k_node->hasAttribute("width");
            if (k_customWidth)
                w_width = new double(std::stod(k_node->getAttribute("width"), nullptr));

            const unsigned short k_outlineLevel = (k_node->hasAttribute("outlineLevel") ? std::stoi(k_node->getAttribute("outlineLevel"), nullptr, 10) : 0);
            const bool k_collapsed = (k_node->hasAttribute("collapsed") ? (k_node->getAttribute("collapsed") == "1") : false);

            const bool k_customStyle = k_node->hasAttribute("style");
            const unsigned int k_styleId = (k_customStyle ? std::stoi(k_node->getAttribute("style"), nullptr, 10) : 0);
            if (k_customStyle && (k_styleId < p_styles->formats.size()))
                w_format = createCellFormat(o_worksheet, p_styles->formats[k_styleId]);

            const unsigned int k_min = std::stoi(k_node->getAttribute("min"), nullptr, 10) - 1;
            const unsigned int k_max = std::stoi(k_node->getAttribute("max"), nullptr, 10) - 1;
            for (unsigned int w_iColRow = k_min; w_iColRow <= k_max; ++w_iColRow) {
                o_worksheet->setColumnVisible(w_iColRow, k_visible);
                o_worksheet->setColumnWidth(w_iColRow, w_width);
                o_worksheet->setColumnOutlineLevel(w_iColRow, k_outlineLevel);
                o_worksheet->setColumnFormat(w_iColRow, w_format);

                if (k_collapsed)
                    w_collapsedColumns.push_back(w_iColRow);
            }

            delete w_format;
            delete w_width;
        } catch (...) {
            delete w_format;
            delete w_width;
            throw;
        }
    }

    for (unsigned int i = 0; i < w_collapsedColumns.size(); ++i)
        o_worksheet->setColumnChildrenCollapsed(w_collapsedColumns[i], true);
}

void Reader::rows(XML::DOM::Document& p_xml, const Reader::styles_t& p_styles, Interface::Write::Worksheet* o_worksheet)
{
    xPathElement_t w_elements = xpath(&p_xml, "fn:data(ssml:worksheet/ssml:sheetPr/ssml:outlinePr/@summaryBelow)");
    const bool k_summaryBelow = ((!w_elements->value()) || (toString(w_elements) != "0"));
    o_worksheet->setOutlineSummaryBelow(k_summaryBelow);

    unsigned int w_currentRowIndex = 0;
    std::vector<unsigned int> w_collapsedRows;

    w_elements = xpath(&p_xml, "ssml:worksheet/ssml:sheetData/ssml:row");
    for (int i = 1; i <= w_elements->size(); ++i) {     // w_elements->size() devrait être de type size_t
        XML::DOM::Node const * const k_node = w_elements->at(i)->node();

        unsigned int w_index = w_currentRowIndex++;
        const std::string k_rowStringIndex = k_node->getAttribute("r");
        if (!k_rowStringIndex.empty()) {
            w_index = std::stoi(k_rowStringIndex, nullptr, 10) - 1;
            w_currentRowIndex = w_index;
        }
        
        if (k_node->hasAttribute("hidden"))
            o_worksheet->setRowVisible(w_index, k_node->getAttribute("hidden") != "1");
        if ((k_node->getAttribute("customHeight") == "1") && (k_node->hasAttribute("ht"))) {
            const double k_size = std::stod(k_node->getAttribute("ht"), nullptr);
            o_worksheet->setRowHeight(w_index, &k_size);
        }
        if (k_node->hasAttribute("outlineLevel")) {
            const unsigned int k_outlineLevel = std::stoi(k_node->getAttribute("outlineLevel"), nullptr, 10);
            o_worksheet->setRowOutlineLevel(w_index, k_outlineLevel);
        }
        if (k_node->hasAttribute("collapsed") && (k_node->getAttribute("collapsed") == "1"))
            w_collapsedRows.push_back(w_index);
        if ((k_node->getAttribute("customFormat") == "1") && (k_node->hasAttribute("s"))) {
            const unsigned int k_styleId = std::stoi(k_node->getAttribute("s"), nullptr, 10);
            if (k_styleId < p_styles->formats.size()) {
                Interface::Write::CellFormat const * const k_format = createCellFormat(o_worksheet, p_styles->formats[k_styleId]);
                try {
                    o_worksheet->setRowFormat(w_index, k_format);
                    delete k_format;
                } catch (...) {
                    delete k_format;
                    throw;
                }
            }
        }
    }

    for (unsigned int i = 0; i < w_collapsedRows.size(); ++i)
        o_worksheet->setRowChildrenCollapsed(w_collapsedRows[i], true);
}

void Reader::headerFooterString(const std::string& p_string, std::string& o_left, std::string& o_center, std::string& o_right)
{
    o_left = "";
    o_center = "";
    o_right = "";

    bool w_amp = false;
    std::string* w_current = nullptr;
    for (std::string::const_iterator w_it = p_string.begin(); w_it != p_string.end(); ++w_it) {
        switch (*w_it) {
        case '&':
            if ((w_amp) && (w_current))
                *w_current += "&&";
            w_amp = !w_amp;
            break;
        case 'L':
        case 'C':
        case 'R':
            if (w_amp) {
                if (*w_it == 'L')
                    w_current = &o_left;
                else if (*w_it == 'C')
                    w_current = &o_center;
                else if (*w_it == 'R')
                    w_current = &o_right;
            } else if (w_current)
                *w_current += *w_it;
            w_amp = false;
            break;
        default:
            if (w_current) {
                if (w_amp)
                    *w_current += "&";
                *w_current += *w_it;
            }
            w_amp = false;
        }
    }
}

void Reader::headerFooter(XML::DOM::Document& p_xml, Interface::Write::PageSetting* o_pageSetting)
{
    xPathElement_t w_element = xpath(&p_xml, "ssml:worksheet/ssml:headerFooter");
    if (node(w_element)) {
        Interface::Write::PageHeaderFooter* w_pageHeaderFooter = o_pageSetting->createPageHeaderFooter();
        try {
            if (node(xpath(node(w_element), "oddHeader"))) {
                std::string w_left = "";
                std::string w_center = "";
                std::string w_right = "";
                std::string w_header = toString(xpath(node(w_element), "fn:data(oddHeader/text())"));
                headerFooterString(w_header, w_left, w_center, w_right);
                w_pageHeaderFooter->setHeader(w_left, w_center, w_right);
            }

            if (node(xpath(node(w_element), "oddFooter"))) {
                std::string w_left = "";
                std::string w_center = "";
                std::string w_right = "";
                std::string w_footer = toString(xpath(node(w_element), "fn:data(oddFooter/text())"));
                headerFooterString(w_footer, w_left, w_center, w_right);
                w_pageHeaderFooter->setFooter(w_left, w_center, w_right);
            }

            if (node(xpath(node(w_element), "evenHeader"))) {
                std::string w_left = "";
                std::string w_center = "";
                std::string w_right = "";
                std::string w_header = toString(xpath(node(w_element), "fn:data(evenHeader/text())"));
                headerFooterString(w_header, w_left, w_center, w_right);
                w_pageHeaderFooter->setEvenHeader(w_left, w_center, w_right);
            }

            if (node(xpath(node(w_element), "evenFooter"))) {
                std::string w_left = "";
                std::string w_center = "";
                std::string w_right = "";
                std::string w_footer = toString(xpath(node(w_element), "fn:data(evenFooter/text())"));
                headerFooterString(w_footer, w_left, w_center, w_right);
                w_pageHeaderFooter->setEvenFooter(w_left, w_center, w_right);
            }

            if (node(xpath(node(w_element), "firstHeader"))) {
                std::string w_left = "";
                std::string w_center = "";
                std::string w_right = "";
                std::string w_header = toString(xpath(node(w_element), "fn:data(firstHeader/text())"));
                headerFooterString(w_header, w_left, w_center, w_right);
                w_pageHeaderFooter->setFirstHeader(w_left, w_center, w_right);
            }

            if (node(xpath(node(w_element), "firstFooter"))) {
                std::string w_left = "";
                std::string w_center = "";
                std::string w_right = "";
                std::string w_footer = toString(xpath(node(w_element), "fn:data(firstFooter/text())"));
                headerFooterString(w_footer, w_left, w_center, w_right);
                w_pageHeaderFooter->setFirstFooter(w_left, w_center, w_right);
            }

            o_pageSetting->setPageHeaderFooter(*w_pageHeaderFooter);
            delete w_pageHeaderFooter;
        } catch (...) {
            delete w_pageHeaderFooter;
            throw;
        }
    }
}

void Reader::sheet(Zip::ZipArchiveReader& p_zipReader, const std::string& p_filename, const styles_t& p_styles, const sharedStrings_t& p_sharedStrings, const std::string& p_printArea, const std::string& p_printTitles, const images_t& p_images, const comments_t& p_comments, refListValidations_t& o_refListValidations, hyperlinks_t& o_hyperlinks, Interface::Write::Worksheet* o_worksheet)
{
    if (p_filename != "") {
        XML::DOM::Document w_xml;
        loadXMLDocument(p_zipReader, p_filename, w_xml);

        const std::unordered_map<std::string, Interface::cellError_t> k_errors = {
            {"#DIV/0!", Interface::ceDIV0},
            {"#NULL!",  Interface::ceNULL},
            {"#VALUE!", Interface::ceVALUE},
            {"#REF!",   Interface::ceREF},
            {"#NAME?",  Interface::ceNAME},
            {"#NUM!",   Interface::ceNUM},
            {"#N/A",    Interface::ceNA}
            };

        xPathElement_t w_element = xpath(&w_xml, "fn:data(ssml:worksheet/ssml:sheetViews/ssml:sheetView/@showFormulas)");
        if (value(w_element))
            o_worksheet->showFormulas( (toInteger(w_element) == 0) );

        w_element = xpath(&w_xml, "fn:data(ssml:worksheet/ssml:sheetViews/ssml:sheetView/@showGridLines)");
        if (value(w_element))
            o_worksheet->showGridLines( (toInteger(w_element) != 0) );

        w_element = xpath(&w_xml, "fn:data(ssml:worksheet/ssml:sheetViews/ssml:sheetView/@showRowColHeaders)");
        if (value(w_element))
            o_worksheet->showRowColHeaders( (toInteger(w_element) != 0) );

        w_element = xpath(&w_xml, "fn:data(ssml:worksheet/ssml:sheetViews/ssml:sheetView/@showZeros)");
        if (value(w_element))
            o_worksheet->showZeros( (toInteger(w_element) != 0) );

        w_element = xpath(&w_xml, "fn:data(ssml:worksheet/ssml:sheetViews/ssml:sheetView/ssml:pane/@xSplit)");
        if (value(w_element))
            o_worksheet->setXSplit( toInteger(w_element)-1 );

        w_element = xpath(&w_xml, "fn:data(ssml:worksheet/ssml:sheetViews/ssml:sheetView/ssml:pane/@ySplit)");
        if (value(w_element))
            o_worksheet->setYSplit( toInteger(w_element)-1 );

        std::string w_activePane = "";
        w_element = xpath(&w_xml, "fn:data(ssml:worksheet/ssml:sheetViews/ssml:sheetView/ssml:pane/@activePane)");
        if (value(w_element))
            w_activePane = "[@pane eq '"+ toString(w_element) +"']";

        w_element = xpath(&w_xml, "fn:data(ssml:worksheet/ssml:sheetViews/ssml:sheetView/ssml:selection"+ w_activePane +"/@sqref)");
        const coordinatesMultiCellRange_t k_parsedRange = parseMultiCellRangeCoordinates(toString(w_element), nullptr, ' ');
        if (k_parsedRange)
            o_worksheet->setSelection(*k_parsedRange);

        w_element = xpath(&w_xml, "fn:data(ssml:worksheet/ssml:sheetViews/ssml:sheetView/ssml:selection"+ w_activePane +"/@activeCell)");
        const coordinatesCell_t k_parsedCell = parseCellCoordinates(toString(w_element), nullptr);
        if (k_parsedCell)
            o_worksheet->setActiveCell(*k_parsedCell);

        w_element = xpath(&w_xml, "fn:data(ssml:worksheet/ssml:sheetFormatPr/@defaultColWidth)");
        if (value(w_element))
            o_worksheet->setDefaultColumnWidth( toDouble(w_element) );

        w_element = xpath(&w_xml, "fn:data(ssml:worksheet/ssml:sheetFormatPr/@defaultRowHeight)");
        if (value(w_element))
            o_worksheet->setDefaultRowHeight( toDouble(w_element) );

        columns(w_xml, p_styles, o_worksheet);
        rows(w_xml, p_styles, o_worksheet);

        unsigned int w_currentRowIndex = 0;
        xPathElement_t w_rowElement = xpath(&w_xml, "ssml:worksheet/ssml:sheetData/ssml:row");
        for (int i_row = 1; i_row <= w_rowElement->size(); ++i_row) {               // w_elements->size() devrait être de type size_t
            XML::DOM::Node const * const k_rowNode = w_rowElement->at(i_row)->node();

            unsigned int w_currentColumnIndex = 0;
            xPathElement_t w_columnElement = xpath(k_rowNode, "ssml:c");
            for (int i_col = 1; i_col <= w_columnElement->size(); ++i_col) {        // w_elements->size() devrait être de type size_t
                XML::DOM::Node const * const k_node = w_columnElement->at(i_col)->node();

                Coordinates::Cell w_cell(o_worksheet->proxy(), w_currentColumnIndex, w_currentRowIndex, false);
                const coordinatesCell_t k_parsedCell = parseCellCoordinates(k_node->getAttribute("r"), nullptr);
                if (k_parsedCell) {
                    w_cell = Coordinates::Cell(*k_parsedCell);
                    w_currentColumnIndex = w_cell.column();
                    w_currentRowIndex = w_cell.row();
                }

                if (k_node->hasAttribute("s")) {
                    const unsigned int k_styleId = std::stoi(k_node->getAttribute("s"), nullptr, 10);
                    if (k_styleId < p_styles->formats.size()) {
                        Interface::Write::CellFormat* w_format = createCellFormat(o_worksheet, p_styles->formats[k_styleId]);
                        try {
                            o_worksheet->setFormat(w_cell.column(), w_cell.row(), *w_format);

                            delete w_format;
                        } catch (...) {
                            delete w_format;
                            throw;
                        }
                    }
                }

                const std::string k_type = k_node->getAttribute("t");
                const Interface::utf8String_t k_strFormula = toString(xpath(k_node, "fn:data(ssml:f/text())"));

                xPathElement_t w_value = xpath(k_node, "fn:data(ssml:v/text())");
                if (value(w_value)) {
                    if (k_type == "") {
                        o_worksheet->setNumberValue(w_cell.column(), w_cell.row(), toDouble(w_value), k_strFormula);
                    } else if (k_type == "s") {
                        const unsigned int k_index = toInteger(w_value);
						
						Interface::Write::RichText* w_richtext = o_worksheet->createRichText();
						try {
							assignRichText(w_richtext, (*p_sharedStrings)[k_index]);
							o_worksheet->setRichTextValue(w_cell.column(), w_cell.row(), w_richtext, k_strFormula);

							delete w_richtext;
						} catch (...) {
							delete w_richtext;
							throw;
						}
					} else if (k_type == "str") {
                        o_worksheet->setStringValue(w_cell.column(), w_cell.row(), toString(w_value), k_strFormula);
                    } else if (k_type == "b") {
                        const bool k_bool = (toInteger(w_value) == 1);
                        o_worksheet->setBooleanValue(w_cell.column(), w_cell.row(), k_bool, k_strFormula);
                    } else if (k_type == "e") {
                        auto w_index = k_errors.find(toString(w_value));
                        if (w_index != k_errors.end())
                            o_worksheet->setErrorValue(w_cell.column(), w_cell.row(), w_index->second, k_strFormula);
                    }
                } else if (k_type == "inlineStr") {
// Problème avec les balises vides (ex: <c t="inlineStr" ...><is><t xml:space="preserve"/></is></c>)
//                    xPathElement_t w_inlineStrValue = xpath(k_node, "fn:data(ssml:is/ssml:t/text())");
//                    if (value(w_inlineStrValue))
//                        o_worksheet->setStringValue(w_cell.column(), w_cell.row(), toString(w_inlineStrValue), k_strFormula);
                    typedef std::vector<XML::DOM::Node*> nodes_t;
                    nodes_t w_nodes;

                    k_node->getElementsByTagNameNS("http://schemas.openxmlformats.org/spreadsheetml/2006/main", "is", w_nodes);
                    if ((w_nodes.size() == 1) && (w_nodes.at(0))) {
                        const XML::DOM::Node* k_isNode = w_nodes.at(0);

                        w_nodes.clear();
                        k_isNode->getElementsByTagNameNS("http://schemas.openxmlformats.org/spreadsheetml/2006/main", "t", w_nodes);
                        if ((w_nodes.size() == 1) && (w_nodes.at(0))) {
                            const XML::DOM::Node* k_tNode = w_nodes.at(0);
                            o_worksheet->setStringValue(w_cell.column(), w_cell.row(), k_tNode->textContent(), k_strFormula);
                        }
                    }
                }

                ++w_currentColumnIndex;
            }

            ++w_currentRowIndex;
        }

        w_element = xpath(&w_xml, "fn:data(ssml:worksheet/ssml:autoFilter/@ref)");
        if ((w_element->size() == 1) && (w_element->at(1))) {
            const coordinatesCellRange_t k_parsedRange = parseCellRangeCoordinates( toString(w_element->at(1)), nullptr );
            if (k_parsedRange) {
                Interface::Write::Filter* w_filter = o_worksheet->createFilter();
                try {
                    w_filter->setRangeReference(*k_parsedRange);                
                    o_worksheet->setFilter(*w_filter);
                } catch (...) {
                    delete w_filter;
                    throw;
                }
                delete w_filter;
            }
        }

        w_element = xpath(&w_xml, "fn:data(ssml:worksheet/ssml:mergeCells/ssml:mergeCell/@ref)");
        for (int i = 1; i <= w_element->size(); ++i) {      // w_elements->size() devrait être de type size_t
            if (w_element->at(i)->value()) {
                const coordinatesCellRange_t k_parsedRange = parseCellRangeCoordinates( toString(w_element->at(i)), nullptr );
                if (k_parsedRange)
                    o_worksheet->setMerge(*k_parsedRange);
            }
        }

        w_element = xpath(&w_xml, "ssml:worksheet/ssml:conditionalFormatting");
        for (int i = 1; i <= w_element->size(); ++i) {      // w_elements->size() devrait être de type size_t
            XML::DOM::Node const * const k_node = w_element->at(i)->node();

            xPathElement_t w_type = xpath(k_node, "fn:data(ssml:cfRule/@type)");
            if (toString(w_type) == "expression") {
                Interface::Write::ConditionalFormatting* w_conditionalFormatting = o_worksheet->createConditionalFormatting();
                try {
                    unsigned char w_check = 0;

                    const coordinatesMultiCellRange_t k_parsedRanges = parseMultiCellRangeCoordinates(toString(xpath(k_node, "fn:data(@sqref)")), nullptr, ' ');
                    if (k_parsedRanges) {
                        w_conditionalFormatting->setReference( *k_parsedRanges );
                        w_check |= 1;
                    }

                    xPathElement_t w_dxfId = xpath(k_node, "fn:data(ssml:cfRule/@dxfId)");
                    if (value(w_dxfId)) {
                        const diffCellFormat_t k_diffFormat = p_styles->diffFormats[ toInteger(w_dxfId) ];
                        Interface::Write::DifferentialCellFormat const * const k_differencialCellFormat = createDifferentialFormat(o_worksheet, k_diffFormat);
                        try {
                            w_conditionalFormatting->setFormat( *k_differencialCellFormat );
                            w_check |= 2;
                        } catch (...) {
                            delete k_differencialCellFormat;
                            throw;
                        }
                        delete k_differencialCellFormat;
                    }

                    xPathElement_t w_formula = xpath(k_node, "fn:data(ssml:cfRule/formula/text())");
                    if (value(w_formula)) {
                        w_conditionalFormatting->setFormula( toString(w_formula) );
                        w_check |= 4;
                    }

                    if (w_check == 7)
                        o_worksheet->addConditionalFormatting(*w_conditionalFormatting);

                } catch (...) {
                    delete w_conditionalFormatting;
                    throw;
                }
                delete w_conditionalFormatting;
            }

        }

        w_element = xpath(&w_xml, "ssml:worksheet/ssml:dataValidations/ssml:dataValidation | ssml:worksheet/ssml:extLst/ssml:ext/x14:dataValidations/x14:dataValidation");
        for (int i = 1; i <= w_element->size(); ++i) {      // w_elements->size() devrait être de type size_t
            XML::DOM::Node const * const k_node = w_element->at(i)->node();

            Interface::Write::Validation* w_validation = nullptr;

            std::string k_type = toString(xpath(k_node, "fn:data(@type)"));
            if (k_type == "custom")
                w_validation = o_worksheet->createCustomValidation();
            else if (k_type == "list")
                w_validation = o_worksheet->createListValidation();

            if (w_validation) {
                try {
                    std::string w_sqref = toString(xpath(k_node, "fn:data(@sqref)"));
                    if (w_sqref == "")
                        w_sqref = toString(xpath(k_node, "fn:data(xm:sqref/text())"));
                    const coordinatesMultiCellRange_t k_parsedRanges = parseMultiCellRangeCoordinates(w_sqref, nullptr, ' ');
                    if (k_parsedRanges)
                        w_validation->setReference( *k_parsedRanges );

                    w_validation->allowBlank( toString(xpath(k_node, "fn:data(@allowBlank)")) == "1" );

                    w_validation->showPrompt( toString(xpath(k_node, "fn:data(@showInputMessage)")) == "1" );
                    w_validation->showAlert( toString(xpath(k_node, "fn:data(@showErrorMessage)")) == "1" );

                    xPathElement_t w_title = xpath(k_node, "fn:data(@promptTitle)");
                    xPathElement_t w_message = xpath(k_node, "fn:data(@prompt)");
                    if (value(w_title) || value(w_message))
                        w_validation->setPrompt( toString(w_title), toString(w_message) );

                    xPathElement_t w_errorStyle = xpath(k_node, "fn:data(@errorStyle)");
                    if (toString(w_errorStyle) == "information")
                        w_validation->setAlertType( Interface::atInformation );
                    else if (toString(w_errorStyle) == "warning")
                        w_validation->setAlertType( Interface::atWarning );
                    else
                        w_validation->setAlertType( Interface::atError );

                    w_title = xpath(k_node, "fn:data(@errorTitle)");
                    w_message = xpath(k_node, "fn:data(@error)");
                    if (value(w_title) || value(w_message))
                        w_validation->setAlert( toString(w_title), toString(w_message) );

                    Interface::Write::CustomValidation* w_customValidation = dynamic_cast<Interface::Write::CustomValidation*>(w_validation);
                    if (w_customValidation) {
                        std::string w_formula = toString(xpath(k_node, "fn:data(ssml:formula1/text())"));
                        if (w_formula == "")
                            w_formula = toString(xpath(k_node, "fn:data(x14:formula1/xm:f/text())"));
                        w_customValidation->setFormula( w_formula );
                        o_worksheet->addValidation(w_customValidation);
                    }

                    Interface::Write::ListValidation* w_listValidation = dynamic_cast<Interface::Write::ListValidation*>(w_validation);
                    if (w_listValidation) {
                        std::string w_formula = toString(xpath(k_node, "fn:data(ssml:formula1/text())"));
                        if (w_formula == "")
                            w_formula = toString(xpath(k_node, "fn:data(x14:formula1/xm:f/text())"));
                        o_refListValidations.push_back( {w_formula, o_worksheet, std::shared_ptr<Interface::Write::ListValidation>(w_listValidation)} );
                        w_validation = nullptr; // ne pas le liberer !
                    }

                    delete w_validation;
                } catch (...) {
                    delete w_validation;
                    throw;
                }
            }
        }

        w_element = xpath(&w_xml, "ssml:worksheet/ssml:hyperlinks");
        if (node(w_element))
            hyperlinks(p_zipReader, node(w_element), o_worksheet, p_filename, o_hyperlinks);

        Interface::Write::PageSetting* w_pageSetting = o_worksheet->createPageSetting();
        try {

            w_element = xpath(&w_xml, "fn:data(ssml:worksheet/ssml:pageSetup/@orientation)");
            if (toString(w_element) == "portrait")
                w_pageSetting->setPageOrientation(Interface::poPortrait);
            if (toString(w_element) == "landscape")
                w_pageSetting->setPageOrientation(Interface::poLandscape);

            w_element = xpath(&w_xml, "fn:data(ssml:worksheet/ssml:pageSetup/@fitToHeight)");
            if (value(w_element))
                w_pageSetting->setFitToHeight(toInteger(w_element));
            w_element = xpath(&w_xml, "fn:data(ssml:worksheet/ssml:pageSetup/@fitToWidth)");
            if (value(w_element))
                w_pageSetting->setFitToWidth( toInteger(w_element) );
            w_element = xpath(&w_xml, "fn:data(ssml:worksheet/ssml:pageSetup/@scale)");
            if (value(w_element)) {
                const unsigned short k_scale = toInteger(w_element);
                w_pageSetting->setScale( &k_scale );
            }

            if (!p_printArea.empty()) {
                const coordinatesMultiCellRange_t k_parsedRanges = parseMultiCellRangeCoordinates(p_printArea, nullptr);
                if (k_parsedRanges)
                    w_pageSetting->setPrintArea( k_parsedRanges.get() );
            }

            if (!p_printTitles.empty()) {
                const std::size_t k_separator = p_printTitles.find(",");

                const std::string k_printTitle1 = p_printTitles.substr(0, k_separator);
                if (!k_printTitle1.empty()) {
                    const Coordinates::Parser k_parser1(k_printTitle1, nullptr);
                    if (k_parser1.parseResult() && (k_parser1.type() == Coordinates::Parser::ctColumnRowRange))
                        w_pageSetting->setHeader( k_parser1.columnRowRange() );
                }

                const std::string k_printTitle2 = p_printTitles.substr(k_separator+1);
                if (!k_printTitle2.empty()) {
                    const Coordinates::Parser k_parser2(k_printTitle2, nullptr);
                    if (k_parser2.parseResult() && (k_parser2.type() == Coordinates::Parser::ctColumnRowRange))
                        w_pageSetting->setHeader( k_parser2.columnRowRange() );
                }
            }

            headerFooter(w_xml, w_pageSetting);

            o_worksheet->setPageSetting(*w_pageSetting);
            delete w_pageSetting;

        } catch (...) {
            delete w_pageSetting;
            throw;
        }

        w_element = xpath(&w_xml, "fn:data(ssml:worksheet/ssml:drawing/@odr:id)");
        if (toString(w_element) == p_images.id)
            addImages(p_zipReader, o_worksheet, p_images);

//        if (!xpath(&w_xml, "ssml:worksheet/ssml:legacyDrawing")->isEmpty())
            addComments(o_worksheet, p_comments);
    }
}

Reader::xPathElement_t Reader::xpath(const XML::DOM::Node* p_node, const std::string& p_query)
{
    XPath::StaticContext w_staticContext;
    w_staticContext.namespaceHandler()->ensureNamespace("http://schemas.openxmlformats.org/package/2006/relationships", "pr");
    w_staticContext.namespaceHandler()->ensureNamespace("http://schemas.openxmlformats.org/officeDocument/2006/relationships", "odr");
    w_staticContext.namespaceHandler()->ensureNamespace("http://schemas.openxmlformats.org/spreadsheetml/2006/main", "ssml");
    w_staticContext.namespaceHandler()->ensureNamespace("http://schemas.openxmlformats.org/drawingml/2006/main", "dml");
    w_staticContext.namespaceHandler()->ensureNamespace("http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing", "dmls");
    w_staticContext.namespaceHandler()->ensureNamespace("http://schemas.microsoft.com/office/spreadsheetml/2009/9/main", "x14");
    w_staticContext.namespaceHandler()->ensureNamespace("http://schemas.microsoft.com/office/excel/2006/main", "xm");
    w_staticContext.namespaceHandler()->ensureNamespace("urn:schemas-microsoft-com:vml", "vml");
    w_staticContext.namespaceHandler()->ensureNamespace("urn:schemas-microsoft-com:office:excel", "excel");
    XPath::Expression w_expression(&w_staticContext);

    XPath::Element* w_element = nullptr;
    try {
        if (w_expression.parse(p_query))
            w_element = w_expression.evaluate(p_node);
    } catch (XMLUtils::Error& w_error) {
        std::cerr << w_error.what();
    }

    return xPathElement_t(w_element);
}

const XMLSchema::Value* Reader::value(const xPathElement_t& p_element)
{
    if (p_element)
        return p_element->value();
    return nullptr;
}

const XML::DOM::Node* Reader::node(const xPathElement_t& p_element)
{
    if (p_element)
        return p_element->node();
    return nullptr;
}

int Reader::toInteger(const xPathElement_t& p_element, int p_default)
{
    return toInteger(p_element.get(), p_default);
}

int Reader::toInteger(const XPath::Element* p_element, int p_default)
{
    if ((p_element) && (p_element->value()))
        return std::stoi( p_element->value()->asSharedString(), nullptr, 10 );
    return p_default;
}

double Reader::toDouble(const xPathElement_t& p_element, double p_default)
{
    return toDouble(p_element.get(), p_default);
}

double Reader::toDouble(const XPath::Element* p_element, double p_default)
{
    if ((p_element) && (p_element->value()))
        return std::stod( p_element->value()->asSharedString(), nullptr );
    return p_default;
}

std::string Reader::toString(const xPathElement_t& p_element, const std::string& p_default)
{
    return toString(p_element.get(), p_default);
}

std::string Reader::toString(const XPath::Element* p_element, const std::string& p_default)
{
    if ((p_element) && (p_element->value()))
        return p_element->value()->asSharedString();
    return p_default;
}

void Reader::loadXMLDocument(Zip::ZipArchiveReader& p_zipReader, const std::string& p_filename, XML::DOM::Document& o_xml)
{
    std::stringstream w_memStream;
    p_zipReader.extractToStream(p_filename, &w_memStream);
    o_xml.parse(w_memStream);
}

std::string Reader::path(const std::string& p_filename)
{
    const std::size_t k_pos = p_filename.find_last_of('/');
    return p_filename.substr(0, k_pos+1);
}

std::string Reader::name(const std::string& p_filename)
{
    const std::size_t k_pos = p_filename.find_last_of('/');
    return p_filename.substr(k_pos+1);
}

std::string Reader::absoluteName(const std::string& p_path, const std::string& p_filename)
{
    if (p_filename == "")
        return "";

    if (p_filename.at(0) == '/')
        return p_filename.substr(1);

    std::string w_absName = p_path + p_filename;

    size_t w_pos = w_absName.find("/..");
    while (w_pos != std::string::npos) {
        size_t w_first = w_absName.find_last_of("/", w_pos-1);
        if (w_first != std::string::npos) {
            w_absName = w_absName.substr(0, w_first) + w_absName.substr(w_pos+3);
            w_pos = w_absName.find("/..");
        } else
            w_pos = std::string::npos;
    }

    return w_absName;
}

std::string Reader::officeDocument(Zip::ZipArchiveReader& p_zipReader)
{
    const relations_t k_relations = rels(p_zipReader, "_rels/.rels");
    std::string w_officeDocument = targetFromRels(k_relations, rtOfficeDocument);
    if (w_officeDocument.at(0) == '/')
        return w_officeDocument.substr(1);
    return w_officeDocument;
}

void Reader::load(Zip::ZipArchiveReader& p_zipReader, Interface::Write::Workbook* o_workbook)
{
    if (!o_workbook)
        return;

    const std::string k_officeDocument = officeDocument(p_zipReader);
    const std::string k_path = path(k_officeDocument);
    const std::string k_file = name(k_officeDocument);

    const relations_t k_officeDocumentRels = rels(p_zipReader, k_path +"_rels/"+ k_file +".rels");

    // theme
    std::string w_filename = absoluteName(k_path, targetFromRels(k_officeDocumentRels, rtTheme));
    const colorScheme_t k_colors = colorScheme(p_zipReader, w_filename);

    // sharedStrings
    w_filename = absoluteName(k_path, targetFromRels(k_officeDocumentRels, rtSharedStrings));
    const sharedStrings_t k_shareStrings = sharedStrings(p_zipReader, w_filename, k_colors);

    // workbook
    const workbook_t k_workbook = workbook(p_zipReader, k_officeDocument);

    // hyperlinks
    hyperlinks_t w_hyperlinks;

    // styles
    w_filename = absoluteName(k_path, targetFromRels(k_officeDocumentRels, rtStyles));
    styles_t w_styles = styles(p_zipReader, w_filename, k_colors);
    try {

        o_workbook->setDefaultFont(
            w_styles->defaultFont.name,
            w_styles->defaultFont.size,
            w_styles->defaultFont.color,
            w_styles->defaultFont.bold,
            w_styles->defaultFont.italic,
            w_styles->defaultFont.underline
            );

        // worksheets
        refListValidations_t w_refListValidations;

        for (sheets_t::const_iterator w_iSheet = k_workbook->sheets.begin(); w_iSheet != k_workbook->sheets.end(); ++w_iSheet) {
            Interface::Write::Worksheet* w_worksheet = o_workbook->newWorksheet(w_iSheet->name);
            w_worksheet->setHidden(w_iSheet->hidden);

            const images_t k_images = images(p_zipReader, w_worksheet, absoluteName(k_path, (*k_officeDocumentRels)[w_iSheet->id].target));

            const comments_t k_comments = comments(p_zipReader, w_worksheet, absoluteName(k_path, (*k_officeDocumentRels)[w_iSheet->id].target), k_colors);

            const printAreas_t::const_iterator k_paIndex = k_workbook->printAreas.find( w_iSheet->name );
            const std::string k_printArea = ((k_paIndex != k_workbook->printAreas.end()) ? k_paIndex->second : "");

            const printTitles_t::const_iterator k_ptIndex = k_workbook->printTitles.find( w_iSheet->name );
            const std::string k_printTitle = ((k_ptIndex != k_workbook->printTitles.end()) ? k_ptIndex->second : "");

            sheet(p_zipReader, absoluteName(k_path, (*k_officeDocumentRels)[w_iSheet->id].target), w_styles, k_shareStrings, k_printArea, k_printTitle, k_images, k_comments, w_refListValidations, w_hyperlinks, w_worksheet);
        }

        for (refListValidations_t::iterator w_it = w_refListValidations.begin(); w_it != w_refListValidations.end(); ++w_it) {
            o_workbook->selectWorksheet(w_it->worksheet);
            const coordinatesCellRange_t k_parsedRange = parseCellRangeCoordinates(w_it->range, o_workbook->proxy());
            if (k_parsedRange)
                w_it->validation->setRangeReference(*k_parsedRange);
            w_it->worksheet->addValidation(w_it->validation.get());
        }
        o_workbook->selectWorksheetIndex(0);

    } catch (...) {
        freeStyles(w_styles);
        throw;
    }
    freeStyles(w_styles);
    w_styles = nullptr;

    // defined names
    for (definedNames_t::const_iterator w_iDefinedNames = k_workbook->definedNames.begin(); w_iDefinedNames != k_workbook->definedNames.end(); ++w_iDefinedNames) {
        Interface::Write::DefinedName* w_definedName = o_workbook->createDefinedName();
        try {
            const coordinatesMultiCellRange_t k_parsedRanges = parseMultiCellRangeCoordinates(w_iDefinedNames->second, o_workbook->proxy());
            if ((k_parsedRanges) && (k_parsedRanges->rangeCount())) {
                w_definedName->setName( w_iDefinedNames->first );
                w_definedName->setZone( *k_parsedRanges );

                o_workbook->addDefinedName(*w_definedName);
            }
        } catch (...) {
            delete w_definedName;
            throw;
        }
        delete w_definedName;
    }

    // hyperlinks
    for (hyperlinks_t::const_iterator w_iHyperlinks = w_hyperlinks.begin(); w_iHyperlinks != w_hyperlinks.end(); ++w_iHyperlinks) {
        const hyperlinkStruct_t k_hyperlinkStruct = *w_iHyperlinks;

        Interface::Write::Hyperlink* w_hyperlink = k_hyperlinkStruct.worksheet->createHyperlink();
        try {
            w_hyperlink->setReference(k_hyperlinkStruct.ref);

            w_hyperlink->setDisplay(k_hyperlinkStruct.display);
            w_hyperlink->setTooltip(k_hyperlinkStruct.tooltip);

            if (k_hyperlinkStruct.location != "") {
                const coordinatesCellRange_t k_location = parseCellRangeCoordinates(k_hyperlinkStruct.location, o_workbook->proxy());
                if (!k_location) {
                    const std::string k_strRange = k_workbook->definedNames[k_hyperlinkStruct.location];
                    const coordinatesMultiCellRange_t k_parsedRanges = parseMultiCellRangeCoordinates(k_strRange, o_workbook->proxy());
                    if ((k_parsedRanges) && (k_parsedRanges->rangeCount())) {
                        Interface::Write::DefinedName* w_definedName = o_workbook->createDefinedName();
                        try {
                            w_definedName->setName(k_hyperlinkStruct.location);
                            w_definedName->setZone(*k_parsedRanges);
                            w_hyperlink->setLocation(*w_definedName);
                        } catch (...) {
                            delete w_definedName;
                            throw;
                        }
                        delete w_definedName;
                    }
                } else
                    w_hyperlink->setLocation(*k_location);
            }

            if (k_hyperlinkStruct.target != "") {
                if (k_hyperlinkStruct.target.substr(0, 7) == "mailto:") {
                    size_t w_pos = k_hyperlinkStruct.target.find("?subject=");
                    w_hyperlink->setMailLocation( k_hyperlinkStruct.target.substr(7, w_pos-7), k_hyperlinkStruct.target.substr(w_pos+9) );
                } else if (k_hyperlinkStruct.target.substr(0, 8) == "file:///")
                    w_hyperlink->setFileLocation(k_hyperlinkStruct.target.substr(8));
            }

            k_hyperlinkStruct.worksheet->addHyperlink(w_hyperlink);
        } catch (...) {
            delete w_hyperlink;
            throw;
        }
        delete w_hyperlink;
    }
}

void Reader::load(const std::string& p_filename, Interface::Write::Workbook* o_workbook)
{
    if (o_workbook) {
        Zip::ZipArchiveReader* w_zipReader = Zip::openZipArchive(p_filename);
        try {
            load(*w_zipReader, o_workbook);
        } catch (...) {
            delete w_zipReader;
            throw;
        }
        delete w_zipReader;
    }
}

void Reader::load(std::istream& p_zipStream, Interface::Write::Workbook* o_workbook)
{
    if (o_workbook) {
        Zip::ZipArchiveReader* w_zipReader = Zip::openZipArchive(p_zipStream);
        try {
            load(*w_zipReader, o_workbook);
        } catch (...) {
            delete w_zipReader;
            throw;
        }
        delete w_zipReader;
    }
}

void Reader::load(const Zip::byte_t* p_memory, unsigned int p_size, Interface::Write::Workbook* o_workbook)
{
    if (o_workbook) {
        Zip::ZipArchiveReader* w_zipReader = Zip::openZipArchive(p_memory, p_size);
        try {
            load(*w_zipReader, o_workbook);
        } catch (...) {
            delete w_zipReader;
            throw;
        }
        delete w_zipReader;
    }
}

} // namespace XLSX
} // namespace Invoke
