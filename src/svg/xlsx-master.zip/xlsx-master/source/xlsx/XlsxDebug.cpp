/*!
 * \file        XlsxTrace.cpp
 * \author      Invoke - Jean-Christophe PHILIPPE (jcphilippe\@invoke.fr)
 * \date        Novembre 2017
 * \copyright   SA Invoke
 */

#include "xlsx/XlsxDebug.hpp"

namespace Invoke {
namespace XLSX {
namespace Debug {

#if defined(INVOKE_XLSX_LOGS)

LogFile::LogFile(const std::string& p_filename)
:   m_logFile(p_filename, std::ios::out | std::ios::trunc)
{
}

LogFile::~LogFile()
{
    m_logFile.close();
}

HRChrono::HRChrono()
:   m_start(),
    m_stop()
{
    start();
}

void HRChrono::start()
{
    m_start = std::chrono::high_resolution_clock::now();
    m_stop = m_start;
}

std::chrono::duration<double> HRChrono::stop()
{
    m_stop = std::chrono::high_resolution_clock::now();
    return timeSpan();
}

std::chrono::duration<double> HRChrono::timeSpan() const
{
    return std::chrono::duration_cast<std::chrono::duration<double>>(m_stop - m_start);
}

void Logs::message(const std::string& p_message)
{
    if (!p_message.empty())
        m_file << p_message << "\n";
}

void Logs::startChrono(const std::string& p_message)
{
    message("-> " + p_message);
    m_chrono.start();
}

void Logs::stopChrono()
{
    m_chrono.stop();
    m_file << "Chrono: " << m_chrono.timeSpan().count() << "s.\n";
}

void Logs::checkMemory()
{
#if defined(_WIN32)
    PROCESS_MEMORY_COUNTERS_EX pmc;
    GetProcessMemoryInfo(GetCurrentProcess(), reinterpret_cast<PROCESS_MEMORY_COUNTERS*>(&pmc), sizeof(pmc));

    size_t w_virtualMemoryUsedByProcess = pmc.PrivateUsage;
    size_t w_physicalMemoryUsedByProcess = pmc.WorkingSetSize;

    m_file << "Virtual memory: " << w_virtualMemoryUsedByProcess << ".\n";
    m_file << "Physical memory: " << w_physicalMemoryUsedByProcess << ".\n";
#endif
}

Logs::Logs()
:   m_chrono(),
    m_file("invoke_xlsx_logs.txt")
{
}

Object::Object(const std::string& p_name)
:   m_name(p_name),
    m_avgSize(0),
    m_count(0),
    m_minSize(0),
    m_maxSize(0)
{
}

void Object::add(size_t p_size)
{
    m_avgSize = ((m_avgSize * m_count) + p_size) / (m_count + 1);
    if ((m_minSize == 0) || (m_minSize > p_size))
        m_minSize = p_size;
    if ((m_maxSize == 0) || (m_maxSize < p_size))
        m_maxSize = p_size;
    ++m_count;
}

std::string Object::log() const
{
    return "<object name=\"" + m_name + "\" count=\"" + std::to_string(m_count) + "\" avg-size=\"" + std::to_string(m_avgSize) + "\" min-size=\"" + std::to_string(m_minSize) + "\"  max-size=\"" + std::to_string(m_maxSize) + "\"></object>";
}

Container::Container(const std::string& p_name, size_t p_size)
:   m_name(p_name),
    m_size(p_size),
    m_containers(),
    m_objects()
{
}

Container::~Container()
{
    for (std::vector<Container*>::const_iterator w_it = m_containers.begin(); w_it != m_containers.end(); ++w_it)
        delete *w_it;

    for (std::unordered_map<std::string, Object*>::const_iterator w_it = m_objects.begin(); w_it != m_objects.end(); ++w_it)
        delete w_it->second;
}

Container* Container::addContainer(const std::string& p_name, size_t p_size)
{
    Container* w_container = new Container(p_name, p_size);
    m_containers.push_back(w_container);

    return w_container;
}

Object* Container::addObject(const std::string& p_name)
{
    Object* w_object = getObject(p_name);
    if (!w_object) {
        w_object = new Object(p_name);
        m_objects.emplace(p_name, w_object);
    }

    return w_object;
}

Object* Container::getObject(const std::string& p_name) const
{
    std::unordered_map<std::string, Object*>::const_iterator w_got = m_objects.find(p_name);
    if (w_got != m_objects.end())
        return w_got->second;
    return nullptr;
}

std::string Container::log() const
{
    std::string w_result = "<container name=\"" + m_name + "\" size=\"" + std::to_string(m_size) + "\">";

    for (std::unordered_map<std::string, Object*>::const_iterator w_it = m_objects.begin(); w_it != m_objects.end(); ++w_it)
        w_result += w_it->second->log();

    for (std::vector<Container*>::const_iterator w_it = m_containers.begin(); w_it != m_containers.end(); ++w_it)
        w_result += (*w_it)->log();

    w_result += "</container>";

    return w_result;
}

void Container::clear()
{
    for (std::vector<Container*>::const_iterator w_it = m_containers.begin(); w_it != m_containers.end(); ++w_it)
        delete *w_it;
    m_containers.clear();

    for (std::unordered_map<std::string, Object*>::const_iterator w_it = m_objects.begin(); w_it != m_objects.end(); ++w_it)
        delete w_it->second;
    m_objects.clear();
}

Container* Counter::container()
{
    return &m_container;
}

void Counter::log() const
{
    LogFile w_file("invoke_xlsx_counter.xml");
    w_file << m_container.log();
}

void Counter::clear()
{
    m_container.clear();
}

Counter::Counter()
:   m_container("root", 0)
{
}

#endif /* INVOKE_XLSX_LOGS */

#if defined(INVOKE_XLSX_TRACE)
    
// HRChrono
HRChrono::HRChrono()
:   m_start()
{
    start();
}

void HRChrono::start()
{
    m_start = std::chrono::high_resolution_clock::now();
}

HRChrono::duration_t HRChrono::timeSpan() const
{
    const timePoint_t k_stop = std::chrono::high_resolution_clock::now();
    return std::chrono::duration_cast<duration_t>(k_stop - m_start);
}

// Trace
Trace& Trace::get()
{
    static Trace s_trace(INVOKE_XLSX_TRACE);
    return s_trace;
}

Trace::Trace(const std::string& p_filename)
:   m_outfile(nullptr),
    m_chronos(),
    m_functions(0)
{
    if (p_filename != "")
        m_outfile = new std::ofstream(p_filename);
    else
        m_outfile = new std::ofstream("__xlsx_trace__.xml");
    
    *m_outfile << "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
               << "<TRACE start=\"" << timeToXML() << "\">";
    
    startChrono();
}

Trace::~Trace()
{
    for (int i = 0; i < m_functions; ++i) 
        *m_outfile << "<!-- never finished --></FUNCTION>";
    
    writeChrono();
    *m_outfile << "</TRACE>";
    
    m_outfile->close();
    delete m_outfile;
}

void Trace::beginFunction(const std::string& p_name, const arguments_t& p_args)
{
    std::string w_args = "";
    for (int i = 0; i < p_args.size(); ++i)
        w_args += " arg"+ std::to_string(i) +"=\""+ textToXML(p_args[i])  +"\"";

    *m_outfile << "<FUNCTION name=\"" << textToXML(p_name) << "\"" + w_args + " start=\"" << timeToXML() << "\">";
    startChrono();
    ++m_functions;
}

void Trace::endFunction()
{
    if (m_functions) {
        writeChrono();
        --m_functions;
    } else 
        *m_outfile << "<FUNCTION fictitious=\"true\">";
    *m_outfile << "</FUNCTION>";
}

void Trace::exception(const std::exception& p_exception)
{
    *m_outfile << "<EXCEPTION what=\"" << textToXML(p_exception.what()) << "\" />";
}

void Trace::writeInfos(const std::string& p_message)
{
    *m_outfile << "<INFOS message=\"" << textToXML(p_message) << "\" />";
}

std::string Trace::textToXML(const std::string& p_text)
{
    std::string w_result = p_text;

    std::string::size_type w_pos = w_result.find('&', 0);
    while (w_pos != std::string::npos) {
        w_result.replace(w_pos, 1, "&amp;");
        w_pos = w_result.find('&', w_pos+5);
    }

    w_pos = w_result.find('>', 0);
    while (w_pos != std::string::npos) {
        w_result.replace(w_pos, 1, "&gt;");
        w_pos = w_result.find('>', w_pos+4);
    }

    w_pos = w_result.find('<', 0);
    while (w_pos != std::string::npos) {
        w_result.replace(w_pos, 1, "&lt;");
        w_pos = w_result.find('<', w_pos+4);
    }

    return w_result;
}
    
std::string Trace::timeToXML()
{
    char w_buffer[21];
    time_t w_now;
    time(&w_now);
    strftime(w_buffer, 21, "%Y-%m-%dT%H:%M:%SZ", gmtime(&w_now));
    return w_buffer;
}

void Trace::startChrono()
{
    m_chronos.push(HRChrono());
}

double Trace::stopChrono()
{
    const HRChrono::duration_t k_duration = m_chronos.top().timeSpan();
    m_chronos.pop();
    return k_duration.count();
}

void Trace::writeChrono()
{
    *m_outfile << "<CHRONO value=\"" << trunc(stopChrono()) << "ms\"/>";
}

// TraceFunction
TraceFunction::TraceFunction(const std::string& p_name, const Trace::arguments_t& p_args)
{
    Trace::get().beginFunction(p_name, p_args);
}

TraceFunction::~TraceFunction()
{
    Trace::get().endFunction();
}

void TraceFunction::exception(const std::exception& p_exception)
{
    Trace::get().exception(p_exception);
}

void TraceFunction::writeInfos(const std::string& p_message)
{
    Trace::get().writeInfos(p_message);
}

#endif /* INVOKE_XLSX_TRACE */

} // namespace Debug
} // namespace XLSX
} // namespace Invoke