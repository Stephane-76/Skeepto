/*!
 * \file        Coordinates.cpp
 * \author      Invoke - Jean-Christophe PHILIPPE (jcphilippe\@invoke.fr)
 * \date        Avril 2015
 * \copyright   SA Invoke
 */

#include "xlsx/Coordinates.hpp"
#include "string/UtfString.hpp"
#include "string/Unicode.hpp"
#include <concept_check.hpp>

#include <string>
#include <vector>
#include <sstream>
#include <algorithm>

namespace Invoke {
namespace XLSX {
namespace Coordinates {

// -----------------------------------------------------------------------------
// WorksheetProxy
// -----------------------------------------------------------------------------
WorksheetProxy::~WorksheetProxy()
{
}

utf8String_t WorksheetProxy::quotedName() const
{
    const utf8String_t k_name = name();

    bool w_quote = false;
    utf8String_t w_result = "";

    utf8String_t::const_iterator w_it = k_name.begin();
    while (w_it != k_name.end()) {
        const char32_t k_char = UtfString::UTF8::read(w_it);
        if (!Unicode::isLetter(k_char))
            w_quote = true;
        if (k_char == '\'')
            UtfString::UTF8::write('\'', std::back_inserter(w_result));
        UtfString::UTF8::write(k_char, std::back_inserter(w_result));
    }

    if (w_quote)
        return "'"+ w_result +"'";
    return w_result;
}

// -----------------------------------------------------------------------------
// WorkbookProxy
// -----------------------------------------------------------------------------
WorkbookProxy::~WorkbookProxy()
{
}

// -----------------------------------------------------------------------------
// Index
// -----------------------------------------------------------------------------
utf8String_t Index::columnNameFromIndex(unsigned int p_index)
{
    std::string w_result = "";

    int w_div = p_index / 26;
    while (w_div--) {
        w_result = (char)((short)'A' + (w_div % 26)) + w_result;
        w_div = w_div / 26;
    }

    int w_mod = p_index % 26;
    return w_result + (char)((short)'A' + w_mod);
}

Index::Index(unsigned int p_index, bool p_locked)
:   m_index(p_index),
    m_locked(p_locked)
{
}

bool Index::operator ==(const Index& p_index) const
{
    return (m_index == p_index.m_index);
}

bool Index::operator !=(const Index& p_index) const
{
    return (m_index != p_index.m_index);
}

unsigned int Index::index() const
{
    return m_index;
}

bool Index::isLocked() const
{
    return m_locked;
}

utf8String_t Index::name(indexType_t p_type) const
{
    std::basic_ostringstream<char> w_result;
    w_result.imbue(std::locale::classic());

    if (m_locked)
        w_result << "$";

    if (p_type == itColumn)
        w_result << columnNameFromIndex(m_index);
    else
        w_result << (m_index+1);

    return w_result.str();
}

// -----------------------------------------------------------------------------
// Cell
// -----------------------------------------------------------------------------
Cell::Cell(const WorksheetProxy* p_worksheet, const Index& p_column, const Index& p_row)
:   m_worksheet(p_worksheet),
    m_column(p_column),
    m_row(p_row)
{
}

Cell::Cell(const WorksheetProxy* p_worksheet, unsigned int p_column, unsigned int p_row, bool p_locked)
:   m_worksheet(p_worksheet),
    m_column(p_column, p_locked),
    m_row(p_row, p_locked)
{
}

const WorksheetProxy* Cell::worksheet() const
{
    return m_worksheet;
}

const Index& Cell::columnIndex() const
{
    return m_column;
}

const Index& Cell::rowIndex() const
{
    return m_row;
}

unsigned int Cell::column() const
{
    return m_column.index();
}

unsigned int Cell::row() const
{
    return m_row.index();
}

bool Cell::operator ==(const Cell& p_cell) const
{
    return  (   (m_worksheet == p_cell.m_worksheet)
            &&  (m_column == p_cell.m_column)
            &&  (m_row == p_cell.m_row)
            );
}

bool Cell::operator !=(const Cell& p_cell) const
{
    return !(*this == p_cell);
}

utf8String_t Cell::name(const WorksheetProxy* p_currentWorksheet) const
{
    return  ((m_worksheet) && (m_worksheet != p_currentWorksheet) ? m_worksheet->quotedName() +"!" : "")
            + m_column.name(Index::itColumn)
            + m_row.name(Index::itRow);
}

// -----------------------------------------------------------------------------
// CellRange
// -----------------------------------------------------------------------------
CellRange::CellRange(const WorksheetProxy* p_worksheet, const Index& p_left, const Index& p_top, const Index& p_right, const Index& p_bottom)
:   m_worksheet(p_worksheet),
    m_left(p_left),
    m_top(p_top),
    m_right(p_right),
    m_bottom(p_bottom)
{
}

CellRange::CellRange(const WorksheetProxy* p_worksheet, unsigned int p_left, unsigned int p_top, unsigned int p_right, unsigned int p_bottom, bool pLocked)
:   m_worksheet(p_worksheet),
    m_left(p_left, pLocked),
    m_top(p_top, pLocked),
    m_right(p_right, pLocked),
    m_bottom(p_bottom, pLocked)
{
}

const WorksheetProxy* CellRange::worksheet() const
{
    return m_worksheet;
}

Cell CellRange::topLeft() const
{
    return Cell(m_worksheet, m_left, m_top);
}

Cell CellRange::rightBottom() const
{
    return Cell(m_worksheet, m_right, m_bottom);
}

const Index& CellRange::leftIndex() const
{
    return m_left;
}

const Index& CellRange::topIndex() const
{
    return m_top;
}

const Index& CellRange::rightIndex() const
{
    return m_right;
}

const Index& CellRange::bottomIndex() const
{
    return m_bottom;
}

unsigned int CellRange::left() const
{
    return m_left.index();
}

unsigned int CellRange::top() const
{
    return m_top.index();
}

unsigned int CellRange::right() const
{
    return m_right.index();
}

unsigned int CellRange::bottom() const
{
    return m_bottom.index();
}

bool CellRange::isCell() const
{
    return ((m_left == m_right) && (m_top == m_bottom));
}

bool CellRange::intersectWith(const CellRange& p_range) const
{
    CellRange* w_intersect = nullptr;
    bool w_result = false;
    try {
        w_result = getIntersection(p_range, w_intersect);
        delete w_intersect;
    } catch (...) {
        delete w_intersect;
    }
    return w_result;
}

bool CellRange::getIntersection(const CellRange& p_range, CellRange*& o_intersect) const
{
    o_intersect = nullptr;

    if (m_worksheet == p_range.m_worksheet) {
        unsigned int w_left = ((left() > p_range.left()) ? left() : p_range.left());
        unsigned int w_top = ((top() > p_range.top()) ? top() : p_range.top());
        unsigned int w_right = ((right() < p_range.right()) ? right() : p_range.right());
        unsigned int w_bottom = ((bottom() < p_range.bottom()) ? bottom() : p_range.bottom());

        if ((w_right < w_left) || (w_bottom < w_top))
            return false;

        o_intersect = new CellRange( m_worksheet, w_left, w_top, w_right, w_bottom );
        return true;
    }

    return false;
}

bool CellRange::unionWith(const CellRange& p_range) const
{
    CellRange* w_union = nullptr;
    bool w_result = false;
    try {
        w_result = getUnion(p_range, w_union);
        delete w_union;
    } catch (...) {
        delete w_union;
    }
    return w_result;
}

bool CellRange::getUnion(const CellRange& p_range, CellRange*& o_union) const
{
    o_union = nullptr;

    if (m_worksheet == p_range.m_worksheet) {
        unsigned int w_left = ((left() < p_range.left()) ? left() : p_range.left());
        unsigned int w_top = ((top() < p_range.top()) ? top() : p_range.top());
        unsigned int w_right = ((right() > p_range.right()) ? right() : p_range.right());
        unsigned int w_bottom = ((bottom() > p_range.bottom()) ? bottom() : p_range.bottom());

        if ((w_right < w_left) || (w_bottom < w_top))
            return false;

        o_union = new CellRange( m_worksheet, w_left, w_top, w_right, w_bottom );
        return true;
    }

    return false;
}

bool CellRange::operator ==(const CellRange& p_range) const
{
    return  (   (m_worksheet == p_range.m_worksheet)
            &&  (m_left == p_range.m_left)
            &&  (m_top == p_range.m_top)
            &&  (m_right == p_range.m_right)
            &&  (m_bottom == p_range.m_bottom)
            );
}

bool CellRange::operator !=(const CellRange& p_range) const
{
    return !(*this == p_range);
}

utf8String_t CellRange::name(const WorksheetProxy* p_currentWorksheet) const
{
    if (isCell())
        return Cell(m_worksheet, m_left, m_top).name(p_currentWorksheet);

    return  ((m_worksheet) && (m_worksheet != p_currentWorksheet) ? m_worksheet->quotedName() +"!" : "")
            + m_left.name(Index::itColumn)
            + m_top.name(Index::itRow)
            + ":"
            + m_right.name(Index::itColumn)
            + m_bottom.name(Index::itRow);
}

// -----------------------------------------------------------------------------
// ColumnRow
// -----------------------------------------------------------------------------
ColumnRow::ColumnRow(Index::indexType_t p_type, const WorksheetProxy* p_worksheet, const Index& p_index)
:   m_type(p_type),
    m_worksheet(p_worksheet),
    m_index(p_index)
{
}

ColumnRow::ColumnRow(Index::indexType_t p_type, const WorksheetProxy* p_worksheet, unsigned int p_index, bool p_locked)
:   m_type(p_type),
    m_worksheet(p_worksheet),
    m_index(p_index, p_locked)
{
}

Index::indexType_t ColumnRow::type() const
{
    return m_type;
}

const WorksheetProxy* ColumnRow::worksheet() const
{
    return m_worksheet;
}

const Index& ColumnRow::index() const
{
    return m_index;
}

bool ColumnRow::operator ==(const ColumnRow& p_columnRow) const
{
    return  (   (m_type == p_columnRow.m_type)
            &&  (m_worksheet == p_columnRow.m_worksheet)
            &&  (m_index == p_columnRow.m_index)
            );
}

bool ColumnRow::operator !=(const ColumnRow& p_columnRow) const
{
    return !(*this == p_columnRow);
}

utf8String_t ColumnRow::name(const WorksheetProxy* p_currentWorksheet) const
{
    return  ((m_worksheet) && (m_worksheet != p_currentWorksheet) ? m_worksheet->quotedName() +"!" : "")
            + m_index.name(m_type);
}

// -----------------------------------------------------------------------------
// ColumnRowRange
// -----------------------------------------------------------------------------
ColumnRowRange::ColumnRowRange(Index::indexType_t p_type, const WorksheetProxy* p_worksheet, const Index& p_first, const Index& p_last)
:   m_type(p_type),
    m_worksheet(p_worksheet),
    m_first(p_first),
    m_last(p_last)
{
}

ColumnRowRange::ColumnRowRange(Index::indexType_t p_type, const WorksheetProxy* p_worksheet, unsigned int p_first, unsigned int p_last, bool p_locked)
:   m_type(p_type),
    m_worksheet(p_worksheet),
    m_first(p_first, p_locked),
    m_last(p_last, p_locked)
{
}

Index::indexType_t ColumnRowRange::type() const
{
    return m_type;
}

const WorksheetProxy* ColumnRowRange::worksheet() const
{
    return m_worksheet;
}

const Index& ColumnRowRange::firstIndex() const
{
    return m_first;
}

const Index& ColumnRowRange::lastIndex() const
{
    return m_last;
}

unsigned int ColumnRowRange::first() const
{
    return m_first.index();
}

unsigned int ColumnRowRange::last() const
{
    return m_last.index();
}

bool ColumnRowRange::isColumRow() const
{
    return (m_first == m_last);
}

bool ColumnRowRange::operator ==(const ColumnRowRange& p_columnRowRange) const
{
    return  (   (m_type == p_columnRowRange.m_type)
            &&  (m_worksheet == p_columnRowRange.m_worksheet)
            &&  (m_first == p_columnRowRange.m_first)
            &&  (m_last == p_columnRowRange.m_last)
            );
}

bool ColumnRowRange::operator !=(const ColumnRowRange& p_columnRowRange) const
{
    return !(*this == p_columnRowRange);
}

utf8String_t ColumnRowRange::name(const WorksheetProxy* p_currentWorksheet) const
{
    if (isColumRow())
        return ColumnRow(m_type, m_worksheet, m_first).name(p_currentWorksheet);

    return  ((m_worksheet) && (m_worksheet != p_currentWorksheet) ? m_worksheet->quotedName() +"!" : "")
            + m_first.name(m_type)
            + ":"
            + m_last.name(m_type);
}

// -----------------------------------------------------------------------------
// MultiCellRange
// -----------------------------------------------------------------------------
MultiCellRange::MultiCellRange(const MultiCellRange& p_multiCellRange)
:   m_ranges()
{
    addRange(p_multiCellRange);
}

MultiCellRange& MultiCellRange::operator =(const MultiCellRange& p_multiCellRange)
{
    for (ranges_t::iterator w_it = m_ranges.begin(); w_it != m_ranges.end(); ++w_it)
        delete *w_it;
    m_ranges.clear();

    addRange(p_multiCellRange);

    return *this;
}

MultiCellRange::~MultiCellRange()
{
    for (ranges_t::iterator w_it = m_ranges.begin(); w_it != m_ranges.end(); ++w_it)
        delete *w_it;
}

bool MultiCellRange::addRange(const Cell& p_cell)
{
    return addRange( CellRange(p_cell.worksheet(), p_cell.columnIndex(), p_cell.rowIndex(), p_cell.columnIndex(), p_cell.rowIndex()) );
}

bool MultiCellRange::addRange(const CellRange& p_range)
{
    const ranges_t::const_iterator k_index = std::find(m_ranges.begin(), m_ranges.end(), &p_range);

    if (k_index == m_ranges.end()) {
        m_ranges.push_back( new CellRange(p_range) );
        return true;
    }

    return false;
}

unsigned int MultiCellRange::addRange(const MultiCellRange& p_multiCellRange)
{
    unsigned int w_result = 0;
    for (ranges_t::const_iterator w_it = p_multiCellRange.m_ranges.begin(); w_it != p_multiCellRange.m_ranges.end(); ++w_it)
        w_result += ((addRange(**w_it)) ? 1 : 0);
    return w_result;
}

size_t MultiCellRange::rangeCount() const
{
    return m_ranges.size();
}

const CellRange* MultiCellRange::range(size_t p_index) const
{
    if (p_index < m_ranges.size())
        return m_ranges[p_index];
    return nullptr;
}

bool MultiCellRange::operator ==(const MultiCellRange& p_multiCellRange) const
{
    if (m_ranges.size() != p_multiCellRange.rangeCount())
        return false;

    ranges_t w_ranges;
    for (unsigned int w_iRange = 0; w_iRange < p_multiCellRange.rangeCount(); ++w_iRange)
        w_ranges.push_back( p_multiCellRange.range(w_iRange) );

    unsigned int w_index = 0;
    while (w_ranges.size()) {
        unsigned int w_iRange = 0;
        bool w_found = false;
        while ((!w_found) && (w_iRange < m_ranges.size())) {
            w_found = (*w_ranges[w_iRange] == *m_ranges[w_index]);
            ++w_iRange;
        }
        ++w_index;

        if (w_found)
            w_ranges.erase(w_ranges.begin() + w_iRange - 1);
        else
            return false;
    }

    return true;
}

bool MultiCellRange::operator !=(const MultiCellRange& p_multiCellRange) const
{
    return !(*this == p_multiCellRange);
}

bool MultiCellRange::isEqual(const MultiCellRange& p_multiCellRange) const
{
    typedef std::vector<Cell> cells_t;
    cells_t w_cells;

    for (unsigned int w_iRange = 0; w_iRange < p_multiCellRange.rangeCount(); ++w_iRange) {
        const CellRange* w_range = p_multiCellRange.range(w_iRange);
        for (unsigned int w_iRow = w_range->top(); w_iRow <= w_range->bottom(); ++w_iRow) {
            for (unsigned int w_iColumn = w_range->left(); w_iColumn <= w_range->right(); ++w_iColumn)
                w_cells.push_back( Cell(w_range->worksheet(), w_iColumn, w_iRow) );
        }
    }

    for (unsigned int w_iRange = 0; w_iRange < m_ranges.size(); ++w_iRange) {
        const CellRange* w_range = m_ranges[w_iRange];
        for (unsigned int w_iRow = w_range->top(); w_iRow <= w_range->bottom(); ++w_iRow) {
            for (unsigned int w_iColumn = w_range->left(); w_iColumn <= w_range->right(); ++w_iColumn) {

                Cell w_cell = Cell(w_range->worksheet(), w_iColumn, w_iRow);
                bool w_found = 0;
                unsigned int w_index = 0;
                while ((w_index < w_cells.size()) && (!w_found)) {
                    w_found = (w_cell == w_cells[w_index]);
                    ++w_index;
                }

                if (w_found)
                    w_cells.erase(w_cells.begin() + w_index - 1);
                else
                    return false;
            }
        }
    }

    return (w_cells.size() == 0);
}

bool MultiCellRange::isContaining(const Cell& p_cell) const
{
    const CellRange w_cell = CellRange(p_cell.worksheet(), p_cell.columnIndex(), p_cell.rowIndex(), p_cell.columnIndex(), p_cell.rowIndex());

    for (ranges_t::const_iterator w_iRange = m_ranges.begin(); w_iRange != m_ranges.end(); ++w_iRange)
        if ((*w_iRange)->intersectWith(w_cell))
            return true;
    return false;
}

void MultiCellRange::reduce()
{
#define SHEET_NAME(__p_sheet__) ((__p_sheet__) ? __p_sheet__->name() : "")

    if (m_ranges.size() > 1) {
        // tri par colonne puis ligne
        std::sort(m_ranges.begin(), m_ranges.end(), [](const CellRange* p_range1, const CellRange* p_range2)
                                                        {
                                                            return  (   (SHEET_NAME(p_range1->worksheet()) < SHEET_NAME(p_range2->worksheet()))
                                                                    ||  (   (p_range1->worksheet() == p_range2->worksheet())
                                                                        &&  (p_range1->left() < p_range2->left())
                                                                        )
                                                                    ||  (   (p_range1->worksheet() == p_range2->worksheet())
                                                                        &&  (p_range1->left() == p_range2->left())
                                                                        &&  (p_range1->top() < p_range2->top())
                                                                        )
                                                                    );
                                                        });

        // fusion sur les colonnes
        unsigned int w_iRange = 0;
        while (w_iRange < m_ranges.size()-1) {
            if (    (m_ranges[w_iRange]->worksheet() == m_ranges[w_iRange+1]->worksheet())
               &&   (m_ranges[w_iRange]->left() == m_ranges[w_iRange+1]->left())
               &&   (m_ranges[w_iRange]->right() == m_ranges[w_iRange+1]->right())
               &&   (m_ranges[w_iRange]->bottom() == m_ranges[w_iRange+1]->top()-1)
               ) {
                CellRange* w_range = nullptr;
                m_ranges[w_iRange]->getUnion(*m_ranges[w_iRange+1], w_range);

                if (w_range) {
                    delete m_ranges[w_iRange];
                    m_ranges.erase(m_ranges.begin() + w_iRange);
                    delete m_ranges[w_iRange];
                    m_ranges.erase(m_ranges.begin() + w_iRange);

                    if (w_iRange >= m_ranges.size())
                        m_ranges.push_back(w_range);
                    else
                        m_ranges.insert(m_ranges.begin() + w_iRange, w_range);
                } else
                    ++w_iRange;
            } else
                ++w_iRange;
        }
    }

    if (m_ranges.size() > 1) {
        // tri par ligne puis colonne
        std::sort(m_ranges.begin(), m_ranges.end(), [](const CellRange* p_range1, const CellRange* p_range2)
                                                        {
                                                            return  (   (SHEET_NAME(p_range1->worksheet()) < SHEET_NAME(p_range2->worksheet()))
                                                                    ||  (   (p_range1->worksheet() == p_range2->worksheet())
                                                                        &&  (p_range1->top() < p_range2->top())
                                                                        )
                                                                    ||  (   (p_range1->worksheet() == p_range2->worksheet())
                                                                        &&  (p_range1->top() == p_range2->top())
                                                                        &&  (p_range1->left() < p_range2->left())
                                                                        )
                                                                    );
                                                        });

        // fusion sur les lignes
        unsigned int w_iRange = 0;
        while (w_iRange < m_ranges.size()-1) {
            if (    (m_ranges[w_iRange]->worksheet() == m_ranges[w_iRange+1]->worksheet())
               &&   (m_ranges[w_iRange]->top() == m_ranges[w_iRange+1]->top())
               &&   (m_ranges[w_iRange]->bottom() == m_ranges[w_iRange+1]->bottom())
               &&   (m_ranges[w_iRange]->right() == m_ranges[w_iRange+1]->left()-1)
               ) {
                CellRange* w_range = nullptr;
                m_ranges[w_iRange]->getUnion(*m_ranges[w_iRange+1], w_range);

                if (w_range) {
                    delete m_ranges[w_iRange];
                    m_ranges.erase(m_ranges.begin() + w_iRange);
                    delete m_ranges[w_iRange];
                    m_ranges.erase(m_ranges.begin() + w_iRange);

                    if (w_iRange >= m_ranges.size())
                        m_ranges.push_back(w_range);
                    else
                        m_ranges.insert(m_ranges.begin() + w_iRange, w_range);
                } else
                    ++w_iRange;
            } else
                ++w_iRange;
        }
    }

#undef SHEET_NAME
}

utf8String_t MultiCellRange::name(const WorksheetProxy* p_worksheet, char32_t p_separator) const
{
    if (!m_ranges.empty()) {
        ranges_t::const_iterator w_it = m_ranges.begin();
        std::string w_result = (*w_it)->name(p_worksheet);

        while (++w_it != m_ranges.end()) {
            UtfString::UTF8::write(p_separator, std::back_inserter(w_result));
            w_result += (*w_it)->name(p_worksheet);
        }

        return w_result;
    }

    return "";
}

// -----------------------------------------------------------------------------
// MultiColumnRowRange
// -----------------------------------------------------------------------------
MultiColumnRowRange::MultiColumnRowRange(const MultiColumnRowRange& p_multiColumnRowRange)
:   m_type(p_multiColumnRowRange.m_type),
    m_ranges()
{
    addRange(p_multiColumnRowRange);
}

MultiColumnRowRange& MultiColumnRowRange::operator =(const MultiColumnRowRange& p_multiColumnRowRange)
{
    for (ranges_t::iterator w_it = m_ranges.begin(); w_it != m_ranges.end(); ++w_it)
        delete *w_it;
    m_ranges.clear();

    addRange(p_multiColumnRowRange);

    return *this;
}

MultiColumnRowRange::MultiColumnRowRange(Index::indexType_t p_type)
:   m_type(p_type),
    m_ranges()
{
}

MultiColumnRowRange::~MultiColumnRowRange()
{
    for (ranges_t::iterator w_it = m_ranges.begin(); w_it != m_ranges.end(); ++w_it)
        delete *w_it;
}

Index::indexType_t MultiColumnRowRange::type() const
{
    return m_type;
}

bool MultiColumnRowRange::addRange(const ColumnRow& p_columnRow)
{
    return addRange( ColumnRowRange( p_columnRow.type(), p_columnRow.worksheet(), p_columnRow.index(), p_columnRow.index() ) );
}

bool MultiColumnRowRange::addRange(const ColumnRowRange& p_columnRowRange)
{
    if (p_columnRowRange.type() != m_type)
        return false;

    const ranges_t::const_iterator k_index = std::find(m_ranges.begin(), m_ranges.end(), &p_columnRowRange);

    if (k_index == m_ranges.end()) {
        m_ranges.push_back( new ColumnRowRange(p_columnRowRange) );
        return true;
    }

    return false;
}

unsigned int MultiColumnRowRange::addRange(const MultiColumnRowRange& p_multiColumnRowRange)
{
    unsigned int w_result = 0;
    for (ranges_t::const_iterator w_it = p_multiColumnRowRange.m_ranges.begin(); w_it != p_multiColumnRowRange.m_ranges.end(); ++w_it)
        w_result += ((addRange(**w_it)) ? 1 : 0);
    return w_result;
}

size_t MultiColumnRowRange::rangeCount() const
{
    return m_ranges.size();
}

const ColumnRowRange* MultiColumnRowRange::range(size_t p_index) const
{
    if (p_index < m_ranges.size())
        return m_ranges[p_index];
    return nullptr;
}

utf8String_t MultiColumnRowRange::name(const WorksheetProxy* p_worksheet, char32_t p_separator) const
{
    if (!m_ranges.empty()) {
        ranges_t::const_iterator w_it = m_ranges.begin();
        std::string w_result = (*w_it)->name(p_worksheet);

        while (++w_it != m_ranges.end()) {
            UtfString::UTF8::write(p_separator, std::back_inserter(w_result));
            w_result += (*w_it)->name(p_worksheet);
        }

        return w_result;
    }

    return "";
}

// -----------------------------------------------------------------------------
// CellPoint
// -----------------------------------------------------------------------------
CellPoint::CellPoint(const Cell& p_cell, unsigned long p_offsetX, unsigned long p_offsetY)
:   m_worksheet(p_cell.worksheet()),
    m_column(p_cell.column()),
    m_row(p_cell.row()),
    m_offsetX(p_offsetX),
    m_offsetY(p_offsetY)
{
}

CellPoint::CellPoint(const WorksheetProxy* p_worksheet, unsigned int p_column, unsigned int p_row, unsigned long p_offsetX, unsigned long p_offsetY)
:   m_worksheet(p_worksheet),
    m_column(p_column),
    m_row(p_row),
    m_offsetX(p_offsetX),
    m_offsetY(p_offsetY)
{
}

const WorksheetProxy* CellPoint::worksheet() const
{
    return m_worksheet;
}

unsigned int CellPoint::column() const
{
    return m_column;
}

unsigned int CellPoint::row() const
{
    return m_row;
}

unsigned long CellPoint::offsetX() const
{
    return m_offsetX;
}

unsigned long CellPoint::offsetY() const
{
    return m_offsetY;
}

long CellPoint::pixelToEMU(int p_pixel)
{
    return p_pixel * 914400 / 96;
}

int CellPoint::EMUToPixel(long p_emu)
{
    return p_emu * 96 / 914400;
}

// -----------------------------------------------------------------------------
// Parser
// -----------------------------------------------------------------------------
class InternalParser {
private:
//    RelativeRow           ::= R\(([+-]?[0-9]+)*\)
//    RelativeColumn        ::= C\(([+-]?[0-9]+)*\)
//
//    AbsoluteCell          ::= $?[A-Z]+$?[0-9]+
//    RCCell                ::= (R[0-9]+|{RelativeRow})({C[0-9]*}|{RelativeCol})
//    Cells                 ::= ({AbsoluteCell}(:{AbsoluteCell})?|{RCCell}(:{RCCell})?)
//
//    Rows                  ::= ($?[0-9]+(:$?[0-9]+)?|{RelativeRow}(:{RelativeRow})?)
//    Colums                ::= ($?[A-Z]+(:$?[A-Z]+)?|{RelativeColumn}(:{RelativeColumn})?)
//
//    SheetName             ::= .+
//
//    RowsRange             ::= ({SheetName}!|'{SheetName}'!)?{Rows}
//    MultiRowsRange        ::= {Rows}(,{Rows})*
//
//    ColumsRange           ::= ({SheetName}!|'{SheetName}'!)?{Columns}
//    MultiColumnsRange     ::= {ColumsRange}(,{ColumsRange})*
//
//    Range                 ::= ({SheetName}!|'{SheetName}'!)?{Cells}
//    MultiRange            ::= {Range}(,{Range})*

    template<class T>
    class Pointer {
    public:
        Pointer(T* p_pointer) : m_pointer(p_pointer) {}
        ~Pointer() { delete m_pointer; }

        void setNull() { m_pointer = nullptr; }

        T& operator *() { return *m_pointer; }
        T* operator ->() { return m_pointer; }
        operator T*&() { return m_pointer; }

    private:
        T* m_pointer;
    };

    class Indexes {
    public:
        Indexes(unsigned int p_index1, unsigned int p_index2, bool p_index1Locked, bool p_index2Locked)
        :   m_index1(p_index1, p_index1Locked),
            m_index2(p_index2, p_index2Locked)
        {
        }

        Indexes(const Indexes& p_indexes)
        :   m_index1(p_indexes.m_index1),
            m_index2(p_indexes.m_index2)
        {
        }

        const Index& index1() const { return m_index1; }
        const Index& index2() const { return m_index2; }

    private:
        Index m_index1;
        Index m_index2;
    };

    class CellIndexes : private Indexes {
    public:
        CellIndexes(unsigned int p_x, unsigned int p_y, bool p_xLocked, bool p_yLocked)
        :   Indexes(p_x, p_y, p_xLocked, p_yLocked)
        {
        }

        CellIndexes(const CellIndexes& p_cellIndexes)
        :   Indexes(p_cellIndexes.index1().index(), p_cellIndexes.index2().index(), p_cellIndexes.index1().isLocked(), p_cellIndexes.index2().isLocked())
        {
        }

        const Index& x() const { return index1(); }
        const Index& y() const { return index2(); }
    };

    class ParserTools {
    private:
        inline static unsigned char letterValue(char p_latinLetter)
        {
            if ((p_latinLetter >= 0x41) && (p_latinLetter <= 0x5A))
                return (p_latinLetter - 0x41);
            if ((p_latinLetter >= 0x61) && (p_latinLetter <= 0x7A))
                return (p_latinLetter - 0x61);
            return 0;
        }

    public:
        inline static bool isLatinLetter(char32_t p_character)
        {
            return  (   ((p_character >= 0x41) && (p_character <= 0x5A))
                    ||  ((p_character >= 0x61) && (p_character <= 0x7A))
                    );
        }

        inline static bool isLatinDigit(char32_t p_character)
        {
            return ((p_character >= 0x30) && (p_character <= 0x39));
        }

        inline static unsigned long indexFromColumnName(const utf8String_t& p_columnName, unsigned char& o_warnings)
        {
            if (p_columnName.empty()) {
                o_warnings |= Parser::wInvalidResult;
                return 0;
            }

            try {
                utf8String_t::const_reverse_iterator w_it = p_columnName.rbegin();
                unsigned long w_result = letterValue(*w_it);

                unsigned int w_power = 26;
                while (++w_it != p_columnName.rend()) {
                    w_result += ((letterValue(*w_it)+1) * w_power);
                    w_power *= 26;
                }

                return w_result;
            } catch (...) {
                o_warnings |= Parser::wInvalidResult;
                return 0;
            }
        }

        inline static unsigned long indexFromAbsoluteIndex(const utf8String_t& p_index, unsigned char& o_warnings)
        {
            const unsigned long k_result = strtoul(p_index.c_str(), nullptr, 10);

            if (!k_result) {
                o_warnings |= Parser::wInvalidResult;
                return 0;
            }
            return k_result - 1;
        }

        inline static unsigned long indexFromRelativeIndex(const utf8String_t& p_index, unsigned long p_reference, unsigned char& o_warnings)
        {
            const long k_diff = strtol(p_index.c_str(), nullptr, 10);

            unsigned long w_index = 0;
            if (k_diff + static_cast<long>(p_reference) >= 0)
                w_index = k_diff + p_reference;
            else
                o_warnings |= Parser::wInvalidResult;

            return w_index;
        }
    };

    class IteratorContext {
    public:
        IteratorContext(const IteratorContext& p_context)
        :   m_iterator(p_context.iterator()),
            m_warnings(p_context.warnings())
        {
        }

        IteratorContext(const utf8String_t::const_iterator& p_iterator, unsigned char p_warnings)
        :   m_iterator(p_iterator),
            m_warnings(p_warnings)
        {
        }

        inline IteratorContext& operator =(const IteratorContext& p_context) { m_iterator = p_context.iterator(); m_warnings = p_context.warnings(); return *this; }
        inline IteratorContext& operator ++() { UtfString::UTF8::seek(m_iterator); return *this; }
        inline IteratorContext& operator --() { UtfString::UTF8::seek(m_iterator, -1); return *this; }

        inline int unicodeDistance(const utf8String_t::const_iterator& p_begin) const { return static_cast<int>(UtfString::unicodeDistance<UtfString::UTF8>(p_begin, m_iterator)); }

        inline void addWarnings(unsigned char p_warnings) { m_warnings |= p_warnings; }

        inline unsigned char warnings() const { return m_warnings; }
        inline utf8String_t::const_iterator iterator() const { return m_iterator; }

    private:
        utf8String_t::const_iterator m_iterator;
        unsigned char m_warnings;
    };

    class ParserIterator {
    public:
        ParserIterator(const utf8String_t& p_coordinates, const WorkbookProxy* p_proxy)
        :   m_coordinates(p_coordinates),
            m_proxy(p_proxy),
            m_context( m_coordinates.begin(), (p_proxy) ? 0 : Parser::wWorkbookUnknown ),
            m_currentCharacter( (p_coordinates.empty() ? 0 : UtfString::UTF8::peak(m_context.iterator()) ))
        {
        }

//         inline const utf8String_t& coordinates() const
//         {
//             return m_coordinates;
//         }

//         inline unsigned int position() const
//         {
//             return m_context.iterator() - m_coordinates.begin();
//         }

        inline void refresh()
        {
            m_currentCharacter = UtfString::UJOCKER;
            if (!isEnd())
                m_currentCharacter = UtfString::UTF8::peak(m_context.iterator());
        }

//         inline const WorkbookProxy* proxy() const
//         {
//             return m_proxy;
//         }

        inline unsigned char warnings() const
        {
            return m_context.warnings();
        }

        inline void addWarnings(unsigned char p_warnings)
        {
            m_context.addWarnings(p_warnings);
        }

        inline char32_t operator *() const
        {
            return m_currentCharacter;
        }

        inline ParserIterator& operator ++()
        {
            ++m_context;
            refresh();
            return *this;
        }

        inline ParserIterator& operator --()
        {
            --m_context;
            refresh();
            return *this;
        }

        inline IteratorContext context() const
        {
            return m_context;
        }

        inline void setContext(const IteratorContext& p_context)
        {
            m_context = p_context;
            refresh();
        }

        inline int readCharacters() const
        {
            return m_context.unicodeDistance(m_coordinates.begin());
        }

        inline bool isEnd() const
        {
            return (m_context.iterator() == m_coordinates.end());
        }

        const WorksheetProxy* worksheet(const utf8String_t* p_sheetName)
        {
            if ((!m_proxy) || (!p_sheetName))
                return nullptr;

            const WorksheetProxy* k_worksheet = m_proxy->worksheet(*p_sheetName);
            if (!k_worksheet)
                m_context.addWarnings(Parser::wSheetNameUnknown);

            return k_worksheet;
        }

        const WorksheetProxy* selectedWorksheet() const
        {
            if (m_proxy)
                return m_proxy->selectedWorksheet();
            return nullptr;
        }

        CellIndexes activeCell(const WorksheetProxy* p_worksheet)
        {
            if (!p_worksheet)
                return CellIndexes(0, 0, true, true);

            const Cell* k_activeCell = p_worksheet->activeCell();

            if (!k_activeCell) {
                m_context.addWarnings(Parser::wInvalidResult);
                return CellIndexes(0, 0, true, true);
            }

            return CellIndexes(k_activeCell->column(), k_activeCell->row(), k_activeCell->columnIndex().isLocked(), k_activeCell->rowIndex().isLocked());
        }

    private:
        utf8String_t m_coordinates;
        const WorkbookProxy* m_proxy;

        IteratorContext m_context;
        char32_t m_currentCharacter;
    };


    static bool getAbsoluteCell(ParserIterator& o_iterator, CellIndexes*& o_indexes)
    {
        IteratorContext w_originContext = o_iterator.context();

        const unsigned char k_error = 0xFF;
        const unsigned char k_stop = 0xFE;
        const unsigned char k_final = 0x80;

        utf8String_t w_column = "";
        utf8String_t w_row = "";
        bool w_isRowLocked = false;
        bool w_isColumnLocked = false;

        unsigned char w_step = 0;
        while ((w_step < k_stop) && (!o_iterator.isEnd())) {
            switch (w_step) {
            case 0:
                if (*o_iterator == '$') {
                    w_isColumnLocked = true;
                    w_step = 1;
                } else if (ParserTools::isLatinLetter(*o_iterator)) {
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_column));
                    w_step = 2;
                } else
                    w_step = k_error;
                ++o_iterator;
                break;
            case 1:
                if (ParserTools::isLatinLetter(*o_iterator)) {
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_column));
                    w_step = 2;
                } else
                    w_step = k_error;
                ++o_iterator;
                break;
            case 2:
                if (*o_iterator == '$') {
                    w_isRowLocked = true;
                    w_step = 3;
                } else if (ParserTools::isLatinDigit(*o_iterator)) {
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_row));
                    w_step = k_final;
                } else if (ParserTools::isLatinLetter(*o_iterator))
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_column));
                else
                    w_step = k_error;
                ++o_iterator;
                break;
            case 3:
                if (ParserTools::isLatinDigit(*o_iterator)) {
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_row));
                    w_step = k_final;
                } else
                    w_step = k_error;
                ++o_iterator;
                break;
            case k_final:
                if (ParserTools::isLatinDigit(*o_iterator))
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_row));
                else
                    w_step = k_stop;
                ++o_iterator;
                break;
            default:
                w_step = k_error;
            }
        }

        o_indexes = nullptr;

        if ((w_step != k_final) && (w_step != k_stop)) {
            o_iterator.setContext(w_originContext);
            return false;
        }

        if (w_step == k_stop)
            --o_iterator;

        try {
            unsigned char w_warnings = 0;
            o_indexes = new CellIndexes(ParserTools::indexFromColumnName(w_column, w_warnings), ParserTools::indexFromAbsoluteIndex(w_row, w_warnings), w_isColumnLocked, w_isRowLocked);
            o_iterator.addWarnings(w_warnings);
        } catch (...) {
            o_iterator.setContext(w_originContext);
            delete o_indexes;
            o_indexes = nullptr;
            return false;
        }

        return true;
    }

    static bool getRCCell(ParserIterator& o_iterator, const CellIndexes& p_reference, CellIndexes*& o_indexes)
    {
        IteratorContext w_originContext = o_iterator.context();

        const unsigned char k_error = 0xFF;
        const unsigned char k_stop1 = 0xFE;
        const unsigned char k_stop2 = 0xFD;
        const unsigned char k_final1 = 0x80;
        const unsigned char k_final2 = 0x81;

        utf8String_t w_relativeRow = "";
        utf8String_t w_relativeColumn = "";
        utf8String_t w_row = "";
        utf8String_t w_column = "";

        unsigned char w_step = 0;
        while ((w_step < k_stop2) && (!o_iterator.isEnd())) {
            switch (w_step) {
            case 0:
                if ((*o_iterator == 'R') || (*o_iterator == 'r'))
                    w_step = 1;
                else
                    w_step = k_error;
                ++o_iterator;
                break;
            case 1:
                if (ParserTools::isLatinDigit(*o_iterator)) {
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_row));
                    w_step = 9;
                } else if (*o_iterator == '(')
                    w_step = 2;
                else
                    w_step = k_error;
                ++o_iterator;
                break;
            case 2:
                if ((*o_iterator == '+') || (*o_iterator == '-')) {
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_relativeRow));
                    w_step = 3;
                } else if (ParserTools::isLatinDigit(*o_iterator)) {
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_relativeRow));
                    w_step = 4;
                } else
                    w_step = k_error;
                ++o_iterator;
                break;
            case 3:
                if (ParserTools::isLatinDigit(*o_iterator)) {
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_relativeRow));
                    w_step = 4;
                } else
                    w_step = k_error;
                ++o_iterator;
                break;
            case 4:
                if (ParserTools::isLatinDigit(*o_iterator))
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_relativeRow));
                else if (*o_iterator == ')')
                    w_step = 5;
                else
                    w_step = k_error;
                ++o_iterator;
                break;
            case 5:
                if ((*o_iterator == 'C') || (*o_iterator == 'c'))
                    w_step = k_final1;
                else
                    w_step = k_error;
                ++o_iterator;
                break;
            case 6:
                if ((*o_iterator == '+') || (*o_iterator == '-')) {
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_relativeColumn));
                    w_step = 7;
                } else if (ParserTools::isLatinDigit(*o_iterator)) {
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_relativeColumn));
                    w_step = 8;
                } else
                    w_step = k_error;
                ++o_iterator;
                break;
            case 7:
                if (ParserTools::isLatinDigit(*o_iterator)) {
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_relativeColumn));
                    w_step = 8;
                } else
                    w_step = k_error;
                ++o_iterator;
                break;
            case 8:
                if (ParserTools::isLatinDigit(*o_iterator))
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_relativeColumn));
                else if (*o_iterator == ')')
                    w_step = k_stop2;
                else
                    w_step = k_error;
                ++o_iterator;
                break;
            case 9:
                if (ParserTools::isLatinDigit(*o_iterator))
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_row));
                else if ((*o_iterator == 'C') || (*o_iterator == 'c'))
                    w_step = k_final1;
                else
                    w_step = k_error;
                ++o_iterator;
                break;
            case k_final1:
                if (ParserTools::isLatinDigit(*o_iterator)) {
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_column));
                    w_step = k_final2;
                } else if (*o_iterator == '(')
                    w_step = 6;
                else
                    w_step = k_stop1;
                ++o_iterator;
                break;
            case k_final2:
                if (ParserTools::isLatinDigit(*o_iterator))
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_column));
                else
                    w_step = k_stop1;
                ++o_iterator;
                break;
            default:
                w_step = k_error;
            }
        }

        o_indexes = nullptr;

        if ((w_step != k_final1) && (w_step != k_final2) && (w_step != k_stop1) && (w_step != k_stop2)) {
            o_iterator.setContext(w_originContext);
            return false;
        }

        if (w_step == k_stop1)
            --o_iterator;

        try {
            unsigned char w_warnings = 0;

            unsigned int w_finalColumn = 0;
            if (w_relativeColumn != "")
                w_finalColumn = ParserTools::indexFromRelativeIndex(w_relativeColumn, p_reference.x().index(), w_warnings);
            else
                w_finalColumn = ParserTools::indexFromAbsoluteIndex(w_column, w_warnings);

            unsigned int w_finalRow = 0;
            if (w_relativeRow != "")
                w_finalRow = ParserTools::indexFromRelativeIndex(w_relativeRow, p_reference.y().index(), w_warnings);
            else
                w_finalRow = ParserTools::indexFromAbsoluteIndex(w_row, w_warnings);

            o_indexes = new CellIndexes(w_finalColumn, w_finalRow, false, false);

            o_iterator.addWarnings(w_warnings);
        } catch (...) {
            o_iterator.setContext(w_originContext);
            delete o_indexes;
            o_indexes = nullptr;
            return false;
        }

        return true;
    }

    static bool getCells(ParserIterator& o_iterator, const CellIndexes& p_reference, CellIndexes*& o_cell1, CellIndexes*& o_cell2)
    {
        IteratorContext w_originContext = o_iterator.context();

        o_cell1 = nullptr;
        o_cell2 = nullptr;

        if (getRCCell(o_iterator, p_reference, o_cell1)) {
            if (*o_iterator == ':') {
                ++o_iterator;
                if (!getRCCell(o_iterator, p_reference, o_cell2))
                    --o_iterator;
                return true;
            } else
                return true;
        } else if (getAbsoluteCell(o_iterator, o_cell1)) {
            if (*o_iterator == ':') {
                ++o_iterator;
                if (!getAbsoluteCell(o_iterator, o_cell2))
                    --o_iterator;
                return true;
            } else
                return true;
        }

        o_iterator.setContext(w_originContext);
        return false;
    }

    static bool getColumnsRows(ParserIterator& o_iterator, const CellIndexes& p_reference, Index::indexType_t p_type, Indexes*& o_indexes)
    {
        IteratorContext w_originContext = o_iterator.context();

        const unsigned char k_error = 0xFF;
        const unsigned char k_stop1 = 0xFE;
        const unsigned char k_stop2 = 0xFD;
        const unsigned char k_final1 = 0x80;
        const unsigned char k_final2 = 0x81;
        const unsigned char k_final3 = 0x82;
        const unsigned char k_final4 = 0x83;

        utf8String_t w_index1 = "";
        utf8String_t w_relativeIndex1 = "";
        utf8String_t w_index2 = "";
        utf8String_t w_relativeIndex2 = "";
        bool w_index1Locked = false;
        bool w_index2Locked = false;

        unsigned char w_step = 0;
        while ((w_step < k_stop2) && (!o_iterator.isEnd())) {
            switch (w_step) {
            case 0:
                if (*o_iterator == '$') {
                    w_index1Locked = true;
                    w_step = 1;
                } else if   (   ((p_type == Index::itRow) && ((*o_iterator == 'R') || (*o_iterator == 'r')))
                            ||  ((p_type == Index::itColumn) && ((*o_iterator == 'C') || (*o_iterator == 'c')))
                            ) {
                    w_step = k_final2;
                } else if   (   ((p_type == Index::itRow) && (ParserTools::isLatinDigit(*o_iterator)))
                            ||  ((p_type == Index::itColumn) && (ParserTools::isLatinLetter(*o_iterator)))
                            ) {
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_index1));
                    w_step = 2;
                } else
                    w_step = k_error;
                ++o_iterator;
                break;
            case 1:
                if  (    ((p_type == Index::itRow) && (ParserTools::isLatinDigit(*o_iterator)))
                    ||   ((p_type == Index::itColumn) && (ParserTools::isLatinLetter(*o_iterator)))
                    ) {
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_index1));
                    w_step = 2;
                } else
                    w_step = k_error;
                ++o_iterator;
                break;
            case 2:
                if  (    ((p_type == Index::itRow) && (ParserTools::isLatinDigit(*o_iterator)))
                    ||   ((p_type == Index::itColumn) && (ParserTools::isLatinLetter(*o_iterator)))
                    )
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_index1));
                else if (*o_iterator == ':')
                    w_step = 3;
                else
                    w_step = k_error;
                ++o_iterator;
                break;
            case 3:
                if (*o_iterator == '$') {
                    w_index2Locked = true;
                    w_step = 4;
                } else if   (   ((p_type == Index::itRow) && (ParserTools::isLatinDigit(*o_iterator)))
                            ||   ((p_type == Index::itColumn) && (ParserTools::isLatinLetter(*o_iterator)))
                            ) {
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_index2));
                    w_step = k_final1;
                } else
                    w_step = k_error;
                ++o_iterator;
                break;
            case 4:
                if  (    ((p_type == Index::itRow) && (ParserTools::isLatinDigit(*o_iterator)))
                    ||   ((p_type == Index::itColumn) && (ParserTools::isLatinLetter(*o_iterator)))
                    ) {
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_index2));
                    w_step = k_final1;
                } else
                    w_step = k_error;
                ++o_iterator;
                break;
            case 5:
                if ((*o_iterator == '+') || (*o_iterator == '-')) {
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_relativeIndex1));
                    w_step = 6;
                } else if (ParserTools::isLatinDigit(*o_iterator)) {
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_relativeIndex1));
                    w_step = 7;
                } else
                    w_step = k_error;
                ++o_iterator;
                break;
            case 6:
                if (ParserTools::isLatinDigit(*o_iterator)) {
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_relativeIndex1));
                    w_step = 7;
                } else
                    w_step = k_error;
                ++o_iterator;
                break;
            case 7:
                if (ParserTools::isLatinDigit(*o_iterator))
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_relativeIndex1));
                else if (*o_iterator == ')')
                    w_step = k_final3;
                else
                    w_step = k_error;
                ++o_iterator;
                break;
            case 8:
                if  (   ((p_type == Index::itRow) && ((*o_iterator == 'R') || (*o_iterator == 'r')))
                    ||  ((p_type == Index::itColumn) && ((*o_iterator == 'C') || (*o_iterator == 'c')))
                    )
                    w_step = k_final4;
                else
                    w_step = k_error;
                ++o_iterator;
                break;
            case 9:
                if ((*o_iterator == '+') || (*o_iterator == '-')) {
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_relativeIndex2));
                    w_step = 10;
                } else if (ParserTools::isLatinDigit(*o_iterator)) {
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_relativeIndex2));
                    w_step = 11;
                } else
                    w_step = k_error;
                ++o_iterator;
                break;
            case 10:
                if (ParserTools::isLatinDigit(*o_iterator)) {
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_relativeIndex2));
                    w_step = 11;
                } else
                    w_step = k_error;
                ++o_iterator;
                break;
            case 11:
                if (ParserTools::isLatinDigit(*o_iterator))
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_relativeIndex2));
                else if (*o_iterator == ')')
                    w_step = k_stop2;
                else
                    w_step = k_error;
                ++o_iterator;
                break;
            case k_final1:
                if  (    ((p_type == Index::itRow) && (ParserTools::isLatinDigit(*o_iterator)))
                    ||   ((p_type == Index::itColumn) && (ParserTools::isLatinLetter(*o_iterator)))
                    )
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_index2));
                else
                    w_step = k_stop1;
                ++o_iterator;
                break;
            case k_final2:
                if ((p_type == Index::itColumn) && (ParserTools::isLatinLetter(*o_iterator))) {
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_index1));
                    w_step = 2;
                } else if (*o_iterator == '(')
                    w_step = 5;
                else
                    w_step = k_stop1;
                ++o_iterator;
                break;
            case k_final3:
                if (*o_iterator == ':')
                    w_step = 8;
                else
                    w_step = k_stop1;
                ++o_iterator;
                break;
            case k_final4:
                if (*o_iterator == '(')
                    w_step = 9;
                else
                    w_step = k_stop1;
                ++o_iterator;
                break;
            default:
                w_step = k_error;
            }
        }

        o_indexes = nullptr;

        if ((w_step != k_final1) && (w_step != k_final2) && (w_step != k_final3) && (w_step != k_final4) && (w_step != k_stop1) && (w_step != k_stop2)) {
            o_iterator.setContext(w_originContext);
            return false;
        }

        if (w_step == k_stop1)
            --o_iterator;

        try {
            unsigned char w_warnings = 0;

            const unsigned int k_reference = ((p_type == Index::itColumn) ? p_reference.x().index() : p_reference.y().index());

            unsigned int w_finalIndex1 = 0;
            if (w_index1 != "") {
                if (p_type == Index::itColumn)
                    w_finalIndex1 = ParserTools::indexFromColumnName(w_index1, w_warnings);
                else
                    w_finalIndex1 = ParserTools::indexFromAbsoluteIndex(w_index1, w_warnings);
            } else
                w_finalIndex1 = ParserTools::indexFromRelativeIndex(w_relativeIndex1, k_reference, w_warnings);

            unsigned int w_finalIndex2 = w_finalIndex1;
            if (w_index2 != "") {
                if (p_type == Index::itColumn)
                    w_finalIndex2 = ParserTools::indexFromColumnName(w_index2, w_warnings);
                else
                    w_finalIndex2 = ParserTools::indexFromAbsoluteIndex(w_index2, w_warnings);
            } else if (w_relativeIndex2 != "")
                w_finalIndex2 = ParserTools::indexFromRelativeIndex(w_relativeIndex2, k_reference, w_warnings);

            o_indexes = new Indexes(w_finalIndex1, w_finalIndex2, w_index1Locked, w_index2Locked);

            o_iterator.addWarnings(w_warnings);
        } catch (...) {
            o_iterator.setContext(w_originContext);
            delete o_indexes;
            o_indexes = nullptr;
            return false;
        }

        return true;
    }

    static bool getSheetName(ParserIterator& o_iterator, utf8String_t*& o_sheetName)
    {
        IteratorContext w_originContext = o_iterator.context();

        const unsigned char k_error = 0xFF;
        const unsigned char k_final = 0x80;

        utf8String_t w_sheetName = "";

        unsigned char w_step = 0;
        while ((w_step < k_final) && (!o_iterator.isEnd())) {
            switch (w_step) {
            case 0:
                if (*o_iterator == '\'') {
                    w_step = 1;
                    ++o_iterator;
                } else if (!Unicode::isSpace(*o_iterator) && (*o_iterator != ','))
                    w_step = 3;
                else
                    w_step = k_error;
                break;
            case 1:
                if (*o_iterator == '\'')
                    w_step = 2;
                else
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_sheetName));
                ++o_iterator;
                break;
            case 2:
                if (*o_iterator == '\'') {
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_sheetName));
                    w_step = 1;
                } else if (*o_iterator == '!')
                    w_step = k_final;
                else
                    w_step = k_error;
                ++o_iterator;
                break;
            case 3:
                if (*o_iterator == '!')
                    w_step = k_final;
                else if (!Unicode::isSpace(*o_iterator) && (*o_iterator != ','))
                    UtfString::UTF8::write(*o_iterator, std::back_inserter(w_sheetName));
                else
                    w_step = k_error;
                ++o_iterator;
                break;
            default:
                w_step = k_error;
            }
        }

        o_sheetName = nullptr;

        if (w_step != k_final) {
            o_iterator.setContext(w_originContext);
            return false;
        }

        try {
            o_sheetName = new utf8String_t(w_sheetName);
        } catch (...) {
            o_iterator.setContext(w_originContext);
            delete o_sheetName;
            o_sheetName = nullptr;
            return false;
        }

        return true;
    }

    class Utf8StringWrapper {
    public:
        Utf8StringWrapper() : m_utf8String(nullptr) { }
        ~Utf8StringWrapper() { delete m_utf8String; }

        bool operator !() const { return (m_utf8String != nullptr); }
        operator utf8String_t*&() { return m_utf8String; }

    private:
        utf8String_t* m_utf8String;
    };

    static bool getMultiCellRange(ParserIterator& o_iterator, char32_t p_separator, MultiCellRange*& o_multiCellRange)
    {
        IteratorContext w_originContext = o_iterator.context();
        IteratorContext w_lastOkContext = w_originContext;

        bool w_ok = false;
        o_multiCellRange = new MultiCellRange();
        try {
            bool w_continue = false;
            do {
                Utf8StringWrapper w_sheetName;
                getSheetName(o_iterator, w_sheetName);
                const WorksheetProxy* w_worksheet = (!w_sheetName ? o_iterator.worksheet(w_sheetName) : o_iterator.selectedWorksheet());

                Pointer<CellIndexes> w_cell1(nullptr);
                Pointer<CellIndexes> w_cell2(nullptr);
                w_ok = getCells(o_iterator, o_iterator.activeCell(w_worksheet), w_cell1, w_cell2);

                w_continue = false;
                if (w_ok) {
                    if (!w_cell2)
                        o_multiCellRange->addRange( Cell(w_worksheet, w_cell1->x(), w_cell1->y()) );
                    else
                        o_multiCellRange->addRange( CellRange(w_worksheet, w_cell1->x(), w_cell1->y(), w_cell2->x(), w_cell2->y()) );
                    w_lastOkContext = o_iterator.context();

                    if ((!o_iterator.isEnd()) && (*o_iterator == p_separator)) {
                        ++o_iterator;
                        w_continue = true;
                    }
                }
            } while (w_continue);
        } catch (...) {
            o_iterator.setContext(w_originContext);
            delete o_multiCellRange;
            o_multiCellRange = nullptr;
            return false;
        }

        if (w_ok)
            return true;

        o_iterator.setContext(w_lastOkContext);
        if (w_lastOkContext.iterator() == w_originContext.iterator()) {
            delete o_multiCellRange;
            o_multiCellRange = nullptr;
            return false;
        }
        return true;
    }

    static bool getSelectedMultiColumnRowRange(ParserIterator& o_iterator, Index::indexType_t p_type, char32_t p_separator, MultiColumnRowRange*& o_multiColumnRowRange)
    {
        IteratorContext w_originContext = o_iterator.context();
        IteratorContext w_lastOkContext = w_originContext;

        bool wOk = false;

        o_multiColumnRowRange = new MultiColumnRowRange(p_type);
        try {
            bool w_continue = false;
            do {
                Utf8StringWrapper w_sheetName;
                getSheetName(o_iterator, w_sheetName);
                const WorksheetProxy* w_worksheet = o_iterator.worksheet(w_sheetName);

                Pointer<Indexes> w_columnsRows(nullptr);
                wOk = getColumnsRows(o_iterator, o_iterator.activeCell(w_worksheet), p_type, w_columnsRows);

                w_continue = false;
                if (wOk) {
                    o_multiColumnRowRange->addRange( ColumnRowRange(p_type, w_worksheet, w_columnsRows->index1(), w_columnsRows->index2()) );
                    w_lastOkContext = o_iterator.context();

                    if ((!o_iterator.isEnd()) && (*o_iterator == p_separator)) {
                        ++o_iterator;
                        w_continue = true;
                    }
                }
            } while (w_continue);
        } catch (...) {
            o_iterator.setContext(w_originContext);
            delete o_multiColumnRowRange;
            o_multiColumnRowRange = nullptr;
            return false;
        }

        if (wOk)
            return true;

        o_iterator.setContext(w_lastOkContext);
        if (w_lastOkContext.iterator() == w_originContext.iterator()) {
            delete o_multiColumnRowRange;
            o_multiColumnRowRange = nullptr;
            return false;
        }
        return true;
    }

    static bool getMultiColumnRowRange(ParserIterator& o_iterator, char32_t p_separator, MultiColumnRowRange*& o_multiColumnRowRange)
    {
        o_multiColumnRowRange = nullptr;

        IteratorContext w_originContext = o_iterator.context();

        Pointer<MultiColumnRowRange> w_multiColumnRange(nullptr);
        bool w_result = getSelectedMultiColumnRowRange(o_iterator, Index::itColumn, p_separator, w_multiColumnRange);

        if ((!w_result) || (!o_iterator.isEnd())) {
            IteratorContext w_endColumnContext = o_iterator.context();
            o_iterator.setContext( w_originContext );

            Pointer<MultiColumnRowRange> w_multiRowRange(nullptr);
            w_result = getSelectedMultiColumnRowRange(o_iterator, Index::itRow, p_separator, w_multiRowRange);

            if (w_result) {
                if (o_iterator.isEnd() || (o_iterator.context().iterator() >= w_endColumnContext.iterator())) {
                    o_multiColumnRowRange = w_multiRowRange;
                    w_multiRowRange.setNull();
                } else  {
                    o_multiColumnRowRange = w_multiColumnRange;
                    w_multiColumnRange.setNull();
                    o_iterator.setContext(w_endColumnContext);
                }
            }
        } else {
            o_multiColumnRowRange = w_multiColumnRange;
            w_multiColumnRange.setNull();
        }

        return w_result;
    }

public:
    static bool parse(const utf8String_t& p_coordinates, const WorkbookProxy* p_proxy, char32_t p_separator, unsigned char& o_warnings, unsigned int& o_read, Parser::coordType_t& o_type, void*& o_coordinates)
    {
        o_type = Parser::ctNull;
        o_coordinates = nullptr;
        o_warnings = 0;
        o_read = 0;

        ParserIterator w_iterator(p_coordinates, p_proxy);

        Pointer<MultiCellRange> w_multiCellRange(nullptr);
        if (getMultiCellRange(w_iterator, p_separator, w_multiCellRange)) {
            switch (w_multiCellRange->rangeCount()) {
            case 0:
                break;
            case 1: {
                const CellRange* k_range = w_multiCellRange->range(0);
                if (k_range->isCell()) {
                    o_type = Parser::ctCell;
                    o_coordinates = new Cell( k_range->topLeft() );
                } else {
                    o_type = Parser::ctCellRange;
                    o_coordinates = new CellRange( *k_range );
                }
                break;
                }
            default:
                o_type = Parser::ctMultiCellRange;
                o_coordinates = new MultiCellRange( *w_multiCellRange );
                break;
            }

            o_warnings |= w_iterator.warnings();
            if (!w_iterator.isEnd())
                o_warnings |= Parser::wIncompleteParse;
            o_read = w_iterator.readCharacters();
            return true;
        }

        Pointer<MultiColumnRowRange> w_multiColumnRowRange(nullptr);
        if (getMultiColumnRowRange(w_iterator, p_separator, w_multiColumnRowRange)) {
            switch (w_multiColumnRowRange->rangeCount()) {
            case 0:
                break;
            case 1: {
                const ColumnRowRange* k_range = w_multiColumnRowRange->range(0);
                if (k_range->isColumRow()) {
                    o_type = Parser::ctColumnRow;
                    o_coordinates = new ColumnRow( k_range->type(), k_range->worksheet(), k_range->firstIndex() );
                } else {
                    o_type = Parser::ctColumnRowRange;
                    o_coordinates = new ColumnRowRange( *k_range );
                }
                break;
                }
            default:
                o_type = Parser::ctMultiColumnRowRange;
                o_coordinates = new MultiColumnRowRange( *w_multiColumnRowRange );
                break;
            }

            o_warnings |= w_iterator.warnings();
            if (!w_iterator.isEnd())
                o_warnings |= Parser::wIncompleteParse;
            o_read = w_iterator.readCharacters();
            return true;
        }

        return false;
    }
};

// -----------------------------------------------------------------------------
// Parser
// -----------------------------------------------------------------------------
Parser::Parser(const utf8String_t& p_coordinates, const WorkbookProxy* p_proxy, char32_t p_separator)
:   m_parseResult(false),
    m_warnings(0),
    m_read(0),
    m_type(ctNull),
    m_coordinates(nullptr)
{
    m_parseResult = InternalParser::parse(p_coordinates, p_proxy, p_separator, m_warnings, m_read, m_type, m_coordinates);
}

Parser::~Parser()
{
    switch (m_type) {
    case ctNull:
        break;
    case ctCell:
        delete static_cast<Cell*>(m_coordinates);
        break;
    case ctCellRange:
        delete static_cast<CellRange*>(m_coordinates);
        break;
    case ctMultiCellRange:
        delete static_cast<MultiCellRange*>(m_coordinates);
        break;
    case ctColumnRow:
        delete static_cast<ColumnRow*>(m_coordinates);
        break;
    case ctColumnRowRange:
        delete static_cast<ColumnRowRange*>(m_coordinates);
        break;
    case ctMultiColumnRowRange:
        delete static_cast<MultiColumnRowRange*>(m_coordinates);
        break;
    }
}

bool Parser::parseResult() const
{
    return m_parseResult;
}

unsigned char Parser::warnings() const
{
    return m_warnings;
}

unsigned int Parser::readCharacters() const
{
    return m_read;
}

Parser::coordType_t Parser::type() const
{
    return m_type;
}

const Cell* Parser::cell() const
{
    if (m_type == ctCell)
        return static_cast<Cell*>(m_coordinates);
    return nullptr;
}

const CellRange* Parser::cellRange() const
{
    if (m_type == ctCellRange)
        return static_cast<CellRange*>(m_coordinates);
    return nullptr;
}

const MultiCellRange* Parser::multiCellRange() const
{
    if (m_type == ctMultiCellRange)
        return static_cast<MultiCellRange*>(m_coordinates);
    return nullptr;
}

const ColumnRow* Parser::columnRow() const
{
    if (m_type == ctColumnRow)
        return static_cast<ColumnRow*>(m_coordinates);
    return nullptr;
}

const ColumnRowRange* Parser::columnRowRange() const
{
    if (m_type == ctColumnRowRange)
        return static_cast<ColumnRowRange*>(m_coordinates);
    return nullptr;
}

const MultiColumnRowRange* Parser::multiColumnRowRange() const
{
    if (m_type == ctMultiColumnRowRange)
        return static_cast<MultiColumnRowRange*>(m_coordinates);
    return nullptr;
}

} // namespace Coordinates
} // namespace XLSX
} // namespace Invoke
