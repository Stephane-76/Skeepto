/*!
 * \file        WorkbookInterface.cpp
 * \author      Invoke - Jean-Christophe PHILIPPE (jcphilippe\@invoke.fr)
 * \date        Juin 2015
 * \copyright   SA Invoke
 */

#include <iostream>
#include <iomanip>
#include <sstream>

#include "xlsx/WorkbookInterface.hpp"
#include "xlsx/Coordinates.hpp"
#include "string/Unicode.hpp"
#include "string/UtfString.hpp"

namespace Invoke {
namespace XLSX {
namespace Interface {

utf8String_t code(headerFooterConstant_t p_constant)
{
    switch (p_constant) {
    case hfcPage:
        return "&P";
    case hfcPages:
        return "&N";
    case hfcDate:
        return "&D";
    case hfcTime:
        return "&T";
    case hfcPath:
        return "&Z";
    case hfcFile:
        return "&F";
    case hfcSheet:
        return "&A";
    default:
        return "";
    }
}

utf8String_t headerFooterFontCode(const utf8String_t& p_name, unsigned short p_size, color_t p_color)
{
    std::stringstream w_stream;
    if (p_name != "")
        w_stream << "&\"" << p_name << "\"";
    if (p_size != 0)
        w_stream << "&" << p_size;
    if (p_color & 0xFF000000)
        w_stream << "&K" << std::hex << std::setw(6) << std::setfill('0') << std::uppercase << (p_color & 0xFFFFFF);
    return w_stream.str();
}

bool isDefinedNameValid(const utf8String_t& p_name)
{
    // NON : chaîne vide
    if (p_name.empty())
        return false;

    // NON : commence par un chiffre
    utf8String_t::const_iterator w_it = p_name.begin();
    if (Unicode::isDigit(UtfString::UTF8::read(w_it)))
        return false;

    // NON : (L|l|C|c)[0-9]+.*
    w_it = p_name.begin();
    if (w_it != p_name.end()) {
        const char32_t k_char = UtfString::UTF8::read(w_it);
        if  (   (  (k_char == 'L')
                || (k_char == 'l') 
                || (k_char == 'C')
                || (k_char == 'c')
                ) 
            &&  (w_it != p_name.end())
            )
            if (Unicode::isDigit(UtfString::UTF8::read(w_it)))
                return false;
    }

    // NON : nom contenant des caractères autres que des lettres
    w_it = p_name.begin();
    if (w_it != p_name.end()) {
        bool w_valid = true;
        do {
            const char32_t k_char = UtfString::UTF8::read(w_it);
            w_valid = (Unicode::isLetter(k_char) || Unicode::isDigit(k_char)) || (k_char == '_');
        } while (w_valid && (w_it != p_name.end()));

        if (!w_valid)
            return false;
    }

    // NON : nom de cellule
    Coordinates::Parser w_parser(p_name, nullptr);
    if (w_parser.parseResult() && (w_parser.readCharacters() == p_name.length()))
        return false;

    return true;
}

utf8String_t correctDefinedName(const utf8String_t& p_name)
{
    utf8String_t w_result = "";

    utf8String_t::const_iterator w_it = p_name.begin();
    while (w_it != p_name.end()) {
        const char32_t k_char = UtfString::UTF8::read(w_it);
        if (Unicode::isLetter(k_char) || Unicode::isDigit(k_char))
            UtfString::UTF8::write(k_char, std::back_inserter(w_result));
        else
            UtfString::UTF8::write('_', std::back_inserter(w_result));
    }

    w_it = w_result.begin();
    bool w_addPrefix = ((w_result == "") || (Unicode::isDigit(UtfString::UTF8::read(w_it))));

    if (!w_addPrefix) {
        w_it = w_result.begin();
        if (w_it != w_result.end()) {
            const char32_t k_char = UtfString::UTF8::read(w_it);
            if  (  (  (k_char == 'L') 
                   || (k_char == 'l')
                   || (k_char == 'C')
                   || (k_char == 'c')
                   ) 
                && (w_it != w_result.end())
                )
                w_addPrefix = (Unicode::isDigit(UtfString::UTF8::read(w_it)));
        }
    }

    if (!w_addPrefix) {
        Coordinates::Parser w_parser(w_result, nullptr);
        w_addPrefix = (w_parser.parseResult() && (w_parser.readCharacters() == w_result.length()));
    }

    return (w_addPrefix ? "_"+ w_result : w_result);
}

std::string stringImageType(imageType_t p_type)
{
    switch (p_type) {
    case itJPG: return "jpg";
    case itGIF: return "gif";
    case itPNG: return "png";
    case itBMP: return "bmp";
    default:    return "";
    }
}

bool getImageProperties(const unsigned char* const p_memory, const unsigned int p_memorySize, imageType_t& o_type, unsigned int& o_width, unsigned int& o_height)
{
    // cf. http://www.cplusplus.com/forum/beginner/45217/ (+BMP)

    o_type = itUnknown;
    o_width = 0;
    o_height = 0;

    // Strategy:
    // reading GIF:  dimensions requires the first 10 bytes of the file
    // reading PNG:  dimensions requires the first 24 bytes of the file
    // reading JPEG: dimensions requires scanning through jpeg chunks
    // reading BMP:  dimensions requires the first 26 bytes of the file
    // In all formats, the file is at least 26 bytes big.

    if  (   (!p_memory)
        ||  (p_memorySize < 26)
        )
        return false;

    const unsigned char* w_read = p_memory;

    // .. JPEG .................................................................
    // for JPEGs, we need to read the first bytes of each chunk.
    if  (   (w_read[0] == 0xFF)
        &&  (w_read[1] == 0xD8)
        &&  (w_read[2] == 0xFF)
        &&  (w_read[3] == 0xE0)
        &&  (w_read[6] == 'J')
        &&  (w_read[7] == 'F')
        &&  (w_read[8] == 'I')
        &&  (w_read[9] == 'F')
        ) {

        unsigned char const * const k_end = p_memory + p_memorySize;

        w_read += 2;
        while   (   ((w_read + 4) < k_end)
                &&  (w_read[0] == 0xFF)
                &&  (w_read[1] != 0xC0)
                &&  (w_read[1] != 0xC1)
                &&  (w_read[1] != 0xC2)
                &&  (w_read[1] != 0xC3)
                &&  (w_read[1] != 0xC9)
                &&  (w_read[1] != 0xCA)
                &&  (w_read[1] != 0xCB)
                )
            w_read += (w_read[2] << 8) + w_read[3] + 2;

        // buffer is the DCT frame.
        if  (   ((w_read + 9) < k_end)
            &&  (w_read[0] == 0xFF)
            ) {

            o_type = itJPG;
            o_height = (w_read[5] << 8) + w_read[6];
            o_width = (w_read[7] << 8) + w_read[8];

            return true;
        }
    }

    // .. GIF ..................................................................
    // first three bytes say "GIF", next three give version number. Then dimensions.
    if  (   (w_read[0] == 'G')
        &&  (w_read[1] == 'I')
        &&  (w_read[2] == 'F')
        ) {

        o_type = itGIF;
        o_width = w_read[6] + (w_read[7] << 8);
        o_height = w_read[8] + (w_read[9] << 8);

        return true;
    }

    // .. PNG ..................................................................
    // the first frame is by definition an IHDR frame, which gives dimensions.
    if  (   (w_read[0] == 0x89)
        &&  (w_read[1] == 'P')
        &&  (w_read[2] == 'N')
        &&  (w_read[3] == 'G')
        &&  (w_read[4] == 0x0D)
        &&  (w_read[5] == 0x0A)
        &&  (w_read[6] == 0x1A)
        &&  (w_read[7] == 0x0A)
        &&  (w_read[12] == 'I')
        &&  (w_read[13] == 'H')
        &&  (w_read[14] == 'D')
        &&  (w_read[15] == 'R')
        ) {

        o_type = itPNG;
        o_width = (w_read[16] << 24) + (w_read[17] << 16) + (w_read[18] << 8) + w_read[19];
        o_height = (w_read[20] << 24) + (w_read[21] << 16) + (w_read[22] << 8) + w_read[23];

        return true;
    }

    // .. BMP ..................................................................
    // first two bytes is say "BM", next sixteen give informations. Then dimensions.
    if  (   (w_read[0] == 'B')
        &&  (w_read[1] == 'M')
        ) {

        o_type = itBMP;
        o_width = w_read[18] + (w_read[19] << 8) + (w_read[20] << 16) + (w_read[21] << 24);
        o_height = w_read[22] + (w_read[23] << 8) + (w_read[24] << 16) + (w_read[25] << 24);

        return true;
    }

    return false;
}

bool operator ==(const font_t& p_font1, const font_t& p_font2)
{
	return  (   (p_font1.name == p_font2.name)
            &&  (p_font1.size == p_font2.size)
            &&  (p_font1.color == p_font2.color)
            &&  (p_font1.bold == p_font2.bold)
            &&	(p_font1.italic == p_font2.italic)
            &&  (p_font1.underline == p_font2.underline)
            );
}

} // namespace Interface
} // namespace XLSX
} // namespace Invoke
