/*!
 * \file        XlsxWriter.cpp
 * \author      Invoke - Jean-Christophe PHILIPPE (jcphilippe\@invoke.fr)
 * \date        Octobre 2014
 * \copyright   SA Invoke
 */

#include "xlsx/XlsxWriter.hpp"
#include "string/UtfString.hpp"
#include "string/Unicode.hpp"

#include <iterator>
#include <algorithm>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cstring>
#include <map>

#if defined(_WIN32)
#define NOMINMAX
#include <windows.h>
#endif

#if defined(INVOKE_XLSX_LOGS)
#include "xlsx/SimpleWorkbook.hpp"
#include "xlsx/XlsxDebug.hpp"
#define LOGS_MESSAGE(__message__)       Invoke::XLSX::Debug::Logs::get().message(__message__);
#define LOGS_STARTCHRONO(__message__)   Invoke::XLSX::Debug::Logs::get().startChrono(__message__);
#define LOGS_STOPCHRONO                 Invoke::XLSX::Debug::Logs::get().stopChrono();
#define LOGS_CHECKMEMORY                Invoke::XLSX::Debug::Logs::get().checkMemory();
#else
#define LOGS_MESSAGE(__message__)
#define LOGS_STARTCHRONO(__message__)
#define LOGS_STOPCHRONO
#define LOGS_CHECKMEMORY
#endif

namespace Invoke {
namespace XLSX {

class StreamWrapper {
public:
    StreamWrapper()
    :   m_stream(nullptr)
    { }

    ~StreamWrapper()
    {
        delete m_stream;
    }

    void clear()
    {
        delete m_stream;
        m_stream = nullptr;
    }

    StreamWrapper& operator =(std::istream* p_stream)
    {
        delete m_stream;
        m_stream = p_stream;
        return *this;
    }

    operator std::istream*() const
    {
        return m_stream;
    }

private:
    std::istream* m_stream;
};

std::string Writer::doubleToString(double p_number)
{
    std::ostringstream w_oss;
    w_oss.precision(std::numeric_limits<double>::digits10);
    w_oss << p_number;
    std::string w_string = w_oss.str();

    return w_string;
}

std::string Writer::textToXML(const std::string& p_string)
{
    std::string w_result = p_string;

    std::string::size_type w_pos = w_result.find('&', 0);
    while (w_pos != std::string::npos) {
        w_result.replace(w_pos, 1, "&amp;");
        w_pos = w_result.find('&', w_pos+5);
    }

    w_pos = w_result.find('>', 0);
    while (w_pos != std::string::npos) {
        w_result.replace(w_pos, 1, "&gt;");
        w_pos = w_result.find('>', w_pos+4);
    }

    w_pos = w_result.find('<', 0);
    while (w_pos != std::string::npos) {
        w_result.replace(w_pos, 1, "&lt;");
        w_pos = w_result.find('<', w_pos+4);
    }

    return w_result;
}

std::string Writer::textToXMLAttribute(const std::string& p_string)
{
    std::string w_result = p_string;

    std::string::size_type w_pos = w_result.find('&', 0);
    while (w_pos != std::string::npos) {
        w_result.replace(w_pos, 1, "&amp;");
        w_pos = w_result.find('&', w_pos+5);
    }

    w_pos = w_result.find('"', 0);
    while (w_pos != std::string::npos) {
        w_result.replace(w_pos, 1, "&quot;");
        w_pos = w_result.find('"', w_pos+6);
    }

    w_pos = w_result.find('>', 0);
    while (w_pos != std::string::npos) {
        w_result.replace(w_pos, 1, "&gt;");
        w_pos = w_result.find('>', w_pos+4);
    }

    w_pos = w_result.find('<', 0);
    while (w_pos != std::string::npos) {
        w_result.replace(w_pos, 1, "&lt;");
        w_pos = w_result.find('<', w_pos+4);
    }

    return w_result;
}

std::string Writer::colorToXML(Interface::color_t p_color)
{
	std::stringstream w_result;
	w_result << "FF"
		<< std::hex << std::setw(6) << std::setfill('0') << std::uppercase
		<< (p_color & 0xFFFFFF);

	return w_result.str();
}

std::istream* Writer::createContentTypes(const Interface::Read::Workbook* p_workbook, const ListValidationParams& p_listValidationsParams)
{
    std::stringstream* w_result = new std::stringstream;
    try {
        *w_result <<            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                                    "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                                    "<Default Extension=\"bin\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.printerSettings\"/>"
                                    "<Default Extension=\"jpg\" ContentType=\"image/jpeg\"/>"
                                    "<Default Extension=\"gif\" ContentType=\"image/gif\"/>"
                                    "<Default Extension=\"png\" ContentType=\"image/png\"/>"
                                    "<Default Extension=\"bmp\" ContentType=\"image/bmp\"/>";

        if ((p_workbook) && (p_workbook->worksheetCount())) {
            unsigned int w_iWorksheet = 0;
            while ((w_iWorksheet < p_workbook->worksheetCount()) && (p_workbook->worksheet(w_iWorksheet)->commentCount() == 0)) 
                ++w_iWorksheet;
            if (w_iWorksheet < p_workbook->worksheetCount())
                *w_result <<        "<Default Extension=\"vml\" ContentType=\"application/vnd.openxmlformats-officedocument.vmlDrawing\"/>";
        }

        *w_result <<                "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>"
                                    "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
                                    "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
                                    "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>"
                                    "<Override PartName=\"/docProps/app.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.extended-properties+xml\"/>";

        if ((p_workbook) && (p_workbook->worksheetCount())) {
            for (unsigned int w_iWorksheet = 0; w_iWorksheet < p_workbook->worksheetCount(); ++w_iWorksheet) {
                *w_result <<        "<Override PartName=\"/xl/worksheets/sheet" << w_iWorksheet+1 << ".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>";

                if (p_workbook->worksheet(w_iWorksheet)->containsValidImages())
                    *w_result <<    "<Override PartName=\"/xl/drawings/drawing" << w_iWorksheet+1 << ".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.drawing+xml\"/>";

                if (p_workbook->worksheet(w_iWorksheet)->commentCount() > 0)
                    *w_result <<    "<Override PartName=\"/xl/comments" << w_iWorksheet+1 << ".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.comments+xml\"/>";
            }

            if (p_listValidationsParams.isExist())
                *w_result <<        "<Override PartName=\"/xl/worksheets/sheet" << p_listValidationsParams.id() << ".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>";


        } else
            *w_result <<            "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>";

        *w_result <<                "<Override PartName=\"/xl/sharedStrings.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml\"/>"
                                    "<Override PartName=\"/docProps/core.xml\" ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/>"
                                "</Types>";
    } catch (...) {
        delete w_result;
        throw;
    }

    return w_result;
}

std::istream* Writer::createRels()
{
    std::stringstream* w_result = new std::stringstream;
    try {
        *w_result <<    "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                        "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                            "<Relationship Id=\"rId3\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties\" Target=\"docProps/app.xml\"/>"
                            "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties\" Target=\"docProps/core.xml\"/>"
                            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>"
                        "</Relationships>";
    } catch (...) {
        delete w_result;
        throw;
    }

    return w_result;
}

std::istream* Writer::createApp(const Interface::Read::Workbook* p_workbook, const ListValidationParams& p_listValidationsParams)
{
    const size_t k_worksheetCount = (((p_workbook) && (p_workbook->worksheetCount())) ? p_workbook->worksheetCount() : 1) + (p_listValidationsParams.isExist() ? 1 : 0);

    std::stringstream* w_result = new std::stringstream;
    try {
        *w_result <<    "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                        "<Properties xmlns=\"http://schemas.openxmlformats.org/officeDocument/2006/extended-properties\" xmlns:vt=\"http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes\">"
                            "<Application>Microsoft Excel</Application>" // ne pas changer !
                            "<DocSecurity>0</DocSecurity>"
                            "<ScaleCrop>false</ScaleCrop>"
                            "<HeadingPairs>"
                                "<vt:vector size=\"2\" baseType=\"variant\">"
                                    "<vt:variant>"
                                        "<vt:lpstr>Feuilles de calcul</vt:lpstr>"
                                    "</vt:variant>"
                                    "<vt:variant>"
                                        "<vt:i4>" << k_worksheetCount << "</vt:i4>"
                                    "</vt:variant>"
                                "</vt:vector>"
                            "</HeadingPairs>"
                            "<TitlesOfParts>"
                                "<vt:vector size=\"" << k_worksheetCount << "\" baseType=\"lpstr\">";

        if ((p_workbook) && (p_workbook->worksheetCount())) {
            for (unsigned int i = 0; i < p_workbook->worksheetCount(); ++i)
                *w_result << "<vt:lpstr>" << textToXML(p_workbook->worksheet(i)->name()) << "</vt:lpstr>";

            if (p_listValidationsParams.isExist())
                *w_result << "<vt:lpstr>" << textToXML(p_listValidationsParams.name()) << "</vt:lpstr>";
        } else
            *w_result << "<vt:lpstr> </vt:lpstr>";

        *w_result <<            "</vt:vector>"
                            "</TitlesOfParts>"
                            "<Company>Microsoft</Company>" // ne pas changer !
                            "<LinksUpToDate>false</LinksUpToDate>"
                            "<SharedDoc>false</SharedDoc>"
                            "<HyperlinksChanged>false</HyperlinksChanged>"
                            "<AppVersion>12.0000</AppVersion>" // ne pas changer !
                        "</Properties>";
    } catch (...) {
        delete w_result;
        throw;
    }

    return w_result;
}

std::istream* Writer::createCore(time_t p_creationDate)
{
    time_t w_time = p_creationDate;
#if defined(_MSC_VER)
    struct tm w_now;
    localtime_s(&w_now, &w_time);
#else
    struct tm w_now = *localtime(&w_time);
#endif

    std::stringstream w_formatedDateTime;
    w_formatedDateTime  << std::setfill('0')
                        << std::setw(4) << (w_now.tm_year + 1900)
                        << "-"
                        << std::setw(2) << (w_now.tm_mon + 1)
                        << "-"
                        << std::setw(2) << w_now.tm_mday
                        << "T"
                        << std::setw(2) << w_now.tm_hour
                        << ":"
                        << std::setw(2) << w_now.tm_min
                        << ":"
                        << std::setw(2) << w_now.tm_sec
                        << "Z";

    std::stringstream* w_result = new std::stringstream;
    try {
        *w_result <<    "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                        "<cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:dcterms=\"http://purl.org/dc/terms/\" xmlns:dcmitype=\"http://purl.org/dc/dcmitype/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">"
                            "<dc:creator>Invoke</dc:creator>"
                            "<cp:lastModifiedBy>Invoke</cp:lastModifiedBy>"
                            "<dcterms:created xsi:type=\"dcterms:W3CDTF\">" << w_formatedDateTime.str() << "</dcterms:created>"
                            "<dcterms:modified xsi:type=\"dcterms:W3CDTF\">" << w_formatedDateTime.str() << "</dcterms:modified>"
                        "</cp:coreProperties>";
    } catch (...) {
        delete w_result;
        throw;
    }

    return w_result;
}

std::istream* Writer::createWorkbookRels(const Interface::Read::Workbook* p_workbook, const ListValidationParams& p_listValidationsParams)
{
    std::stringstream* w_result = new std::stringstream;
    try {
        *w_result <<    "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                        "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">";

        if ((p_workbook) && (p_workbook->worksheetCount())) {
            for (unsigned int i = 0; i < p_workbook->worksheetCount(); ++i)
                *w_result << "<Relationship Id=\"rId" << i+1 << "\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet" << i+1 << ".xml\"/>";

            if (p_listValidationsParams.isExist())
                *w_result << "<Relationship Id=\"rId" << p_listValidationsParams.id() << "\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet" << p_listValidationsParams.id() << ".xml\"/>";
        } else
            *w_result << "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>";

        const size_t k_worksheetCount = (((p_workbook) && (p_workbook->worksheetCount())) ? p_workbook->worksheetCount() : 1) + (p_listValidationsParams.isExist() ? 1 : 0);
        *w_result <<        "<Relationship Id=\"rId" << k_worksheetCount+1 << "\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings\" Target=\"sharedStrings.xml\"/>"
                            "<Relationship Id=\"rId" << k_worksheetCount+2 << "\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>"
                        "</Relationships>";
    } catch (...) {
        delete w_result;
        throw;
    }

    return w_result;
}

void Writer::imagesInventory(const Interface::Read::Workbook* p_workbook, imagesMap_t& o_imagesMap)
{
    if (!p_workbook)
        return;

    unsigned int w_id = 0;
    for (unsigned int w_iWorksheet = 0; w_iWorksheet < p_workbook->worksheetCount(); ++w_iWorksheet) {
        Interface::Read::Worksheet const * const k_worksheet = p_workbook->worksheet(w_iWorksheet);

        for (unsigned int w_iImage = 0; w_iImage < k_worksheet->imageCount(); ++w_iImage) {
            Interface::Read::Image const * const k_image = k_worksheet->image(w_iImage);

            if (k_image->isValid()) {
                unsigned char* w_memory = nullptr;
                unsigned int w_size = 0;
                k_image->getImageBuffer(w_memory, w_size);

                unsigned int w_prevImageId = 0;
                imagesMap_t::const_iterator w_iPrevImage = o_imagesMap.begin();
                while ((w_prevImageId == 0) && (w_iPrevImage != o_imagesMap.end())) {
                    unsigned char* w_prevImageMemory = nullptr;
                    unsigned int w_prevImageSize = 0;
                    w_iPrevImage->first->getImageBuffer(w_prevImageMemory, w_prevImageSize);

                    if  (   (w_size == w_prevImageSize)
                        &&  (!std::memcmp(w_memory, w_prevImageMemory, w_size))
                        )
                        w_prevImageId = w_iPrevImage->second;

                    ++w_iPrevImage;
                }

                if (w_prevImageId != 0)
                    o_imagesMap[k_image] = w_prevImageId;
                else
                    o_imagesMap[k_image] = ++w_id;
            }
        }
    }
}

void Writer::saveImages(const imagesMap_t& p_imagesMap, Zip::ZipArchiveWriter* o_zipWriter)
{
    std::vector<unsigned int> w_filesId;
    for (imagesMap_t::const_iterator w_iImages = p_imagesMap.begin(); w_iImages != p_imagesMap.end(); ++w_iImages) {
        unsigned int w_id = w_iImages->second;
        if (std::find(w_filesId.begin(), w_filesId.end(), w_id) == w_filesId.end()) {
            w_filesId.push_back(w_id);

            Interface::Read::Image const * const k_image = w_iImages->first;
            unsigned char* w_memory = nullptr;
            unsigned int w_size = 0;
            k_image->getImageBuffer(w_memory, w_size);
            o_zipWriter->addFromStream("xl/media/image"+ std::to_string(w_id) +"."+ Interface::stringImageType(k_image->type()), reinterpret_cast<Zip::byte_t*>(w_memory), w_size);
        }
    }
}

std::istream* Writer::createDrawing(const Interface::Read::Worksheet* p_worksheet, const imagesMap_t& p_imagesMap)
{
    if (!p_worksheet->containsValidImages())
        return nullptr;

    std::stringstream* w_result = new std::stringstream;
    try {
        *w_result <<    "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                        "<xdr:wsDr xmlns:xdr=\"http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\">";

        for (unsigned int w_iImage = 0; w_iImage < p_worksheet->imageCount(); ++w_iImage) {
            Interface::Read::Image const * const k_image = p_worksheet->image(w_iImage);

            if (k_image->isValid()) {
                *w_result << "<xdr:twoCellAnchor";
                switch (k_image->property()) {
                case Interface::ipMoveWithCells:
                    *w_result << " editAs=\"oneCell\"";
                    break;
                case Interface::ipStatic:
                    *w_result << " editAs=\"absolute\"";
                    break;
                default:
                    ;
                }
                *w_result << ">";

                *w_result <<    "<xdr:from>"
                                    "<xdr:col>" << k_image->topLeft().column() << "</xdr:col>"
                                    "<xdr:colOff>" << k_image->topLeft().offsetX() << "</xdr:colOff>"
                                    "<xdr:row>" << k_image->topLeft().row() << "</xdr:row>"
                                    "<xdr:rowOff>" << k_image->topLeft().offsetY() << "</xdr:rowOff>"
                                "</xdr:from>";

                if (k_image->rightBottom()) {
                    *w_result <<    "<xdr:to>"
                                        "<xdr:col>" << k_image->rightBottom()->column() << "</xdr:col>"
                                        "<xdr:colOff>" << k_image->rightBottom()->offsetX() << "</xdr:colOff>"
                                        "<xdr:row>" << k_image->rightBottom()->row() << "</xdr:row>"
                                        "<xdr:rowOff>" << k_image->rightBottom()->offsetY() << "</xdr:rowOff>"
                                    "</xdr:to>";
                } else {
                    const unsigned int k_width = ((k_image->cropRectangle()) ? k_image->cropRectangle()->width : k_image->width());
                    const unsigned int k_height = ((k_image->cropRectangle()) ? k_image->cropRectangle()->height : k_image->height());

                    const unsigned int k_fromColOff = Coordinates::CellPoint::EMUToPixel(k_image->topLeft().offsetX());
                    const unsigned int k_fromRowOff = Coordinates::CellPoint::EMUToPixel(k_image->topLeft().offsetY());

                    unsigned int w_col = ((k_width + k_fromColOff) / 80) + k_image->topLeft().column();
                    unsigned int w_colOff = Coordinates::CellPoint::pixelToEMU((k_width + k_fromColOff) % 80);
                    unsigned int w_row = ((k_height + k_fromRowOff) / 17) + k_image->topLeft().row();
                    unsigned int w_rowOff = Coordinates::CellPoint::pixelToEMU((k_height + k_fromRowOff) % 17);

                    if (p_worksheet) {
                        w_col = k_image->topLeft().column();
                        unsigned int w_width = k_width + k_fromColOff;
                        unsigned int w_colWidth =   (   p_worksheet->isColumnVisible(w_col)
                                                    ?   ((p_worksheet->columnWidth(w_col) != p_worksheet->defaultColumnWidth()) ? static_cast<unsigned int>(p_worksheet->columnWidth(w_col) * 7) : 80)
                                                    :   0
                                                    );
                        while (w_width > w_colWidth) {
                            w_width -= w_colWidth;
                            ++w_col;
                            w_colWidth =    (   p_worksheet->isColumnVisible(w_col)
                                            ?   ((p_worksheet->columnWidth(w_col) != p_worksheet->defaultColumnWidth()) ? static_cast<unsigned int>(p_worksheet->columnWidth(w_col) * 7) : 80)
                                            :   0
                                            );
                        }
                        w_colOff = Coordinates::CellPoint::pixelToEMU(w_width);

                        w_row = k_image->topLeft().row();
                        unsigned int w_height = k_height + k_fromRowOff;
                        unsigned int w_rowHeight =  (   p_worksheet->isRowVisible(w_row)
                                                    ?   ((p_worksheet->rowHeight(w_row) != p_worksheet->defaultRowHeight()) ? static_cast<unsigned int>(p_worksheet->rowHeight(w_row) * 96 / 72) : 17)
                                                    :   0
                                                    );
                        while (w_height > w_rowHeight) {
                            w_height -= w_rowHeight;
                            ++w_row;
                            w_rowHeight =   (   p_worksheet->isRowVisible(w_row)
                                            ?   ((p_worksheet->rowHeight(w_row) != p_worksheet->defaultRowHeight()) ? static_cast<unsigned int>(p_worksheet->rowHeight(w_row) * 96 / 72) : 17)
                                            :   0
                                            );
                        }
                        w_rowOff = Coordinates::CellPoint::pixelToEMU(w_height);
                    }

                    *w_result <<    "<xdr:to>"
                                        "<xdr:col>" << w_col << "</xdr:col>"
                                        "<xdr:colOff>" << w_colOff << "</xdr:colOff>"
                                        "<xdr:row>" << w_row << "</xdr:row>"
                                        "<xdr:rowOff>" << w_rowOff << "</xdr:rowOff>"
                                    "</xdr:to>";
                }

                const unsigned int k_id = p_imagesMap.at(k_image);
                *w_result <<    "<xdr:pic>"
                                    "<xdr:nvPicPr>"
                                        "<xdr:cNvPr id=\"" << w_iImage+1 << "\" name=\"Image" << w_iImage+1 << "\" descr=\"Image" << k_id << "." << Interface::stringImageType(k_image->type()) << "\"/>"
                                        "<xdr:cNvPicPr>"
                                            "<a:picLocks noChangeAspect=\"1\"/>"
                                        "</xdr:cNvPicPr>"
                                    "</xdr:nvPicPr>"
                                    "<xdr:blipFill>"
                                        "<a:blip xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" r:embed=\"rId" << k_id << "\" cstate=\"print\"/>";

                if (k_image->cropRectangle()) {
                    *w_result << "<a:srcRect";
                    if (k_image->cropRectangle()->left)
                        *w_result << " l=\"" << k_image->cropRectangle()->left * 100000 / k_image->width() << "\"";
                    if (k_image->cropRectangle()->top)
                        *w_result << " t=\"" << k_image->cropRectangle()->top * 100000 / k_image->height() << "\"";
                    if (k_image->cropRectangle()->width)
                        *w_result << " r=\"" << 100000 - (k_image->cropRectangle()->width + k_image->cropRectangle()->left) * 100000 / k_image->width() << "\"";
                    if (k_image->cropRectangle()->height)
                        *w_result << " b=\"" << 100000 - (k_image->cropRectangle()->height + k_image->cropRectangle()->top) * 100000 / k_image->height() << "\"";

                    *w_result << "/>";
                }

                *w_result <<            "<a:stretch>"
                                            "<a:fillRect/>"
                                        "</a:stretch>"
                                    "</xdr:blipFill>"
                                    "<xdr:spPr>"
                                        "<a:xfrm>"
                                            "<a:off x=\"0\" y=\"0\"/>"
                                            "<a:ext cx=\"0\" cy=\"0\"/>"
                                        "</a:xfrm>"
                                        "<a:prstGeom prst=\"rect\">"
                                            "<a:avLst/>"
                                        "</a:prstGeom>"
                                    "</xdr:spPr>"
                                "</xdr:pic>"
                                "<xdr:clientData/>"
                            "</xdr:twoCellAnchor>";
            }
        }

        *w_result << "</xdr:wsDr>";
    } catch (...) {
        delete w_result;
        throw;
    }

    return w_result;
}

std::istream* Writer::createDrawingRels(const Interface::Read::Worksheet* p_worksheet, const imagesMap_t& p_imagesMap)
{
    if (!p_worksheet->containsValidImages())
        return nullptr;

    std::stringstream* w_result = new std::stringstream;
    try {
        *w_result <<    "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                        "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">";

        std::vector<unsigned int> w_filesId;
        for (unsigned int w_iImage = 0; w_iImage < p_worksheet->imageCount(); ++w_iImage) {
            Interface::Read::Image const * const k_image = p_worksheet->image(w_iImage);

            if (k_image->isValid()) {
                const unsigned int k_id = p_imagesMap.at(k_image);
                if (std::find(w_filesId.begin(), w_filesId.end(), k_id) == w_filesId.end()) {
                    w_filesId.push_back(k_id);
                    *w_result << "<Relationship Id=\"rId" << k_id << "\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"../media/image" << k_id << "." << Interface::stringImageType(k_image->type()) << "\"/>";
                }
            }
        }

        *w_result <<    "</Relationships>";
    } catch (...) {
        delete w_result;
        throw;
    }

    return w_result;
}

std::istream* Writer::createComments(const Interface::Read::Worksheet* p_worksheet)
{
    if (p_worksheet->commentCount() == 0)
        return nullptr;

    typedef std::vector<Interface::utf8String_t> strings_t;
    strings_t w_authors;
    strings_t w_comments;

    for (size_t w_iComment = 0; w_iComment < p_worksheet->commentCount(); ++w_iComment) {
        Interface::Read::Comment const * const k_comment = p_worksheet->comment(w_iComment);

        size_t w_authorId = 0;
        while ((w_authorId < w_authors.size()) && (w_authors.at(w_authorId) != k_comment->author()))
            ++w_authorId;
        if (w_authorId == w_authors.size())
            w_authors.push_back(k_comment->author());

        Interface::utf8String_t w_comment = "<comment ref=\"" + k_comment->reference().name(k_comment->reference().worksheet()) + "\""
                                                    " authorId=\"" + std::to_string(w_authorId) + "\""
                                                    " shapeId=\"0\""
                                            ">"
                                                "<text>";

        for (size_t w_iRun = 0; w_iRun < k_comment->runCount(); ++w_iRun) {
            w_comment +=                            "<r>"
                                                        "<rPr>";

            if (k_comment->runFont(w_iRun)->bold)
                w_comment +=                                "<b/>";
            if (k_comment->runFont(w_iRun)->italic)
                w_comment +=                                "<i/>";
            if (k_comment->runFont(w_iRun)->underline)
                w_comment +=                                "<u/>";
            w_comment +=                                    "<sz val=\"" + std::to_string(k_comment->runFont(w_iRun)->size) + "\"/>"
                                                            "<color rgb=\"" + colorToXML(k_comment->runFont(w_iRun)->color) + "\"/>"
                                                            "<rFont val=\"" + k_comment->runFont(w_iRun)->name + "\"/>"
                                                        "</rPr>"
                                                        "<t xml:space=\"preserve\">" + textToXML(*k_comment->runText(w_iRun)) + "</t>"
                                                    "</r>";
        }

        w_comment +=                            "</text>"
                                            "</comment>";

        w_comments.push_back(w_comment);
    }

    std::stringstream* w_result = new std::stringstream;
    try {
        *w_result <<    "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                        "<comments xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">";

        *w_result << "<authors>";
        for (strings_t::const_iterator w_it = w_authors.begin(); w_it != w_authors.end(); ++w_it)
            *w_result << "<author>" << textToXML(*w_it) << "</author>";
        *w_result << "</authors>";
        
        *w_result << "<commentList>";
        for (strings_t::const_iterator w_it = w_comments.begin(); w_it != w_comments.end(); ++w_it)
            *w_result << *w_it;
        *w_result << "</commentList>";

        *w_result <<    "</comments>";
    } catch (...) {
        delete w_result;
        throw;
    }

    return w_result;
}

std::istream* Writer::createVmlDrawing(const Interface::Read::Worksheet* p_worksheet, unsigned int p_worksheetId)
{
    if (p_worksheet->commentCount() == 0)
        return nullptr;

    std::stringstream* w_result = new std::stringstream;
    try {
        *w_result <<    "<xml xmlns:v=\"urn:schemas-microsoft-com:vml\" xmlns:o=\"urn:schemas-microsoft-com:office:office\" xmlns:x=\"urn:schemas-microsoft-com:office:excel\">"
	                        "<o:shapelayout v:ext=\"edit\">"
		                        "<o:idmap v:ext=\"edit\" data=\"" << p_worksheetId+1 << "\"/>"
	                        "</o:shapelayout>"
	                        "<v:shapetype id=\"_x0000_t202\" coordsize=\"21600,21600\" o:spt=\"202\" path=\"m,l,21600r21600,l21600,xe\">"
                                "<v:stroke joinstyle=\"miter\"/>"
                                "<v:path gradientshapeok=\"t\" o:connecttype=\"rect\"/>"
	                        "</v:shapetype>";

        for (size_t w_iComment = 0; w_iComment < p_worksheet->commentCount(); ++w_iComment) {
            Interface::Read::Comment const * const k_comment = p_worksheet->comment(w_iComment);

            std::string w_name = "_x0000_s" + std::to_string((1024 * (p_worksheetId+1)) + (w_iComment+1));

            std::string w_alignment = "left";
            if (k_comment->alignment() == Interface::haCenter)
                w_alignment = "center";
            if (k_comment->alignment() == Interface::haRight)
                w_alignment = "right";

            *w_result << "<v:shape id=\"" << w_name << "\""
                                 " type=\"#_x0000_t202\""
                                 << ((k_comment->hyperlink() != "") ? "href=\"" + k_comment->hyperlink() + "\"" : "") <<
                                 " style='position:absolute;z-index:" << (w_iComment+1) << ";visibility:" << ((k_comment->visibility() == Interface::vVisible) ? "visible" : "hidden") << "'"
                                 " fillcolor=\"#" << std::setfill('0') << std::setw(6) << std::hex << k_comment->fillColor() << std::dec << "\""
                                 " o:insetmode=\"auto\""
                                 ">"
                                 "<v:textbox" << (k_comment->autoSize() ? " style='mso-fit-shape-to-text:t'" : "") << ">"
			                        "<div style='text-align:" << w_alignment << "'/>"
		                         "</v:textbox>"
                             "<x:ClientData ObjectType=\"Note\">";

            if (k_comment->property() == Interface::cpStatic)
                *w_result << "<x:MoveWithCells/>";  // fonctionne � l'envers...
            if (k_comment->property() != Interface::cpMoveAndResizeWithCells)
                *w_result << "<x:SizeWithCells/>";  // fonctionne � l'envers...

            *w_result << "<x:Anchor>" << k_comment->topLeft().column() << ", " << (k_comment->topLeft().offsetX() / 10000) << ", "
                                      << k_comment->topLeft().row() << ", " << (k_comment->topLeft().offsetY() / 10000) << ", "
                                      << k_comment->rightBottom().column() << ", " << (k_comment->rightBottom().offsetX() / 10000) << ", "
                                      << k_comment->rightBottom().row() << ", " << (k_comment->rightBottom().offsetY() / 10000) 
                                      << "</x:Anchor>";

            if (k_comment->alignment() == Interface::haCenter)
                *w_result << "<x:TextHAlign>Center</x:TextHAlign>";
            if (k_comment->alignment() == Interface::haRight)
                *w_result << "<x:TextHAlign>Right</x:TextHAlign>";

            *w_result << "<x:Row>" << k_comment->reference().row() << "</x:Row>";
            *w_result << "<x:Column>" << k_comment->reference().column() << "</x:Column>";

            if (k_comment->visibility() == Interface::vVisible)
                *w_result << "<x:Visible/>";

            *w_result <<     "</x:ClientData>"
                         "</v:shape>";
        }

        *w_result <<    "</xml>";

    } catch (...) {
        delete w_result;
        throw;
    }

    return w_result;
}

std::istream* Writer::createWorksheetRels(const Interface::Read::Worksheet* p_worksheet, unsigned int p_worksheetId, relsMap_t& o_rels)
{
    o_rels.clear();
    std::stringstream w_relationships;
    unsigned int w_id = 1;

    if (p_worksheet->containsValidImages()) {
        o_rels.emplace(nullptr, 0);
        w_relationships << "<Relationship Id=\"rId0\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing\" Target=\"../drawings/drawing" << p_worksheetId << ".xml\"/>";
    }

    for (unsigned int i = 0; i < p_worksheet->hyperlinkCount(); ++i) {
        if (p_worksheet->hyperlink(i)->isValid()) {
            std::string w_target = "";
            if (p_worksheet->hyperlink(i)->fileLocation())
                w_target = *(p_worksheet->hyperlink(i)->fileLocation());
            else {
                std::string w_address;
                std::string w_object;
                if (p_worksheet->hyperlink(i)->getMailLocation(w_address, w_object))
                    w_target = "mailto:" + w_address + "?subject=" + w_object;
            }

            if (w_target != "") {
                o_rels.emplace(p_worksheet->hyperlink(i), w_id);
                w_relationships << "<Relationship Id=\"rId" << w_id << "\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink\" Target=\"" << textToXMLAttribute(w_target) << "\" TargetMode=\"External\"/>";
                ++w_id;
            }
        }
    }

    if (p_worksheet->commentCount() > 0) {
        o_rels.emplace((void*)1, w_id);
        w_relationships << "<Relationship Id=\"rId" << w_id << "\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/vmlDrawing\" Target=\"../drawings/vmlDrawing" << p_worksheetId << ".vml\"/>"
                           "<Relationship Id=\"rId" << w_id+1 << "\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments\" Target=\"../comments" << p_worksheetId << ".xml\"/>";
        w_id += 2;
    }

    if (o_rels.empty())
        return nullptr;

    std::stringstream* w_result = new std::stringstream;
    try {
        *w_result <<    "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                        "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                  <<        w_relationships.str()
                  <<    "</Relationships>";
    } catch (...) {
        delete w_result;
        throw;
    }

    return w_result;
}

unsigned int Writer::getFirstVisibleSheetIndex(const Interface::Read::Workbook* p_workbook)
{
    if ((!p_workbook) || (!p_workbook->worksheetCount()))
        return 0;

    unsigned int w_index = 0;
    while ((w_index < p_workbook->worksheetCount()) && (p_workbook->worksheet(w_index)->isHidden()))
        w_index++;

    if (w_index >= p_workbook->worksheetCount())
        return 0;
    return w_index;
}

std::istream* Writer::createWorkbook(const Interface::Read::Workbook* p_workbook, const ListValidationParams& p_listValidationsParams)
{
    std::stringstream w_sheets;
    std::stringstream w_definedNames;

    if ((p_workbook) && (p_workbook->worksheetCount())) {
        for (unsigned int w_iWorksheet = 0; w_iWorksheet < p_workbook->worksheetCount(); ++w_iWorksheet) {
            Interface::Read::Worksheet const * const k_worksheet = p_workbook->worksheet(w_iWorksheet);

            w_sheets << "<sheet name=\"" << textToXMLAttribute(k_worksheet->name()) << "\" sheetId=\"" << w_iWorksheet+1 << "\" r:id=\"rId" << w_iWorksheet+1 << "\"" << (k_worksheet->isHidden() ? " state=\"hidden\"" : "") << "/>";

            if (k_worksheet->pageSetting()) {
                Coordinates::MultiCellRange const * const k_ranges = k_worksheet->pageSetting()->printArea();
                if (k_ranges)
                    w_definedNames << "<definedName name=\"_xlnm.Print_Area\" localSheetId=\"" << w_iWorksheet << "\">" << textToXML(k_ranges->name(nullptr)) +"</definedName>";

                if  (   (k_worksheet->pageSetting()->headerColumns())
                    ||  (k_worksheet->pageSetting()->headerRows())
                    ) {

                    Coordinates::ColumnRowRange const * const k_columns = k_worksheet->pageSetting()->headerColumns();
                    Coordinates::ColumnRowRange const * const k_rows = k_worksheet->pageSetting()->headerRows();

                    w_definedNames << "<definedName name=\"_xlnm.Print_Titles\" localSheetId=\"" << w_iWorksheet << "\">";
                    if (k_columns)
                        w_definedNames << textToXML(k_columns->name(nullptr));
                    if  (   (k_columns)
                        &&  (k_rows)
                        )
                        w_definedNames << ",";
                    if (k_rows)
                        w_definedNames << textToXML(k_rows->name(nullptr));
                    w_definedNames << "</definedName>";

                }
            }
        }
    } else
        w_sheets << "<sheet name=\" \" sheetId=\"1\" r:id=\"rId1\"/>";

    if (p_listValidationsParams.isExist()) {
        w_sheets    << "<sheet"
                    << " name=\"" << textToXML(p_listValidationsParams.name()) << "\""
                    << " sheetId=\"" << p_listValidationsParams.id() << "\""
                    << " r:id=\"rId" << p_listValidationsParams.id() << "\""
                    << " state=\"hidden\""
                    << "/>";
    }

    if (p_workbook) {
        for (unsigned int w_iWorksheet = 0; w_iWorksheet < p_workbook->worksheetCount(); ++w_iWorksheet) {
            Interface::Read::Filter const * const k_filter = p_workbook->worksheet(w_iWorksheet)->filter();
            if (k_filter)
                w_definedNames << "<definedName name=\"_xlnm._FilterDatabase\" localSheetId=\"" << w_iWorksheet << "\" hidden=\"1\">" << textToXML(k_filter->rangeReference()->name(nullptr)) << "</definedName>";
        }

        for (unsigned int w_iDefinedName = 0; w_iDefinedName < p_workbook->definedNameCount(); ++w_iDefinedName) {
            Interface::Read::DefinedName const * const k_definedName = p_workbook->definedName(w_iDefinedName);
            w_definedNames << "<definedName name=\"" << textToXMLAttribute(k_definedName->name()) << "\">" << textToXML(k_definedName->zone().name(nullptr)) << "</definedName>";
        }
    }

    std::stringstream* w_result = new std::stringstream;
    try {
        *w_result <<    "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                        "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">";

        const unsigned int k_index = getFirstVisibleSheetIndex(p_workbook);
        if (k_index)
            *w_result << "<bookViews><workbookView activeTab=\"" << k_index << "\" firstSheet=\"" << k_index << "\"/></bookViews>";

        if (w_sheets.rdbuf()->in_avail() > 0)
            *w_result << "<sheets>" << w_sheets.str() << "</sheets>";

        if (w_definedNames.rdbuf()->in_avail() > 0)
            *w_result << "<definedNames>" << w_definedNames.str() << "</definedNames>";

        *w_result << "</workbook>";
    } catch (...) {
        delete w_result;
        throw;
    }

    return w_result;
}

class SSTGenerator
{
private:
    typedef enum { tvtCellValue, tvtUtf8String } textValueType_t;
    typedef std::pair<textValueType_t, std::vector<void*>> pair_t;
    typedef std::vector<pair_t> textValues_t;

public:
    typedef std::vector<std::pair<void*, size_t>> writerSST_t;
    typedef std::string (*stringToXML)(const Interface::utf8String_t&);
    typedef std::string (*richtextToXML)(const Interface::Read::RichText*);

public:
    void add(Interface::Read::CellValue const * const p_value)
    {
        const textValues_t::const_iterator k_index = index(p_value);

        if ((k_index == m_texts.end()) || (!equal(k_index, p_value))) {
            pair_t w_pair;
            w_pair.first = tvtCellValue;
            w_pair.second.push_back((void*)p_value);
            m_texts.insert(k_index, w_pair);
        } else
            m_texts[k_index - m_texts.begin()].second.push_back((void*)p_value);
    }

    void add(Interface::utf8String_t const * const p_value)
    {
        const textValues_t::const_iterator k_index = index(p_value);

        if ((k_index == m_texts.end()) || (!equal(k_index, p_value))) {
            pair_t w_pair;
            w_pair.first = tvtUtf8String;
            w_pair.second.push_back((void*)p_value);
            m_texts.insert(k_index, w_pair);
        } else
            m_texts[k_index - m_texts.begin()].second.push_back((void*)p_value);
    }

    std::istream* generate(writerSST_t& o_sst, stringToXML p_s2x, richtextToXML p_rt2x)
    {
        std::stringstream* w_result = new std::stringstream;
        try {

            *w_result <<    "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                            "<sst xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" count=\"" << m_texts.size() << "\" uniqueCount=\"" << m_texts.size() << "\">";

            size_t w_index = 0;
            for (textValues_t::const_iterator w_it = m_texts.begin(); w_it != m_texts.end(); ++w_it) {
                std::string w_xml = "";
                if ((*w_it).first == tvtCellValue) {
                    Interface::Read::CellValue const * const k_value = (Interface::Read::CellValue const * const)((*w_it).second[0]);
                    if (k_value->type() == Interface::ctRichText)
                        w_xml = p_rt2x(k_value->text());
                    if (k_value->type() == Interface::ctString)
                        w_xml = p_s2x(k_value->string());
                }
                if ((*w_it).first == tvtUtf8String) {
                    Interface::utf8String_t const * const k_value = (Interface::utf8String_t const * const)((*w_it).second[0]);
                    w_xml = p_s2x(*k_value);
                }
                *w_result << "<si>" << w_xml << "</si>";

                for (std::vector<void*>::const_iterator w_ivector = w_it->second.begin(); w_ivector != w_it->second.end(); ++w_ivector) {
                    std::pair<void*, size_t> w_pair;
                    w_pair.first = *w_ivector;
                    w_pair.second = w_index;
                    o_sst.push_back( w_pair );
                }
                w_index++;
            }

            *w_result << "</sst>";

            std::sort(o_sst.begin(), o_sst.end());

        } catch (...) {
            delete w_result;
            throw;
        }

        return w_result;
    }

private:
    bool equal(const textValues_t::const_iterator& p_it, Interface::Read::CellValue const * const p_value)
    {
        if ((*p_it).first == tvtCellValue) {
            Interface::Read::CellValue const * const k_value = (Interface::Read::CellValue const * const)((*p_it).second[0]);
            return (*k_value == p_value);
        }

        if (((*p_it).first == tvtUtf8String) && (p_value->type() == Interface::ctString)) {
            Interface::utf8String_t const * const k_string = (Interface::utf8String_t const * const)((*p_it).second[0]);
            return (*k_string == p_value->string());
        }

        return false;
    }

    bool lowerThan(const textValues_t::const_iterator& p_it, Interface::Read::CellValue const * const p_value)
    {
        if ((*p_it).first == tvtCellValue) {
            Interface::Read::CellValue const * const k_value = (Interface::Read::CellValue const * const)((*p_it).second[0]);
            return (*k_value < p_value);
        }

        if (((*p_it).first == tvtUtf8String) && (p_value->type() == Interface::ctString)) {
            Interface::utf8String_t const * const k_string = (Interface::utf8String_t const * const)((*p_it).second[0]);
            return (*k_string < p_value->string());
        }

        return false;
    }

    bool equal(const textValues_t::const_iterator& p_it, Interface::utf8String_t const * const p_value)
    {
        if ((*p_it).first == tvtCellValue) {
            Interface::Read::CellValue const * const k_value = (Interface::Read::CellValue const * const)((*p_it).second[0]);
            if (k_value->type() == Interface::ctString)
                return (k_value->string() == *p_value);
        }

        if ((*p_it).first == tvtUtf8String) {
            Interface::utf8String_t const * const k_string = (Interface::utf8String_t const * const)((*p_it).second[0]);
            return (*k_string == *p_value);
        }

        return false;
    }

    bool lowerThan(const textValues_t::const_iterator& p_it, Interface::utf8String_t const * const p_value)
    {
        if ((*p_it).first == tvtCellValue) {
            Interface::Read::CellValue const * const k_value = (Interface::Read::CellValue const * const)((*p_it).second[0]);
            if (k_value->type() == Interface::ctString)
                return (k_value->string() < *p_value);
        }

        if ((*p_it).first == tvtUtf8String) {
            Interface::utf8String_t const * const k_string = (Interface::utf8String_t const * const)((*p_it).second[0]);
            return (*k_string < *p_value);
        }

        return false;
    }

    const textValues_t::const_iterator index(Interface::Read::CellValue const * const p_value)
    {
        // from lower_bound
        textValues_t::const_iterator w_first = m_texts.begin();
        textValues_t::const_iterator w_last = m_texts.end();

        textValues_t::difference_type w_count = std::distance(w_first, w_last);
        while (w_count > 0) {
            textValues_t::const_iterator w_it = w_first;
            textValues_t::difference_type w_step = w_count / 2;
            std::advance(w_it, w_step);

            if (lowerThan(w_it, p_value)) {
                w_first = ++w_it;
                w_count -= (w_step + 1);
            } else
                w_count = w_step;
        }

        return w_first;
    }

    const textValues_t::const_iterator index(Interface::utf8String_t const * const p_value)
    {
        // from lower_bound
        textValues_t::const_iterator w_first = m_texts.begin();
        textValues_t::const_iterator w_last = m_texts.end();

        textValues_t::difference_type w_count = std::distance(w_first, w_last);
        while (w_count > 0) {
            textValues_t::const_iterator w_it = w_first;
            textValues_t::difference_type w_step = w_count / 2;
            std::advance(w_it, w_step);

            if (lowerThan(w_it, p_value)) {
                w_first = ++w_it;
                w_count -= (w_step + 1);
            } else
                w_count = w_step;
        }

        return w_first;
    }

private:
    textValues_t m_texts;
};

size_t Writer::SSTIndex(const sst_t& p_sst, void* p_object)
{
    sstPair_t w_pair;
    w_pair.first = p_object;
    w_pair.second = 0;

    const sst_t::const_iterator k_index = std::lower_bound(p_sst.begin(), p_sst.end(), w_pair, [](const sstPair_t& lhs, const sstPair_t& rhs) -> bool { return lhs.first < rhs.first; } );
    
    if (k_index != p_sst.end())
        return k_index->second;
    return p_sst.size();
}

std::string Writer::createShareString_toXml(const Interface::utf8String_t& p_text)
{
    bool w_spaces = false;
    
    if (p_text != "") {
        Interface::utf8String_t::const_iterator w_it = p_text.begin();
        w_spaces = Unicode::isSpace(UtfString::UTF8::read(w_it));
        if (!w_spaces) {
            w_it = p_text.end();
            UtfString::UTF8::seek(w_it, -1);
            w_spaces = Unicode::isSpace(UtfString::UTF8::read(w_it));
        }
    }

	std::string w_spacePreserve = ((w_spaces) ? " xml:space=\"preserve\"" : "");
	return "<t" + w_spacePreserve + ">" + textToXML(p_text) + "</t>";
}

std::string Writer::createShareString_toXml(const Interface::Read::RichText* p_richtext)
{
	if (!p_richtext)
		return "";

    std::string w_xml = "";

	if (p_richtext->runCount() > 0) {
		for (size_t i = 0; i < p_richtext->runCount(); ++i) {
			w_xml += "<r>";
			if (p_richtext->runFont(i)) {
				w_xml += "<rPr>";
				w_xml += "<rFont val=\"" + textToXMLAttribute(p_richtext->runFont(i)->name) + "\"/>";
				w_xml += "<sz val=\"" + std::to_string(p_richtext->runFont(i)->size) + "\"/>";
				w_xml += "<color rgb=\"" + colorToXML(p_richtext->runFont(i)->color) + "\"/>";
				w_xml += (p_richtext->runFont(i)->bold ? "<b/>" : "");
				w_xml += (p_richtext->runFont(i)->italic ? "<i/>" : "");
				w_xml += (p_richtext->runFont(i)->underline ? "<u/>" : "");
				w_xml += "</rPr>";
			}
			if (p_richtext->runText(i))
				w_xml += createShareString_toXml(*p_richtext->runText(i));
			w_xml += "</r>";
		}
	} else
		w_xml = createShareString_toXml(p_richtext->text());

	return w_xml;
}

std::istream* Writer::createSharedStrings(const Interface::Read::Workbook* p_workbook, sst_t& o_sst)
{
    o_sst.clear();

    SSTGenerator w_sstGenerator;

    if (p_workbook) {
        for (unsigned int w_iWorksheet = 0; w_iWorksheet < p_workbook->worksheetCount(); ++w_iWorksheet) {
            Interface::Read::Worksheet const * const k_worksheet = p_workbook->worksheet(w_iWorksheet);
            
            const Coordinates::CellRange k_minBounds = k_worksheet->minBounds();
            for (unsigned int w_iCol = k_minBounds.left(); w_iCol <= k_minBounds.right(); ++w_iCol) {
                for (unsigned int w_iRow = k_minBounds.top(); w_iRow <= k_minBounds.bottom(); ++w_iRow) {
                    Interface::Read::CellValue const * const k_value = k_worksheet->cellValue(w_iCol, w_iRow);
					if ((k_value) && ((k_value->type() == Interface::ctString) || (k_value->type() == Interface::ctRichText)))
                        w_sstGenerator.add(k_value);
                }
            }

            for (unsigned int w_iValidation = 0; w_iValidation < k_worksheet->validationCount(); ++w_iValidation) {
                const Interface::Read::ListValidation* k_listValidation = dynamic_cast<const Interface::Read::ListValidation*>(k_worksheet->validation(w_iValidation));
                if (k_listValidation) {
                    const Interface::valueList_t* w_valueList = k_listValidation->list();
					if (w_valueList) {
						for (Interface::valueList_t::const_iterator w_it = w_valueList->begin(); w_it != w_valueList->end(); ++w_it) 
                            w_sstGenerator.add(&((*w_it).string()));
					}
                }
            }
        }
    }

    return w_sstGenerator.generate(o_sst, &Writer::createShareString_toXml, &Writer::createShareString_toXml);
}

std::string Writer::createStyles_DefaultFontToXML(const Interface::Read::Workbook* p_workbook)
{
    Interface::utf8String_t w_fontName = "Arial";
    unsigned short w_fontSize = 10;
    Interface::color_t w_fontColor = 0xFF000000;
    bool w_fontBolded = false;
    bool w_fontItalicized = false;
    bool w_fontUnderlined = false;

    if (p_workbook)
        p_workbook->getDefaultFont(w_fontName, w_fontSize, w_fontColor, w_fontBolded, w_fontItalicized, w_fontUnderlined);

    std::stringstream w_result;
    w_result    <<  "<font>"
                <<      (w_fontBolded ? "<b/>" : "")
                <<      (w_fontItalicized ? "<i/>" : "")
                <<      (w_fontUnderlined ? "<u/>" : "")
                <<      "<sz val=\"" << w_fontSize << "\"/>"
                <<      ((w_fontColor != 0xFF000000) ? "<color rgb=\""+ colorToXML(w_fontColor) +"\"/>" : "")
                <<      "<name val=\"" << textToXMLAttribute(w_fontName) << "\"/>"
                    "</font>";
    return w_result.str();
}

std::string Writer::createStyles_FontToXML(const Interface::Read::CellFormat* p_format)
{
    if (p_format) {
        std::stringstream w_result;
        w_result    <<  "<font>"
                    <<      ((p_format->isFontBolded()) ? "<b/>" : "")
                    <<      ((p_format->isFontItalicized()) ? "<i/>" : "")
                    <<      ((p_format->isFontUnderlined()) ? "<u/>" : "")
                    <<      "<sz val=\"" << p_format->fontSize() << "\"/>"
                            "<color rgb=\"" << colorToXML(p_format->fontColor()) << "\"/>"
                            "<name val=\"" << textToXMLAttribute(p_format->fontName()) << "\"/>"
                        "</font>";
        return w_result.str();
    }

    return "";
}

std::string Writer::createStyles_PatternStyleAttribute(Interface::patternStyle_t p_style)
{
    switch (p_style) {
    case Interface::psNone:
        return "none";
    case Interface::psSolid:
        return "solid";
    case Interface::psDarkGray:
        return "darkGray";
    case Interface::psMediumGray:
        return "mediumGray";
    case Interface::psLightGray:
        return "lightGray";
    case Interface::psGray125:
        return "gray125";
    case Interface::psGray0625:
        return "gray0625";
    case Interface::psDarkHorizontal:
        return "darkHorizontal";
    case Interface::psDarkVertical:
        return "darkVertical";
    case Interface::psDarkDown:
        return "darkDown";
    case Interface::psDarkUp:
        return "darkUp";
    case Interface::psDarkGrid:
        return "darkGrid";
    case Interface::psDarkTrellis:
        return "darkTrellis";
    case Interface::psLightHorizontal:
        return "lightHorizontal";
    case Interface::psLightVertical:
        return "lightVertical";
    case Interface::psLightDown:
        return "lightDown";
    case Interface::psLightUp:
        return "lightUp";
    case Interface::psLightGrid:
        return "lightGrid";
    case Interface::psLightTrellis:
        return "lightTrellis";
    }

    return "";  // pour Visual Studio... (Warning C4715)
}

std::string Writer::createStyles_FillToXML(const Interface::Read::CellFormat* p_format)
{
    if (p_format) {
        std::stringstream w_result;

        if (p_format->patternStyle() == Interface::psNone)
            w_result << "<fill>"
                            "<patternFill patternType=\"none\"/>"
                        "</fill>";
        else
            w_result << "<fill>"
                     <<     "<patternFill patternType=\""+ createStyles_PatternStyleAttribute(p_format->patternStyle()) +"\">"
                     <<         ((p_format->foregroundColor() & 0xFF000000) ? "<fgColor rgb=\""+ colorToXML(p_format->foregroundColor()) +"\"/>" : "")
                     <<         ((p_format->backgroundColor() & 0xFF000000) ? "<bgColor rgb=\""+ colorToXML(p_format->backgroundColor()) +"\"/>" : "")
                     <<     "</patternFill>"
                     << "</fill>";

        return w_result.str();
    }

    return "";
}

std::string Writer::createStyles_BorderMarkup(Interface::border_t p_border)
{
    switch (p_border) {
    case Interface::bLeft:
        return "left";
    case Interface::bTop:
        return "top";
    case Interface::bRight:
        return "right";
    case Interface::bBottom:
        return "bottom";
    case Interface::bDiagonalUp:
    case Interface::bDiagonalDown:
        return "diagonal";
    }

    return "";  // pour Visual Studio... (Warning C4715)
}

std::string Writer::createStyles_BorderStyleAttribute(Interface::borderStyle_t p_borderStyle)
{
    switch (p_borderStyle) {
    case Interface::bsHair:
        return "hair";
    case Interface::bsDotted:
        return "dotted";
    case Interface::bsDashDotDot:
        return "dashDotDot";
    case Interface::bsDashDot:
        return "dashDot";
    case Interface::bsDashed:
        return "dashed";
    case Interface::bsThin:
        return "thin";
    case Interface::bsMediumDashDotDot:
        return "mediumDashDotDot";
    case Interface::bsSlantDashDot:
        return "slantDashDot";
    case Interface::bsMediumDashDot:
        return "mediumDashDot";
    case Interface::bsMediumDashed:
        return "mediumDashed";
    case Interface::bsMedium:
        return "medium";
    case Interface::bsThick:
        return "thick";
    case Interface::bsDouble:
        return "double";
    }

    return ""; // pour Visual Studio... (Warning C4715)
}

std::string Writer::createStyles_BorderToXML(const Interface::Read::CellFormat* p_format, Interface::border_t p_border)
{
    const std::string k_markup = createStyles_BorderMarkup(p_border);

    if ((p_format) && (p_format->isBorderVisible(p_border))) {
        std::stringstream w_result;
        w_result << "<" << k_markup << " style=\"" << createStyles_BorderStyleAttribute( p_format->borderStyle(p_border) ) << "\">"
                        "<color rgb=\"" << colorToXML( p_format->borderColor(p_border) ) << "\"/>"
                    "</" << k_markup << ">";

        return w_result.str();
    }

    return "<"+ k_markup +"/>";
}

std::string Writer::createStyles_BordersToXML(const Interface::Read::CellFormat* p_format)
{
    if (p_format) {
        return  "<border"+
                std::string( ((p_format->isBorderVisible(Interface::bDiagonalUp)) ? " diagonalUp=\"1\"" : "") ) +
                std::string( (p_format->isBorderVisible(Interface::bDiagonalDown) ? " diagonalDown=\"1\"" : "") ) +
                ">"+
                    createStyles_BorderToXML(p_format, Interface::bLeft) +
                    createStyles_BorderToXML(p_format, Interface::bRight) +
                    createStyles_BorderToXML(p_format, Interface::bTop) +
                    createStyles_BorderToXML(p_format, Interface::bBottom) +
                    ( (p_format->isBorderVisible(Interface::bDiagonalUp)) ? createStyles_BorderToXML(p_format, Interface::bDiagonalUp) : createStyles_BorderToXML(p_format, Interface::bDiagonalDown) ) +
                "</border>";
    }

    return "";
}

void Writer::createStyles_XfsInventory(const Interface::Read::Workbook* p_workbook, xfsMap_t& o_xfsMap, xfs_t& o_xfs, fonts_t& o_fonts, numFmts_t& o_numFmts, fills_t& o_fills, borders_t& o_borders)
{
    if (!p_workbook)
        return;

    Interface::Read::Workbook::cellFormatList_t w_formats = p_workbook->formats();
    for (Interface::Read::Workbook::cellFormatList_t::const_iterator w_iFormat = w_formats.begin(); w_iFormat != w_formats.end(); ++w_iFormat) {
        Interface::Read::CellFormat const * const k_format = *w_iFormat;

        std::stringstream w_xmlXf;
        w_xmlXf << "<xf xfId=\"0\"";

        const std::string k_xmlFont = createStyles_FontToXML(k_format);
        fonts_t::const_iterator w_fontIndex = std::find(o_fonts.begin(), o_fonts.end(), k_xmlFont);
        if (w_fontIndex == o_fonts.end()) {
            o_fonts.push_back(k_xmlFont);
            w_fontIndex = o_fonts.end()-1;
        }
        w_xmlXf << " fontId=\"" << w_fontIndex - o_fonts.begin() << "\" applyFont=\"1\"";

        if (k_format->numberFormat() != "") {
            const std::string k_xmlNumberFormat = textToXMLAttribute(k_format->numberFormat());
            numFmts_t::const_iterator w_numFmtsIndex = std::find(o_numFmts.begin(), o_numFmts.end(), k_xmlNumberFormat);
            if (w_numFmtsIndex == o_numFmts.end()) {
                o_numFmts.push_back(k_xmlNumberFormat);
                w_numFmtsIndex = o_numFmts.end()-1;
            }
            w_xmlXf << " numFmtId=\"" << (w_numFmtsIndex - o_numFmts.begin()) + 164 << "\" applyNumberFormat=\"1\"";
        } else
            w_xmlXf << " numFmtId=\"" << k_format->builtInNumberFormatId() << "\"" << ((k_format->builtInNumberFormatId()) ? " applyNumberFormat=\"1\"" : "");

        if (k_format->patternStyle() != Interface::psNone) {
            const std::string k_xmlFill = createStyles_FillToXML(k_format);
            fills_t::const_iterator w_fillsIndex = std::find(o_fills.begin(), o_fills.end(), k_xmlFill);
            if (w_fillsIndex == o_fills.end()) {
                o_fills.push_back(k_xmlFill);
                w_fillsIndex = o_fills.end()-1;
            }
            w_xmlXf << " fillId=\"" << w_fillsIndex - o_fills.begin() << "\" applyFill=\"1\"";
        } else
            w_xmlXf << " fillId=\"0\"";

        const std::string k_xmlBorders = createStyles_BordersToXML(k_format);
        borders_t::const_iterator w_bordersIndex = std::find(o_borders.begin(), o_borders.end(), k_xmlBorders);
        if (w_bordersIndex == o_borders.end()) {
            o_borders.push_back(k_xmlBorders);
            w_bordersIndex = o_borders.end()-1;
        }
        w_xmlXf << " borderId=\"" << w_bordersIndex - o_borders.begin() << "\" applyBorder=\"1\"";

        const short k_textRotation = k_format->textRotation() % 360;

        if  (   (k_format->horizontalAlignment() != Interface::haAuto)
            ||  (k_format->verticalAlignment() != Interface::vaBottom)
            ||  (k_format->textIndent() != 0)
            ||  ((k_textRotation) && (k_textRotation >= -90) && (k_textRotation <= 90))
            ||  (k_format->wrapText())
            ) {
            w_xmlXf << " applyAlignment=\"1\"><alignment";

            switch (k_format->horizontalAlignment()) {
            case Interface::haAuto:
                break;
            case Interface::haLeft:
                w_xmlXf << " horizontal=\"left\"";
                break;
            case Interface::haCenter:
                w_xmlXf << " horizontal=\"center\"";
                break;
            case Interface::haRight:
                w_xmlXf << " horizontal=\"right\"";
                //break;
            }

            switch (k_format->verticalAlignment()) {
            case Interface::vaTop:
                w_xmlXf << " vertical=\"top\"";
                break;
            case Interface::vaCenter:
                w_xmlXf << " vertical=\"center\"";
                break;
            case Interface::vaBottom:
                ;
                //break;
            }

            if (k_format->textIndent() > 0)
                w_xmlXf << " indent=\"" << k_format->textIndent() << "\"";

            if ((k_textRotation) && (k_textRotation >= -90) && (k_textRotation <= 90))
                w_xmlXf << " textRotation=\"" << ((k_textRotation < 0) ? 90 - k_textRotation : k_textRotation) << "\"";

            if (k_format->wrapText())
                w_xmlXf << " wrapText=\"1\"";

            w_xmlXf << "/></xf>";
        } else
            w_xmlXf << "/>";

        xfs_t::const_iterator w_xfsIndex = std::find(o_xfs.begin(), o_xfs.end(), w_xmlXf.str());
        if (w_xfsIndex == o_xfs.end()) {
            o_xfs.push_back(w_xmlXf.str());
            w_xfsIndex = o_xfs.end()-1;
        }
        o_xfsMap[k_format] = w_xfsIndex - o_xfs.begin();
    }
}

void Writer::createStyles_DxfsInventory(const Interface::Read::Workbook* p_workbook, dxfsMap_t& o_dxfsMap, dxfs_t& o_dxfs)
{
    if (!p_workbook)
        return;

    for (unsigned int w_iSheet = 0; w_iSheet < p_workbook->worksheetCount(); ++w_iSheet) {
        for (unsigned int w_iCondFormatting = 0; w_iCondFormatting < p_workbook->worksheet(w_iSheet)->conditionalFormattingCount(); ++w_iCondFormatting) {
            Interface::Read::ConditionalFormatting const * const k_condFormatting = p_workbook->worksheet(w_iSheet)->conditionalFormatting(w_iCondFormatting);

            if (k_condFormatting->isValid()) {
                std::stringstream w_xmlFont;
                if (k_condFormatting->format()->isFontBolded())
                    w_xmlFont << "<b" << ((!*k_condFormatting->format()->isFontBolded()) ? " val=\"0\"" : "") << "/>";
                if (k_condFormatting->format()->isFontItalicized())
                    w_xmlFont << "<i" << ((!*k_condFormatting->format()->isFontItalicized()) ? " val=\"0\"" : "") << "/>";
                if (k_condFormatting->format()->isFontUnderlined())
                    w_xmlFont << "<u" << ((!*k_condFormatting->format()->isFontUnderlined()) ? " val=\"none\"" : "") << "/>";
                if (k_condFormatting->format()->fontColor())
                    w_xmlFont << "<color rgb=\"" << colorToXML(*k_condFormatting->format()->fontColor()) << "\"/>";

                std::stringstream w_xmlNumFormat;
                if  (   (k_condFormatting->format()->numberFormat())
                    ||  (k_condFormatting->format()->builtInNumberFormatId())
                    ) {
                    w_xmlNumFormat << "<numFmt ";
                    if (k_condFormatting->format()->numberFormat())
                        w_xmlNumFormat << "formatCode=\"" << textToXMLAttribute(*k_condFormatting->format()->numberFormat()) << "\"";
                    else if (k_condFormatting->format()->builtInNumberFormatId())
                        w_xmlNumFormat << "numFmtId=\"" << *k_condFormatting->format()->builtInNumberFormatId() << "\"";
                    w_xmlNumFormat << "/>";
                }

                std::stringstream w_xmlFill;
                if (k_condFormatting->format()->patternStyle())
                    w_xmlFill <<    "<fill>"
                                        "<patternFill patternType=\""+ createStyles_PatternStyleAttribute(*k_condFormatting->format()->patternStyle()) +"\">"
                              <<            (k_condFormatting->format()->foregroundColor() ? "<fgColor rgb=\""+ colorToXML(*k_condFormatting->format()->foregroundColor()) +"\"/>" : "")
                              <<            (k_condFormatting->format()->backgroundColor() ? "<bgColor rgb=\""+ colorToXML(*k_condFormatting->format()->backgroundColor()) +"\"/>" : "")
                              <<        "</patternFill>"
                                    "</fill>";

                std::stringstream w_xmlBorder;
                for (unsigned short w_iBorder = 0; w_iBorder < 4; ++w_iBorder) {
                    const Interface::border_t k_border = static_cast<Interface::border_t>(w_iBorder);
                    if (k_condFormatting->format()->isBorderVisible(k_border)) {
                        const std::string k_markup = createStyles_BorderMarkup(k_border);

                        w_xmlBorder << "<" << k_markup;

                        if (*k_condFormatting->format()->isBorderVisible(k_border)) {
                            w_xmlBorder << " style=\"";
                            if (k_condFormatting->format()->borderStyle(k_border))
                                w_xmlBorder << createStyles_BorderStyleAttribute(*k_condFormatting->format()->borderStyle(k_border)) << "\"";
                            else
                                w_xmlBorder << "thin\"";

                            if (k_condFormatting->format()->borderColor(k_border)) {
                                w_xmlBorder <<  ">"
                                                    "<color rgb=\"" << colorToXML(*k_condFormatting->format()->borderColor(k_border)) << "\"/>"
                                                "</" << k_markup << ">";
                            } else
                                w_xmlBorder << "/>";
                        } else
                            w_xmlBorder << "/>";
                    }
                }
                if  (   (w_xmlBorder.str() != "")
                    &&  (k_condFormatting->format()->isBorderVisible(Interface::bLeft))
                    &&  (k_condFormatting->format()->isBorderVisible(Interface::bRight))
                    &&  (k_condFormatting->format()->isBorderVisible(Interface::bTop))
                    &&  (k_condFormatting->format()->isBorderVisible(Interface::bBottom))
                    )
                    w_xmlBorder << "<vertical/><horizontal/>";

                std::stringstream w_xmlDxf;
                w_xmlDxf << "<dxf>";
                if (w_xmlFont.str() != "")
                    w_xmlDxf << "<font>" << w_xmlFont.str() << "</font>";
                w_xmlDxf << w_xmlNumFormat.str();
                w_xmlDxf << w_xmlFill.str();
                if (w_xmlBorder.str() != "")
                    w_xmlDxf << "<border>" << w_xmlBorder.str() << "</border>";
                w_xmlDxf << "</dxf>";

                dxfs_t::const_iterator w_dxfsIndex = std::find(o_dxfs.begin(), o_dxfs.end(), w_xmlDxf.str());
                if (w_dxfsIndex == o_dxfs.end()) {
                    o_dxfs.push_back(w_xmlDxf.str());
                    w_dxfsIndex = o_dxfs.end()-1;
                }
                o_dxfsMap[k_condFormatting->format()] = w_dxfsIndex - o_dxfs.begin();
            }
        }
    }
}

std::istream* Writer::createStyles(const Interface::Read::Workbook* p_workbook, xfsMap_t& o_xfsMap, dxfsMap_t& o_dxfsMap)
{
    o_xfsMap.clear();

    std::stringstream* w_result = new std::stringstream;
    try {
        *w_result <<    "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                        "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">";

        fonts_t w_fonts;
        w_fonts.push_back( createStyles_DefaultFontToXML(p_workbook) );
//         w_fonts.push_back("<font><sz val=\"10\"/><name val=\"Arial\"/></font>");

        numFmts_t w_numFmts;

        fills_t w_fills;
        w_fills.push_back("<fill><patternFill patternType=\"none\"/></fill>");
        w_fills.push_back("<fill><patternFill patternType=\"gray125\"/></fill>");

        borders_t w_borders;
        w_borders.push_back("<border><left/><right/><top/><bottom/><diagonal/></border>");

        xfs_t w_xfs;
        w_xfs.push_back("<xf xfId=\"0\" fontId=\"0\" numFmtId=\"0\" fillId=\"0\" borderId=\"0\"/>");

        dxfs_t w_dxfs;

        if ((p_workbook) && (p_workbook->worksheetCount())) {
            createStyles_XfsInventory(p_workbook, o_xfsMap, w_xfs, w_fonts, w_numFmts, w_fills, w_borders);
            createStyles_DxfsInventory(p_workbook, o_dxfsMap, w_dxfs);

#if defined INVOKE_XLSX_LOGS
            const size_t k_log_fontCount = w_fonts.size();
            if (k_log_fontCount > (512 - 1))
                LOGS_MESSAGE("XLSX WARNING: " + std::to_string(k_log_fontCount) + " font types (Unique font types: 1,024 global fonts available for use; 512 per workbook)");

            const size_t k_log_fillCount = w_fills.size();
            if (k_log_fillCount > (256 - 2))
                LOGS_MESSAGE("XLSX WARNING: " + std::to_string(k_log_fillCount) + " fill styles (Fill styles: 256)");

            const size_t k_log_xfCount = w_xfs.size();
            if (k_log_xfCount > (64000 - 1))
                LOGS_MESSAGE("XLSX WARNING: " + std::to_string(k_log_xfCount) + " cell styles (Unique cell formats/cell styles: 64000)");
#endif

            *w_result << "<numFmts count=\"" << w_numFmts.size() << "\">";
            for (numFmts_t::const_iterator w_iNumFmt = w_numFmts.begin(); w_iNumFmt != w_numFmts.end(); ++w_iNumFmt) {
#if defined(_MSC_VER)
                *w_result << "<numFmt numFmtId=\"" << 164 + static_cast<unsigned int>(w_iNumFmt - w_numFmts.begin()) << "\" formatCode=\"" << *w_iNumFmt << "\"/>";
#else
                *w_result << "<numFmt numFmtId=\"" << 164 + w_iNumFmt - w_numFmts.begin() << "\" formatCode=\"" << *w_iNumFmt << "\"/>";
#endif
            }
            *w_result << "</numFmts>";

            *w_result << "<fonts count=\"" << w_fonts.size() << "\">";
            for (fonts_t::const_iterator w_it = w_fonts.begin(); w_it != w_fonts.end(); ++w_it)
                *w_result << *w_it;
            *w_result << "</fonts>";

            *w_result << "<fills count=\"" << w_fills.size() << "\">";
            for (fills_t::const_iterator w_it = w_fills.begin(); w_it != w_fills.end(); ++w_it)
                *w_result << *w_it;
            *w_result << "</fills>";

            *w_result << "<borders count=\"" << w_borders.size() << "\">";
            for (borders_t::const_iterator w_it = w_borders.begin(); w_it != w_borders.end(); ++w_it)
                *w_result << *w_it;
            *w_result << "</borders>";

            *w_result << "<cellStyleXfs count=\"1\">"
                            "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/>"
                         "</cellStyleXfs>";

            *w_result << "<cellXfs count=\"" << w_xfs.size() << "\">";
            for (xfs_t::const_iterator w_it = w_xfs.begin(); w_it != w_xfs.end(); ++w_it)
                *w_result << *w_it;
            *w_result << "</cellXfs>";

            if (w_dxfs.size()) {
                *w_result << "<dxfs count=\"" << w_dxfs.size() << "\">";
                for (dxfs_t::const_iterator w_it = w_dxfs.begin(); w_it != w_dxfs.end(); ++w_it)
                    *w_result << *w_it;
                *w_result << "</dxfs>";
            }
        }

        *w_result << "</styleSheet>";
    } catch (...) {
        delete w_result;
        throw;
    }

    return w_result;
}

void Writer::createSheet_CollapsedInventory(const Interface::Read::Worksheet* p_worksheet, unsigned int& o_iterator, unsigned short& o_maxOutlineLevel, Writer::collapsed_t& o_collapsed, Writer::columnRowType_t p_type)
{
    const unsigned short k_level =  (   (p_type == crtColumn)
                                    ?   p_worksheet->columnOutlineLevel(o_iterator)
                                    :   p_worksheet->rowOutlineLevel(o_iterator)
                                    );

    if (k_level) {
        if (k_level > o_maxOutlineLevel)
            o_maxOutlineLevel = k_level;

        unsigned int w_first = o_iterator;
        bool w_collapsed = false;
        bool w_continue = true;

        while (w_continue) {
            const unsigned short k_currentLevel =   (   (p_type == crtColumn)
                                                    ?   p_worksheet->columnOutlineLevel(o_iterator)
                                                    :   p_worksheet->rowOutlineLevel(o_iterator)
                                                    );
            if (k_currentLevel == k_level) {
                if ( (p_type == crtColumn) ? p_worksheet->isColumnCollapsed(o_iterator) : p_worksheet->isRowCollapsed(o_iterator) )
                    w_collapsed = true;
                ++o_iterator;
            } else if (k_currentLevel > k_level)
                createSheet_CollapsedInventory(p_worksheet, o_iterator, o_maxOutlineLevel, o_collapsed, p_type);
            else
                w_continue = false;
        }

        if (w_collapsed) {
            for (unsigned int w_iColumnRow = w_first; w_iColumnRow < o_iterator; ++w_iColumnRow)
                o_collapsed[w_iColumnRow] |= csHidden;
            if (  ((p_type == crtColumn) && (p_worksheet->outlineSummaryRight()))
               || ((p_type == crtRow) && (p_worksheet->outlineSummaryBelow()))
               )
                o_collapsed[o_iterator] |= csCollapsed;
            else if (w_first)
                o_collapsed[w_first-1] |= csCollapsed;
        }
    } else
        ++o_iterator;
}

void Writer::createSheet_Outlines(const Interface::Read::Worksheet* p_worksheet, unsigned short& o_maxColumnOutline, unsigned short& o_maxRowOutline, Writer::collapsed_t& o_collapsedColumns, Writer::collapsed_t& o_collapsedRows)
{
    o_maxColumnOutline = 0;
    o_maxRowOutline = 0;
    o_collapsedColumns.clear();
    o_collapsedRows.clear();

    if (!p_worksheet)
        return;

    unsigned int w_iColumn = p_worksheet->minBounds().left();
    while (w_iColumn <= p_worksheet->minBounds().right())
        createSheet_CollapsedInventory(p_worksheet, w_iColumn, o_maxColumnOutline, o_collapsedColumns, crtColumn);

    unsigned int w_iRow = p_worksheet->minBounds().top();
    while (w_iRow <= p_worksheet->minBounds().bottom())
        createSheet_CollapsedInventory(p_worksheet, w_iRow, o_maxRowOutline, o_collapsedRows, crtRow);
}

std::string Writer::createSheet_SheetViews(const Interface::Read::Worksheet* p_worksheet, bool p_selected)
{
    if (!p_worksheet)
        return "";

    std::stringstream w_result;

    w_result << "<sheetViews>";

    unsigned int w_xSplit;
    unsigned int w_ySplit;
    const bool k_xSplitExist = p_worksheet->getXSplit(w_xSplit);
    const bool k_ySplitExist = p_worksheet->getYSplit(w_ySplit);
    const std::string k_selected = (p_selected ? " tabSelected=\"1\"" : "");
    const std::string k_showFormulas = (p_worksheet->formulasShown() ? " showFormulas=\"1\"" : "");
    const std::string k_showGridLines = (p_worksheet->gridLinesShown() ? "": " showGridLines=\"0\"");
    const std::string k_showRowColHeaders = (p_worksheet->rowColHeadersShown() ? "": " showRowColHeaders=\"0\"");
    const std::string k_showZeros = (p_worksheet->zerosShown() ? "" : " showZeros=\"0\"");

    std::string w_selection = "";
    const Coordinates::Cell k_defaultActiveCell = Coordinates::Cell(p_worksheet, 0, 0);
    Coordinates::MultiCellRange w_defaultSelection = Coordinates::MultiCellRange();
    w_defaultSelection.addRange(k_defaultActiveCell);
    if (!(*p_worksheet->selection() == w_defaultSelection) || !(*p_worksheet->activeCell() == k_defaultActiveCell)) {
        w_selection = "<selection sqref=\""+ textToXMLAttribute(p_worksheet->selection()->name(p_worksheet, ' ')) +"\""+
                        " activeCell=\""+ textToXMLAttribute(p_worksheet->activeCell()->name(p_worksheet)) +"\"";

        if (p_worksheet->selection()->rangeCount() > 1) {
            const Coordinates::MultiCellRange* k_selection = p_worksheet->selection();
            const Coordinates::Cell* k_activeCell = p_worksheet->activeCell();
            const Coordinates::CellRange k_activeRange = Coordinates::CellRange(k_activeCell->worksheet(), k_activeCell->column(), k_activeCell->row(), k_activeCell->column(), k_activeCell->row());
            size_t w_activeCellId = k_selection->rangeCount() - 1;
            while ((w_activeCellId > 0) && (!k_selection->range(w_activeCellId)->intersectWith(k_activeRange)))
                --w_activeCellId;
            w_selection += " activeCellId=\""+ std::to_string(w_activeCellId) +"\"";
        }

        if (k_xSplitExist && !k_ySplitExist)
            w_selection += " pane=\"topRight\"";
        else if (!k_xSplitExist && k_ySplitExist)
            w_selection += " pane=\"bottomLeft\"";
        else if (k_xSplitExist && k_ySplitExist)
            w_selection += " pane=\"bottomRight\"";

        w_selection +=  "/>";
    }


    if (k_xSplitExist && !k_ySplitExist)
        w_result << "<sheetView workbookViewId=\"0\"" << k_showZeros << k_selected << k_showFormulas << k_showGridLines << k_showRowColHeaders << ">"
                        "<pane xSplit=\"" << w_xSplit+1 << "\" topLeftCell=\"" << textToXMLAttribute(Coordinates::Cell(nullptr, w_xSplit+1, 0).name()) << "\" activePane=\"topRight\" state=\"frozen\"" << k_selected << "/>"
                 <<     w_selection
                 << "</sheetView>";
    else if (!k_xSplitExist && k_ySplitExist)
        w_result << "<sheetView workbookViewId=\"0\"" << k_showZeros << k_selected << k_showFormulas << k_showGridLines << k_showRowColHeaders << ">"
                        "<pane ySplit=\"" << w_ySplit + 1 << "\" topLeftCell=\"" << textToXMLAttribute(Coordinates::Cell(nullptr, 0, w_ySplit + 1).name()) << "\" activePane=\"bottomLeft\" state=\"frozen\"" << k_selected << "/>"
                 <<     w_selection
                 << "</sheetView>";
    else if (k_xSplitExist && k_ySplitExist)
        w_result << "<sheetView workbookViewId=\"0\"" << k_showZeros << k_selected << k_showFormulas << k_showGridLines << k_showRowColHeaders << ">"
                        "<pane xSplit=\"" << w_xSplit + 1 << "\" ySplit=\"" << w_ySplit + 1 << "\" topLeftCell=\"" << textToXMLAttribute(Coordinates::Cell(nullptr, w_xSplit + 1, w_ySplit + 1).name()) << "\" activePane=\"bottomRight\" state=\"frozen\"" << k_selected << "/>"
                 <<     w_selection
                 << "</sheetView>";
    else if (w_selection != "")
        w_result << "<sheetView workbookViewId=\"0\"" << k_showZeros << k_selected << k_showFormulas << k_showGridLines << k_showRowColHeaders << ">"
                 <<     w_selection
                 << "</sheetView>";
    else
        w_result << "<sheetView workbookViewId=\"0\"" << k_showZeros << k_selected << k_showFormulas << k_showGridLines << k_showRowColHeaders << "/>";

    w_result << "</sheetViews>";

    return w_result.str();
}

typedef struct {
    unsigned int min;
    unsigned int max;
    std::string attributes;
} columnsAttributes_t;

std::string Writer::createSheet_Columns(const Interface::Read::Worksheet* p_worksheet, const xfsMap_t& p_xfsMap, const collapsed_t& p_collapsedColumns)
{
    if (!p_worksheet)
        return "";

    std::vector<columnsAttributes_t> w_columnsAttributes;

    for (unsigned int w_iColumn = p_worksheet->minBounds().left(); w_iColumn <= p_worksheet->minBounds().right()+1; ++w_iColumn) {
        unsigned char w_collapsedColumnInfos = 0;
        const collapsed_t::const_iterator k_index = p_collapsedColumns.find(w_iColumn);
        if (k_index != p_collapsedColumns.end())
            w_collapsedColumnInfos = k_index->second;

        std::stringstream w_attributes;
        w_attributes.imbue(std::locale::classic());

        bool w_isDefault = p_worksheet->isColumnDefault(w_iColumn);
        if (!w_isDefault)
            w_isDefault =   (   (p_worksheet->isColumnVisible(w_iColumn))
                            &&  (p_worksheet->columnWidth(w_iColumn) == p_worksheet->defaultColumnWidth())
                            &&  (p_worksheet->columnOutlineLevel(w_iColumn) == 0)
                            &&  (p_worksheet->isColumnCollapsed(w_iColumn) == false)
                            &&  (p_worksheet->columnCellFormat(w_iColumn) == nullptr)
                            );

        if  (   (!w_isDefault)
            ||  (w_collapsedColumnInfos)
            ) {
#if defined INVOKE_XLSX_LOGS
            const double k_log_columnWidth = p_worksheet->columnWidth(w_iColumn);
            if (k_log_columnWidth > 255)
                LOGS_MESSAGE("XLSX WARNING: " + std::to_string(k_log_columnWidth) + " characters (Column width: 255 characters)");
#endif

            const unsigned short k_outlineLevel = p_worksheet->columnOutlineLevel(w_iColumn);
            const double k_width = p_worksheet->columnWidth(w_iColumn);
            Interface::Read::CellFormat const * const k_format = p_worksheet->columnCellFormat(w_iColumn);

            if (k_outlineLevel > 0) {
                w_attributes << " outlineLevel=\"" << ((k_outlineLevel < 8) ? k_outlineLevel : 7) << "\"";
                if (w_collapsedColumnInfos & csHidden)
                    w_attributes << " width=\"0\" hidden=\"1\" customWidth=\"1\"";
                else if (k_width != p_worksheet->defaultColumnWidth())
                    w_attributes << " width=\"" << k_width << "\" customWidth=\"1\"";
                else
                    w_attributes << " width=\"" << p_worksheet->defaultColumnWidth() << "\"";
            } else {
                if ((k_width != p_worksheet->defaultColumnWidth()) || (w_collapsedColumnInfos & csCollapsed) || (k_format))
                    w_attributes << " width=\"" << k_width << "\" customWidth=\"1\"";
                if (!p_worksheet->isColumnVisible(w_iColumn))
                    w_attributes << " hidden=\"1\"";
            }

            if (w_collapsedColumnInfos & csCollapsed)
                w_attributes << " collapsed=\"1\"";

            if (k_format) {
                const xfsMap_t::const_iterator k_formatIndex = p_xfsMap.find(k_format);
                if (k_formatIndex != p_xfsMap.end())
                    w_attributes << " style=\"" << std::to_string(k_formatIndex->second) << "\"";
            }

            std::vector<columnsAttributes_t>::reverse_iterator w_last = w_columnsAttributes.rbegin();
            if ((w_last == w_columnsAttributes.rend()) || (w_last->attributes != w_attributes.str()) || (w_last->max != (w_iColumn+1))) {
                columnsAttributes_t w_newColumnsAttributes;
                w_newColumnsAttributes.min = w_iColumn;
                w_newColumnsAttributes.max = w_iColumn;
                w_newColumnsAttributes.attributes = w_attributes.str();
                w_columnsAttributes.push_back(w_newColumnsAttributes);
            } else
                w_last->max += 1;
        }
    }

    if (w_columnsAttributes.size() > 0) {
        std::stringstream w_result;

        w_result << "<cols>";
        for (std::vector<columnsAttributes_t>::const_iterator w_it = w_columnsAttributes.begin(); w_it != w_columnsAttributes.end(); ++w_it)
            w_result << "<col min=\"" << w_it->min + 1 << "\" max=\"" << w_it->max + 1 << "\"" << w_it->attributes << "/>";
        w_result << "</cols>";

        return w_result.str();
    }

    return "";
}

std::string Writer::createSheet_RowAttributes(const Interface::Read::Worksheet* p_worksheet, unsigned int p_rowIndex, const xfsMap_t& p_xfsMap, unsigned char p_collapsedRowInfo)
{
#if defined INVOKE_XLSX_LOGS
    const unsigned int k_log_rowHeight = static_cast<unsigned int>(p_worksheet->rowHeight(p_rowIndex));
    if (k_log_rowHeight > 409)
        LOGS_MESSAGE("XLSX WARNING: " + std::to_string(k_log_rowHeight) + " points (Row height: 409 points)");
#endif

    std::stringstream w_result;
    w_result.imbue(std::locale::classic());

    if (p_collapsedRowInfo & csHidden)
        w_result << " hidden=\"1\"";

    if (p_collapsedRowInfo & csCollapsed)
        w_result << " collapsed=\"1\"";

    const unsigned int k_height = static_cast<unsigned int>(p_worksheet->rowHeight(p_rowIndex));
    if (k_height != p_worksheet->defaultRowHeight())
        w_result << " ht=\"" << k_height << "\" customHeight=\"1\"";

    const bool k_visible = p_worksheet->isRowVisible(p_rowIndex);
    if (!(p_collapsedRowInfo & csHidden) && (!k_visible))
        w_result << " hidden=\"1\"";

    const unsigned short k_outlineLevel = p_worksheet->rowOutlineLevel(p_rowIndex);
    if (k_outlineLevel > 0)
        w_result << " outlineLevel=\"" << ((k_outlineLevel < 8) ? k_outlineLevel : 7) << "\"";

    Interface::Read::CellFormat const * const k_format = p_worksheet->rowCellFormat(p_rowIndex);
    if (k_format) {
        const xfsMap_t::const_iterator k_formatIndex = p_xfsMap.find(k_format);
        if (k_formatIndex != p_xfsMap.end())
            w_result << " customFormat=\"1\" s=\"" << std::to_string(k_formatIndex->second) << "\"";
    }

    return w_result.str();
}

std::string Writer::createSheet_MergeCells(const Interface::Read::Worksheet* p_worksheet)
{
    if  (   (!p_worksheet)
        ||  (!p_worksheet->mergeCount())
        )
        return "";

    std::stringstream w_result;

    w_result << "<mergeCells count=\"" << p_worksheet->mergeCount() << "\">";
    for (unsigned int w_iMerge = 0; w_iMerge < p_worksheet->mergeCount(); ++w_iMerge)
        w_result << "<mergeCell ref=\"" << textToXMLAttribute(p_worksheet->merge(w_iMerge)->name(p_worksheet)) << "\"/>";
    w_result << "</mergeCells>";

    return w_result.str();
}

std::string Writer::createSheet_ConditionalFormatting(const Interface::Read::Worksheet* p_worksheet, const dxfsMap_t& p_dxfsMap)
{
    if  (   (!p_worksheet)
        ||  (!p_worksheet->conditionalFormattingCount())
        )
        return "";

    std::stringstream w_result;

    unsigned int w_count = 0;
    for (unsigned int w_iConditionalFormatting = 0; w_iConditionalFormatting < p_worksheet->conditionalFormattingCount(); ++w_iConditionalFormatting) {
        const Interface::Read::ConditionalFormatting* k_conditionalFormatting = p_worksheet->conditionalFormatting(w_iConditionalFormatting);

        if  (k_conditionalFormatting->isValid()) {

            const std::string k_ref = k_conditionalFormatting->reference().name( k_conditionalFormatting->reference().range(0)->worksheet(), ' ' );
            Interface::Read::DifferentialCellFormat const * const k_format = k_conditionalFormatting->format();
            const dxfsMap_t::const_iterator k_formatIndex = p_dxfsMap.find(k_format);
            const std::string k_xmlStyle =  ( ((k_format) && (k_formatIndex != p_dxfsMap.end()) )
                                            ? " dxfId=\""+ std::to_string(k_formatIndex->second) +"\""
                                            : " dxfId=\"0\""
                                            );

            w_result << "<conditionalFormatting sqref=\"" << textToXMLAttribute(k_ref) << "\">"
                            "<cfRule priority=\"" << ++w_count << "\"" << k_xmlStyle << " type=\"expression\">"
                                "<formula>" << textToXML(k_conditionalFormatting->formula()) << "</formula>"
                            "</cfRule>"
                        "</conditionalFormatting>";
        }
    }

    return w_result.str();
}

std::string Writer::createSheet_Validations(const Interface::Read::Workbook* p_workbook, const Interface::Read::Worksheet* p_worksheet, const ListValidationParams& p_listValidationsParams, unsigned int& o_count)
{
    o_count = 0;
    if (!p_worksheet)
        return "";

    std::stringstream w_result;

    typedef std::unordered_map<std::string, Coordinates::MultiCellRange*> validationsMap_t;
    validationsMap_t w_validations;
    try {

        for (unsigned int w_iValidation = 0; w_iValidation < p_worksheet->validationCount(); ++w_iValidation) {
            Interface::Read::Validation const * const k_validation = p_worksheet->validation(w_iValidation);
            Interface::Read::CustomValidation const * const k_customValidation = dynamic_cast<const Interface::Read::CustomValidation*>(k_validation);
            Interface::Read::ListValidation const * const k_listValidation = dynamic_cast<const Interface::Read::ListValidation*>(k_validation);

            std::string w_type = "";
            Interface::utf8String_t w_formula = "";
            if (k_customValidation) {
                w_type = "custom";
                w_formula = k_customValidation->formula();
            }
            if (k_listValidation) {
                w_type = "list";

                if (k_listValidation->list()) {
                    ListValidationParams::listPositions_t const * const k_positions = p_listValidationsParams.positions();
                    const ListValidationParams::listPositions_t::const_iterator k_index =  k_positions->find(k_listValidation);

                    if (k_index != k_positions->end()) {
                        const unsigned int k_row = k_index->second;
                        w_formula = "'"+ p_listValidationsParams.name() +"'!"+ Coordinates::CellRange(nullptr, 0, k_row, static_cast<unsigned int>(k_listValidation->list()->size()-1), k_row, true).name();
                    }
                } else if (k_listValidation->rangeReference())
                    w_formula = k_listValidation->rangeReference()->name();
            }

            if ((k_validation->isValid()) && (w_type != "")) {
                std::string w_errorStyle = "";
                switch (k_validation->alertType()) {
                case Interface::atWarning:
                    w_errorStyle = "warning";
                    break;
                case Interface::atInformation:
                    w_errorStyle = "information";
                    break;
                default:
                    ;
                }

                std::stringstream w_params;
                w_params    <<  ((k_validation->isBlankAllowed()) ? " allowBlank=\"1\"" : "")
                            <<  ((k_validation->isPromptShown()) ? " showInputMessage=\"1\"" : "")
                            <<  ((k_validation->promptTitle() != "") ? " promptTitle=\""+ textToXMLAttribute(k_validation->promptTitle()) +"\"" : "")
                            <<  ((k_validation->promptMessage() != "") ? " prompt=\""+ textToXMLAttribute(k_validation->promptMessage()) +"\"" : "")
                            <<  ((k_validation->isAlertShown()) ? " showErrorMessage=\"1\"" : "")
                            <<  ((k_validation->alertTitle() != "") ? " errorTitle=\""+ textToXMLAttribute(k_validation->alertTitle()) +"\"" : "")
                            <<  ((k_validation->alertMessage() != "") ? " error=\""+ textToXMLAttribute(k_validation->alertMessage()) +"\"" : "")
                            <<  ((w_errorStyle != "") ? " errorStyle=\""+ w_errorStyle +"\"" : "")
                            <<  " type=\"" << w_type << "\""
                            <<  ">"
                            <<  "<formula1>" << textToXML(w_formula) << "</formula1>";

                validationsMap_t::const_iterator w_it = w_validations.find(w_params.str());
                if (w_it == w_validations.end()) {
                    Coordinates::MultiCellRange* w_ranges = new Coordinates::MultiCellRange(k_validation->reference());
                    w_validations.emplace(w_params.str(), w_ranges);
                } else
                    w_it->second->addRange(k_validation->reference());
            }
        }

        for (validationsMap_t::iterator w_it = w_validations.begin(); w_it != w_validations.end(); ++w_it) {
            w_it->second->reduce();

            std::string w_ref = w_it->second->name(p_worksheet, ' ');

            w_result    <<  "<dataValidation"
                        <<      " sqref=\"" << textToXMLAttribute(w_ref) << "\""
                        <<      w_it->first
                        <<  "</dataValidation>";

            ++o_count;
        }

        for (validationsMap_t::iterator w_it = w_validations.begin(); w_it != w_validations.end(); ++w_it)
            delete w_it->second;
    } catch (...) {
        for (validationsMap_t::iterator w_it = w_validations.begin(); w_it != w_validations.end(); ++w_it)
            delete w_it->second;
        throw;
    }

    return w_result.str();
}

std::string Writer::createSheet_Hyperlinks(const Interface::Read::Worksheet* p_worksheet, const relsMap_t& p_rels)
{
    if  (   (!p_worksheet)
        ||  (!p_worksheet->hyperlinkCount())
        )
        return "";

#if defined INVOKE_XLSX_LOGS
    const size_t k_log_hyperlinkCount = p_worksheet->hyperlinkCount();
    if (k_log_hyperlinkCount > 66530)
        LOGS_MESSAGE("XLSX WARNING: " + std::to_string(k_log_hyperlinkCount) + " hyperlinks (Hyperlinks in a worksheet: 66530 hyperlinks)");
#endif

    std::stringstream w_result;

    w_result << "<hyperlinks>";
    for (unsigned int w_iHyperlink = 0; w_iHyperlink < p_worksheet->hyperlinkCount(); ++w_iHyperlink) {
        Interface::Read::Hyperlink const * const k_hyperlink = p_worksheet->hyperlink(w_iHyperlink);

        if (k_hyperlink->isValid()) {
            Coordinates::CellRange k_reference = k_hyperlink->reference();

            std::string w_location;
            if (k_hyperlink->location())
                w_location = " location=\"" + k_hyperlink->location()->name() + "\"";
            else if (k_hyperlink->definedName())
                w_location = " location=\"" + k_hyperlink->definedName()->name() + "\"";
            else if (p_rels.find(k_hyperlink) != p_rels.end())
                w_location = " r:id=\"rId" + std::to_string(p_rels.at(k_hyperlink)) + "\"";

            std::string w_tooltip;
            if (k_hyperlink->tooltip() != "")
                w_tooltip = " tooltip=\"" + textToXMLAttribute(k_hyperlink->tooltip()) + "\"";

            std::string w_display;
            if (k_hyperlink->display() != "")
                w_display = " display=\"" + textToXMLAttribute(k_hyperlink->display()) + "\"";

            w_result    << "<hyperlink"
                        <<  " ref=\"" << k_reference.name(k_reference.worksheet()) << "\""
                        <<  w_location
                        <<  w_tooltip
                        <<  w_display
                        <<  "/>";
        }
    }
    w_result << "</hyperlinks>";

    return w_result.str();
}

std::string Writer::createSheet_Filters(const Interface::Read::Worksheet* p_worksheet)
{
    if (!p_worksheet)
        return "";

    if (!p_worksheet->filter())
        return "";

    std::stringstream w_result;

    w_result << "<autoFilter ref=\"" + p_worksheet->filter()->rangeReference()->name(p_worksheet) + "\">"
             << "</autoFilter>";

    return w_result.str();
}

std::istream* Writer::createSheet(const Interface::Read::Workbook* p_workbook, const Interface::Read::Worksheet* p_worksheet, unsigned int p_worksheetId, const sst_t& p_sst, const xfsMap_t& p_xfsMap, const dxfsMap_t& p_dxfsMap, const ListValidationParams& p_listValidationsParams, const relsMap_t& p_rels, bool p_selected)
{
    if (!p_worksheet)
        return nullptr;

    std::stringstream* w_result = new std::stringstream;
    try {
        *w_result <<    "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                        "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">"
                        "<sheetPr>"
                            "<outlinePr summaryBelow=\"" << ((p_worksheet->outlineSummaryBelow()) ? "1" : "0") << "\" summaryRight=\"" << ((p_worksheet->outlineSummaryRight()) ? "1" : "0") << "\"/>";

        if  (   (p_worksheet->pageSetting())
            &&  (   (   (p_worksheet->pageSetting()->fitToWidth() != 0)
                    ||  (p_worksheet->pageSetting()->fitToHeight() != 0)
                    )
                &&  !p_worksheet->pageSetting()->scale()
                )
            )
            *w_result << "<pageSetUpPr fitToPage=\"1\"/>";

        *w_result <<    "</sheetPr>"
                        "<dimension ref=\"" << p_worksheet->minBounds().name(p_worksheet) << "\"/>";

        *w_result << createSheet_SheetViews(p_worksheet, (p_selected && !p_worksheet->isHidden()));

        unsigned short w_maxColumnOutline = 0;
        unsigned short w_maxRowOutline = 0;
        collapsed_t w_collapsedColumns;
        collapsed_t w_collapsedRows;
        createSheet_Outlines(p_worksheet, w_maxColumnOutline, w_maxRowOutline, w_collapsedColumns, w_collapsedRows);

        *w_result   << "<sheetFormatPr"
                    << " baseColWidth=\"10\""
                    << ( p_worksheet->defaultColumnWidth() != 10 ? " defaultColWidth=\""+ std::to_string(p_worksheet->defaultColumnWidth()) +"\"" : "")
                    << " defaultRowHeight=\"" << p_worksheet->defaultRowHeight() << "\""
                    << ((w_maxColumnOutline) ? " outlineLevelCol=\""+ std::to_string( ((w_maxColumnOutline < 8) ? w_maxColumnOutline : 7) ) +"\"" : "")
                    << ((w_maxRowOutline) ? " outlineLevelRow=\""+ std::to_string( ((w_maxRowOutline < 8) ? w_maxRowOutline : 7) ) +"\"" : "")
                    << "/>";

        *w_result << createSheet_Columns(p_worksheet, p_xfsMap, w_collapsedColumns);

#if defined INVOKE_XLSX_LOGS
        const int k_log_rowCount = p_worksheet->minBounds().bottom() - p_worksheet->minBounds().top();
        if (k_log_rowCount > 1048576)
            LOGS_MESSAGE("XLSX WARNING: " + std::to_string(k_log_rowCount) + " rows (Total number of rows on a worksheet: 1048576 rows)");

        const int k_log_columnCount = p_worksheet->minBounds().right() - p_worksheet->minBounds().left();
        if (k_log_columnCount > 16384)
            LOGS_MESSAGE("XLSX WARNING: " + std::to_string(k_log_columnCount) + " columns (Total number of columns on a worksheet: 16384 columns)");
#endif

        *w_result << "<sheetData>";
        for (unsigned int w_iRow = p_worksheet->minBounds().top(); w_iRow <= p_worksheet->minBounds().bottom(); ++w_iRow) {
            bool w_rowWritten = false;

            unsigned char w_collapsedRowInfos = 0;
            const collapsed_t::const_iterator k_index = w_collapsedRows.find(w_iRow);
            if (k_index != w_collapsedRows.end())
                w_collapsedRowInfos = k_index->second;
            const std::string k_rowAttributes = createSheet_RowAttributes(p_worksheet, w_iRow, p_xfsMap, w_collapsedRowInfos);

            for (unsigned int w_iCol = p_worksheet->minBounds().left(); w_iCol <= p_worksheet->minBounds().right(); ++w_iCol) {
                Interface::Read::CellValue const * const k_cellValue = p_worksheet->cellValue(w_iCol, w_iRow);

                if (k_cellValue) {
                    if (!w_rowWritten) {
                        *w_result << "<row r=\"" << w_iRow+1 << "\"" << k_rowAttributes << ">";
                        w_rowWritten = true;
                    }

                    const std::string k_formula = ((k_cellValue->formula() != "") ? "<f>"+ textToXML( k_cellValue->formula() ) +"</f>" : "");

                    Interface::Read::CellFormat const * const k_format = p_worksheet->cellFormat(w_iCol, w_iRow);
                    const xfsMap_t::const_iterator k_formatIndex = p_xfsMap.find(k_format);
                    const std::string k_xmlStyle =  (   ( (k_format) && (k_formatIndex != p_xfsMap.end()) )
                                                    ?   " s=\""+ std::to_string(k_formatIndex->second) +"\""
                                                    :   " s=\"0\""
                                                    );

                    switch (k_cellValue->type()) {
                    case Interface::ctNull:
                        *w_result << "<c r=\"" << textToXMLAttribute(Coordinates::Cell(nullptr, w_iCol, w_iRow).name()) << "\"" << k_xmlStyle << ">"
                                        << k_formula <<
                                     "</c>";
                        break;

                    case Interface::ctBoolean:
                        *w_result << "<c r=\"" << textToXMLAttribute(Coordinates::Cell(nullptr, w_iCol, w_iRow).name()) << "\"" << k_xmlStyle << " t=\"b\">"
                                        << k_formula <<
                                        "<v>" << ((k_cellValue->boolean()) ? "1" : "0") << "</v>"
                                     "</c>";
                        break;

                    case Interface::ctNumber:
                        *w_result << "<c r=\"" << textToXMLAttribute(Coordinates::Cell(nullptr, w_iCol, w_iRow).name()) << "\"" << k_xmlStyle << ">"
                                        << k_formula <<
                                        "<v>" << doubleToString(k_cellValue->number()) << "</v>"
                                     "</c>";
                        break;

                    case Interface::ctString: 
                    case Interface::ctRichText: {
#if defined INVOKE_XLSX_LOGS
                        const std::string k_log_string = k_cellValue->string();
                        const size_t k_log_length = k_log_string.length();
                        if (k_log_length > 32767)
                            LOGS_MESSAGE("XLSX WARNING: " + Coordinates::Cell(nullptr, w_iCol, w_iRow).name() + " -> " + std::to_string(k_log_length) + " characters (Total number of characters that a cell can contain: 32,767 characters)");

                        const size_t k_log_lineFeeds = std::count(k_log_string.begin(), k_log_string.end(), '\n');
                        if (k_log_lineFeeds > 253)
                            LOGS_MESSAGE("XLSX WARNING: " + Coordinates::Cell(nullptr, w_iCol, w_iRow).name() + " -> " + std::to_string(k_log_lineFeeds) + " line feeds (Maximum number of line feeds per cell: 253)");
#endif
                        if (k_formula != "") {
                            *w_result << "<c r=\"" << textToXMLAttribute(Coordinates::Cell(nullptr, w_iCol, w_iRow).name()) << "\"" << k_xmlStyle << " t=\"str\">"
                                            << k_formula <<
                                            "<v>" << textToXML(k_cellValue->string()) << "</v>"
                                         "</c>";
                        } else {
                            size_t w_index = SSTIndex(p_sst, (void*)k_cellValue);
                            if (w_index == p_sst.size())
                                *w_result << "<c r=\"" << textToXMLAttribute(Coordinates::Cell(nullptr, w_iCol, w_iRow).name()) << "\"" << k_xmlStyle << " t=\"str\">"
                                                "<v>" << textToXML(k_cellValue->string()) << "</v>"
                                             "</c>";
                            else
                                *w_result << "<c r=\"" << textToXMLAttribute(Coordinates::Cell(nullptr, w_iCol, w_iRow).name()) << "\"" << k_xmlStyle << " t=\"s\">"
                                                "<v>" << w_index << "</v>"
                                             "</c>";
                        }
                        break;
                    }

                    case Interface::ctError:
                        *w_result << "<c r=\"" << textToXMLAttribute(Coordinates::Cell(nullptr, w_iCol, w_iRow).name()) << "\"" << k_xmlStyle << " t=\"e\">"
                                        << k_formula;

                        switch (k_cellValue->error()) {
                        case Interface::ceDIV0:
                            *w_result << "<v>#DIV/0!</v>";
                            break;
                        case Interface::ceNULL:
                            *w_result << "<v>#NULL!</v>";
                            break;
                        case Interface::ceVALUE:
                            *w_result << "<v>#VALUE!</v>";
                            break;
                        case Interface::ceREF:
                            *w_result << "<v>#REF!</v>";
                            break;
                        case Interface::ceNAME:
                            *w_result << "<v>#NAME?</v>";
                            break;
                        case Interface::ceNUM:
                            *w_result << "<v>#NUM!</v>";
                            break;
                        case Interface::ceNA:
                            *w_result << "<v>#N/A</v>";
                            break;
                        default:
                            *w_result << "<v></v>";
                            break;
                        }
                        *w_result << "</c>";
                        break;

                    }
                }
            }

            if (w_rowWritten)
                *w_result << "</row>";
            else if (!k_rowAttributes.empty())
                *w_result << "<row r=\"" << w_iRow+1 << "\"" << k_rowAttributes << "/>";
        }
        *w_result << "</sheetData>";

        *w_result << createSheet_Filters(p_worksheet);

        *w_result << createSheet_MergeCells(p_worksheet);

        *w_result << createSheet_ConditionalFormatting(p_worksheet, p_dxfsMap);

        unsigned int w_count = 0;
        const std::string k_validation = createSheet_Validations(p_workbook, p_worksheet, p_listValidationsParams, w_count);
        if (w_count) {
            *w_result   << "<dataValidations count=\"" << w_count << "\">"
                        <<  k_validation
                        << "</dataValidations>";
        }

        *w_result << createSheet_Hyperlinks(p_worksheet, p_rels);

        if  (   (p_worksheet->pageSetting())
            &&  (   (p_worksheet->pageSetting()->pageOrientation() != Interface::poDefault)
                ||  (   (   (p_worksheet->pageSetting()->fitToWidth() != 0)
                        ||  (p_worksheet->pageSetting()->fitToHeight() != 0)
                        )
                    &&  !p_worksheet->pageSetting()->scale()
                    )
                ||  p_worksheet->pageSetting()->scale()
                )
            ) {
            *w_result << "<pageSetup";
            if (!p_worksheet->pageSetting()->scale()) {
                if (p_worksheet->pageSetting()->fitToWidth() != 0)
                    *w_result << " fitToWidth=\"" << p_worksheet->pageSetting()->fitToWidth() << "\"";
                if (p_worksheet->pageSetting()->fitToHeight() != 0)
                    *w_result << " fitToHeight=\"" << p_worksheet->pageSetting()->fitToHeight() << "\"";
            } else
                *w_result << " scale=\"" << p_worksheet->pageSetting()->scale() << "\"";
            *w_result << " orientation=\"" << ((p_worksheet->pageSetting()->pageOrientation() == Interface::poPortrait) ? "portrait" : "landscape") << "\"";
            *w_result << "/>";
        }

        if  (   (p_worksheet->pageSetting())
            &&  (p_worksheet->pageSetting()->pageHeaderFooter())
            ) {
            Interface::Read::PageHeaderFooter const * const k_pageHeaderFooter = p_worksheet->pageSetting()->pageHeaderFooter();

            *w_result   << "<headerFooter"
                        << ((k_pageHeaderFooter->isDifferentOddEven()) ? " differentOddEven=\"1\"" : "")
                        << ((k_pageHeaderFooter->isDifferentFirst()) ? " differentFirst=\"1\"" : "")
                        << ">";

#if defined INVOKE_XLSX_LOGS
            const std::string k_log_header = k_pageHeaderFooter->leftHeader() + k_pageHeaderFooter->centerHeader() + k_pageHeaderFooter->rightHeader();
            const size_t k_log_headerLength = k_log_header.length();
            if (k_log_headerLength > 255)
                LOGS_MESSAGE("XLSX WARNING: " + std::to_string(k_log_headerLength) + " characters (Characters in a header: 255 characters)");

            const std::string k_log_footer = k_pageHeaderFooter->leftFooter() + k_pageHeaderFooter->centerFooter() + k_pageHeaderFooter->rightFooter();
            const size_t k_log_footerLength = k_log_footer.length();
            if (k_log_footerLength > 255)
                LOGS_MESSAGE("XLSX WARNING: " + std::to_string(k_log_footerLength) + " characters (Characters in a footer: 255 characters)");
#endif

            *w_result   << "<oddHeader>"
                        << ((k_pageHeaderFooter->leftHeader() != "") ? textToXML("&L"+ k_pageHeaderFooter->leftHeader()) : "")
                        << ((k_pageHeaderFooter->centerHeader() != "") ? textToXML("&C"+ k_pageHeaderFooter->centerHeader()) : "")
                        << ((k_pageHeaderFooter->rightHeader() != "") ? textToXML("&R"+ k_pageHeaderFooter->rightHeader()) : "")
                        << "</oddHeader>";
            *w_result   << "<oddFooter>"
                        << ((k_pageHeaderFooter->leftFooter() != "") ? textToXML("&L"+ k_pageHeaderFooter->leftFooter()) : "")
                        << ((k_pageHeaderFooter->centerFooter() != "") ? textToXML("&C"+ k_pageHeaderFooter->centerFooter()) : "")
                        << ((k_pageHeaderFooter->rightFooter() != "") ? textToXML("&R"+ k_pageHeaderFooter->rightFooter()) : "")
                        << "</oddFooter>";

            if (k_pageHeaderFooter->isDifferentOddEven()) {
                if ((k_pageHeaderFooter->leftEvenHeader()) || (k_pageHeaderFooter->centerEvenHeader()) || (k_pageHeaderFooter->rightEvenHeader())) {
                    *w_result   << "<evenHeader>"
                                << ((k_pageHeaderFooter->leftEvenHeader()) ? textToXML("&L"+ *k_pageHeaderFooter->leftEvenHeader()) : "")
                                << ((k_pageHeaderFooter->centerEvenHeader()) ? textToXML("&C"+ *k_pageHeaderFooter->centerEvenHeader()) : "")
                                << ((k_pageHeaderFooter->rightEvenHeader()) ? textToXML("&R"+ *k_pageHeaderFooter->rightEvenHeader()) : "")
                                << "</evenHeader>";
                }
                if ((k_pageHeaderFooter->leftEvenFooter()) || (k_pageHeaderFooter->centerEvenFooter()) || (k_pageHeaderFooter->rightEvenFooter())) {
                    *w_result   << "<evenFooter>"
                                << ((k_pageHeaderFooter->leftEvenFooter()) ? textToXML("&L"+ *k_pageHeaderFooter->leftEvenFooter()) : "")
                                << ((k_pageHeaderFooter->centerEvenFooter()) ? textToXML("&C"+ *k_pageHeaderFooter->centerEvenFooter()) : "")
                                << ((k_pageHeaderFooter->rightEvenFooter()) ? textToXML("&R"+ *k_pageHeaderFooter->rightEvenFooter()) : "")
                                << "</evenFooter>";
                }
            }

            if (k_pageHeaderFooter->isDifferentFirst()) {
                if ((k_pageHeaderFooter->leftFirstHeader()) || (k_pageHeaderFooter->centerFirstHeader()) || (k_pageHeaderFooter->rightFirstHeader())) {
                    *w_result   << "<firstHeader>"
                                << ((k_pageHeaderFooter->leftFirstHeader()) ? textToXML("&L"+ *k_pageHeaderFooter->leftFirstHeader()) : "")
                                << ((k_pageHeaderFooter->centerFirstHeader()) ? textToXML("&C"+ *k_pageHeaderFooter->centerFirstHeader()) : "")
                                << ((k_pageHeaderFooter->rightFirstHeader()) ? textToXML("&R"+ *k_pageHeaderFooter->rightFirstHeader()) : "")
                                << "</firstHeader>";
                }
                if ((k_pageHeaderFooter->leftFirstFooter()) || (k_pageHeaderFooter->centerFirstFooter()) || (k_pageHeaderFooter->rightFirstFooter())) {
                    *w_result   << "<firstFooter>"
                                << ((k_pageHeaderFooter->leftFirstFooter()) ? textToXML("&L"+ *k_pageHeaderFooter->leftFirstFooter()) : "")
                                << ((k_pageHeaderFooter->centerFirstFooter()) ? textToXML("&C"+ *k_pageHeaderFooter->centerFirstFooter()) : "")
                                << ((k_pageHeaderFooter->rightFirstFooter()) ? textToXML("&R"+ *k_pageHeaderFooter->rightFirstFooter()) : "")
                                << "</firstFooter>";
                }
            }

            *w_result << "</headerFooter>";
        }

        if (p_worksheet->containsValidImages())
            *w_result << "<drawing r:id=\"rId0\"/>";

        if (p_worksheet->commentCount() > 0)
            *w_result << "<legacyDrawing r:id=\"rId" << p_rels.at((void*)1) << "\"/>";

        *w_result << "</worksheet>";
    } catch (...) {
        delete w_result;
        throw;
    }

    return w_result;
}

Writer::ListValidationParams::ListValidationParams(const Interface::Read::Workbook* p_workbook)
:   m_workbook(p_workbook),
    m_isExist(false),
    m_name(""),
    m_id(0),
    m_positions(nullptr)
{
    if ((m_workbook) && (m_workbook->worksheetCount())) {
        unsigned int w_iWorksheet = 0;
        while   (   (!m_isExist)
                &&  (w_iWorksheet < m_workbook->worksheetCount())
                ) {
            Interface::Read::Worksheet const * const k_worksheet = m_workbook->worksheet(w_iWorksheet++);

            if (k_worksheet->validationCount()) {
                unsigned int w_iValidation = 0;
                while   (   (!m_isExist)
                        &&  (w_iValidation < k_worksheet->validationCount())
                        ) {
                    Interface::Read::ListValidation const * const k_listValidation = dynamic_cast<const Interface::Read::ListValidation*>(k_worksheet->validation(w_iValidation++));
                    m_isExist = (   (k_listValidation != nullptr)
                                &&  (k_listValidation->isValid())
                                &&  (k_listValidation->list())
                                );
                }
            }
        }
    }

    if (m_isExist) {
        m_positions = new listPositions_t();

        typedef std::unordered_map<unsigned long, unsigned int> unicity_t;
        unicity_t w_unicity;

        unsigned int w_row = 0;

        for (unsigned int w_iWorksheet = 0; w_iWorksheet < m_workbook->worksheetCount(); ++w_iWorksheet) {
            const Interface::Read::Worksheet* k_worksheet = m_workbook->worksheet(w_iWorksheet);

            for (unsigned int w_iValidation = 0; w_iValidation < k_worksheet->validationCount(); ++w_iValidation) {
                const Interface::Read::ListValidation* k_listValidation = dynamic_cast<const Interface::Read::ListValidation*>(k_worksheet->validation(w_iValidation));
                if  (   (k_listValidation)
                    &&  (k_listValidation->isValid())
                    &&  (k_listValidation->list())
                    ) {
                    const Interface::valueList_t* k_values = k_listValidation->list();

                    // hash....
                    std::string w_strKey = "|";
                    for (unsigned int w_iValue = 0; w_iValue < k_values->size(); ++w_iValue)
                        w_strKey += k_values->at(w_iValue) +"|";

                    unsigned long w_key = 5381;
                    for (std::string::const_iterator w_it = w_strKey.begin(); w_it != w_strKey.end(); ++w_it)
                        w_key = (w_key << 5) + w_key + *w_it;
                    // ........

                    const unicity_t::const_iterator k_index = w_unicity.find(w_key);
                    if (k_index == w_unicity.end()) {
                        w_unicity[w_key] = w_row;
                        (*m_positions)[k_listValidation] = w_row++;
                    } else
                        (*m_positions)[k_listValidation] = (*k_index).second;
                }
            }
        }

        m_name = m_workbook->checkWorksheetName("@lists");
        m_id = m_workbook->worksheetCount()+1;
    }
}

Writer::ListValidationParams::~ListValidationParams()
{
    delete m_positions;
}

bool Writer::ListValidationParams::isExist() const
{
    return m_isExist;
}

Interface::utf8String_t Writer::ListValidationParams::name() const
{
    return m_name;
}

size_t Writer::ListValidationParams::id() const
{
    return m_id;
}

const Writer::ListValidationParams::listPositions_t* Writer::ListValidationParams::positions() const
{
    return m_positions;
}

std::istream* Writer::createListValidationSheet(const Interface::Read::Workbook* p_workbook, const ListValidationParams& p_listValidationsParams, const sst_t& p_sst)
{
     ListValidationParams::listPositions_t const * const k_positions = p_listValidationsParams.positions();

    typedef std::vector<const Interface::Read::ListValidation*> validations_t;
    validations_t w_validations;

    for (ListValidationParams::listPositions_t::const_iterator w_it = k_positions->begin(); w_it != k_positions->end(); ++w_it) {
        while (w_validations.size() <= w_it->second)
            w_validations.push_back(nullptr);
        w_validations[w_it->second] = w_it->first;
    }

    std::stringstream w_datas;

    size_t w_column = 0;

    if ((p_workbook) && (p_workbook->worksheetCount())) {
        for (unsigned int w_iValidation = 0; w_iValidation < w_validations.size(); ++w_iValidation) {
            const Interface::valueList_t* k_values = (w_validations[w_iValidation])->list();

            w_datas << "<row r=\"" << w_iValidation+1 << "\">";
            if (k_values) {
                for (unsigned int w_iValue = 0; w_iValue < k_values->size(); ++w_iValue) {
                    size_t w_index = SSTIndex(p_sst, (void*)&(k_values->at(w_iValue).string()));
                    if (w_index == p_sst.size())
                        w_datas <<  "<c r=\"" << textToXMLAttribute(Coordinates::Cell(nullptr, w_iValue, w_iValidation).name()) << "\" s=\"0\" t=\"str\">"
                                        "<v>" << textToXML( k_values->at(w_iValue) ) << "</v>"
                                    "</c>";
                    else
                        w_datas <<  "<c r=\"" << textToXMLAttribute(Coordinates::Cell(nullptr, w_iValue, w_iValidation).name()) << "\" s=\"0\" t=\"s\">"
                                        "<v>" << w_index << "</v>"
                                    "</c>";
                }
            }
            w_datas << "</row>";

            if ((k_values) && (k_values->size() > w_column))
                w_column = k_values->size();
        }
    }

    const Coordinates::CellRange k_dimension = Coordinates::CellRange(nullptr, 0, 0, static_cast<unsigned int>(w_column-1), static_cast<unsigned int>(w_validations.size()-1));

    std::stringstream* w_result = new std::stringstream;
    try {
        *w_result <<    "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                        "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">"
                            "<sheetPr>"
                                "<outlinePr summaryBelow=\"1\" summaryRight=\"1\"/>"
                            "</sheetPr>"
                            "<dimension ref=\"" << textToXMLAttribute(k_dimension.name()) << "\"/>"
                            "<sheetViews>"
                                "<sheetView workbookViewId=\"0\"/>"
                            "</sheetViews>"
                            "<sheetFormatPr baseColWidth=\"10\" defaultRowHeight=\"15\"/>"
                            "<sheetData>" << w_datas.str() << "</sheetData>"
                            // mot de passe : "invoke"
                            "<sheetProtection selectUnlockedCells=\"1\" selectLockedCells=\"1\" scenarios=\"1\" objects=\"1\" sheet=\"1\" spinCount=\"100000\" saltValue=\"oYzWP56t3qmuvPlw7RSbdw==\" hashValue=\"oUIGkU59f9lhWD/kAZeKMfeYeK6mlfcefRmp6waDbOiYrE1HOBXrjPqH5oq/C9znU8aOIlxckW50TFAbqVn1Xg==\" algorithmName=\"SHA-512\"/>"
                        "</worksheet>";
    } catch (...) {
        delete w_result;
        throw;
    }

    return w_result;
}

std::istream* Writer::createNullSheet()
{
    std::stringstream* w_result = new std::stringstream;
    try {
        *w_result <<    "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
                        "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">"
                            "<sheetData/>"
                        "</worksheet>";
    } catch (...) {
        delete w_result;
        throw;
    }

    return w_result;
}

void Writer::save(const Interface::Read::Workbook* p_workbook, Zip::ZipArchiveWriter* o_zipWriter, time_t p_creationDate)
{
#if defined(INVOKE_XLSX_LOGS)
    try {

    LOGS_MESSAGE("**** scan ****");
    const Invoke::XLSX::SimpleWorkbook::SimpleWorkbook* w_log_simpleWorkbook = dynamic_cast<const Invoke::XLSX::SimpleWorkbook::SimpleWorkbook*>(p_workbook);
    if (w_log_simpleWorkbook) {
        w_log_simpleWorkbook->log_scan(Invoke::XLSX::Debug::Counter::get().container()); 
        Invoke::XLSX::Debug::Counter::get().log(); 
        Invoke::XLSX::Debug::Counter::get().clear();
    }
#endif

    LOGS_MESSAGE("**** save ****");
    LOGS_CHECKMEMORY;

    const ListValidationParams k_listValidationsParams(p_workbook);

    StreamWrapper w_streamWrapper;

    // [Content_Types].xml
    LOGS_STARTCHRONO("[Content_Types].xml");
    w_streamWrapper = createContentTypes(p_workbook, k_listValidationsParams);
    if (w_streamWrapper)
        o_zipWriter->addFromStream("[Content_Types].xml", *w_streamWrapper);
    LOGS_STOPCHRONO;
    LOGS_CHECKMEMORY;

    // _rels/.rels
    LOGS_STARTCHRONO("_rels/.rels");
    w_streamWrapper = createRels();
    if (w_streamWrapper)
        o_zipWriter->addFromStream("_rels/.rels", *w_streamWrapper);
    LOGS_STOPCHRONO;
    LOGS_CHECKMEMORY;

    // docProps/app.xml
    LOGS_STARTCHRONO("docProps/app.xml");
    w_streamWrapper = createApp(p_workbook, k_listValidationsParams);
    if (w_streamWrapper)
        o_zipWriter->addFromStream("docProps/app.xml", *w_streamWrapper);
    LOGS_STOPCHRONO;
    LOGS_CHECKMEMORY;

    // docProps/core.xml
    LOGS_STARTCHRONO("docProps/core.xml");
    w_streamWrapper = createCore(p_creationDate);
    if (w_streamWrapper)
        o_zipWriter->addFromStream("docProps/core.xml", *w_streamWrapper);
    LOGS_STOPCHRONO;
    LOGS_CHECKMEMORY;

    // xl/_rels/workbook.xml.rels
    LOGS_STARTCHRONO("xl/_rels/workbook.xml.rels");
    w_streamWrapper = createWorkbookRels(p_workbook, k_listValidationsParams);
    if (w_streamWrapper)
        o_zipWriter->addFromStream("xl/_rels/workbook.xml.rels", *w_streamWrapper);
    LOGS_STOPCHRONO;
    LOGS_CHECKMEMORY;

    // xl/workbook.xml
    LOGS_STARTCHRONO("xl/workbook.xml");
    w_streamWrapper = createWorkbook(p_workbook, k_listValidationsParams);
    if (w_streamWrapper)
        o_zipWriter->addFromStream("xl/workbook.xml", *w_streamWrapper);
    LOGS_STOPCHRONO;
    LOGS_CHECKMEMORY;

    // xl/sharedStrings.xml
    LOGS_STARTCHRONO("xl/sharedStrings.xml");
	sst_t w_sst;
    w_streamWrapper = createSharedStrings(p_workbook, w_sst);
    if (w_streamWrapper)
        o_zipWriter->addFromStream("xl/sharedStrings.xml", *w_streamWrapper);
    LOGS_STOPCHRONO;
    LOGS_CHECKMEMORY;

    // xl/styles.xml
    LOGS_STARTCHRONO("xl/styles.xml");
    xfsMap_t w_xfsMap;
    dxfsMap_t w_dxfsMap;
    w_streamWrapper = createStyles(p_workbook, w_xfsMap, w_dxfsMap);
    if (w_streamWrapper)
        o_zipWriter->addFromStream("xl/styles.xml", *w_streamWrapper);
    LOGS_STOPCHRONO;
    LOGS_CHECKMEMORY;

    // xl/media/imageX
    LOGS_STARTCHRONO("xl/media/imageX");
    imagesMap_t w_imagesMap;
    imagesInventory(p_workbook, w_imagesMap);
    saveImages(w_imagesMap, o_zipWriter);
    LOGS_STOPCHRONO;
    LOGS_CHECKMEMORY;

    if ((p_workbook) && (p_workbook->worksheetCount())) {
        const unsigned int k_index = getFirstVisibleSheetIndex(p_workbook);

        for (unsigned int w_iWorksheet = 0; w_iWorksheet < p_workbook->worksheetCount(); ++w_iWorksheet) {
            Interface::Read::Worksheet const * const k_worksheet = p_workbook->worksheet(w_iWorksheet);

            const std::string k_worksheetId = std::to_string(w_iWorksheet + 1);

            // xl/drawings/drawingX.xml
            LOGS_STARTCHRONO("xl/drawings/drawing" + k_worksheetId + ".xml");
            w_streamWrapper = createDrawing(k_worksheet, w_imagesMap);
            if (w_streamWrapper)
                o_zipWriter->addFromStream("xl/drawings/drawing"+ k_worksheetId +".xml", *w_streamWrapper);
            LOGS_STOPCHRONO;
            LOGS_CHECKMEMORY;

            // xl/drawings/_rels/drawingX.xml.rels
            LOGS_STARTCHRONO("xl/drawings/_rels/drawing" + k_worksheetId + ".xml.rels");
            w_streamWrapper = createDrawingRels(k_worksheet, w_imagesMap);
            if (w_streamWrapper)
                o_zipWriter->addFromStream("xl/drawings/_rels/drawing"+ k_worksheetId +".xml.rels", *w_streamWrapper);
            LOGS_STOPCHRONO;
            LOGS_CHECKMEMORY;

            // xl/commentsX.xml & xl/drawings/vmlDrawingX.vml
            LOGS_STARTCHRONO("xl/comments" + k_worksheetId + ".xml & xl/drawings/vmlDrawing" + k_worksheetId + ".vml");
            if (k_worksheet->commentCount() > 0) {
                w_streamWrapper = createComments(k_worksheet);
                if (w_streamWrapper)
                    o_zipWriter->addFromStream("xl/comments"+ k_worksheetId +".xml", *w_streamWrapper);
                w_streamWrapper = createVmlDrawing(k_worksheet, w_iWorksheet);
                if (w_streamWrapper)
                    o_zipWriter->addFromStream("xl/drawings/vmlDrawing"+ k_worksheetId +".vml", *w_streamWrapper);
            }
            LOGS_STOPCHRONO;
            LOGS_CHECKMEMORY;

            // xl/worksheets/_rels/sheetX.xml.rels
            LOGS_STARTCHRONO("xl/worksheets/_rels/sheet" + k_worksheetId + ".xml.rels");
            relsMap_t w_rels;
            w_streamWrapper = createWorksheetRels(k_worksheet, w_iWorksheet+1, w_rels);
            if (w_streamWrapper)
                o_zipWriter->addFromStream("xl/worksheets/_rels/sheet" + k_worksheetId + ".xml.rels", *w_streamWrapper);
            LOGS_STOPCHRONO;
            LOGS_CHECKMEMORY;

            // xl/worksheets/sheetX.xml
            LOGS_STARTCHRONO("xl/worksheets/sheet" + k_worksheetId + ".xml");
            w_streamWrapper = createSheet(p_workbook, k_worksheet, w_iWorksheet+1, w_sst, w_xfsMap, w_dxfsMap, k_listValidationsParams, w_rels, ((w_iWorksheet == k_index) && (w_iWorksheet)));
            if (w_streamWrapper)
                o_zipWriter->addFromStream("xl/worksheets/sheet" + k_worksheetId + ".xml", *w_streamWrapper);
            LOGS_STOPCHRONO;
            LOGS_CHECKMEMORY;
        }

        if (k_listValidationsParams.isExist()) {
            // xl/worksheets/sheetX.xml
            LOGS_STARTCHRONO("xl/worksheets/sheetList.xml");
            w_streamWrapper = createListValidationSheet(p_workbook, k_listValidationsParams, w_sst);
            if (w_streamWrapper)
                o_zipWriter->addFromStream("xl/worksheets/sheet" + std::to_string(k_listValidationsParams.id()) + ".xml", *w_streamWrapper);
            LOGS_STOPCHRONO;
            LOGS_CHECKMEMORY;
        }
    } else {
        // xl/worksheets/sheetNull.xml
        LOGS_STARTCHRONO("xl/worksheets/sheetNull.xml");
        w_streamWrapper = createNullSheet();
        if (w_streamWrapper)
            o_zipWriter->addFromStream("xl/worksheets/sheet1.xml", *w_streamWrapper);
        LOGS_STOPCHRONO;
        LOGS_CHECKMEMORY;
    }

#if defined(INVOKE_XLSX_LOGS)
    } catch (std::exception w_log_exception) {
        LOGS_MESSAGE("!!!! EXCEPTION : " + std::string(w_log_exception.what()) + " !!!!");
    } catch (...) {
        LOGS_MESSAGE("!!!! EXCEPTION : ???? !!!!");
    }
#endif
}

void Writer::save(const Interface::Read::Workbook* p_workbook, const std::string& p_filename, time_t p_creationDate)
{
// PROBLEME AVEC LES NOMS DE FICHIER CONTENANT DES CARACTERES UNICODE ------------------------
//     Zip::ZipArchiveWriter* w_zipWriter = Zip::createZipArchive(p_filename);
//     try {
//         save(p_workbook, w_zipWriter, p_creationDate);
//     } catch (...) {
//         delete w_zipWriter;
//         throw;
//     }
//     delete w_zipWriter;
// -------------------------------------------------------------------------------------------

    Zip::byte_t* w_memory = nullptr;
    unsigned int w_size = 0;
    try {
        save(p_workbook, w_memory, w_size, p_creationDate);

#if defined(_WIN32)
        int w_sizeNeeded = MultiByteToWideChar(CP_UTF8, 0, &p_filename[0], (int)p_filename.size(), nullptr, 0);
        std::wstring w_filename(w_sizeNeeded, 0);
        MultiByteToWideChar(CP_UTF8, 0, &p_filename[0], (int)p_filename.size(), &w_filename[0], w_sizeNeeded);
        std::ofstream w_file(w_filename, std::ofstream::binary);
#else
        std::ofstream w_file(p_filename, std::ofstream::binary);
#endif

        w_file.write(w_memory, w_size);
        w_file.close();

        free(w_memory);
    } catch (...) {
        free(w_memory);
        throw;
    }

}

void Writer::save(const Interface::Read::Workbook* p_workbook, std::ostream& o_zipStream, time_t p_creationDate)
{
    Zip::ZipArchiveWriter* w_zipWriter = Zip::createZipArchive(o_zipStream);
    try {
        save(p_workbook, w_zipWriter, p_creationDate);
    } catch (...) {
        delete w_zipWriter;
        throw;
    }
    delete w_zipWriter;
}

void Writer::save(const Interface::Read::Workbook* p_workbook, Zip::byte_t*& o_memory, unsigned int& o_size, time_t p_creationDate)
{
    Zip::ZipArchiveWriter* w_zipWriter = Zip::createZipArchive(o_memory, o_size);
    try {
        save(p_workbook, w_zipWriter, p_creationDate);
    } catch (...) {
        delete w_zipWriter;
        throw;
    }
    delete w_zipWriter;
}

} // namespace XLSX
} // namespace Invoke
